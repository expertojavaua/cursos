package es.ua.jtech.jdm.sesion20.agenda.vista;

import javax.microedition.lcdui.ChoiceGroup;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.List;

import es.ua.jtech.jdm.sesion20.agenda.modelo.Cita;
import es.ua.jtech.jdm.sesion20.agenda.modelo.Recursos;

public class ListaCitasUI extends List implements CommandListener {

	ControladorUI controlador;

	Cita [] citas;
	
	Command cmdSelec;
	Command cmdVolver;
	int eventoSelec = ControladorUI.EVENTO_MUESTRA_DATOS_CITA;
	int eventoVolver = ControladorUI.EVENTO_MUESTRA_MENU;
	
	public ListaCitasUI(ControladorUI controlador) {
		super(controlador.getString(Recursos.STR_LISTA_CITAS_TITULO), ChoiceGroup.IMPLICIT);
		
		this.controlador = controlador;
		
		cmdSelec = new Command(controlador.getString(Recursos.STR_CMD_SELECCIONAR), Command.OK, 1);
		cmdVolver = new Command(controlador.getString(Recursos.STR_CMD_VOLVER), Command.BACK, 1);
		this.addCommand(cmdSelec);
		this.addCommand(cmdVolver);
		
		this.setCommandListener(this);
	}

	private void setCitas(Cita [] citas) {

		this.citas = citas;		

		// Vacia la lista
		for(int i=this.size()-1; i>=0; i--) {
			this.delete(i);
		}

		// Agrega las nuevas citas
		for(int i=0;i<citas.length;i++) {
			this.append(citas[i].getAsunto(), null);
		}
	}
	
	private Cita getSelectedCita() {
		return citas[this.getSelectedIndex()];
	}
	
	public void reset(Cita [] citas, int eventoSelec, int eventoVolver) {
		this.setCitas(citas);
		this.eventoSelec = eventoSelec;
		this.eventoVolver = eventoVolver;
	}
	
	public void commandAction(Command cmd, Displayable disp) {
		if(cmd==cmdSelec || cmd==List.SELECT_COMMAND) {
			if(this.getSelectedIndex()>=0 && this.getSelectedIndex()<citas.length) {
				controlador.procesaEvento(eventoSelec, this.getSelectedCita());				
			}
		} else if(cmd==cmdVolver) {
			controlador.procesaEvento(eventoVolver, null);
		}
	}

}
