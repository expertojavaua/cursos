package es.ua.jtech.jdm.sesion20.agenda;

import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

import es.ua.jtech.jdm.sesion20.agenda.vista.ControladorUI;

public class MIDletAgenda extends MIDlet {

	ControladorUI controlador;

	protected void startApp() throws MIDletStateChangeException {
		controlador = new ControladorUI(this);
		controlador.showMenu();
	}

	protected void pauseApp() {
	}

	protected void destroyApp(boolean cond) throws MIDletStateChangeException {

		try {
			// Registra alarmas pendientes con push
			controlador.registraAlarmasPush();

			// Libera recursos del modelo
			controlador.destroy();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void salir() {
		try {
			destroyApp(true);
		} catch (MIDletStateChangeException e) {
		}
		notifyDestroyed();
	}
}