package es.ua.jtech.jdm.sesion20.agenda.vista;

import java.util.Calendar;

import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.StringItem;

import es.ua.jtech.jdm.sesion20.agenda.modelo.Cita;
import es.ua.jtech.jdm.sesion20.agenda.modelo.Recursos;

public class DatosCitaUI extends Form implements CommandListener {

	ControladorUI controlador;
	
	StringItem iFecha;
	StringItem iAsunto;
	StringItem iLugar;
	StringItem iContacto;
	StringItem iAlarma;
	
	Command cmdVolver;
	int eventoVolver;
	
	public DatosCitaUI(ControladorUI controlador) {
		super(controlador.getString(Recursos.STR_DATOS_TITULO));
		
		this.controlador = controlador;

		iFecha = new StringItem(controlador.getString(Recursos.STR_DATOS_ITEM_FECHA), "");
		iAsunto = new StringItem(controlador.getString(Recursos.STR_DATOS_ITEM_ASUNTO), "");
		iLugar = new StringItem(controlador.getString(Recursos.STR_DATOS_ITEM_LUGAR), "");
		iContacto = new StringItem(controlador.getString(Recursos.STR_DATOS_ITEM_CONTACTO), "");
		iAlarma = new StringItem(controlador.getString(Recursos.STR_DATOS_ITEM_ALARMA), "");
		
		this.append(iFecha);
		this.append(iAsunto);
		this.append(iLugar);
		this.append(iContacto);
		this.append(iAlarma);
		
		cmdVolver = new Command(controlador.getString(Recursos.STR_CMD_VOLVER), Command.BACK, 1);
		this.addCommand(cmdVolver);
		
		this.setCommandListener(this);
	}
	
	private void setCita(Cita cita) {
		
		Calendar cal = Calendar.getInstance();
		cal.setTime(cita.getFecha());
		String fecha = cal.get(Calendar.HOUR_OF_DAY) + ":" + 
						cal.get(Calendar.MINUTE) + " " + 
						cal.get(Calendar.DAY_OF_MONTH) + "/" + 
						cal.get(Calendar.MONTH) + "/" + 
						cal.get(Calendar.YEAR);
		
		iFecha.setText(fecha);
		iAsunto.setText(cita.getAsunto());
		iLugar.setText(cita.getLugar());
		iContacto.setText(cita.getContacto());
		if(cita.isAlarma()) {
			iAlarma.setText(controlador.getString(Recursos.STR_DATOS_ITEM_ALARMA_ON));					
		} else {
			iAlarma.setText(controlador.getString(Recursos.STR_DATOS_ITEM_ALARMA_OFF));					
		}
	}	
	
	public void reset(Cita cita, int eventoVolver) {
		this.setCita(cita);
		this.eventoVolver = eventoVolver;
	}	
	
	public void commandAction(Command cmd, Displayable disp) {
		if(cmd == cmdVolver) {
			controlador.procesaEvento(eventoVolver, null);
		}
	}
}
