package es.ua.jtech.jdm.sesion20.agenda.vista;

import java.io.IOException;

import javax.microedition.io.ConnectionNotFoundException;
import javax.microedition.io.PushRegistry;
import javax.microedition.lcdui.Alert;
import javax.microedition.lcdui.AlertType;
import javax.microedition.lcdui.Display;
import javax.microedition.rms.RecordStoreException;

import es.ua.jtech.jdm.sesion20.agenda.MIDletAgenda;
import es.ua.jtech.jdm.sesion20.agenda.modelo.Cita;
import es.ua.jtech.jdm.sesion20.agenda.modelo.FachadaModelo;
import es.ua.jtech.jdm.sesion20.agenda.modelo.GestorAlarmas;
import es.ua.jtech.jdm.sesion20.agenda.modelo.InfoLocal;
import es.ua.jtech.jdm.sesion20.agenda.modelo.Recursos;

public class ControladorUI {

	/*
	 * Tipos de eventos
	 */
	public final static int EVENTO_MUESTRA_MENU = 0;
	public final static int EVENTO_MUESTRA_NUEVA_CITA = 1;
	public final static int EVENTO_MUESTRA_LISTA_CITAS = 2;
	public final static int EVENTO_MUESTRA_DATOS_CITA = 3;
	public final static int EVENTO_MUESTRA_LISTA_ALARMAS_PENDIENTES = 4;
	public final static int EVENTO_MUESTRA_DATOS_ALARMA_PENDIENTE = 5;
	public final static int EVENTO_AGREGA_CITA = 6;
	public final static int EVENTO_PROGRAMA_ALARMAS = 7;
	public final static int EVENTO_SALIR = 8;
	public final static int EVENTO_SINCRONIZAR = 9;
	public final static int EVENTO_MUESTRA_CONFIG =10;
	public final static int EVENTO_APLICA_CONFIG = 11;

	/*
	 * Componentes de la UI
	 */
	DatosCitaUI uiDatosCita;
	EditaCitaUI uiEditaCita;
	ListaCitasUI uiListaCitas;
	EditaConfigUI uiEditaConfig;
	MenuPrincipalUI uiMenuPrincipal;
	BarraProgresoUI uiBarraProgreso;
	
	/*
	 * Gestor de recursos
	 */
	Recursos recursos;
	
	/*
	 * Modelo
	 */
	FachadaModelo modelo;
	
	/*
	 * Gestor de alarmas
	 */
	GestorAlarmas alarmas;
	
	MIDletAgenda midlet;
	Display display;
	
	public ControladorUI(MIDletAgenda midlet) {
		this.midlet = midlet;
		display = Display.getDisplay(midlet);
		
		init();
	}
	
	/*
	 * Inicializacion de los componentes de la UI
	 */
	public void init() {
		
		// Crea gestor de recursos
		recursos = new Recursos();

		// Crea UI
		uiDatosCita = new DatosCitaUI(this);
		uiEditaCita = new EditaCitaUI(this);
		uiListaCitas = new ListaCitasUI(this);
		uiEditaConfig = new EditaConfigUI(this);
		uiMenuPrincipal = new MenuPrincipalUI(this);
		uiBarraProgreso = new BarraProgresoUI(this);
		
		alarmas = new GestorAlarmas(this);
		
		try {
			// Crea modelo
			modelo = new FachadaModelo(alarmas);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		// Programa las alarmas pendientes
		this.procesaEvento(ControladorUI.EVENTO_PROGRAMA_ALARMAS, null);
	}
		
	public void destroy() throws RecordStoreException {
		modelo.destroy();
	}
	
	public void showMenu() {
		display.setCurrent(uiMenuPrincipal);
	}
		
	public String getString(int cod) {
		return recursos.getString(cod);
	}
	
	/*
	 * Lanza el procesamiento de un evento
	 */
	public void procesaEvento(int evento, Object param) {
		HiloEventos he = new HiloEventos(evento, param);
		he.start();
	}
	
	/*
	 * Hilo para el procesamiento de eventos
	 */
	class HiloEventos extends Thread {
		int evento;
		Object param;
		
		public HiloEventos(int evento, Object param) {
			this.evento = evento;
			this.param = param;
		}
		
		public void run() {
			Cita cita;
			Cita [] citas;
			InfoLocal info;
			
			try {
				switch(evento) {
					case EVENTO_MUESTRA_MENU:
						showMenu();
						break;
					case EVENTO_MUESTRA_NUEVA_CITA:
						uiEditaCita.reset(null, ControladorUI.EVENTO_AGREGA_CITA, ControladorUI.EVENTO_MUESTRA_MENU);
						display.setCurrent(uiEditaCita);		
						break;
					case EVENTO_AGREGA_CITA:
						cita = (Cita)param;
						modelo.nuevaCita(cita);
						showMenu();
						break;
					case EVENTO_MUESTRA_LISTA_CITAS:
						uiBarraProgreso.reset(getString(Recursos.STR_PROGRESO_CARGA_LISTA), 10, 0, true);
						display.setCurrent(uiBarraProgreso);
						citas = modelo.listaCitas();
						uiListaCitas.reset(citas, ControladorUI.EVENTO_MUESTRA_DATOS_CITA, ControladorUI.EVENTO_MUESTRA_MENU);
						display.setCurrent(uiListaCitas);
						break;
					case EVENTO_MUESTRA_DATOS_CITA:
						cita = (Cita)param;
						uiDatosCita.reset(cita, ControladorUI.EVENTO_MUESTRA_LISTA_CITAS);
						display.setCurrent(uiDatosCita);
						break;
					case EVENTO_MUESTRA_LISTA_ALARMAS_PENDIENTES:
						uiBarraProgreso.reset(getString(Recursos.STR_PROGRESO_CARGA_LISTA), 10, 0, true);
						display.setCurrent(uiBarraProgreso);
						citas = modelo.listaAlarmasPendientes();
						uiListaCitas.reset(citas, ControladorUI.EVENTO_MUESTRA_DATOS_ALARMA_PENDIENTE, ControladorUI.EVENTO_MUESTRA_MENU);
						display.setCurrent(uiListaCitas);
						break;
					case EVENTO_MUESTRA_DATOS_ALARMA_PENDIENTE:
						cita = (Cita)param;
						uiDatosCita.reset(cita, ControladorUI.EVENTO_MUESTRA_LISTA_ALARMAS_PENDIENTES);
						display.setCurrent(uiDatosCita);
						break;
					case EVENTO_PROGRAMA_ALARMAS:												
						citas = modelo.listaAlarmasPendientes();
						for(int i=0;i<citas.length;i++) {
							alarmas.programaAlarma(citas[i]);
						}
						break;
					case EVENTO_SINCRONIZAR:												
						uiBarraProgreso.reset(getString(Recursos.STR_PROGRESO_SINCRONIZA), 10, 0, true);
						display.setCurrent(uiBarraProgreso);
						modelo.sincroniza();
						display.setCurrent(uiMenuPrincipal);
						break;
					case EVENTO_MUESTRA_CONFIG:
						info = modelo.getConfig();
						uiEditaConfig.reset(info, ControladorUI.EVENTO_APLICA_CONFIG, ControladorUI.EVENTO_MUESTRA_MENU);
						display.setCurrent(uiEditaConfig);		
						break;
					case EVENTO_APLICA_CONFIG:
						info = (InfoLocal)param;
						modelo.updateConfig(info);
						display.setCurrent(uiMenuPrincipal);		
						break;
					case EVENTO_SALIR:												
						midlet.salir();
						break;
				}				
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	/*
	 * Registra las alarmas pendientes mediante push
	 */
	public void registraAlarmasPush() throws RecordStoreException, IOException, ConnectionNotFoundException, ClassNotFoundException {
		uiBarraProgreso.reset(getString(Recursos.STR_PROGRESO_CARGA_LISTA), 10, 0, true);
		display.setCurrent(uiBarraProgreso);

		Cita [] alarmas = modelo.listaAlarmasPendientes();
		if(alarmas!=null && alarmas.length>0) {
			long fechaAlarma = alarmas[0].getFecha().getTime();
			long delta = 10000;
			PushRegistry.registerAlarm("es.ua.jtech.ctj.sesion16.agenda.MIDletAgenda", fechaAlarma - delta);
		}

		uiBarraProgreso.stop();
	}

	/*
	 * Muestra una alerta cuando se dispara una alarma
	 */
	public void showAlert(Cita cita) {
		Alert a = new Alert(getString(Recursos.STR_ALARMA_TITULO), cita.getAsunto(), null, AlertType.ALARM);
		a.setTimeout(Alert.FOREVER);
		AlertType.ALARM.playSound(display);
		display.setCurrent(a, display.getCurrent());		
	}

}
