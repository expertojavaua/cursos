package es.ua.jtech.jdm.sesion20.agenda.modelo;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class InfoLocal {

	boolean online = false;

	long timeStamp = 0;

	public void serialize(DataOutputStream dos) throws IOException {
		dos.writeBoolean(online);
		dos.writeLong(timeStamp);
	}

	public static InfoLocal deserialize(DataInputStream dis) throws IOException {
		InfoLocal info = new InfoLocal();

		info.setOnline(dis.readBoolean());
		info.setTimeStamp(dis.readLong());

		return info;
	}

	public boolean isOnline() {
		return online;
	}

	public void setOnline(boolean online) {
		this.online = online;
	}

	public long getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(long timeStamp) {
		this.timeStamp = timeStamp;
	}
}