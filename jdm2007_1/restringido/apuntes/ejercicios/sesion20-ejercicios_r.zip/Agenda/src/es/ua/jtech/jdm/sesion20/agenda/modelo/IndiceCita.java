package es.ua.jtech.jdm.sesion20.agenda.modelo;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Date;

public class IndiceCita {

	// Identificador del registro en RMS (clave primaria)
	
	int rmsID;

	// Datos del indice
	
	int id;

	Date fecha;

	boolean alarma;

	boolean pendiente;

	public IndiceCita() {
	}

	public IndiceCita(int id, Date fecha, boolean alarma, boolean pendiente) {
		this.id = id;
		this.fecha = fecha;
		this.alarma = alarma;
		this.pendiente = pendiente;
	}

	public int getRmsID() {
		return rmsID;
	}

	public void setRmsID(int rmsID) {
		this.rmsID = rmsID;
	}

	public boolean isPendiente() {
		return pendiente;
	}

	public void setPendiente(boolean pendiente) {
		this.pendiente = pendiente;
	}

	public boolean isAlarma() {
		return alarma;
	}

	public void setAlarma(boolean alarma) {
		this.alarma = alarma;
	}

	public Date getFecha() {
		return fecha;
	}

	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void serialize(DataOutputStream dos) throws IOException {
		dos.writeInt(id);
		dos.writeLong(fecha.getTime());
		dos.writeBoolean(alarma);
		dos.writeBoolean(pendiente);
	}

	public static IndiceCita deserialize(DataInputStream dis)
			throws IOException {
		IndiceCita indice = new IndiceCita();

		indice.setId(dis.readInt());
		indice.setFecha(new Date(dis.readLong()));
		indice.setAlarma(dis.readBoolean());
		indice.setPendiente(dis.readBoolean());

		return indice;
	}

}