package es.ua.jtech.jdm.sesion20.mensajes.modelo;

import java.io.IOException;

import javax.microedition.rms.RecordStoreException;

public class ModeloLocal {

	AdaptadorRMS rms;

	public ModeloLocal() throws RecordStoreException {
		rms = new AdaptadorRMS();
	}

	/*
	 * Agrega un mensaje indicando si esta pendiente de ser enviado al servidor
	 */
	public void addMensaje(Mensaje msg, boolean pendiente) throws IOException,
			RecordStoreException {
		msg.setPendiente(pendiente);
		rms.addMensaje(msg);
	}

	/*
	 * Obtiene todos los mensajes
	 */
	public Mensaje[] listaMensajes() throws RecordStoreException, IOException {
		return rms.listaMensajes();
	}

	/*
	 * Busca los mensajes pendientes de ser enviados al servidor
	 */
	public Mensaje[] listaMensajesPendientes() throws RecordStoreException,
			IOException {
		Mensaje[] mensajes = rms.listaMensajesPendientes();

		return mensajes;
	}

	/*
	 * Marca los mensajes indicados como enviados al servidor
	 */
	public void marcaEnviados(Mensaje[] mensajes) throws IOException,
			RecordStoreException {
		for (int i = 0; i < mensajes.length; i++) {
			mensajes[i].setPendiente(false);
			rms.updateMensaje(mensajes[i]);
		}
	}

	/*
	 * Obtiene la configuracion local
	 */
	public InfoLocal getInfoLocal() throws RecordStoreException, IOException {

		try {
			InfoLocal info = rms.getInfoLocal();
			return info;
		} catch (Exception e) {
		}

		InfoLocal info = new InfoLocal();
		rms.setInfoLocal(info);

		return info;
	}

	/*
	 * Modifica la configuracion local
	 */
	public void setInfoLocal(InfoLocal info) throws RecordStoreException,
			IOException {
		rms.setInfoLocal(info);
	}

	/*
	 * Libera recursos del modelo
	 */
	public void destroy() throws RecordStoreException {
		rms.cerrar();
	}
}