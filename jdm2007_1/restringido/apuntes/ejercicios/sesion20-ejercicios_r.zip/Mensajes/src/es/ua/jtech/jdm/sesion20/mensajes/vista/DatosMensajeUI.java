package es.ua.jtech.jdm.sesion20.mensajes.vista;

import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.StringItem;

import es.ua.jtech.jdm.sesion20.mensajes.modelo.Mensaje;
import es.ua.jtech.jdm.sesion20.mensajes.modelo.Recursos;

public class DatosMensajeUI extends Form implements CommandListener {

	ControladorUI controlador;
	
	StringItem iAsunto;
	StringItem iTexto;
	
	Command cmdVolver;
	int eventoVolver;
	
	public DatosMensajeUI(ControladorUI controlador) {
		super(controlador.getString(Recursos.STR_DATOS_TITULO));
		
		this.controlador = controlador;

		iAsunto = new StringItem(controlador.getString(Recursos.STR_DATOS_ITEM_ASUNTO), "");
		iTexto = new StringItem(controlador.getString(Recursos.STR_DATOS_ITEM_TEXTO), "");
		
		this.append(iAsunto);
		this.append(iTexto);
		
		cmdVolver = new Command(controlador.getString(Recursos.STR_CMD_VOLVER), Command.BACK, 1);
		this.addCommand(cmdVolver);
		
		this.setCommandListener(this);
	}
	
	private void setMensaje(Mensaje mensaje) {
		
		iAsunto.setText(mensaje.getAsunto());
		iTexto.setText(mensaje.getTexto());
	}	
	
	public void reset(Mensaje mensaje, int eventoVolver) {
		this.setMensaje(mensaje);
		this.eventoVolver = eventoVolver;
	}	
	
	public void commandAction(Command cmd, Displayable disp) {
		if(cmd == cmdVolver) {
			controlador.procesaEvento(eventoVolver, null);
		}
	}
}
