package es.ua.jtech.jdm.sesion20.mensajes.modelo;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Vector;

import javax.microedition.rms.RecordEnumeration;
import javax.microedition.rms.RecordFilter;
import javax.microedition.rms.RecordStore;
import javax.microedition.rms.RecordStoreException;

public class AdaptadorRMS {

	// Nombres de los almacenes
	
	public final static String RS_DATOS = "rs_datos";

	public final static String RS_CONFIG = "rs_config";

	// Almacenes de registros
	
	RecordStore rsDatos;

	RecordStore rsConfig;

	public AdaptadorRMS() throws RecordStoreException {
		rsDatos = RecordStore.openRecordStore(RS_DATOS, true);
		rsConfig = RecordStore.openRecordStore(RS_CONFIG, true);
	}

	/*
	 * Obtiene los datos de configuracion local
	 */
	public InfoLocal getInfoLocal() throws RecordStoreException, IOException {
		byte[] datos = rsConfig.getRecord(1);

		ByteArrayInputStream bais = new ByteArrayInputStream(datos);
		DataInputStream dis = new DataInputStream(bais);

		return InfoLocal.deserialize(dis);
	}

	/*
	 * Guarda los datos de configuracion local
	 */
	public void setInfoLocal(InfoLocal info) throws RecordStoreException,
			IOException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(baos);

		info.serialize(dos);
		byte[] datos = baos.toByteArray();

		try {
			rsConfig.setRecord(1, datos, 0, datos.length);
		} catch (RecordStoreException e) {
			int id = rsConfig.addRecord(datos, 0, datos.length);
		}
	}

	/*
	 * Obtiene todos los mensajes
	 */
	public Mensaje[] listaMensajes() throws RecordStoreException, IOException {
		RecordEnumeration re = rsDatos.enumerateRecords(null, null, false);

		Vector mensajes = new Vector();

		while (re.hasNextElement()) {
			int id = re.nextRecordId();
			byte[] datos = rsDatos.getRecord(id);

			ByteArrayInputStream bais = new ByteArrayInputStream(datos);
			DataInputStream dis = new DataInputStream(bais);

			Mensaje msg = Mensaje.deserializeRMS(dis);
			msg.setRmsID(id);
			mensajes.addElement(msg);
		}

		Mensaje[] result = new Mensaje[mensajes.size()];
		mensajes.copyInto(result);

		return result;
	}

	/*
	 * Busca mensajes pendientes de ser enviados al servidor
	 */
	public Mensaje[] listaMensajesPendientes() throws RecordStoreException,
			IOException {
		RecordEnumeration re = rsDatos.enumerateRecords(new FiltroPendientes(
				true), null, false);

		Vector mensajes = new Vector();

		while (re.hasNextElement()) {
			int id = re.nextRecordId();
			byte[] datos = rsDatos.getRecord(id);

			ByteArrayInputStream bais = new ByteArrayInputStream(datos);
			DataInputStream dis = new DataInputStream(bais);

			Mensaje msg = Mensaje.deserializeRMS(dis);
			msg.setRmsID(id);
			mensajes.addElement(msg);
		}

		Mensaje[] result = new Mensaje[mensajes.size()];
		mensajes.copyInto(result);

		return result;
	}

	public int addMensaje(Mensaje msg) throws IOException, RecordStoreException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(baos);

		msg.serializeRMS(dos);
		byte[] datos = baos.toByteArray();

		int id = rsDatos.addRecord(datos, 0, datos.length);
		msg.setRmsID(id);
		return id;
	}

	public void updateMensaje(Mensaje msg) throws IOException, RecordStoreException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(baos);

		msg.serializeRMS(dos);
		byte[] datos = baos.toByteArray();

		rsDatos.setRecord(msg.getRmsID(), datos, 0, datos.length);
	}

	public void removeMensaje(int id) throws RecordStoreException {
		rsDatos.deleteRecord(id);
	}

	public Mensaje getMensaje(int id) throws RecordStoreException, IOException {
		byte[] datos = rsDatos.getRecord(id);

		ByteArrayInputStream bais = new ByteArrayInputStream(datos);
		DataInputStream dis = new DataInputStream(bais);

		Mensaje msg = Mensaje.deserializeRMS(dis);
		msg.setRmsID(id);

		return msg;
	}

	public void cerrar() throws RecordStoreException {
		rsDatos.closeRecordStore();
		rsConfig.closeRecordStore();
	}


	/*
	 * Filtra mensajes pendientes de ser enviados al servidor
	 */
	class FiltroPendientes implements RecordFilter {

		boolean pendiente;

		public FiltroPendientes(boolean pendiente) {
			this.pendiente = pendiente;
		}

		public boolean matches(byte[] datos) {

			try {
				ByteArrayInputStream bais = new ByteArrayInputStream(datos);
				DataInputStream dis = new DataInputStream(bais);
				Mensaje msg = Mensaje.deserializeRMS(dis);

				return msg.isPendiente();

			} catch (IOException e) {
				e.printStackTrace();
				return false;
			}

		}
	}


}