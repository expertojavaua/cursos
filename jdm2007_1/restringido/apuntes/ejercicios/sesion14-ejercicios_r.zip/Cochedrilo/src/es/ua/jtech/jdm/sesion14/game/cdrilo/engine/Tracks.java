/*
 * Created on 26/06/2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package es.ua.jtech.jdm.sesion14.game.cdrilo.engine;

import java.util.Vector;

import es.ua.jtech.jdm.sesion14.game.cdrilo.data.CommonData;
import es.ua.jtech.jdm.sesion14.game.cdrilo.data.StageData;
import es.ua.jtech.jdm.sesion14.game.cdrilo.data.TrackData;

/**
 * @author Miguel Angel
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Tracks {

	Track [] tracks;
	
	public Tracks() {		
	}
	
	public void reset(StageData stage) {
		TrackData [] trackData = stage.tracks;

		tracks = new Track[trackData.length];
		for(int i=0;i<tracks.length;i++) {
			tracks[i] = new Track(trackData[i].velocity, trackData[i].distance, trackData[i].carType);			
		}
	}
	
	public void checkTracks(Vector cars) {
		int y = CommonData.SPRITE_CAR_BASE_Y;
		
		for(int i=0;i<tracks.length;i++) {
		
			if(tracks[i].tick()) {
				int type = tracks[i].carType;
				int vel = tracks[i].velocity;
				
				CarSprite car = new CarSprite(type, -CommonData.SPRITE_CAR_WIDTH[type], y, vel);
				cars.addElement(car);
			}
			
			y += CommonData.SPRITE_CAR_STEP_Y;			
		}
	}
}
