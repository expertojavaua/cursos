/*
 * Created on 26/06/2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package es.ua.jtech.jdm.sesion14.game.cdrilo.engine;

import es.ua.jtech.jdm.sesion14.game.cdrilo.data.CommonData;

/**
 * @author Miguel Angel
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Track {

	public int gap;
	public byte velocity;
	public byte carType;

	public int nextCar; 
	
	public Track(byte velocity, int gap, byte carType) {
		this.gap = gap + CommonData.SPRITE_CAR_WIDTH[carType];
		this.velocity = velocity;
		this.carType = carType;
		
		this.nextCar = 0;
	}
	
	public boolean tick() {
		nextCar = nextCar - velocity;
		if(nextCar < 0) {
			nextCar += gap;
			return true;
		}
		return false;
	}
}
