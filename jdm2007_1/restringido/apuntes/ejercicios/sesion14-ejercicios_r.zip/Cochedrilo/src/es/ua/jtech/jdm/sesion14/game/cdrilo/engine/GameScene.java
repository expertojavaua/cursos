/*
 * Created on 25/06/2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package es.ua.jtech.jdm.sesion14.game.cdrilo.engine;

import java.util.Enumeration;
import java.util.Vector;

import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.game.GameCanvas;

import es.ua.jtech.jdm.sesion14.game.cdrilo.data.CommonData;
import es.ua.jtech.jdm.sesion14.game.cdrilo.data.Resources;
import es.ua.jtech.jdm.sesion14.game.cdrilo.data.StageData;

/**
 * @author Miguel Angel
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class GameScene implements Scene {

	public static int E_INICIO = 0;
	public static int E_JUGANDO = 1;
	public static int E_MUERTO = 2;
	public static int E_CONSEGUIDO = 3;
	
	int numLives;
	int state;
	int timer;
	int stage;
	
	CrocSprite croc;
	Background bg;
	Tracks tracks;
	Image face;
	
	Vector cars;
	
	public GameScene() {
		
		croc = new CrocSprite();
		bg = new Background();
		tracks = new Tracks();
		face = Resources.getImage(Resources.IMG_FACE_LIVES);
		
		cars = new Vector();
		
		reset();
	}
	
	// Reinicio de la partida
	public void reset() {
		numLives = CommonData.NUM_LIVES;
		stage = 0;

		reset(stage);
	}
	
	// Reinicio de una fase
	public void reset(int nStage) {
		StageData stage = Resources.stageData[nStage];
		croc.reset();
		bg.reset(stage);
		tracks.reset(stage);
		
		cars.removeAllElements();
		
		this.setState(E_INICIO);
	}
	
	public void setState(int state) {
		this.state = state;

		if(state==E_INICIO) {
			timer = 50;
		} else if(state==E_MUERTO) {
			timer = 30;
			croc.die();
		} else if(state==E_CONSEGUIDO) {
			timer = 50;
		}
	}
	
	public void tick(int keyState) {

		// Decrementa el tiempo de espera
		if(state==E_INICIO || state==E_MUERTO || state==E_CONSEGUIDO) {
			timer--;
		}

		// Comienza el juego
		if(state==E_INICIO && timer <= 0) {
			this.setState(E_JUGANDO);
		}
		
		// Reinicia el nivel o termina el juego
		if(state==E_MUERTO && timer <= 0) {
			numLives--;
			if(numLives<0) {
				Resources.midlet.showTitle();
			} else {
				this.reset(stage);
				return;
			}
		}
		
		if(state==E_CONSEGUIDO && timer <= 0) {
			stage++;
			if(stage >= Resources.stageData.length) {
				stage = 0;
			}

			this.reset(stage);
			return;
		}
		
		if(state==E_JUGANDO) {
			// Control del sprite
			if( (keyState & GameCanvas.UP_PRESSED)!=0 && croc.getY() > 0 ) {
				croc.moveUp();
			} else if( (keyState & GameCanvas.DOWN_PRESSED)!=0 && croc.getY() < CommonData.SCREEN_HEIGHT - CommonData.SPRITE_HEIGHT) {
				croc.moveDown();
			} else if( (keyState & GameCanvas.LEFT_PRESSED)!=0 && croc.getX() > 0) {
				croc.moveLeft();
			} else if( (keyState & GameCanvas.RIGHT_PRESSED)!=0 && croc.getX() < CommonData.SCREEN_WIDTH - CommonData.SPRITE_WIDTH) {
				croc.moveRight();
			} else {
				croc.stay();
			}			
		}
		
		// Crea nuevos coches en los carriles
		tracks.checkTracks(cars);

		// Actualiza coches y comprueba colisiones
		Enumeration enum = cars.elements();
		while(enum.hasMoreElements()) {
			CarSprite car = (CarSprite)enum.nextElement();
			car.tick();

			if(state == E_JUGANDO && car.collidesWith(croc, false)) {
				this.setState(E_MUERTO);
			}
		}
		
		if(state == E_JUGANDO && croc.getY()<CommonData.SPRITE_END_Y) {
			this.setState(E_CONSEGUIDO);
		}
		
		return;
	}

	public void render(Graphics g) {

		bg.paint(g);
		croc.paint(g);
		
		Enumeration enum = cars.elements();
		while(enum.hasMoreElements()) {
			CarSprite car = (CarSprite)enum.nextElement();
			car.paint(g);
		}	
		
		for(int i=0;i<this.numLives;i++) {
			g.drawImage(face, i*CommonData.FACE_WIDTH, 0, Graphics.TOP | Graphics.LEFT);
		}

		if(state==E_INICIO) {
			g.setFont(CommonData.STAGE_TITLE_FONT);
			g.setColor(CommonData.STAGE_TITLE_COLOR);
			g.drawString(Resources.stageData[stage].title, CommonData.STAGE_TITLE_X, CommonData.STAGE_TITLE_Y, Graphics.HCENTER | Graphics.TOP);			
		}

		if(state==E_CONSEGUIDO) {
			g.setFont(CommonData.STAGE_TITLE_FONT);
			g.setColor(CommonData.STAGE_TITLE_COLOR);
			g.drawString(CommonData.STAGE_COMPLETED_TEXT, CommonData.STAGE_TITLE_X, CommonData.STAGE_TITLE_Y, Graphics.HCENTER | Graphics.TOP);			
		}
	
	}

}
