/*
 * Created on 26/06/2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package es.ua.jtech.jdm.sesion14.game.cdrilo.engine;

import javax.microedition.lcdui.game.TiledLayer;

import es.ua.jtech.jdm.sesion14.game.cdrilo.data.CommonData;
import es.ua.jtech.jdm.sesion14.game.cdrilo.data.Resources;
import es.ua.jtech.jdm.sesion14.game.cdrilo.data.StageData;
import es.ua.jtech.jdm.sesion14.game.cdrilo.data.TrackData;

/**
 * @author Miguel Angel
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Background extends TiledLayer {

	public Background() {
		super(CommonData.BG_H_TILES, CommonData.BG_V_TILES, Resources.getImage(Resources.IMG_BG_STAGE_1), CommonData.BG_TILE_WIDTH, CommonData.BG_TILE_HEIGHT);		
	}

	public void reset(StageData stage) {
		TrackData [] tracks = stage.tracks;
		int nTracks = tracks.length;
				
		int row;
		
		// Filas superiores de cesped
		for(row=0;row<CommonData.BG_V_TOP_TILES;row++) {
			for(int col=0;col<CommonData.BG_H_TILES; col++) {
				this.setCell(col, row, CommonData.BG_TILE_GRASS);
			}
		}
		
		// Margen superior de la carretera
		for(int col=0;col<CommonData.BG_H_TILES; col++) {
			this.setCell(col, row, CommonData.BG_TILE_TOP);
		}
		row++;
		
		// Parte interna de la carreteta
		for(;row<CommonData.BG_V_TOP_TILES + nTracks - 1;row++) {
			for(int col=0;col<CommonData.BG_H_TILES; col++) {
				this.setCell(col, row, CommonData.BG_TILE_CENTER);
			}
		}

		// Margen inferior de la carretera
		for(int col=0;col<CommonData.BG_H_TILES; col++) {
			this.setCell(col, row, CommonData.BG_TILE_BOTTOM);
		}
		row++;
		
		// Hierba en la zona inferior
		for(;row<CommonData.BG_V_TILES;row++) {
			for(int col=0;col<CommonData.BG_H_TILES; col++) {
				this.setCell(col, row, CommonData.BG_TILE_GRASS);
			}
		}
		
	}
}
