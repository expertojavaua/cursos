package es.ua.jtech.jdm.sesion11.adivina;

import java.util.*;
import javax.microedition.lcdui.*;

public class EntradaTexto extends TextBox implements CommandListener {

	Command selec;

	AdivinaMIDlet owner;
	int intentos;
	int numero;

	public EntradaTexto(AdivinaMIDlet owner) {
		super("Introduzca un n�mero de 1 a 100", "", 3, TextField.NUMERIC);
		
		this.owner = owner;
		this.intentos = 0;
		
		// Genera numero aleatorio
		Random rand = new Random();
		this.numero = Math.abs(rand.nextInt()) % 100 + 1;
		
		// A�ade comandos
		selec = new Command("Seleccionar", Command.OK, 1);
		this.addCommand(selec);
		this.setCommandListener(this);
	}

	public void commandAction(Command c, Displayable d) {
		if(c == selec) {
			Display display = Display.getDisplay(owner);

			// Comprueba el n�mero introducido
			try {
				int entrada = Integer.parseInt(this.getString());
				this.setString("");

				if(entrada < 1 || entrada > 100) {
					display.setCurrent(new Alert("�Error!", "El n�mero debe estar entre 1 y 100", null, AlertType.INFO), this);					
				} else {
					this.intentos++;

					if(entrada < numero) {
						display.setCurrent(new Alert("Fallo!", "Ese n�mero es demasiado bajo", null, AlertType.INFO), this);									
					} else if(entrada > numero) {
						display.setCurrent(new Alert("Fallo!", "Ese n�mero es demasiado alto", null, AlertType.INFO), this);									
					} else {
						display.setCurrent(new Alert("�Enhorabuena!", "Ha acertado en " + intentos + " intento(s)", null, AlertType.INFO), new MenuPrincipal(owner));									
					}
				}
				
			} catch(NumberFormatException e) {
				this.setString("");
				display.setCurrent(new Alert("�Error!", "Eso no es un n�mero", null, AlertType.INFO), this);				
			}
		}
	}

}
