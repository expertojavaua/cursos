/*
 * GameEngine.java
 * Copyright (C) 2004 Miguel Angel Lozano
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package es.ua.jtech.jdm.sesion14.game.cdrilo.engine;

import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.game.GameCanvas;

import es.ua.jtech.jdm.sesion14.game.cdrilo.data.CommonData;
import es.ua.jtech.jdm.sesion14.game.cdrilo.data.Resources;

public class GameEngine extends GameCanvas implements Runnable {

	// Milisegundos que transcurren entre dos instantes / frames consecutivos
	public final static int CICLO = 50;

	public final static int LEFT_SOFTKEY = -6;
	public final static int RIGHT_SOFTKEY = -7;
	
	// Escena y estado actual (pantalla de titulo, juego, etc)
	Scene escena;
	
	// Estado de pausa
	boolean isPaused;

	// Hilo del juego
	Thread t;
	
	// Fuente pausa
	Font font;

	public GameEngine(Scene escena) {
		super(false);
		this.setFullScreenMode(true);

		// Establece la escena actual
		this.escena = escena;

		// Inicializa fuente para el texto de la pausa
		font = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_BOLD, Font.SIZE_MEDIUM);
	}

	public void setScene(Scene escena) {
		this.escena = escena;
	}
	
	public void showNotify() {
		start();
	}
	
	public void hideNotify() {
		stop();
	}

	public void keyPressed(int keyCode) {

		if(isPaused) {
			if(keyCode == LEFT_SOFTKEY) {
				start();
			} else if(keyCode == RIGHT_SOFTKEY) {
				Resources.midlet.exitGame();
			}
		} else {
			if(keyCode == LEFT_SOFTKEY || keyCode == RIGHT_SOFTKEY) {
				stop();
			}
		}
	}

	public synchronized void stop() {
		t = null; 

		isPaused = true;

		Graphics g = getGraphics();
		render(g);
		flushGraphics();
	}

	public synchronized void start() {
		isPaused = false;

		t = new Thread(this);
		t.start();		
	}

	public void run() {

		// Obtiene contexto gr�fico
		Graphics g = getGraphics();

		while (t == Thread.currentThread()) {

			long t_ini, t_dif;
			t_ini = System.currentTimeMillis();

			// Lee las teclas
			int keyState = this.getKeyStates();

			// Actualiza la escena

			escena.tick(keyState);

			render(g);
			flushGraphics();

			t_dif = System.currentTimeMillis() - t_ini;

			// Duerme hasta el siguiente frame

			if (t_dif < CICLO) {
				try {
					Thread.sleep(CICLO - t_dif);
				} catch (InterruptedException e) {
				}
			}
		}
	}

	public void render(Graphics g) {

		escena.render(g);
		
		if(isPaused) {
			g.setColor(0x000000);
			for(int i=0;i<CommonData.SCREEN_HEIGHT;i+=2) {
				g.drawLine(0,i,CommonData.SCREEN_WIDTH,i);
			}

			g.setColor(0x0FFFF00);
			g.setFont(font);
			g.drawString("Reanudar", 0, CommonData.SCREEN_HEIGHT, Graphics.LEFT | Graphics.BOTTOM);
			g.drawString("Salir", CommonData.SCREEN_WIDTH, CommonData.SCREEN_HEIGHT, Graphics.RIGHT | Graphics.BOTTOM);
			g.drawString("PAUSADO", CommonData.SCREEN_WIDTH/2, CommonData.SCREEN_HEIGHT/2, Graphics.HCENTER | Graphics.BOTTOM);
		}

	}
}
