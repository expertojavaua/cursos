/*
 * SplashScreen.java
 * Copyright (C) 2004 Miguel Angel Lozano
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package es.ua.jtech.jdm.sesion14.game.panj.engine;

import java.io.IOException;

import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

import es.ua.jtech.jdm.sesion14.game.panj.data.Resources;

/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class SplashScreen extends Canvas implements Runnable {

	private final static int LOGO_Y = 20;
	private final static int TEXT_Y = 70;	
	
	int logoX;
	int logoY;

	int textX;
	int textY;
	int textSep;

	Image logo;
	Font font;

	String[] lineasTexto =
		{
			"2004 (c) Miguel Angel Lozano",
			"malozano@dccia.ua.es",
			"",
			"Juego exclusivo para alumnos",
			"del curso de Programacion de",
			"dispositivos moviles. Mas ",
			"informacion en:",
			"",
			"www.j2ee.ua.es/pdm" };

	public SplashScreen() {
		
		this.setFullScreenMode(true);
		
		logo = Resources.splashImage;

		logoX = this.getWidth() / 2;
		logoY = LOGO_Y;

		textX = this.getWidth() / 2;
		textY = TEXT_Y;

		font =
			Font.getFont(Font.FACE_SYSTEM, Font.STYLE_PLAIN, Font.SIZE_SMALL);

		textSep = font.getHeight();
	}

	protected void paint(Graphics g) {

		// Dibuja el logo
		g.setColor(0x0000000);
		g.fillRect(0, 0, this.getWidth(), this.getHeight());
		g.drawImage(logo, logoX, logoY, Graphics.HCENTER | Graphics.TOP);

		// Escribe el texto
		g.setColor(0x0FFFFFF);
		g.setFont(font);
		for (int i = 0; i < lineasTexto.length; i++) {
			g.drawString(
				lineasTexto[i],
				textX,
				textY + i * textSep,
				Graphics.TOP | Graphics.HCENTER);
		}
	}

	public void run() {
		try {
			Resources.init();
			Resources.midlet.showTitle();
		} catch(IOException e) {
			Resources.midlet.showError("Error al cargar recursos");
		}
		
	}
}