/*
 * GameScene.java
 * Copyright (C) 2004 Miguel Angel Lozano
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package es.ua.jtech.jdm.sesion14.game.panj.engine;
import java.util.Vector;

import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.game.GameCanvas;

import es.ua.jtech.jdm.sesion14.game.panj.data.*;

public class GameScene implements Scene
{
	// Posibles estados dentro de la fase
	public static final int E_JUGANDO = 0;
	public static final int E_INICIO = 1;
	public static final int E_MURIENDO = 2;
	public static final int E_COMPLETADO = 3;

	// Sprites del juego
	Vector bolas;
	GuySprite pers;
	RaySprite rayo;
	Background escenario;
	Image face;

	// Datos y estado de la fase
	int state;
	int timer;
	int stage;
	int numLives;

	String stageName;
	boolean dibujar_nombre;
	boolean hay_rayo;
	
	public GameScene() {

		// Construye las bolas necesarias para la fase
		bolas = new Vector();
		
		// Construye los sprites del personaje y del rayo
		pers = new GuySprite();
		rayo = new RaySprite();
		face = Resources.img[Resources.IMG_CARA];
		escenario = new Background();
		
		reset();
	}
	
	public void reset() {
		stage = 0;
		numLives = CommonData.NUM_LIVES;
		
		reset(0);
	}
	
	public void reset(int stage) {
		StageData sd = Resources.stageData[stage];

		// Inicializa nombre y fondo de la fase
		stageName = sd.name;
		escenario.reset(sd.imgBackground);

		// Inicializa vector de bolas de la fase
		
		bolas.removeAllElements();
		
		BallSprite bola = null;

		for(int i=0;i<sd.ballsNumber;i++) {
			BallData ballData = sd.balls[i];

			bola = new BallSprite(ballData.size, ballData.color, ballData.vx);
			bola.setPosition(ballData.x, CommonData.BALL_BASE - bola.getHeight() - CommonData.BALL_ARC[bola.altura]);
			bolas.addElement(bola);
		}	
		
		// Fija el estado inicial del juego
		pers.reset();
		hay_rayo = false;
		setState(E_INICIO);
	}
	
	public void setState(int state) {
		this.state = state;
		if(state==E_INICIO) {
			timer = 50;
		} else if(state==E_MURIENDO) {
			timer = 20;
			pers.die();
		} else if(state==E_COMPLETADO) {
			stage++;
			if(stage>=Resources.stageData.length) {
				stage = 0;
			}
			this.reset(stage);
		}
	}
	
	public void tick(int keyState) {

		// Estado iniciando la fase (muestra el nombre de la fase)
		if(state == E_INICIO) {
			timer--;
			
			if(timer<=0) {
				this.setState(E_JUGANDO);
			}
			
			return;
		}

		// Estado muriendo el personaje (el personaje cae muerto)
		if(state == E_MURIENDO) {
			timer--;

			if(timer<0) {
				numLives--;
				if(numLives<0) {
					Resources.midlet.showTitle();
					return;
				} else {
					reset(stage);
					return;
				}
			}

			pers.setPosition(pers.getX() + CommonData.DIE_X_INCR, CommonData.SPRITE_INI_Y - CommonData.DIE_ARC[timer]);
		}


		if(state == E_JUGANDO) {
			// Entrada del teclado (movimiento del personaje y disparos)

			if ( (keyState & GameCanvas.RIGHT_PRESSED)!=0 && pers.getX() < CommonData.SCREEN_WIDTH - CommonData.SPRITE_WIDTH) {
				pers.stepRight();
			} else if ( (keyState & GameCanvas.LEFT_PRESSED)!=0 && pers.getX() > 0) {
				pers.stepLeft();
			} else {
				pers.stay();
			}			

			if( !hay_rayo && (keyState & GameCanvas.FIRE_PRESSED)!=0 ) {
				rayo.reset(pers.getX());
				hay_rayo = true;
				pers.stay();
			}

		}

		// Actualiza el rayo
		if(hay_rayo) {
			rayo.tick();
			if(rayo.getY() < CommonData.RAY_MAX) {
				hay_rayo = false;
			}
		}

		// Movimiento y colisiones de las bolas

		BallSprite bola = null;

		for(int i=0;i<bolas.size();i++) {
			bola = (BallSprite) bolas.elementAt(i);

			// Actualiza la posicion de la bola
			
			bola.tick();
			
			// Colision con el personaje

			if(state==E_JUGANDO && bola.collidesWith(pers,false)) {
				this.setState(E_MURIENDO);
			}

			// Colision con el rayo

			if(state==E_JUGANDO && hay_rayo) {
				if(bola.collidesWith(rayo,false)) {
					if(bola.desc1 != null && bola.desc2 != null) {
						int n_x = bola.getX();
						int n_y = bola.getY();

						bola.desc1.setPosition(n_x, n_y);
						bola.desc2.setPosition(n_x, n_y);

						bola.desc1.vy = bola.vy;
						bola.desc2.vy = bola.vy;
						
						bola.desc1.altura = bola.altura;
						bola.desc2.altura = bola.altura;

						bola.desc1.sube = true;
						bola.desc2.sube = true;

						bolas.addElement(bola.desc1);
						bolas.addElement(bola.desc2);
						
					}

					// Elimina la bola
					
					bolas.removeElement(bola);
					hay_rayo = false;
					i--;

					// Si no quedan bolas, nivel completado
					
					if(bolas.size() == 0) {
						this.setState(E_COMPLETADO);
					}
				}
			}
		}
	}

	public void render(Graphics g) {
		// Dibuja el escenario
		escenario.render(g);

		// Dibuja el rayo si lo hubiese
		if(hay_rayo) {
			g.setClip(rayo.getX(), rayo.getY(), rayo.getWidth(), CommonData.BALL_BASE - rayo.getY());
			rayo.paint(g);
			g.setClip(0,0,CommonData.SCREEN_WIDTH, CommonData.SCREEN_HEIGHT);
		}

		// Dibuja el personaje
		pers.paint(g);

		// Dibuja las bolas
		for(int i=0;i<bolas.size();i++) {
			((BallSprite)bolas.elementAt(i)).paint(g);
		}

		// Dibuja el nombre de la fase durante el inicio
		if(state == E_INICIO) {
			g.setColor(CommonData.STAGE_TITLE_COLOR);
			g.setFont(CommonData.STAGE_TITLE_FONT);
			g.drawString(stageName, CommonData.STAGE_TITLE_X, CommonData.STAGE_TITLE_Y, Graphics.HCENTER | Graphics.TOP);
		}
		
		// Dibuja el contador de vidas
		for(int i=0;i<numLives;i++) {
			g.drawImage(face, i*CommonData.FACE_WIDTH, 0, Graphics.LEFT | Graphics.TOP);
		}


	}
}