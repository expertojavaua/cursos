/*
 * CommonData.java
 * Copyright (C) 2004 Miguel Angel Lozano
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package es.ua.jtech.jdm.sesion14.game.panj.data;

import javax.microedition.lcdui.Font;

/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class CommonData {

	// Numero de vidas total
	public static final int NUM_LIVES = 3;
	
	// Ruta de la imagen del titulo
	public final static int [][] RUTA_TITULO = { 
		{ 88, 20 },
		{ 86, 21 },
		{ 82, 23 },
		{ 82, 25 },
		{ 86, 26 },
		{ 88, 26 },
		{ 90, 25 },
		{ 94, 23 },
		{ 94, 21 },
		{ 90, 20 }
	};

	// Ruta y posicion de las bolas
	public final static int[] BALL_ARC =
		{
			0,
			17,
			34,
			49,
			64,
			78,
			91,
			103,
			115,
			125,
			135,
			143,
			151,
			157,
			163,
			168,
			172,
			175,
			178,
			179,
			180 };
	public final static int BALL_MAX_HEIGHT = BALL_ARC.length - 1;
	public final static int BALL_BASE = 198;


	// Ruta trazada por el esqueleto al morir
	public final static int DIE_X_INCR = 4;
	public final static int[] DIE_ARC =
		{
			0,
			7,
			14,
			20,
			25,
			30,
			33,
			36,
			38,
			39,
			40,
			39,
			38,
			36,
			33,
			29,
			25,
			20,
			14,
			7 };

	// Dimensiones de la pantalla
	public final static int SCREEN_WIDTH = 176;
	public final static int SCREEN_HEIGHT = 208;

	// Datos del sprite del personaje
	public final static int SPRITE_WIDTH = 25;
	public final static int SPRITE_HEIGHT = 38;
	public final static int SPRITE_STEP = 4;
	public final static int SPRITE_INI_X = 75;
	public final static int SPRITE_INI_Y = 160;

	// Indices de los frames del sprite y secuencias de animacion
	public final static int SPRITE_STAY = 0; 
	public final static int [] SPRITE_MOVE_LEFT = { 1, 2 }; 
	public final static int [] SPRITE_MOVE_RIGHT = { 3, 4 }; 
	public final static int SPRITE_DIE = 5; 
	
	// Datos de los sprites de las bolas
	public final static int[] BALL_SIZE = { 5, 10, 20, 40 };

	// Datos de la image de la cara para el contador de vidas
	public final static int FACE_WIDTH = 15;
	public final static int FACE_HEIGHT = 15;

	// Datos del sprite del rayo
	public final static int RAY_WIDTH = 10;
	public final static int RAY_HEIGHT = 215;
	public final static int RAY_BASE = 170;
	public final static int RAY_MAX = -25;
	public final static int RAY_INCR = -8;	
	public final static int RAY_SPRITE_OFFSET = 6;		
	public final static int RAY_NUM_FRAMES = 3;
	
	// Datos del texto de titulo de fase
	public final static int STAGE_TITLE_X = 88;	
	public final static int STAGE_TITLE_Y = 100;	
	public static final int STAGE_TITLE_COLOR = 0x0FFFF00;
	public static final Font STAGE_TITLE_FONT = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_BOLD, Font.SIZE_SMALL);

	// Datos del texto de la pantalla de titulo
	public static final int GAME_START_X = 88;
	public static final int GAME_START_Y = 150;
	public static final String GAME_START_TEXT = "PULSA START PARA COMENZAR";
	public static final int GAME_START_COLOR = 0x0FFFF00;
	public static final Font GAME_START_FONT = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_BOLD, Font.SIZE_SMALL);

}
