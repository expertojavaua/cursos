package es.ua.jtech.sesion04;

import java.io.*;

public class Ej3
{
	public Ej3()
	{
	}
	
	public static void main (String[] args)
	{
		new Ej3();
	}
}