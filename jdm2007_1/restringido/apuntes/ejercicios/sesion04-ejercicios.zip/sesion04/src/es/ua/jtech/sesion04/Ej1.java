package es.ua.jtech.sesion04;

import java.io.*;
import java.util.*;

public class Ej1
{
	String cabecera = "# Esto es la cabecera del fichero que hay que introducir\r\n";
	
	public Ej1()
	{
	}
	
	public void leeEscribeStream()
	{
	}
	
	public void leeEscribeWriter()
	{
	}
	
	public static void main(String[] args)
	{
		Ej1 e = new Ej1();
		e.leeEscribeStream();
		e.leeEscribeWriter();
	}
}