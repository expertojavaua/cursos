package es.ua.jtech.sesion04.datos;

import java.util.*;

public class Persona implements Comparable
{
	String nombre;
	String apellido1;
	String apellido2;
	String direccion;
	String telefono;
	
	public Persona (String nombre, String apellido1, String apellido2, String direccion, String telefono)
	{
		this.nombre = nombre;
		this.apellido1 = apellido1;
		this.apellido2 = apellido2;
		this.direccion = direccion;
		this.telefono = telefono;
	}
	
	public String getNombre()
	{
		return nombre;
	}
	
	public String getApellido1()
	{
		return apellido1;
	}
	
	public String getApellido2()
	{
		return apellido2;
	}
	
	public String getDireccion()
	{
		return direccion;
	}
	
	public String getTelefono()
	{
		return telefono;
	}
	
	public void setNombre(String nombre)
	{
		this.nombre = nombre;
	}
	
	public void setApellido1(String apellido1)
	{
		this.apellido1 = apellido1;
	}
	
	public void setApellido2(String apellido2)
	{
		this.apellido2 = apellido2;
	}
	
	public void setDireccion(String direccion)
	{
		this.direccion = direccion;
	}
	
	public void setTelefono(String telefono)
	{
		this.telefono = telefono;
	}
	
	public String toString()
	{
		return apellido1 + " " + apellido2 + ", " + nombre + ", " + direccion + ", " + telefono;
	}
	
	public int compareTo(Object o)
	{
		Persona p = (Persona)o;
		if (this.apellido1.compareTo(p.apellido1)!= 0)
			return this.apellido1.compareTo(p.apellido1);
		else
			if (this.apellido2.compareTo(p.apellido2)!= 0)
				return this.apellido2.compareTo(p.apellido2);
			else
				return this.nombre.compareTo(p.nombre);
			
	}

}