package es.ua.jtech.sesion7;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class ServletAlumnoBD extends HttpServlet
{

}