/*
 * Created on 13-sep-2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package es.ua.jtech.chat;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ServletChat extends HttpServlet {
	public void init() throws ServletException {
		ServletContext sc = this.getServletContext();

	}

	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		ServletContext sc = this.getServletContext();
		ListaChat lista = (ListaChat)sc.getAttribute("chat");

		HttpSession sesion = req.getSession();
		String nick = (String)sesion.getAttribute("id");

		String url = res.encodeURL(req.getRequestURL().toString()); 
		res.setHeader("URL-Reescrita", url);

		String cmd = req.getParameter("accion");
		
		if(cmd.equals("login")) {

			// Inicia la sesion de un usuario

			sesion.setAttribute("id", req.getParameter("id"));
			sesion.setAttribute("ts", new Long(lista.getTimeStamp()));
			res.setStatus(HttpServletResponse.SC_OK);

		} else if(cmd.equals("lista")) {

			// Devuelve los nuevos mensajes publicados

			if(nick == null) {
				res.sendError(HttpServletResponse.SC_UNAUTHORIZED);				
			} else {
				long ts = ((Long)sesion.getAttribute("ts")).longValue();

				res.setContentType("application/octet-stream");
				OutputStream out = res.getOutputStream();
				long nuevo_ts = lista.serialize(out, ts);
			
				out.close();

				sesion.setAttribute("ts", new Long(nuevo_ts));
			}

		} else if(cmd.equals("enviar")) {

			// Registra el mensaje de un usuario

			if(nick == null) {
				res.sendError(HttpServletResponse.SC_UNAUTHORIZED);
			} else {
				InputStream in = req.getInputStream();
				DataInputStream dis = new DataInputStream(in);
				String msg = dis.readUTF();
				dis.close();
				in.close();
				
				lista.nuevoMensaje(nick, msg);
				res.setStatus(HttpServletResponse.SC_OK);
			}
			
		} else {
			res.sendError(HttpServletResponse.SC_BAD_REQUEST);
		}
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		doGet(req,res);
	}

}
