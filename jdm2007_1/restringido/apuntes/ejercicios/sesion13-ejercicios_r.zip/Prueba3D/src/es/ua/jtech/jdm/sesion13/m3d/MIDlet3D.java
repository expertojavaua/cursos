/*
 * Created on 19/06/2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package es.ua.jtech.jdm.sesion13.m3d;

import javax.microedition.lcdui.Display;
import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

/**
 * @author Miguel Angel
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class MIDlet3D extends MIDlet {

	public void showMenu() {
		Display d = Display.getDisplay(this);
		Menu m = new Menu(this);
		d.setCurrent(m);		
	}
	
	public void showInmediate() {
		Display d = Display.getDisplay(this);
		Visor3DInmediate v3d = new Visor3DInmediate(this);
		d.setCurrent(v3d);		
	}
	
	public void showRetained() {
		Display d = Display.getDisplay(this);
		Visor3DRetained v3d = new Visor3DRetained(this);
		d.setCurrent(v3d);				
	}
	
	protected void startApp() throws MIDletStateChangeException {
		showMenu();
	}	
	
	protected void pauseApp() {
	}

	protected void destroyApp(boolean arg0) throws MIDletStateChangeException {
	}

	public void salir() {
		try {
			destroyApp(true);
		} catch (MIDletStateChangeException e) {
		}
		notifyDestroyed();
	}
}
