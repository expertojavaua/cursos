/*
 * Created on 07/06/2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package es.ua.j2ee.utils;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 * @author Miguel Angel
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ConsoleUtils {

	private static BufferedReader in;
	
	static {
		in = new BufferedReader(new InputStreamReader(System.in));
	}
	
	public static int readInt(String message, int defaultValue) {
		boolean ok = false;
		int readNum = 0;
		
		do {
			System.out.print(message + " [" + defaultValue + "] ");

			try {
				String readLine = in.readLine();

				if(readLine.equals("")) {
					readNum = defaultValue;
					ok = true;
				} else {
					readNum = Integer.parseInt(readLine);			
					ok = true;
				}
			} catch(Exception e) {
				ok = false;
			}

		} while(!ok);

		return readNum;
	}
	
	public static int readInt(String message, int defaultValue, int minValue, int maxValue) {
		boolean ok = false;
		int readNum = 0;
		
		do {
			System.out.print(message + " (" + minValue + "-" + maxValue + ") [" + defaultValue + "] ");

			try {
				String readLine = in.readLine();

				if(readLine.equals("")) {
					readNum = defaultValue;
					ok = true;
				} else {
					readNum = Integer.parseInt(readLine);			
					if(readNum>=minValue && readNum<=maxValue) {
						ok = true;						
					} else {
						ok = false;
					}
				}
			} catch(Exception e) {
				ok = false;
			}

		} while(!ok);

		return readNum;
	}
	
	public static String readString(String message, String defaultValue) {
		boolean ok = false;
		String readLine = null;

		do {

			System.out.print(message + " [" + defaultValue + "] ");

			try {
				readLine = in.readLine();
				ok = true;
			} catch(Exception e) {
				ok = false;
			}

		} while(!ok);

		if(readLine.equals("")) {
			readLine = defaultValue;
		}
		
		return readLine;
	}
}
