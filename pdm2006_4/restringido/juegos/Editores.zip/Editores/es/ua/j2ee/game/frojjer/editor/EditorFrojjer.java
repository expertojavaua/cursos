/*
 * Created on 08/06/2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package es.ua.j2ee.game.frojjer.editor;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import es.ua.j2ee.utils.ConsoleUtils;

/**
 * @author Miguel Angel
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class EditorFrojjer {

	public static void compruebaFichero() {
		
		// Lee nombre del fichero
		String nombreFichero = ConsoleUtils.readString("Fichero de datos","");

		StageData [] fases = leeDatos(nombreFichero);
		imprimeDatos(fases);

	}

	public static void editaFichero() {
		
		// Lee nombre del fichero
		String nombreFichero = ConsoleUtils.readString("Fichero de datos","");
		
		StageData [] fases = null;

		fases = leeDatos(nombreFichero);
		fases = editaDatosConsola(fases);
		grabaDatos(nombreFichero, fases);
	}

	// Imprime los datos leidos en pantalla
	public static void imprimeDatos(StageData [] fases) {

		for(int i=0;i<fases.length;i++) {
			System.out.println("***** Datos de la fase " + i + " *****\n");
			System.out.println(fases[i]);
		}
		
	}
	
	// Edita los datos de los niveles en la consola
	public static StageData [] editaDatosConsola(StageData [] fases) {

		int numNiveles = fases.length;
		
		// Lee numero de niveles
				
		numNiveles = ConsoleUtils.readInt("Numero de niveles", numNiveles, 0, Integer.MAX_VALUE);

		if(numNiveles!=fases.length) {
			StageData [] aux = new StageData[numNiveles];

			int min = numNiveles<fases.length?numNiveles:fases.length;
			for(int i=0;i<min;i++) {
				aux[i] = fases[i];
			}
			
			fases = aux;
		}
		
		for(int i=0;i<numNiveles;i++) {
			System.out.println("*** Datos del nivel " + i + " ***");
			if(fases[i]==null) {
				fases[i] = new StageData();
			}
			fases[i].leeConsola();
		}
		
		return fases;
	}

	// Codifica los datos en un fichero binario
	public static void grabaDatos(String fichero, StageData [] fases) {
		
		try {
			FileOutputStream fos = new FileOutputStream(fichero);
			DataOutputStream dos = new DataOutputStream(fos);

			dos.writeInt(fases.length);
			
			for(int i=0;i<fases.length;i++) {
				fases[i].serialize(dos);
			}
		} catch(IOException e) {
		}
		
	}

	// Lee los datos codificados en binario
	public static StageData [] leeDatos(String fichero) {
		
		StageData [] fases = null;
		
		try {
			FileInputStream fis = new FileInputStream(fichero);
			DataInputStream dis = new DataInputStream(fis);

			int n_fases = dis.readInt();
			fases = new StageData[n_fases];
			
			for(int i=0;i<n_fases;i++) {
				fases[i] = StageData.deserialize(dis);
			}

		} catch(Exception e) {
			fases = new StageData[1];
			System.out.println("El fichero no existe, creando uno nuevo ...");			
		}
		
		return fases;
	}

	public static void main(String[] args) {

		//creaFicheroDatos(in);
		//compruebaFichero(in);
		editaFichero();

	}	
	
}
