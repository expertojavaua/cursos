/*
 * Created on 08/06/2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package es.ua.j2ee.game.frojjer.editor;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import es.ua.j2ee.utils.ConsoleUtils;

/**
 * @author Miguel Angel
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class TrackData {

	public byte velocity;
	public short separacion;
	public byte tipo_coche;

	public static TrackData deserialize(DataInputStream dis) throws IOException {
		TrackData data = new TrackData();
		data.velocity = dis.readByte();
		data.separacion = dis.readShort();
		data.tipo_coche = dis.readByte();
		
		return data;
	}
	
	public void serialize(DataOutputStream dos) throws IOException {
		dos.writeByte(velocity);
		dos.writeShort(separacion);
		dos.writeByte(tipo_coche);
	}
	
	public void leeConsola() {
		this.velocity = (byte)ConsoleUtils.readInt("Velocidad", velocity, 0, Byte.MAX_VALUE);
		this.separacion = (short)ConsoleUtils.readInt("Separacion", separacion, 0, Short.MAX_VALUE);
		this.tipo_coche = (byte)ConsoleUtils.readInt("Tipo coche", tipo_coche, 0, Byte.MAX_VALUE);
	}
}
