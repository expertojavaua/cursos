/*
 * Created on 09/04/2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package es.ua.j2ee.game.panj.editor;

import java.io.BufferedReader;

import es.ua.j2ee.utils.ConsoleUtils;

/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class DatosBola {

	public int bola_x;
	public int bola_y;
	public byte bola_tam;
	public int bola_vx;
	public byte bola_color;

	public void leeConsola(BufferedReader in) {
		
		this.bola_x = ConsoleUtils.readInt("X", bola_x);
		this.bola_y = ConsoleUtils.readInt("Y", bola_y);
		this.bola_vx = ConsoleUtils.readInt("Velocidad X", bola_vx);
		this.bola_tam = (byte)ConsoleUtils.readInt("Tam", bola_tam, 1, 3);
		this.bola_color = (byte)ConsoleUtils.readInt("Color", bola_color, 0, 2);
	}

	public String toString() {
		String s="";
		
		s+= "X: " + this.bola_x + "\n";
		s+= "Y: " + this.bola_y + "\n";
		s+= "Vel: " + this.bola_vx + "\n";
		s+= "Tam: " + this.bola_tam + "\n";
		s+= "Color: " + this.bola_color + "\n";
		
		return s;
	}
}
