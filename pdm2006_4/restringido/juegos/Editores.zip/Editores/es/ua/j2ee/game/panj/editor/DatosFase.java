
package es.ua.j2ee.game.panj.editor;

import java.io.BufferedReader;

import es.ua.j2ee.utils.ConsoleUtils;

// ------------------------------------------------------------------------------------
// 	Clase encargada de almacenar los datos de cada fase
// ------------------------------------------------------------------------------------

public class DatosFase {

	public int n_bolas;
	public DatosBola [] bolas;
	public String img_background;
	public String music;
	public String nombre;
	
	public void leeConsola(BufferedReader in) {
		
		String readLine=null;
		int readNum=0;
		boolean correcto;
		
		this.nombre = ConsoleUtils.readString("Nombre", nombre);
		this.img_background = ConsoleUtils.readString("Imagen de fondo", img_background);
		this.n_bolas = ConsoleUtils.readInt("Numero de bolas", n_bolas, 0, Integer.MAX_VALUE);
		bolas = new DatosBola[n_bolas];
		
		for(int i=0;i<n_bolas;i++) {
			System.out.println("* Datos de la bola " + i + " *");
			if(bolas[i]==null) {
				bolas[i] = new DatosBola();
			}
			bolas[i].leeConsola(in);
		}		
	}
	
	public String toString() {
		String s="";
		s+= "Nombre: " + this.nombre + "\n";
		s+= "Img.fondo: " + this.img_background + "\n";
		s+= "Num.bolas: " + this.n_bolas + "\n";
		for(int i=0;i<n_bolas;i++) {
			s+="*** Datos de la bola " + i + " ***\n"; 
			s+= bolas[i];
		}

		return s;
	}
}