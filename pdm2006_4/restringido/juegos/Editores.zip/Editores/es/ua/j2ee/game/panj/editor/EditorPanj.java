/*
 * Created on 09/04/2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package es.ua.j2ee.game.panj.editor;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import es.ua.j2ee.utils.ConsoleUtils;

/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class EditorPanj {

	public static void compruebaFichero(BufferedReader in) {
		
		// Lee nombre del fichero
		String nombreFichero = ConsoleUtils.readString("Fichero de datos","");

		DatosFase [] fases = leeDatos(nombreFichero);
		imprimeDatos(fases);

	}

	public static void editaFichero(BufferedReader in) {
		
		// Lee nombre del fichero
		String nombreFichero = ConsoleUtils.readString("Fichero de datos","");
		
		DatosFase [] fases = null;

		fases = leeDatos(nombreFichero);
		fases = editaDatosConsola(in, fases);
		grabaDatos(nombreFichero, fases);
	}

	// Imprime los datos leidos en pantalla
	public static void imprimeDatos(DatosFase [] fases) {

		for(int i=0;i<fases.length;i++) {
			System.out.println("***** Datos de la fase " + i + " *****\n");
			System.out.println(fases[i]);
		}
		
	}
	
	// Edita los datos de los niveles en la consola
	public static DatosFase [] editaDatosConsola(BufferedReader in, DatosFase [] fases) {

		int numNiveles = fases.length;
		
		// Lee numero de niveles
				
		numNiveles = ConsoleUtils.readInt("Numero de niveles", numNiveles, 0, Integer.MAX_VALUE);
		fases = new DatosFase[numNiveles];

		for(int i=0;i<numNiveles;i++) {
			System.out.println("*** Datos del nivel " + i + " ***");
			if(fases[i]==null) {
				fases[i] = new DatosFase();
			}
			fases[i].leeConsola(in);
		}
		
		return fases;
	}

	// Codifica los datos en un fichero binario
	public static void grabaDatos(String fichero, DatosFase [] fases) {
		
		try {
			FileOutputStream fos = new FileOutputStream(fichero);
			DataOutputStream dos = new DataOutputStream(fos);

			dos.writeInt(fases.length);
			
			for(int i=0;i<fases.length;i++) {
				dos.writeUTF(fases[i].nombre);
				dos.writeUTF(fases[i].img_background);
				dos.writeInt(fases[i].n_bolas);
				for(int j=0;j<fases[i].n_bolas;j++) {
					dos.writeInt(fases[i].bolas[j].bola_x);
					dos.writeInt(fases[i].bolas[j].bola_y);
					dos.writeByte(fases[i].bolas[j].bola_tam);
					dos.writeInt(fases[i].bolas[j].bola_vx);
					dos.writeByte(fases[i].bolas[j].bola_color);
				}
			}
		} catch(IOException e) {
		}
		
	}

	// Lee los datos codificados en binario
	public static DatosFase [] leeDatos(String fichero) {
		
		DatosFase [] fases = null;
		
		try {
			FileInputStream fis = new FileInputStream(fichero);
			DataInputStream dis = new DataInputStream(fis);

			int n_fases = dis.readInt();

			fases = new DatosFase[n_fases];
			
			for(int i=0;i<n_fases;i++) {
				fases[i] = new DatosFase();
				fases[i].nombre = dis.readUTF();
				fases[i].img_background = dis.readUTF();
				fases[i].n_bolas = dis.readInt();
				fases[i].bolas = new DatosBola[fases[i].n_bolas];				
				for(int j=0;j<fases[i].n_bolas;j++) {
					fases[i].bolas[j] = new DatosBola();
					fases[i].bolas[j].bola_x = dis.readInt();
					fases[i].bolas[j].bola_y = dis.readInt();
					fases[i].bolas[j].bola_tam = dis.readByte();
					fases[i].bolas[j].bola_vx = dis.readInt();
					fases[i].bolas[j].bola_color = dis.readByte();
				}
			}
		} catch(Exception e) {
			fases = new DatosFase[1];
		}
		
		return fases;
	}

	public static void main(String[] args) {

		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

		//creaFicheroDatos(in);
		//compruebaFichero(in);
		editaFichero(in);
				
	}
}
