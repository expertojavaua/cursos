/*
 * Created on 08/06/2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package es.ua.j2ee.game.frojjer.editor;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import es.ua.j2ee.utils.ConsoleUtils;

/**
 * @author Miguel Angel
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class StageData {

	public String title;
	public TrackData [] tracks = new TrackData[1];
	
	public static StageData deserialize(DataInputStream dis) throws IOException {
		StageData data = new StageData();
		data.title = dis.readUTF();

		byte nTracks = dis.readByte();
		data.tracks = new TrackData[nTracks];
		for(byte i=0;i<nTracks;i++) {
			data.tracks[i] = TrackData.deserialize(dis);
		}
		
		return data;
	}
	
	public void serialize(DataOutputStream dos) throws IOException {
		dos.writeUTF(title);

		dos.writeByte(tracks.length);
		for(byte i=0;i<tracks.length;i++) {
			tracks[i].serialize(dos);
		}
	}
	
	public void leeConsola() {
		this.title = ConsoleUtils.readString("Titulo", title);
		int nTracks = ConsoleUtils.readInt("Numero de carriles", tracks.length, 0, Integer.MAX_VALUE);

		if(nTracks!=tracks.length) {
			TrackData [] aux = new TrackData[nTracks];
			int min = nTracks<tracks.length?nTracks:tracks.length;
			
			for(int i=0;i<min;i++) {
				aux[i] = tracks[i];
			}
			
			tracks = aux;
		}
		
		for(int i=0;i<nTracks;i++) {
			System.out.println("* Datos del carril " + i + " *");
			if(tracks[i] == null) {
				tracks[i] = new TrackData();
			}
			tracks[i].leeConsola();
		}
	}

}
