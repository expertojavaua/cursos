package es.ua.j2ee.mensajes.modelo;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import javax.microedition.io.Connector;
import javax.microedition.io.HttpConnection;

public class ProxyRemoto {

	public final static String URL_SERVLET = "http://www.jtech.ua.es/ejemplos-j2me/servlet/ServletMensajes";

	public ProxyRemoto() {

	}

	public SyncItem sincroniza(SyncItem datosCliente) throws IOException {
		HttpConnection con = (HttpConnection) Connector.open(URL_SERVLET);

		// Envia datos al servidor
		DataOutputStream dos = con.openDataOutputStream();
		Mensaje[] mensajesCliente = datosCliente.getMensajes();
		dos.writeLong(datosCliente.getTimeStamp());
		if (mensajesCliente == null) {
			dos.writeInt(0);
		} else {
			dos.writeInt(mensajesCliente.length);
			for (int i = 0; i < mensajesCliente.length; i++) {
				mensajesCliente[i].serializeRed(dos);
			}
		}

		// Recibe datos del servidor
		DataInputStream dis = con.openDataInputStream();
		long tsServidor = dis.readLong();
		int nMensajesServidor = dis.readInt();
		Mensaje[] mensajesServidor = new Mensaje[nMensajesServidor];
		for (int i = 0; i < nMensajesServidor; i++) {
			mensajesServidor[i] = Mensaje.deserializeRed(dis);
		}

		SyncItem datosServidor = new SyncItem();
		datosServidor.setTimeStamp(tsServidor);
		datosServidor.setMensajes(mensajesServidor);

		return datosServidor;
	}

}