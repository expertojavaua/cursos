package es.ua.j2ee.mensajes.modelo;

import java.io.IOException;

import javax.microedition.rms.RecordStoreException;

public class FachadaModelo {

	boolean online;

	ModeloLocal mLocal;

	ProxyRemoto mRemoto;

	public FachadaModelo() throws RecordStoreException, IOException {
		mLocal = new ModeloLocal();
		mRemoto = new ProxyRemoto();

		InfoLocal info = getConfig();
		online = info.isOnline();
	}

	/*
	 * Crea un nuevo mensaje
	 */
	public void nuevoMensaje(Mensaje msg) throws IOException, RecordStoreException {
		mLocal.addMensaje(msg, true);
		if (online) {
			sincroniza();
		}
	}

	/*
	 * Obtiene la lista de todos los mensajes
	 */
	public Mensaje[] listaMensajes() throws RecordStoreException, IOException {
		if (online) {
			sincroniza();
		}
		return mLocal.listaMensajes();
	}

	/*
	 * Obtiene la configuracion local
	 */
	public InfoLocal getConfig() throws RecordStoreException, IOException {
		return mLocal.getInfoLocal();
	}

	/*
	 * Actualiza la configuracion local
	 */
	public void updateConfig(InfoLocal config) throws RecordStoreException,
			IOException {
		InfoLocal info = mLocal.getInfoLocal();
		info.setOnline(config.isOnline());
		this.online = config.isOnline();
		mLocal.setInfoLocal(info);
	}

	/*
	 * Sincroniza la lista de citas con el servidor
	 */
	public void sincroniza() throws RecordStoreException, IOException {

		// Obtiene datos del cliente
		
		InfoLocal info = mLocal.getInfoLocal();

		Mensaje[] mensajes = mLocal.listaMensajesPendientes();
		
System.out.println("Enviando " + mensajes.length + " mensajes");		
		SyncItem datosCliente = new SyncItem();
		datosCliente.setMensajes(mensajes);
		datosCliente.setTimeStamp(info.getTimeStamp());

		// Envia y recibe
		
		SyncItem datosServidor = mRemoto.sincroniza(datosCliente);

		mLocal.marcaEnviados(mensajes);

		// Agrega los datos recibidos del servidor

		Mensaje[] mensajesServidor = datosServidor.getMensajes();
		if (mensajesServidor != null) {
			for (int i = 0; i < mensajesServidor.length; i++) {
				mLocal.addMensaje(mensajesServidor[i], false);
			}
		}

		info.setTimeStamp(datosServidor.getTimeStamp());
		mLocal.setInfoLocal(info);
	}

	public void destroy() throws RecordStoreException {
		mLocal.destroy();
	}

}