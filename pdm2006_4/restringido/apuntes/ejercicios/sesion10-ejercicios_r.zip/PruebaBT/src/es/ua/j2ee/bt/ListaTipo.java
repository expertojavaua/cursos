package es.ua.j2ee.bt;

import javax.microedition.lcdui.ChoiceGroup;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.List;

public class ListaTipo extends List implements CommandListener {

	int iMaestro;
	int iEsclavo;
	
	Command cmdExit;
	Command cmdSelect;
	
	MIDletBT owner;
	
	public ListaTipo(MIDletBT owner) {
		super("Tipo", ChoiceGroup.IMPLICIT);

		this.owner = owner;
		
		iMaestro = this.append("Maestro", null);
		iEsclavo = this.append("Esclavo", null);
		
		cmdSelect = new Command("Seleccionar", Command.OK, 1);
		cmdExit = new Command("Salir", Command.EXIT, 1);
		
		this.addCommand(cmdSelect);
		this.addCommand(cmdExit);
		
		this.setCommandListener(this);
	}
	
	public void commandAction(Command cmd, Displayable disp) {
		if(cmd==List.SELECT_COMMAND || cmd==cmdSelect) {
			if(this.getSelectedIndex()==iEsclavo) {
				owner.mostrarCliente();
			} else if(this.getSelectedIndex()==iMaestro) {
				owner.mostrarServidor();
			}
		} else if(cmd==cmdExit) {
			owner.salir();
		}
	}
}
