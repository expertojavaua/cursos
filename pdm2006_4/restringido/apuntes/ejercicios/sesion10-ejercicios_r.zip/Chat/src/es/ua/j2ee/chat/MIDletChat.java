package es.ua.j2ee.chat;

import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;
import javax.microedition.lcdui.*;

public class MIDletChat extends MIDlet {

	protected void startApp() throws MIDletStateChangeException {
		PantallaLogin pl = new PantallaLogin(this);
		Display d = Display.getDisplay(this);
		d.setCurrent(pl);
	}

	protected void pauseApp() {
	}

	protected void destroyApp(boolean arg0) throws MIDletStateChangeException {
	}
}
