package es.ua.j2ee.mensajes.vista;


import javax.microedition.lcdui.Display;
import javax.microedition.rms.RecordStoreException;

import es.ua.j2ee.mensajes.MIDletMensajes;
import es.ua.j2ee.mensajes.modelo.FachadaModelo;
import es.ua.j2ee.mensajes.modelo.InfoLocal;
import es.ua.j2ee.mensajes.modelo.Mensaje;
import es.ua.j2ee.mensajes.modelo.Recursos;

public class ControladorUI {

	/*
	 * Tipos de eventos
	 */
	public final static int EVENTO_MUESTRA_MENU = 0;
	public final static int EVENTO_MUESTRA_NUEVO_MENSAJE = 1;
	public final static int EVENTO_MUESTRA_LISTA_MENSAJES = 2;
	public final static int EVENTO_MUESTRA_DATOS_MENSAJE = 3;
	public final static int EVENTO_AGREGA_MENSAJE = 6;
	public final static int EVENTO_SALIR = 8;
	public final static int EVENTO_SINCRONIZAR = 9;
	public final static int EVENTO_MUESTRA_CONFIG =10;
	public final static int EVENTO_APLICA_CONFIG = 11;

	/*
	 * Componentes de la UI
	 */
	DatosMensajeUI uiDatosMensaje;
	EditaMensajeUI uiEditaMensaje;
	ListaMensajesUI uiListaMensajes;
	EditaConfigUI uiEditaConfig;
	MenuPrincipalUI uiMenuPrincipal;
	BarraProgresoUI uiBarraProgreso;
	
	/*
	 * Gestor de recursos
	 */
	Recursos recursos;
	
	/*
	 * Modelo
	 */
	FachadaModelo modelo;
	
	MIDletMensajes midlet;
	Display display;
	
	public ControladorUI(MIDletMensajes midlet) {
		this.midlet = midlet;
		display = Display.getDisplay(midlet);
		
		init();
	}
	
	/*
	 * Inicializacion de los componentes de la UI
	 */
	public void init() {
		
		// Crea gestor de recursos
		recursos = new Recursos();

		// Crea UI
		uiDatosMensaje = new DatosMensajeUI(this);
		uiEditaMensaje = new EditaMensajeUI(this);
		uiListaMensajes = new ListaMensajesUI(this);
		uiEditaConfig = new EditaConfigUI(this);
		uiMenuPrincipal = new MenuPrincipalUI(this);
		uiBarraProgreso = new BarraProgresoUI(this);
		
		try {
			// Crea modelo
			modelo = new FachadaModelo();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
		
	public void destroy() throws RecordStoreException {
		modelo.destroy();
	}
	
	public void showMenu() {
		display.setCurrent(uiMenuPrincipal);
	}
		
	public String getString(int cod) {
		return recursos.getString(cod);
	}
	
	/*
	 * Lanza el procesamiento de un evento
	 */
	public void procesaEvento(int evento, Object param) {
		HiloEventos he = new HiloEventos(evento, param);
		he.start();
	}
	
	/*
	 * Hilo para el procesamiento de eventos
	 */
	class HiloEventos extends Thread {
		int evento;
		Object param;
		
		public HiloEventos(int evento, Object param) {
			this.evento = evento;
			this.param = param;
		}
		
		public void run() {
			Mensaje mensaje;
			Mensaje [] mensajes;
			InfoLocal info;
			
			try {
				switch(evento) {
					case EVENTO_MUESTRA_MENU:
						showMenu();
						break;
					case EVENTO_MUESTRA_NUEVO_MENSAJE:
						uiEditaMensaje.reset(null, ControladorUI.EVENTO_AGREGA_MENSAJE, ControladorUI.EVENTO_MUESTRA_MENU);
						display.setCurrent(uiEditaMensaje);		
						break;
					case EVENTO_AGREGA_MENSAJE:
						mensaje = (Mensaje)param;
						modelo.nuevoMensaje(mensaje);
						showMenu();
						break;
					case EVENTO_MUESTRA_LISTA_MENSAJES:
						uiBarraProgreso.reset(getString(Recursos.STR_PROGRESO_CARGA_LISTA), 10, 0, true);
						display.setCurrent(uiBarraProgreso);
						mensajes = modelo.listaMensajes();
						uiListaMensajes.reset(mensajes, ControladorUI.EVENTO_MUESTRA_DATOS_MENSAJE, ControladorUI.EVENTO_MUESTRA_MENU);
						display.setCurrent(uiListaMensajes);
						break;
					case EVENTO_MUESTRA_DATOS_MENSAJE:
						mensaje = (Mensaje)param;
						uiDatosMensaje.reset(mensaje, ControladorUI.EVENTO_MUESTRA_LISTA_MENSAJES);
						display.setCurrent(uiDatosMensaje);
						break;
					case EVENTO_SINCRONIZAR:												
						uiBarraProgreso.reset(getString(Recursos.STR_PROGRESO_SINCRONIZA), 10, 0, true);
						display.setCurrent(uiBarraProgreso);
						modelo.sincroniza();
						display.setCurrent(uiMenuPrincipal);
						break;
					case EVENTO_MUESTRA_CONFIG:
						info = modelo.getConfig();
						uiEditaConfig.reset(info, ControladorUI.EVENTO_APLICA_CONFIG, ControladorUI.EVENTO_MUESTRA_MENU);
						display.setCurrent(uiEditaConfig);		
						break;
					case EVENTO_APLICA_CONFIG:
						info = (InfoLocal)param;
						modelo.updateConfig(info);
						display.setCurrent(uiMenuPrincipal);		
						break;
					case EVENTO_SALIR:												
						midlet.salir();
						break;
				}				
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
	}
		
}
