package es.ua.j2ee.mensajes.vista;

import javax.microedition.lcdui.ChoiceGroup;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.List;

import es.ua.j2ee.mensajes.modelo.Recursos;

public class MenuPrincipalUI extends List implements CommandListener {

	int itemNuevoMensaje;
	int itemListaMensajes;
	int itemSincronizar;
	int itemConfigurar;
	int itemSalir;
	
	ControladorUI controlador;
	
	public MenuPrincipalUI(ControladorUI controlador) {
		super(controlador.getString(Recursos.STR_MENU_TITULO), ChoiceGroup.IMPLICIT);
		
		this.controlador = controlador;
		
		itemNuevoMensaje = this.append(controlador.getString(Recursos.STR_MENU_ITEM_AGREGAR), null);
		itemListaMensajes = this.append(controlador.getString(Recursos.STR_MENU_ITEM_VER), null);
		itemSincronizar = this.append(controlador.getString(Recursos.STR_MENU_ITEM_SINCRONIZAR), null);
		itemConfigurar = this.append(controlador.getString(Recursos.STR_MENU_ITEM_CONFIGURAR), null);
		itemSalir = this.append(controlador.getString(Recursos.STR_MENU_ITEM_SALIR), null);
		
		this.setCommandListener(this);
	}
	
	public void commandAction(Command cmd, Displayable disp) {
		if(cmd == List.SELECT_COMMAND) {
			if(this.getSelectedIndex() == itemNuevoMensaje) {
				controlador.procesaEvento(ControladorUI.EVENTO_MUESTRA_NUEVO_MENSAJE, null);
			} else if(this.getSelectedIndex() == itemListaMensajes) {
				controlador.procesaEvento(ControladorUI.EVENTO_MUESTRA_LISTA_MENSAJES, null);
			} else if(this.getSelectedIndex() == itemSincronizar) {
				controlador.procesaEvento(ControladorUI.EVENTO_SINCRONIZAR, null);
			} else if(this.getSelectedIndex() == itemConfigurar) {
				controlador.procesaEvento(ControladorUI.EVENTO_MUESTRA_CONFIG, null);
			} else if(this.getSelectedIndex() == itemSalir) {
				controlador.procesaEvento(ControladorUI.EVENTO_SALIR, null);
			}
		}
	}

}
