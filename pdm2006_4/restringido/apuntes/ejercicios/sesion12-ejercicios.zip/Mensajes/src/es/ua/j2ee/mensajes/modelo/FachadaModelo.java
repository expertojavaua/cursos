package es.ua.j2ee.mensajes.modelo;

import java.io.IOException;

import javax.microedition.rms.RecordStoreException;

public class FachadaModelo {

	boolean online;

	public FachadaModelo() throws RecordStoreException, IOException {
		// TODO: Crear modelo local y proxy remoto
	}

	/*
	 * Crea un nuevo mensaje
	 */
	public void nuevoMensaje(Mensaje msg) throws IOException, RecordStoreException {
		// TODO: Crear un nuevo mensaje
	}

	/*
	 * Obtiene la lista de todos los mensajes
	 */
	public Mensaje[] listaMensajes() throws RecordStoreException, IOException {
		// TODO: Devuelve la lista de mensajes
		return null;
	}

	/*
	 * Obtiene la configuracion local
	 */
	public InfoLocal getConfig() throws RecordStoreException, IOException {
		// TODO: Devuelve configuracion local
		return null;
	}

	/*
	 * Actualiza la configuracion local
	 */
	public void updateConfig(InfoLocal config) throws RecordStoreException,
			IOException {
		// TODO: Actualiza la configuracion local en RMS
	}

	/*
	 * Sincroniza la lista de citas con el servidor
	 */
	public void sincroniza() throws RecordStoreException, IOException {
		// TODO: Sincroniza lista de mensajes con el servidor
	}

	public void destroy() throws RecordStoreException {
		// TODO: Liberar recursos
	}

}