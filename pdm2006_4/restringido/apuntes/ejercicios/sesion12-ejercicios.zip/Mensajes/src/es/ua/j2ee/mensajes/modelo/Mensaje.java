package es.ua.j2ee.mensajes.modelo;

import java.io.*;

public class Mensaje {

	int rmsID;

	String asunto;

	String texto;
	
	boolean pendiente;

	public Mensaje() {
	}

	public boolean isPendiente() {
		return pendiente;
	}

	public void setPendiente(boolean pendiente) {
		this.pendiente = pendiente;
	}
	
	public int getRmsID() {
		return rmsID;
	}

	public void setRmsID(int rmsID) {
		this.rmsID = rmsID;
	}

	public String getAsunto() {
		return asunto;
	}

	public void setAsunto(String asunto) {
		this.asunto = asunto;
	}

	public String getTexto() {
		return texto;
	}

	public void setTexto(String texto) {
		this.texto = texto;
	}

	public void serializeRed(DataOutputStream dos) throws IOException {
		dos.writeUTF(asunto);
		dos.writeUTF(texto);
	}

	public static Mensaje deserializeRed(DataInputStream dis) throws IOException {
		Mensaje msg = new Mensaje();

		msg.asunto = dis.readUTF();
		msg.texto = dis.readUTF();

		return msg;
	}
	
	public void serializeRMS(DataOutputStream dos) throws IOException {
		dos.writeUTF(asunto);
		dos.writeUTF(texto);
		dos.writeBoolean(pendiente);
	}

	public static Mensaje deserializeRMS(DataInputStream dis) throws IOException {
		Mensaje msg = new Mensaje();

		msg.asunto = dis.readUTF();
		msg.texto = dis.readUTF();
		msg.pendiente = dis.readBoolean();
		
		return msg;
	}

}