package es.ua.j2ee.agenda.vista;

import java.util.Date;

import javax.microedition.lcdui.ChoiceGroup;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.DateField;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.TextField;

import es.ua.j2ee.agenda.modelo.Cita;
import es.ua.j2ee.agenda.modelo.Recursos;

public class EditaCitaUI extends Form implements CommandListener {

	public final static int MAX_LENGHT = 255;

	ControladorUI controlador;

	DateField iFecha;
	TextField iAsunto;
	TextField iLugar;
	TextField iContacto;
	ChoiceGroup iAlarma;
	int itemAlarmaOn;
	int itemAlarmaOff;

	Command cmdAceptar;
	Command cmdCancelar;
	int eventoAceptar = ControladorUI.EVENTO_AGREGA_CITA;
	int eventoCancelar = ControladorUI.EVENTO_MUESTRA_MENU;

	Cita cita;
	
	public EditaCitaUI(ControladorUI controlador) {
		super(controlador.getString(Recursos.STR_DATOS_TITULO));

		this.controlador = controlador;

		iFecha = new DateField(controlador
				.getString(Recursos.STR_DATOS_ITEM_FECHA), DateField.DATE_TIME);
		iAsunto = new TextField(controlador
				.getString(Recursos.STR_DATOS_ITEM_ASUNTO), "", MAX_LENGHT,
				TextField.ANY);
		iLugar = new TextField(controlador
				.getString(Recursos.STR_DATOS_ITEM_LUGAR), "", MAX_LENGHT,
				TextField.ANY);
		iContacto = new TextField(controlador
				.getString(Recursos.STR_DATOS_ITEM_CONTACTO), "", MAX_LENGHT,
				TextField.ANY);
		iAlarma = new ChoiceGroup(controlador
				.getString(Recursos.STR_DATOS_ITEM_ALARMA),
				ChoiceGroup.EXCLUSIVE);
		itemAlarmaOn = iAlarma.append(controlador
				.getString(Recursos.STR_DATOS_ITEM_ALARMA_ON), null);
		itemAlarmaOff = iAlarma.append(controlador
				.getString(Recursos.STR_DATOS_ITEM_ALARMA_OFF), null);

		this.append(iFecha);
		this.append(iAsunto);
		this.append(iLugar);
		this.append(iContacto);
		this.append(iAlarma);

		cmdAceptar = new Command(controlador
				.getString(Recursos.STR_CMD_ACEPTAR), Command.OK, 1);
		cmdCancelar = new Command(controlador
				.getString(Recursos.STR_CMD_CANCELAR), Command.CANCEL, 1);
		this.addCommand(cmdAceptar);
		this.addCommand(cmdCancelar);

		this.setCommandListener(this);
	}

	private void setCita(Cita cita) {
		if (cita == null) {
			this.cita = new Cita();
			
			iFecha.setDate(new Date());
			iAsunto.setString(null);
			iLugar.setString(null);
			iContacto.setString(null);
			iAlarma.setSelectedIndex(itemAlarmaOff, true);
		} else {
			this.cita = cita;
			
			iFecha.setDate(cita.getFecha());
			iAsunto.setString(cita.getAsunto());
			iLugar.setString(cita.getLugar());
			iContacto.setString(cita.getContacto());
			if (cita.isAlarma()) {
				iAlarma.setSelectedIndex(itemAlarmaOn, true);
			} else {
				iAlarma.setSelectedIndex(itemAlarmaOff, true);
			}
		}
	}

	private Cita getCita() {
		if(cita==null) {
			this.cita = new Cita();			
		}
		if(iFecha.getDate()==null) {
			cita.setFecha(new Date());
		} else {
			cita.setFecha(iFecha.getDate());			
		}
		cita.setAsunto(iAsunto.getString());
		cita.setLugar(iLugar.getString());
		cita.setContacto(iContacto.getString());
		cita.setAlarma(iAlarma.getSelectedIndex() == itemAlarmaOn);

		return cita;
	}

	public void reset(Cita cita, int eventoAceptar, int eventoCancelar) {
		this.setCita(cita);
		this.eventoAceptar = eventoAceptar;
		this.eventoCancelar = eventoCancelar;
	}

	public void commandAction(Command cmd, Displayable disp) {
		if (cmd == cmdAceptar) {
			controlador.procesaEvento(eventoAceptar, this.getCita());
		} else if (cmd == cmdCancelar) {
			controlador.procesaEvento(eventoCancelar, null);
		}
	}

}