package es.ua.j2ee.agenda.vista;

import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.Gauge;

import es.ua.j2ee.agenda.modelo.Recursos;

public class BarraProgresoUI extends Form implements Runnable {

	Gauge barra;

	ControladorUI controlador;

	Thread tAuto;

	private static final long CICLO = 250;

	public BarraProgresoUI(ControladorUI controlador) {
		super(controlador.getString(Recursos.STR_BARRA_PROGRESO_TITULO));

		this.controlador = controlador;

		barra = new Gauge("", false, 100, 0);
		this.append(barra);
	}

	public void reset(String etiq, int valorMax, int valor, boolean auto) {
		barra.setLabel(etiq);
		barra.setMaxValue(valorMax);
		barra.setValue(valor);

		if (auto) {
			tAuto = new Thread(this);
			tAuto.start();
		} else {
			tAuto = null;
		}
	}

	public void update() {
		int valor = barra.getValue();
		int valorMax = barra.getMaxValue();
		
		valor = (valor + 1) % valorMax;

		barra.setValue(valor);
	}
	
	public void stop() {
		tAuto = null;
	}

	public void run() {
		while (tAuto == Thread.currentThread()) {
			update();
			
			try {
				Thread.sleep(CICLO);
			} catch (InterruptedException e) {
			}
		}
	}
}