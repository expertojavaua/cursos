package es.ua.j2ee.midlet;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

public class MIDletSerializacion extends MIDlet {

	protected void startApp() throws MIDletStateChangeException {
		try {
			InputStream in = this.getClass().getResourceAsStream("/curso.dat");
			DataInputStream dis = new DataInputStream(in);
			Curso curso = Curso.deserialize(dis);
			System.out.println(curso);
			
			InputStream in2 = this.getClass().getResourceAsStream("/alumno.dat");
			DataInputStream dis2 = new DataInputStream(in2);
			Alumno alum = Alumno.deserialize(dis2);
			System.out.println(alum);
		} catch(IOException e) {
			System.out.println("Error al leer el fichero");
			e.printStackTrace();
		}
	}

	protected void pauseApp() {

	}

	protected void destroyApp(boolean arg0) throws MIDletStateChangeException {

	}

}
