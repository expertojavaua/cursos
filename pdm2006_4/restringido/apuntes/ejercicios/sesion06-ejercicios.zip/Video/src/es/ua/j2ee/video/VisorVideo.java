package es.ua.j2ee.video;
 
import java.io.*;
import javax.microedition.lcdui.*;
import javax.microedition.media.*;
import javax.microedition.media.control.*;

public class VisorVideo extends Canvas implements CommandListener {

	Command cmdStart;

	VideoControl vc;
	Player p; 

	public VisorVideo() {

		// Crea comandos
		cmdStart = new Command("Start", Command.SCREEN, 1);
		this.addCommand(cmdStart);
		this.setCommandListener(this);

		try {

			// Crea reproductor
			InputStream in = getClass().getResourceAsStream("/video.3gp");
			p = Manager.createPlayer(in, "video/3gpp");
			p.realize();

			// Crea control de video
			vc = (VideoControl)p.getControl("VideoControl");
			vc.initDisplayMode(VideoControl.USE_DIRECT_VIDEO, this);
			vc.setDisplayLocation(0,0);
			vc.setDisplaySize(this.getWidth(), this.getHeight());
			vc.setVisible(true);

		} catch(Exception e) {
			System.err.println("Error al crear video");
		}

	}

	protected void paint(Graphics g) {

		// Dibuja la imagen capturada (si la hubiese)
		g.setColor(0x00ffffff);
		g.fillRect(0,0,getWidth(), getHeight());
	}

	public void commandAction(Command cmd, Displayable disp) {
		if(cmd == cmdStart) {

			// Comienza la reproducci�n
			try {
				p.start();
			} catch(Exception e) {
				System.err.println("Error al reproducir");
			}
		}
	}	
}
