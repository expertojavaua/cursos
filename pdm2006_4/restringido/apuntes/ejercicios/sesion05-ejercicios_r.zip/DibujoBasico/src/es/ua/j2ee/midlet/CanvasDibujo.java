package es.ua.j2ee.midlet;

import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Graphics;

public class CanvasDibujo extends Canvas implements Runnable {

	String texto = "Hola mundo!";
	int x = 80;
	int y = 80;
	
	public void showNotify() {
		Thread t = new Thread(this);
		t.start();
	}
	
	public void run() {
		while(true) {
			x = x + 1;
			if(x> this.getWidth()) {
				x=0;
			}
			
			repaint();
			
			try {
				Thread.sleep(25);
			} catch(InterruptedException e) { }			
		}
	}
	
	protected void paint(Graphics g) {
		// Dibuja rectangulo blanco como fondo
		g.setColor(0xffffff);
		g.fillRect(0, 0, this.getWidth(), this.getHeight());
		
		// Dibuja rectangulo rojo
		g.setColor(0xff0000);
		g.fillRect(x,y,40,40);
		
		// Dibuja texto
		g.setColor(0x000000);
		g.drawString(texto, x, y, Graphics.LEFT | Graphics.BASELINE);
	}

}
