/*
 * Created on 27/06/2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package es.ua.j2ee.m3d;

import javax.microedition.lcdui.ChoiceGroup;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.List;

/**
 * @author Miguel Angel
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Menu extends List implements CommandListener {

	MIDlet3D owner;
	
	int itemInmediato;
	int itemRetained;
	
	public Menu(MIDlet3D owner) {
		super("Menu", ChoiceGroup.IMPLICIT);

		this.owner = owner;
		
		itemInmediato = this.append("Modo inmediato", null);
		itemRetained = this.append("Modo retained", null);
		
		this.setCommandListener(this);
	}

	public void commandAction(Command cmd, Displayable disp) {
		if(cmd==List.SELECT_COMMAND) {
			if(this.getSelectedIndex()==itemInmediato) {
				owner.showInmediate();				
			} else if(this.getSelectedIndex()==itemRetained) {
				owner.showRetained();
			}
		}
	}
}
