/*
 * Created on 19/06/2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package es.ua.j2ee.m3d;

import java.io.IOException;

import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Graphics;
import javax.microedition.m3g.Background;
import javax.microedition.m3g.Camera;
import javax.microedition.m3g.Graphics3D;
import javax.microedition.m3g.Group;
import javax.microedition.m3g.Light;
import javax.microedition.m3g.Loader;
import javax.microedition.m3g.Node;
import javax.microedition.m3g.Object3D;
import javax.microedition.m3g.World;

public class Visor3DRetained extends Canvas implements Runnable {

	MIDlet3D owner;
	
	Graphics3D g3d;
	
	World mundo;
	
	long tiempoInicial;

	Camera cam;
	
	Camera camCoche;
	
	Group coche;
	
	float angulo = 0.0f;
	
	boolean upPressed = false;
	boolean downPressed = false;
	boolean leftPressed = false;
	boolean rightPressed = false;
	
	public Visor3DRetained(MIDlet3D owner) {
		this.owner = owner;
		
		init3D();
	}

	protected void keyPressed(int keyCode) {
		int gameAction = this.getGameAction(keyCode);
		switch(gameAction) {
		case Canvas.DOWN:
			downPressed = true;
			break;
		case Canvas.UP:
			upPressed = true;
			break;
		case Canvas.LEFT:
			leftPressed = true;
			break;
		case Canvas.RIGHT:
			rightPressed = true;
			break;			
		}
	}

	protected void keyReleased(int keyCode) {
		int gameAction = this.getGameAction(keyCode);
		switch(gameAction) {
		case Canvas.DOWN:
			downPressed = false;
			break;
		case Canvas.UP:
			upPressed = false;
			break;
		case Canvas.LEFT:
			leftPressed = false;
			break;
		case Canvas.RIGHT:
			rightPressed = false;
			break;			
		}
	}
	
	
	public void init3D() {
		
		g3d = Graphics3D.getInstance();
		
		try {
			Object3D [] objs = Loader.load("/mundo.m3g");  
			mundo = (World)objs[0];

			cam = mundo.getActiveCamera();
			cam.setOrientation(angulo, 0.0f, 1.0f, 0.0f);
			
			Light am = new Light();
			am.setMode(Light.AMBIENT);
			am.setIntensity(0.8f);
			mundo.addChild(am);
			
			Background bg = new Background();
			bg.setColor(0xFFFFFF77);
			mundo.setBackground(bg);
			
			coche = (Group)mundo.find(101);
			coche.setOrientation(angulo, 0.0f, 1.0f, 0.0f);
			
			camCoche = (Camera)mundo.find(102);
			mundo.setActiveCamera(camCoche);
			
			float aspectRatio = (float)this.getWidth()/this.getHeight();
			System.out.println("Aspect: "+ aspectRatio);
			camCoche.setPerspective(45, aspectRatio, 2.0f, 10000);
			
			exploraHijos(mundo,0);
		} catch (IOException e) {
			System.out.println("Error al cargar modelo 3D: " + e.getMessage());
		}
	}

	public void exploraHijos(Group grupo, int nivel) {
		int numHijos = grupo.getChildCount();
		
		String tab = "";
		for(int k=0;k<nivel;k++) {
			tab = tab + "   ";
		}
		
		for(int i=0;i<numHijos;i++) {
			Node nodo = grupo.getChild(i);
			System.out.println(tab + "Hijo " + i + ": " + nodo.getClass().getName());
			if(nodo instanceof Group) {
				System.out.println(tab + "Subhijos:");
				exploraHijos((Group)nodo, nivel + 1);
				System.out.println(tab + "Fin subhijos");
			}
		}
	}
	
	protected void showNotify() {
		tiempoInicial = System.currentTimeMillis();
		
		Thread t = new Thread(this);
		t.start();
	}

	public void run() {
		while(true) {
			long tiempo = System.currentTimeMillis() - tiempoInicial;
			int restante = mundo.animate(((int)tiempo) % 16000);

			if(downPressed) {
				coche.translate(-15.0f*(float)Math.cos(Math.toRadians(angulo)),0.0f,15.0f*(float)Math.sin(Math.toRadians(angulo)));
			}
			if(upPressed) {
				coche.translate(15.0f*(float)Math.cos(Math.toRadians(angulo)),0.0f,-15.0f*(float)Math.sin(Math.toRadians(angulo)));
			}
			if(leftPressed) {
				angulo = angulo + 5.0f;
				coche.setOrientation(angulo, 0.0f, 1.0f, 0.0f);
			}
			if(rightPressed) {
				angulo = angulo - 5.0f;
				coche.setOrientation(angulo, 0.0f, 1.0f, 0.0f);
			}
			
			repaint();
			
			try {
				Thread.sleep(40);
			} catch (InterruptedException e) {
			}
		}
	}
	
	protected void paint(Graphics g) {
		try {
			g3d.bindTarget(g);		
			g3d.render(mundo);
		} finally {
			g3d.releaseTarget();			
		}
	}

}