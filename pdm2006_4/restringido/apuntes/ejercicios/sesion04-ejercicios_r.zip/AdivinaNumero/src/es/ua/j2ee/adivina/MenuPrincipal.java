package es.ua.j2ee.adivina;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class MenuPrincipal extends List implements CommandListener {

	AdivinaMIDlet owner;

	Command selec;

	int itemNuevo;
	int itemSalir;

	public MenuPrincipal(AdivinaMIDlet owner) {
		super("Adivina n�mero", List.IMPLICIT);

		this.owner = owner;

		// A�ade opciones al menu
		itemNuevo = this.append("Nuevo juego", null);
		itemSalir = this.append("Salir", null);

		// Crea comandos
		selec = new Command("Seleccionar", Command.SCREEN, 1);
		this.addCommand(selec);
		this.setCommandListener(this);
	}
	
	public void commandAction(Command c, Displayable d) {
		if(c == selec || c == List.SELECT_COMMAND) {

			if(getSelectedIndex() == itemNuevo) {

				// Nuevo juego
				Display display = Display.getDisplay(owner);
				EntradaTexto et = new EntradaTexto(owner);
				display.setCurrent(et);

			} else if(getSelectedIndex() == itemSalir) {
				// Salir de la aplicaci�n
				try {
					owner.destroyApp(false);
					owner.notifyDestroyed();
				} catch(MIDletStateChangeException e) {
					// Evitamos salir de la aplicacion
				}				

			}

		} 
	}
}
