package es.ua.j2ee.adivina;

import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;
import javax.microedition.lcdui.*;

public class AdivinaMIDlet extends MIDlet {

	protected void startApp() throws MIDletStateChangeException {
		Display d = Display.getDisplay(this);
		MenuPrincipal mp = new MenuPrincipal(this);
		d.setCurrent(mp);
	}

	protected void pauseApp() {

	}

	protected void destroyApp(boolean arg0) throws MIDletStateChangeException {

	}

}
