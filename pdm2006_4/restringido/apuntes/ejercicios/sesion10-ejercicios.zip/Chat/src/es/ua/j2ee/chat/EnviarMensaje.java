package es.ua.j2ee.chat;

import java.io.*;
import javax.microedition.io.*;
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class EnviarMensaje extends TextBox implements CommandListener {

	MIDlet owner;
	Displayable previo;
	String url;

	Command cmdAtras;
	Command cmdEnviar;

	public EnviarMensaje(MIDlet owner, Displayable previo, String url) {
		super("Mensaje", "", 140, TextField.ANY);

		this.owner = owner;
		this.previo = previo;
		this.url = url;
		
		// Crea los comandos
		cmdAtras = new Command("Atras", Command.BACK, 1);
		cmdEnviar = new Command("OK", Command.OK, 1);
		this.addCommand(cmdAtras);
		this.addCommand(cmdEnviar);
		this.setCommandListener(this);

	}

	private void envia(String msg) throws IOException {
		HttpConnection con = (HttpConnection)Connector.open(url + "?accion=enviar");

		// Escribe mensaje en el POST
		OutputStream out = con.openOutputStream();
		DataOutputStream dos = new DataOutputStream(out);
		dos.writeUTF(msg);
		dos.close();
		out.close();

		if(con.getResponseCode() != HttpConnection.HTTP_OK) {
			throw new IOException();
		}
	}

	public void commandAction(Command cmd, Displayable disp) {

		if(cmd == cmdAtras) {

			// Vuelve a la pantalla anterior
			Display d = Display.getDisplay(owner);
			d.setCurrent(previo);

		} else if(cmd == cmdEnviar) {

			// Envia el mensaje
			HiloEnvio he = new HiloEnvio(this.getString());
			he.start();

		}

	}

	class HiloEnvio extends Thread {

		String msg;

		public HiloEnvio(String msg) {
			this.msg = msg;
		}

		public void run() {
			try {
				envia(msg);

				Display d = Display.getDisplay(owner);
				d.setCurrent(previo);			
			} catch(IOException e) {
				Alert a = new Alert("Error", "Error en la conexion", null, AlertType.ERROR);

				Display d = Display.getDisplay(owner);
				d.setCurrent(a, previo);			
			}
		}
	}

}
