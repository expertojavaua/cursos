/*
 * Created on 29-jun-2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package es.ua.j2ee.comun;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import es.ua.j2ee.chat.ListaChat;
import es.ua.j2ee.citas.ListaCitas;
import es.ua.j2ee.mensajes.ListaMensajes;

/**
 * @author Miguel Angel
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ListenerContexto implements ServletContextListener {

	/* (non-Javadoc)
	 * @see javax.servlet.ServletContextListener#contextInitialized(javax.servlet.ServletContextEvent)
	 */
	public void contextInitialized(ServletContextEvent sce) {
			ServletContext sc = sce.getServletContext();

			ListaChat listaChat = new ListaChat(20);
			sc.setAttribute("chat", listaChat);

			ListaMensajes listaMsg = new ListaMensajes();
			sc.setAttribute("mensajes", listaMsg);

			ListaCitas listaCitas = new ListaCitas();
			sc.setAttribute("citas", listaCitas);
	}

	/* (non-Javadoc)
	 * @see javax.servlet.ServletContextListener#contextDestroyed(javax.servlet.ServletContextEvent)
	 */
	public void contextDestroyed(ServletContextEvent arg0) {
		// TODO Auto-generated method stub

	}

}
