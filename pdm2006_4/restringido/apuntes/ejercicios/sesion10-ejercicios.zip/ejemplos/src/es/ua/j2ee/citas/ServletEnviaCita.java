/*
 * Created on 13-sep-2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package es.ua.j2ee.citas;

import java.io.*;
import java.util.Calendar;
import java.util.StringTokenizer;

import javax.servlet.*;
import javax.servlet.http.*;

/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ServletEnviaCita extends HttpServlet {

	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		ServletContext sc = this.getServletContext();
		ListaCitas lista = (ListaCitas)sc.getAttribute("citas");

		// Lee informacion del cliente

		String fecha = req.getParameter("fecha");
		String hora = req.getParameter("hora");
		String asunto = req.getParameter("asunto");
		String lugar = req.getParameter("lugar");
		String contacto = req.getParameter("contacto");
		String alarma = req.getParameter("alarma");

		Calendar cal = Calendar.getInstance();

		try {
			
			StringTokenizer stFecha = new StringTokenizer(fecha,"/");
			String sDia = stFecha.nextToken();
			String sMes = stFecha.nextToken();
			String sAny = stFecha.nextToken();
			StringTokenizer stHora = new StringTokenizer(hora,":");
			String sHora = stHora.nextToken();
			String sMin = stHora.nextToken();

			int iDia = Integer.parseInt(sDia);
			int iMes = Integer.parseInt(sMes);
			int iAny = Integer.parseInt(sAny);
			int iHora = Integer.parseInt(sHora);
			int iMin = Integer.parseInt(sMin);
			
			cal.set(Calendar.DAY_OF_MONTH, iDia);
			cal.set(Calendar.MONTH, iMes-1);
			cal.set(Calendar.YEAR, iAny);
			cal.set(Calendar.HOUR_OF_DAY, iHora);
			cal.set(Calendar.MINUTE, iMin);
		} catch(Exception e) {
			PrintWriter out = res.getWriter();
			out.println("Formato de fecha incorrecto");
			out.close();
			
			return;
		}
		
		// Crea mensaje
		
		Cita cita = new Cita();
		cita.setFecha(cal.getTime());
		cita.setAsunto(asunto);
		cita.setLugar(lugar);
		cita.setContacto(contacto);
		cita.setAlarma(alarma!=null);
		
		lista.addCita(cita);
		
		// Vuelve al menu
		
		res.sendRedirect(req.getContextPath() + "/citas/index.htm");		
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		doGet(req,res);
	}

}
