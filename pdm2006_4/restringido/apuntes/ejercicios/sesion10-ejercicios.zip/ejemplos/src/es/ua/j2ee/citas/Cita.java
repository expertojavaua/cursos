/*
 * Created on 21/06/2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package es.ua.j2ee.citas;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Date;

/**
 * @author Miguel Angel
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Cita {

	long ts;
	
	Date fecha;
	String asunto;
	String lugar;
	String contacto;
	boolean alarma;

	public Cita() {		
	}
	
	public Cita(Date fecha, String asunto, String descripcion, String lugar, String contacto, boolean alarma) {
		this.fecha = fecha;
		this.asunto = asunto;
		this.lugar = lugar;
		this.contacto = contacto;
		this.alarma = alarma;
	}
	
	public long getTs() {
		return ts;
	}
	public void setTs(long ts) {
		this.ts = ts;
	}
	public boolean isAlarma() {
		return alarma;
	}
	public void setAlarma(boolean alarma) {
		this.alarma = alarma;
	}
	public String getAsunto() {
		return asunto;
	}
	public void setAsunto(String asunto) {
		this.asunto = asunto;
	}
	public String getContacto() {
		return contacto;
	}
	public void setContacto(String contacto) {
		this.contacto = contacto;
	}
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	public String getLugar() {
		return lugar;
	}
	public void setLugar(String lugar) {
		this.lugar = lugar;
	}
	
	public void serialize(DataOutputStream dos) throws IOException {
		dos.writeLong(fecha.getTime());
		dos.writeUTF(asunto);
		dos.writeUTF(lugar);
		dos.writeUTF(contacto);
		dos.writeBoolean(alarma);		
	}
	
	public static Cita deserialize(DataInputStream dis) throws IOException {
		Cita cita = new Cita();
		
		cita.setFecha(new Date(dis.readLong()));
		cita.setAsunto(dis.readUTF());
		cita.setLugar(dis.readUTF());
		cita.setContacto(dis.readUTF());
		cita.setAlarma(dis.readBoolean());
		
		return cita;
	}
}
