package es.ua.j2ee.sw.hola;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface HolaMundoIF extends Remote {
	public String saluda(String nombre) throws RemoteException;
}
