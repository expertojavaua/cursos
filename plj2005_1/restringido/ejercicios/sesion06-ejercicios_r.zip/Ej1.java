
public class Ej1
{
	public static int divide (int dividendo, int divisor) throws NumeroNaturalException
	{
		if (divisor == 0)
			throw new IllegalArgumentException("Divisor incorrecto");
		if (dividendo < 0 || divisor < 0)
			throw new NumeroNaturalException("La division no es natural");
		return dividendo / divisor;
	}
	
	public static void main (String[] args)
	{
		int dividendo=1, divisor=1;
		
		try
		{
			dividendo = Integer.parseInt(args[0]);
			divisor = Integer.parseInt(args[1]);
		} catch (ArrayIndexOutOfBoundsException e) {
			System.out.println ("Faltan parametros");
			System.exit(-1);
		} catch (NumberFormatException e2) {
			System.out.println ("Formato incorrecto del parametro");
			System.exit(-1);
		}
		
		try
		{
			System.out.println("Resultado: " + divide(dividendo, divisor));
		} catch (IllegalArgumentException e3) {
			e3.printStackTrace();
		} catch (NumeroNaturalException e4) {
			System.out.println ("Error: " + e4.getMessage());
			System.exit(-1);
		}
		
	}
}
