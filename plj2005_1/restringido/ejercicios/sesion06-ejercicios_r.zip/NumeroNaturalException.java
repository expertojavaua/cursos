
public class NumeroNaturalException extends Exception
{
	public NumeroNaturalException(String mensaje)
	{
		super(mensaje);
	}
}