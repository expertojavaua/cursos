
public class Ej1
{
	public static int divide (int dividendo, int divisor)
	{
		return dividendo / divisor;
	}
	
	public static void main (String[] args)
	{
		String param1=null, param2=null;
		int dividendo=0, divisor=0;
		
		param1 = args[0];
		param2 = args[1];
		
		dividendo = Integer.parseInt(param1);
		divisor = Integer.parseInt(param2);
		
		System.out.println("Resultado: " + divide(dividendo, divisor));
		
	}
}