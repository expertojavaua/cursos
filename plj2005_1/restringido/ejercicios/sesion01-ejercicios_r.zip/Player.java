public class Player {
 int number;
 
 public void guess() {
     number = (int) (Math.random()* 10);
 }
}
