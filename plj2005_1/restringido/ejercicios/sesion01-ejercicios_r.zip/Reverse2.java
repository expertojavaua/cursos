public class Reverse2 {
    public static void main(String[] args) {
        int i = args.length-1;

        while (i >= 0) {
            String str = args[i];
            int j = str.length()-1;

            // imprimo la cadena al reves
            while (j >= 0) {
                System.out.print(args[i].charAt(j));
                j--;
            }
            System.out.print(":");
            i--;
        }
        
        System.out.println();
    }
}
