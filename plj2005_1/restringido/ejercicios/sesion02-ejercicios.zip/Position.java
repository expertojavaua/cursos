
package plj.geom;

public class Position {
    public double x;
    public double y;
}
