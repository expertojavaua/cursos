package geom;

import java.awt.Graphics;

public abstract class Figura implements java.io.Serializable
{
	public abstract String imprime();
	public abstract void dibuja(Graphics g);
}