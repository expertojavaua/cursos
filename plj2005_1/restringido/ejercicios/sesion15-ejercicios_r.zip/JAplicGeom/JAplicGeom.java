import io.*;
import geom.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class JAplicGeom extends JFrame implements ActionListener
{
	String fichero;
	ArrayList figuras = new ArrayList();
	Figura figActual = null;
	MiCanvas mc = new MiCanvas();
	JRadioButton btnCirculo;
	JRadioButton btnRectangulo;
	JRadioButton btnLinea;	
	int xIni, yIni, xFin, yFin;
	
	public JAplicGeom()
	{
		setSize(400, 300);
		
		// Canvas
		
		getContentPane().add(mc, BorderLayout.CENTER);
		
		// Botones y etiqueta de estado
		
		JPanel panelBotones = new JPanel();
		btnCirculo = new JRadioButton("Circulo", true);
		btnCirculo.addActionListener(this);
		btnRectangulo = new JRadioButton("Rectangulo");
		btnRectangulo.addActionListener(this);
		btnLinea = new JRadioButton("Linea");
		btnLinea.addActionListener(this);
			
		panelBotones.add(btnCirculo);
		panelBotones.add(btnRectangulo);
		panelBotones.add(btnLinea);
		
		getContentPane().add(panelBotones, BorderLayout.SOUTH);
		
		// Menus
		
		JMenuBar mb = new JMenuBar();
		JMenu m = new JMenu("Archivo");
		JMenuItem mi;
		
		mi = new JMenuItem("Abrir");
		mi.addActionListener(this);
		m.add(mi);
		
		mi = new JMenuItem("Guardar");
		mi.addActionListener(this);
		m.add(mi);
		
		mi = new JMenuItem("Salir");
		mi.addActionListener(this);
		m.add(mi);
		
		mb.add(m);
		this.setJMenuBar(mb);
		
		
		// Evento de cerrar la ventana
		
		this.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			}
		});
	}
	
	public void actionPerformed(ActionEvent e)
	{
		if (e.getActionCommand().equals("Abrir"))
		{
			JFileChooser jfc = new JFileChooser(".");
			int result = jfc.showOpenDialog(this);
			if (result == JFileChooser.APPROVE_OPTION)
			{
				fichero = jfc.getSelectedFile().getAbsolutePath();
				Figura[] figs = IOFiguras.leeFiguras(fichero);
				figuras = new ArrayList();
				if (figs != null)
					for (int i = 0; i < figs.length; i++)
						figuras.add(figs[i]);
				repaint();
			}
		} else if (e.getActionCommand().equals("Guardar")) {
			JFileChooser jfc = new JFileChooser(".");
			int result = jfc.showSaveDialog(this);
			if (result == JFileChooser.APPROVE_OPTION)
			{
				fichero = jfc.getSelectedFile().getAbsolutePath();
				Figura[] figs = (Figura[])(figuras.toArray(new Figura[0]));
				IOFiguras.guardaFiguras(figs, fichero);
			}
		} else if (e.getActionCommand().equals("Salir")) {
			System.exit(0);
		} else if (e.getActionCommand().equals("Circulo")) {
			btnCirculo.setSelected(true);
			btnRectangulo.setSelected(false);
			btnLinea.setSelected(false);
		} else if (e.getActionCommand().equals("Rectangulo")) {
			btnCirculo.setSelected(false);
			btnRectangulo.setSelected(true);
			btnLinea.setSelected(false);
		} else if (e.getActionCommand().equals("Linea")) {
			btnCirculo.setSelected(false);
			btnRectangulo.setSelected(false);
			btnLinea.setSelected(true);
		}
	}
	
	public static void main(String[] args)
	{
		JAplicGeom jag = new JAplicGeom();
		jag.show();
	}
	
	class MiCanvas extends JPanel
	{
		Image backbuffer;
		
		public MiCanvas()
		{
			this.addMouseListener(new MouseAdapter()
			{
				public void mousePressed(MouseEvent e)
				{
					xIni = xFin = e.getX();
					yIni = yFin = e.getY();
					
					if (btnCirculo.isSelected())
					{
						figActual = new Circulo(xIni, yIni, 0);
					} else if (btnRectangulo.isSelected()) {
						figActual = new Rectangulo(xIni, yIni, xFin, yFin);
					} else if (btnLinea.isSelected()) {
						figActual = new Linea(xIni, yIni, xFin, yFin);
					}
				}
				
				public void mouseReleased(MouseEvent e)
				{
					xFin = e.getX();
					yFin = e.getY();
					figuras.add(figActual);
					figActual = null;
					repaint();
				}
			});
			
			this.addMouseMotionListener(new MouseMotionAdapter()
			{
				public void mouseDragged(MouseEvent e)
				{
					xFin = e.getX();
					yFin = e.getY();

					if (btnCirculo.isSelected())
					{
						((Circulo)figActual).setX((xIni + xFin) / 2);
						((Circulo)figActual).setY((yIni + yFin) / 2);
						((Circulo)figActual).setRadio(Math.min(Math.abs(xIni - xFin), Math.abs(yIni - yFin)));
					} else if (btnRectangulo.isSelected()) {						
						((Rectangulo)figActual).setX1(Math.min(xIni, xFin));
						((Rectangulo)figActual).setY1(Math.min(yIni, yFin));
						((Rectangulo)figActual).setX2(Math.max(xIni, xFin));
						((Rectangulo)figActual).setY2(Math.max(yIni, yFin));
					} else if (btnLinea.isSelected()) {
						((Linea)figActual).setX2(xFin);
						((Linea)figActual).setY2(yFin);
					}

					repaint();
				}
			});
		}
		
		public void update(Graphics g)
		{
			paint(g);
		}
		
		public void paint(Graphics g)
		{
			if(backbuffer == null)
				backbuffer = createImage(getWidth(), getHeight());
	
			// Dibujamos los gr�ficos en el backbuffer
	
			Graphics off_g = backbuffer.getGraphics();			
			off_g.clearRect(0, 0, getWidth(), getHeight());
			for (int i = 0; i < figuras.size(); i++)
			{
				Figura f = (Figura)(figuras.get(i));
				f.dibuja(off_g);
			}
			if (figActual != null)
				figActual.dibuja(off_g);
	
			// Volcamos el backbuffer a pantalla
	
			g.drawImage(backbuffer, 0, 0, getWidth(), getHeight(), this);
			g.dispose();
		}
	}
}