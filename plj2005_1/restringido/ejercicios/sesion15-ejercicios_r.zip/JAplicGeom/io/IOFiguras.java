package io;

import geom.*;
import java.io.*;
import java.util.*;

public class IOFiguras
{
	public static Figura[] leeFiguras(String fichero)
	{
		ArrayList alAux = new ArrayList();

		try
		{
			Figura f;
			ObjectInputStream oin = new ObjectInputStream (new FileInputStream(fichero));

			while ((f = (Figura)(oin.readObject())) != null)
				alAux.add(f);
			
			oin.close();
			
		} catch (Exception e) {}
		
		if (alAux.size() == 0)
			return null;
		return((Figura[])(alAux.toArray(new Figura[0])));
	}
	
	public static void guardaFiguras(Figura[] figuras, String fichero)
	{
		try
		{
			ObjectOutputStream oout = new ObjectOutputStream (new FileOutputStream(fichero));

			for (int i = 0; i < figuras.length; i++)
				oout.writeObject(figuras[i]);
			
			oout.close();
			
		} catch (Exception e) {}
	}
}