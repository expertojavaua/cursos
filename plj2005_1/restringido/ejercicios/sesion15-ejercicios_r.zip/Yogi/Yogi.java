import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
  * Juego del oso Yogi cogiendo comida que cae del cielo
  */
public class Yogi extends JFrame implements Runnable
{
	public static final int T_ESTADO_INI = 0;			// Estado: iniciar juego
	public static final int T_ESTADO_JUGANDO = 1;		// Estado: jugando
	public static final int T_ESTADO_FIN = 2;			// Estado: juego terminado
	
	public static final int INC_MOV_YOGI = 3;			// Incremento de movimientos, o distancia en pixeles entre dos posiciones consecutivas (de Yogi)
	public static int INC_MOV_COMIDA = 2;				// Incremento de movimientos, o distancia en pixeles entre dos posiciones consecutivas (de las comidas)
	public static final int ANCHO = 400;				// Anchura del area grafica
	public static final int ALTO = 300;					// Altura del area grafica
	int ancho;											// Anchura de pantalla completa
	int alto;											// Altura de pantalla completa
	
	Image backbuffer = null;							// Imagen para hacer el doble buffer al dibujar cada frame de la animacion
	Image fondo = null;									// Imagen de fondo
	SpriteYogi sprn = null;								// Sprites de Yogi
	SpriteVida vida = null;								// Sprite para vidas
	LinkedList comidas = new LinkedList();				// Sprites de comidas que caen de arriba
	
	Font fuentePuntos;									// Fuente para mostrar los puntos
	FontMetrics fmPuntos;								// Metrica de la fuente de puntos
	
	int numFrame = 0;									// Frame actual de animacion de Yogi
	int xIni = ANCHO/2;									// Posicion X actual de Yogi
	int numVidas = 3;									// Numero de vidas restantes
	int puntos = 0;										// Numero de comidas recogidas
	int estado = T_ESTADO_INI;							// Estado inicial del juego
	
	// Secuencias animacion Yogi
	int[] secuenciaDer = { 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2};
	int[] secuenciaIzq = { 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5};
	
	// Hilo que va generando comidas y comprobando colisiones, vidas y puntos
	Thread t = new Thread(this);
	
	/**
	  * Constructor: establece el dispositivo, elige el modo grafico e inicia la animacion
	  */
	public Yogi()
	{		
		// Quitamos la barra superior de la ventana
		this.setUndecorated(true);
		
		// Obtenemos ciertos parametros de dibujo
		fuentePuntos = new Font("Arial", Font.BOLD | Font.ITALIC, 15);
		
		// Tomamos el dispositivo grafico
		GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
		GraphicsDevice gd = ge.getDefaultScreenDevice();
		
		// Mostramos dialogo para elegir un modo grafico
		DlgModos dlg = new DlgModos(gd, this);
		dlg.show();
		DisplayMode modo = dlg.modoSeleccionado;
		if (modo != null)
		{
			ancho = modo.getWidth();
			alto = modo.getHeight();
		}
		
		// Cargamos las imagenes
		sprn = new SpriteYogi();
		vida = new SpriteVida();
		Toolkit tk = Toolkit.getDefaultToolkit();
		fondo = tk.createImage("bosque.jpg");
		fondo = fondo.getScaledInstance(ancho, alto, Image.SCALE_DEFAULT);
		MediaTracker mt = new MediaTracker(this);
		mt.addImage(fondo, 1);
		try 
		{
			mt.waitForAll();
		} catch (Exception e) { e.printStackTrace(); }
		
		// Eventos de teclado
		addKeyListener(new KeyAdapter()
		{
			public void keyPressed(KeyEvent e)
			{
				if (e.getKeyCode()==KeyEvent.VK_ESCAPE)
				{
					System.exit(0);
				} else if (e.getKeyCode()==KeyEvent.VK_S)
				{
					// Pulsar S: iniciar partida
					estado = T_ESTADO_JUGANDO;
					t.start();
				} else if (e.getKeyCode()==KeyEvent.VK_LEFT && estado == T_ESTADO_JUGANDO) {
					// Pulsar flecha izq: mover a Yogi hacia la izq. (si se puede)
					sprn.setFrame(secuenciaIzq[numFrame]);
					if (xIni > 0 + INC_MOV_YOGI)
						xIni -= INC_MOV_YOGI;
					numFrame = (numFrame+1) % secuenciaIzq.length;
				} else if (e.getKeyCode()==KeyEvent.VK_RIGHT && estado == T_ESTADO_JUGANDO) {
					// Pulsar flecha der: mover a Yogi hacia la der. (si se puede)
					sprn.setFrame(secuenciaDer[numFrame]);
					if (xIni < ANCHO - SpriteYogi.ANCHO - INC_MOV_YOGI)
						xIni += INC_MOV_YOGI;
					numFrame = (numFrame+1) % secuenciaIzq.length;
				}
				repaint();
			}
		});
		
		// Obtenemos la pantalla completa, mostrando previamente si se puede tener o no:
		System.out.println ("Pantalla completa soportada: " + (gd.isFullScreenSupported()?"SI":"NO"));
		try
		{ 
			Thread.currentThread().sleep(3000);
		} catch (Exception e) {}
		gd.setFullScreenWindow(this);		
		gd.setDisplayMode(dlg.modoSeleccionado);
		
		// Comenzamos la animacion
		sprn.setFrame(numFrame);		
	}
	
	/**
	  * Actualiza el contexto gr�fico del frame: en nuestro caso, solo llama a paint
	  */
	public void update(Graphics g)
	{
		paint(g);
	}
	
	/**
	  * Redibuja el contexto grafico del frame: dibuja la imagen en el backbuffer, 
	  * y luego la vuelca sobre el frame
	  */
	public void paint(Graphics g)
	{
		if(backbuffer == null)
			backbuffer = createImage(ANCHO, ALTO);

		// Dibujamos los gr�ficos en el backbuffer

		Graphics off_g = backbuffer.getGraphics();
		dibuja(off_g);

		// Volcamos el backbuffer a pantalla

		g.drawImage(backbuffer, 0, 0, ancho, alto, this);
		g.dispose();
	}
	
	/**
	  * Dibuja cada frame de animacion
	  */
	public void dibuja(Graphics g)
	{		
		// Limpiar area
		g.clearRect(0, 0, ANCHO, ALTO);
		
		// Dibujar fondo
		g.drawImage(fondo, 0, 0, ANCHO, ALTO, this);
		
		// Dibujar vidas y puntuaci�n
		g.setColor(Color.yellow);
		g.setFont(fuentePuntos);
		fmPuntos = g.getFontMetrics(fuentePuntos);
		g.drawString("Puntos: " + puntos, 5, fmPuntos.getAscent() + 5);
		for (int i = 1; i <= numVidas; i++)
			g.drawImage(vida.sprites, ANCHO - i*vida.ANCHO, 0, vida.ANCHO, vida.ALTO, this);
		
		if (estado == T_ESTADO_JUGANDO)
		{
			// Dibujar comidas
			for (int i = 0; i < comidas.size(); i++)
			{
				Shape clip = g.getClip();
				NodoComida nc = (NodoComida)(comidas.get(i));			
				g.setClip(nc.x, nc.y, SpriteComida.ANCHO, SpriteComida.ALTO);
				g.drawImage(nc.sc.sprites, nc.x - nc.sc.x, nc.y, nc.sc.width, nc.sc.height, this);
				g.setClip(clip);
			}
		}
		
		// Dibujar a Yogi
		Shape clip = g.getClip();
		g.setClip(xIni, ALTO - SpriteYogi.ALTO, SpriteYogi.ANCHO, SpriteYogi.ALTO);		
		g.drawImage(sprn.sprites, xIni - sprn.x, ALTO - SpriteYogi.ALTO, sprn.width, sprn.height, this);
		g.setClip(clip);
		
		// Dibujar mensaje de pantalla inicial si toca
		if (estado == T_ESTADO_INI)
		{
			Font f = new Font("Arial", Font.BOLD, 30);
			String s = "Pulsa S para comenzar";
			g.setFont(f);
			FontMetrics fm = g.getFontMetrics(f);
			g.setColor(Color.green);
			g.drawString(s, ANCHO/2 - fm.stringWidth(s)/2, ALTO/2 - fm.getAscent()/2);
		}

		// Dibujar mensaje de fin de juego si toca
		if (estado == T_ESTADO_FIN)
		{
			Font f = new Font("Arial", Font.BOLD | Font.ITALIC, 15);
			String s = "JUEGO TERMINADO. Pulsa Esc";
			g.setFont(f);
			FontMetrics fm = g.getFontMetrics(f);
			g.setColor(Color.red);
			g.drawString(s, ANCHO/2 - fm.stringWidth(s)/2, ALTO/2 - fm.getAscent()/2);
		}
		
		// Liberar recursos
		g.dispose();
	}
	
	/**
	  * Metodo principal del hilo
	  */
	public void run()
	{
		Random r = new Random();
		
		while (true && estado == T_ESTADO_JUGANDO)
		{
			// Actualizar la posicion de cada comida
			for (int i = 0; i < comidas.size(); i++)
			{
				NodoComida nc = (NodoComida)(comidas.get(i));
				nc.y += INC_MOV_COMIDA;
			}
			
			if (comidas.size() != 0)
			{
				NodoComida nc = (NodoComida)(comidas.getLast());
			
				// Eliminar la comida y quitar vida si ha tocado el suelo
				if (nc.y >= ALTO - SpriteComida.ALTO - INC_MOV_COMIDA)
				{
					numVidas--;
					if (numVidas == 0)
						estado = T_ESTADO_FIN;
					comidas.removeLast();
				}
				
				// Eliminar la comida y aumentar puntos si esta tocando a Yogi
				// Consideramos que lo toca si alguna parte est� dentro de los 
				// limites del cuadro que ocupa Yogi
				if ((nc.y + SpriteComida.ALTO) >= ALTO - SpriteYogi.ALTO)
				{
					int centroideComida = nc.x + (SpriteComida.ANCHO/2);
					if (centroideComida >= xIni && centroideComida <= xIni + SpriteYogi.ANCHO)
					{
						puntos++;
						INC_MOV_COMIDA = 2 + puntos/5;
						comidas.removeLast();
					}
				}
			}
			
			// Generar nueva comida si se ha caido al suelo o la ha cogido Yogi
			if (comidas.size() == 0)
			{
				int frameComida = r.nextInt(3);
				int x = r.nextInt(ANCHO - SpriteComida.ANCHO - 10) + 5;
				SpriteComida sc = new SpriteComida();
				sc.setFrame(frameComida);
				NodoComida nc = new NodoComida(sc, x, 0);
				comidas.addFirst(nc);
			}
			
			repaint();
			
			try
			{
				Thread.currentThread().sleep(100);
			} catch (Exception e) {}
		}
	}
	
	/**
	  * Metodo principal
	  */
	public static void main(String[] args)
	{
		Yogi y = new Yogi();
		y.show();
	}
}

/**
  * Esta clase muestra un cuadro de dialogo para elegir uno 
  * de los modos graficos disponibles
  */
class DlgModos extends JDialog
{
	DisplayMode [] modes;				// Modos graficos disponibles
	DisplayMode modoSeleccionado;		// Modo grafico finalmente seleccionado
	String [] smodes;					// Cadenas descriptivas de cada modo grafico
	JList lstModos;						// Lista de modos graficos
	JDialog dlg = this;					// Puntero a este dialogo
	
	public DlgModos(GraphicsDevice gd, JFrame padre)
	{
		super(padre, true);
		setSize (300, 300);
		
		// Obtenemos los modos graficos, los pasamos a cadena, y los metemos en la lista
		modes = gd.getDisplayModes();
		smodes = new String[modes.length];
		for(int i=0;i<modes.length;i++) 
			smodes[i] = modes[i].getWidth() + "x" + modes[i].getHeight() + ", " + modes[i].getBitDepth() + "bpp, " + modes[i].getRefreshRate() + " Hz";
		lstModos = new JList(smodes);		
		JScrollPane scrll = new JScrollPane(lstModos);
		
		// Boton para confirmar la eleccion de un modo grafico
		JButton btnAceptar = new JButton("Aceptar");
		btnAceptar.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				if (lstModos.getSelectedIndex() != -1)
				{
					System.out.println ("Cambiando a modo " + smodes[lstModos.getSelectedIndex()]);
					modoSeleccionado = modes[lstModos.getSelectedIndex()];
					dlg.hide();
				}
			}
		});
		
		// Colocamos los componentes
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(scrll, BorderLayout.CENTER);
		getContentPane().add(btnAceptar, BorderLayout.SOUTH);
	}
}

/**
  * Clase que representa la imagen de Yogi en pantalla
  */
class SpriteYogi
{
	public static final int ALTO = 65;		// Altura de Yogi
	public static final int ANCHO = 35;		// Anchura de Yogi

	Image sprites;							// Conjunto de sprites de Yogi
	int x;									// Posicion del sprite que se dibujara en cada momento
	int width;								// Anchura del conjunto de sprites
	int height;								// Altura del conjunto de sprites
	
	/**
	  * Constructor. Carga los sprites, su ancho y su alto, y establece la x del sprite inicial
	  */
	public SpriteYogi()
	{
		Toolkit tk = Toolkit.getDefaultToolkit();
		sprites = tk.createImage("yogi.png");
		width = 210;
		height = 64;
		x = 0;
	}
	
	/**
	  * Cambia a un determinado sprite de Yogi
	  */
	public void setFrame(int frame)
	{
		x = frame * ANCHO;		
	}
}

/**
  * Clase para dibujar las caras de vida de Yogi
  */
class SpriteVida
{
	public static final int ALTO = 25;		// Alto del sprite
	public static final int ANCHO = 25;		// Ancho del sprite

	Image sprites;							// Sprite con la cara de vida
	
	public SpriteVida()
	{
		Toolkit tk = Toolkit.getDefaultToolkit();
		sprites = tk.createImage("vida.png");
	}	
}

/**
  * Clase para dibujar las comidas que caen de arriba
  */
class SpriteComida
{
	public static final int ALTO = 20;		// Alto de cada comida
	public static final int ANCHO = 20;		// Ancho de cada comida

	Image sprites;							// Sprite con todas las comidas disponibles
	int x;									// Coordenada X de la comida que va a dibujarse
	int width;								// Anchura del sprite de comidas
	int height;								// Altura del sprite de comidas
	
	/**
	  * Constructor. Carga los sprites, establece su anchura y altura, y el sprite inicial
	  */
	public SpriteComida()
	{
		Toolkit tk = Toolkit.getDefaultToolkit();
		sprites = tk.createImage("food.png");
		width = 60;
		height = 20;
		x = 0;
	}
	
	/**
	  * Cambia a un sprite determinado (muestra otra comida)
	  */
	public void setFrame(int frame)
	{
		x = frame * ANCHO;		
	}
}

/**
  * El juego se deja hecho para que puedan caer varias comidas a la vez. Ello implica utilizar
  * una lista, y esta clase muestra cada elemento de esa lista, con el sprite de comida que se
  * mostrara, y su posicion x e y
  */
class NodoComida
{
	int x;
	int y;
	SpriteComida sc;
	
	public NodoComida(SpriteComida sc, int x, int y)
	{
		this.x = x;
		this.y = y;
		this.sc = sc;
	}	
}