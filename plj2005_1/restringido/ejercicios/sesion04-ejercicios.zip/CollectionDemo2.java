package modulo1.sesion4;

import java.util.*;

public class CollectionDemo2 {

    public static void main(String args[]) {
        // Creo una coleccion de objetos
        List list = new ArrayList();

        // Anyado elementos a la colecci�n
        list.add(new Integer(50));
        list.add(new Integer(-1));
        list.add(new Integer(35));

        // Creo un TreeSet a partir de la lista
        
        TreeSet set = new TreeSet(list);
        
        // Anyado otros elementos al conjunto
        
        set.add(new Integer(99));
        set.add(new Integer(-5));
        
        // Obtengo un iterador del conjunto y lo recorro
        for (Iterator i = set.iterator(); i.hasNext();) {
            System.out.print(i.next()+" ");
        }
    }
}