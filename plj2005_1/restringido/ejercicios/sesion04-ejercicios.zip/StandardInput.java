package modulo1.sesion4;

import java.io.*;

public class StandardInput {
    public static void main(String[] args) throws IOException {
        BufferedReader in = new BufferedReader(new InputStreamReader(System.in));

        for (;;) {
            System.out.print("StandardInput> ");
            String line = in.readLine();
            // El programa termina cuando llegamos al fin del
            // fichero o el usuario introduce quit
            if ((line == null) || line.equals("quit"))
                break;
            // Parsea la linea y calcula la raiz cuadrada
            try {
                double x = Double.parseDouble(line);
                System.out.println("raiz cuadrada de " + x + " = "
                        + Math.sqrt(x));
            }
            // Si algo falla muestra un mensaje de error
            catch (Exception e) {
                System.out.println("Entrada erronea");
            }
        }
    }
}

