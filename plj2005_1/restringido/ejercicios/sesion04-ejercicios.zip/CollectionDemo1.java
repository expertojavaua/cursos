package modulo1.sesion4;

import java.util.*;

public class CollectionDemo1 {

    public static void main(String args[]) {
        // Creo una coleccion de objetos
        List list = new ArrayList();

        // Anyado elementos a la colecci�n
        list.add("This is a String");
        list.add(new Short((short) 12));
        list.add(new Integer(35));

        // Obtengo un iterador de la lista y lo recorro
        for (Iterator i = list.iterator(); i.hasNext();) {
            System.out.print(i.next()+ " ");
        }
    }
}