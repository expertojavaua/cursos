package modulo1.sesion4;

import plj.geom.Position;

public class Bumper extends Sensor {
    boolean bumped;

    /**
     * doReadings() actualiza bumped. 
     * true -> si ha habido un contacto 
     * false -> si el sensor no ha chocado con nada
     */
    public void doReadings() {
    }

    public boolean bumped() {
        return bumped;
    }

    public Position getPos() {
        return null;
    }

    public double angle() {
        return 0;
    }
}