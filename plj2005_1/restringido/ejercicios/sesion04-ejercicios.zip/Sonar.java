package modulo1.sesion4;

import plj.geom.Position;

public class Sonar extends Sensor {
    double[] readings;
    int resolution;    // numero de lecturas
    int rangeMax;      // maximo alcance
    double angleMax;   // arco del sonar
    
    public Sonar(int resolution, int rangeMax, double angleMax){
        this.resolution = resolution;
        this.rangeMax = rangeMax;
        this.angleMax = angleMax;
    }

    public double[] getReadings() {
        return readings;
    }

    /**
     * doReadings() actualiza el array readings
     * con todas las lecturas de distancias 
     * de objetos frente al sonar en la direccion
     * angle() y en un arco y una resolucion definida por 
     * el tipo de sonar
     */
    public void doReadings() {
    }

    public Position getPos() {
        return null;
    }

    public double angle() {
        return 0;
    }
}