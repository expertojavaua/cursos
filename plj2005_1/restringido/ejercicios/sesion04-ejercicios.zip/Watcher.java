package modulo1.sesion4;

import plj.geom.*;

/**
 * La interfaz Watcher especifica una posici�n y una
 * direcci�n en la que se mira. Ambos datos est�n referidos
 * a un sistema de referencia (mapa) global. 
 */
public interface Watcher {
    public Position getPos();
    public double angle();
}