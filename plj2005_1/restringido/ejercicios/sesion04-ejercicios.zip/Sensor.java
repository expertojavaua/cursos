package modulo1.sesion4;

public abstract class Sensor implements Watcher {
    int state;
    private long time;

    public abstract void doReadings();

    public int getState() {
        return state;
    }

    public void fire() {
        time = System.currentTimeMillis();
        doReadings();
    }

    public long lastTimeFired() {
        return time;
    }
}