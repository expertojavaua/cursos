
package modulo1.sesion4;
import java.util.Arrays;

public class ArrayDemo2 {
    public static void main(String args[]) {
        int vec[] = {-5, 19, 23, 37, 47, 56};
        int slot = Arrays.binarySearch(vec, 35);
        slot = -(slot + 1);
        System.out.println("punto de inserion = " + slot);
    }
}