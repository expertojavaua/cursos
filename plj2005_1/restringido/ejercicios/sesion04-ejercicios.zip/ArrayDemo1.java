package modulo1.sesion4;

import java.util.Arrays;

public class ArrayDemo1 {
    public static void main(String args[]) {
        //int vec[] = { 37, 47, 23, -5, 19, 56 };
        String vec[] = {"hola","que","tal"};
        Arrays.sort(vec);
        for (int i = 0; i < vec.length; i++) {
            System.out.println(vec[i]);
        }
    }
}

