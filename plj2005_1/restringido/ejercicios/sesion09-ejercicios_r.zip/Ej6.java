import java.io.*;

public class Ej6
{
	public Ej6()
	{
		try
		{
			StreamTokenizer st = new StreamTokenizer(new FileReader("matriz.txt"));
			st.commentChar(';');
			int t;
			int[][] matriz;
			int filas, columnas;
			
			// Filas
			st.nextToken();
			filas = (int)(st.nval);
			
			// Columnas
			st.nextToken();
			columnas = (int)(st.nval);
	
			// Inicializamos y vamos rellenando la matriz
			
			matriz = new int[filas][columnas];
			
			for (int i = 0; i < filas; i++)
				for (int j = 0; j < columnas; j++)
				{
					t = st.nextToken();
					if (t != StreamTokenizer.TT_EOF)
					{
						matriz[i][j] = (int)(st.nval);
					}
				}				
	
			// Calculamos los cuadrados
			
			for (int i = 0; i < filas; i++)
				for (int j = 0; j < columnas; j++)
				{
					matriz[i][j] = (int)(Math.pow(matriz[i][j], 2));
				}				
			
			// Volcamos la salida a fichero
			
			PrintWriter pw = new PrintWriter (new FileWriter("matrizSal.txt"));
			pw.println ("; Matriz resultado");
			pw.println ("" + filas + " " + columnas);
			for (int i = 0; i < filas; i++)
			{
				for (int j = 0; j < columnas; j++)
				{
					pw.print("" + matriz[i][j] + " ");
				}				
				pw.println();
			}
			pw.close();
			
		} catch (Exception e) {}
	}
	
	public static void main (String[] args)
	{
		new Ej6();
	}
}