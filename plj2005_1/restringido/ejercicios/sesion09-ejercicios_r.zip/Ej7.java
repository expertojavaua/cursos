import java.io.*;
import java.util.*;

public class Ej7
{
	public Ej7()
	{
		try
		{
			ObjetoFichero of = new ObjetoFichero ("cad1", 1, 1.5);
			of.addCadena("cad2");
			of.addCadena("cad3");

			ObjetoFichero of2 = new ObjetoFichero ("cad1b", 2, 2.5);
			of2.addCadena("cad2b");
			of2.addCadena("cad3b");
			
			// Escribimos el fichero
			
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("ficheroObj.dat"));
			oos.writeObject(of);
			oos.writeObject(of2);
			oos.close();
			
			// Leemos el fichero
			
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream("ficheroObj.dat"));
			ObjetoFichero ofLeido1 = (ObjetoFichero)(ois.readObject());
			ObjetoFichero ofLeido2 = (ObjetoFichero)(ois.readObject());
			
			System.out.println(ofLeido1.imprimeObj());
			System.out.println("\r\n\r\n");
			System.out.println(ofLeido2.imprimeObj());
			
		} catch (Exception e) {}
	}
	
	public static void main (String[] args)
	{
		new Ej7();
	}
}

class ObjetoFichero implements Serializable
{
	String cadena;
	int valorInt;
	double valorDouble;
	Vector cadenas;
	
	public ObjetoFichero(String cadena, int valorInt, double valorDouble)
	{
		this.cadena = cadena;
		this.valorInt = valorInt;
		this.valorDouble = valorDouble;
		cadenas = new Vector();
		cadenas.addElement(cadena);
	}
	
	public void addCadena(String cadena)
	{
		cadenas.addElement(cadena);
	}
	
	public String imprimeObj()
	{
		String res =  "Cadena = " + cadena + "\r\n";
		res += "valorInt = " + valorInt + "\r\n";
		res += "valorDouble = " + valorDouble + "\r\n";
		res += "vector:\r\n";
		
		for (int i = 0; i < cadenas.size(); i++)
			res += (String)(cadenas.elementAt(i)) + "\r\n";
		
		return res;
	}
}