import java.io.*;
import java.util.*;

public class Ej5
{
	public Ej5()
	{
		try
		{
			Properties p = new Properties();
			p.load(new FileInputStream("prop.txt"));
			Enumeration en = p.propertyNames();
			BufferedReader in = new BufferedReader( new InputStreamReader( System.in ) );		
			while (en.hasMoreElements())
			{
				String prop = (String)(en.nextElement());
				System.out.println("Introduzca valor para propiedad " + prop);
				String valor = in.readLine();
				p.setProperty(prop, valor);
			}
			p.store(new FileOutputStream("prop.txt"), "Cabecera del fichero");
			in.close();
			
		} catch (Exception e) {}
	}
	
	public static void main(String[] args)
	{
		new Ej5();
	}
}