import java.io.*;
import java.util.*;

public class Ej4
{
	String cabecera = "# Esto es la cabecera del fichero que hay que introducir\r\n";
	
	public Ej4()
	{
	}
	
	public void leeEscribeStream()
	{
		try
		{
			FileInputStream in = new FileInputStream("entrada.dat");
			FileOutputStream out = new FileOutputStream("salidaStream.dat");
			byte[] b = cabecera.getBytes();
			int c;
			
			out.write(b);
			
			while ((c = in.read()) != -1)
			{
				out.write(c);
			}
			
			in.close();
			out.close();
			
		} catch (FileNotFoundException e) {
			System.err.println ("Fichero no encontrado");
		} catch (IOException e) {
			System.err.println ("Error al acceder a los ficheros");
		}
	}
	
	public void leeEscribeWriter()
	{
		try
		{
			BufferedReader br = new BufferedReader(new FileReader("entrada.dat"));
			PrintWriter pw = new PrintWriter(new FileWriter("salidaWriter.dat"));
			pw.print(cabecera);
			String linea = "";
			while ((linea = br.readLine()) != null)
			{
				pw.println(linea);
			}
			
			br.close();
			pw.close();
			
		} catch (FileNotFoundException e) {
			System.err.println ("Fichero no encontrado");
		} catch (IOException e) {
			System.err.println ("Error al acceder a los ficheros");
		}
	}
	
	public static void main(String[] args)
	{
		Ej4 e = new Ej4();
		e.leeEscribeStream();
		e.leeEscribeWriter();
	}
}