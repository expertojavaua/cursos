import java.awt.*;
import java.awt.event.*;
import java.util.*;

// Clase que implementa una calculadora sencilla

public class Calculadora extends Frame
{	
	// Constructor
	public Calculadora()
	{
	}
	
	// Funcion principal
	public static void main (String[] args)
	{
		Calculadora c = new Calculadora();
		c.show();
	}
	
	
}