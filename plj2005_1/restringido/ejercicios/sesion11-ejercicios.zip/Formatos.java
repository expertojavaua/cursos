
public class Formatos extends Frame 
{
	public Formatos()
	{
	}
	
	public static void main(String[] args)
	{
		Formatos f = new Formatos();
		f.show();
	}
}