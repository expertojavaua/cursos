import java.awt.*;
import java.awt.event.*;
import java.util.*;

// Clase que implementa una calculadora sencilla

public class Calculadora extends Frame
{
	// Operandos
	TextField txtOp1, txtOp2;
	
	// Resultado
	TextField txtRes;
	
	// Operadores
	Choice operadores;
	
	// Boton de resultado
	Button btnRes;
	
	// Constructor
	public Calculadora()
	{
		setSize(300, 150);
		setLayout(new GridLayout(4, 2));
		
		// Primer operando
		Label lblOp1 = new Label("Primer operando:");
		txtOp1 = new TextField();
		add(lblOp1);
		add(txtOp1);
		
		// Operador
		Label lblOper = new Label ("Operador:");
		operadores = new Choice();
		operadores.addItem("+");
		operadores.addItem("-");
		operadores.addItem("*");
		add(lblOper);
		add(operadores);
		
		// Segundo operando
		Label lblOp2 = new Label("Segundo operando:");
		txtOp2 = new TextField();
		add(lblOp2);
		add(txtOp2);
		
		// Resultado
		btnRes = new Button ("Calcular");
		txtRes = new TextField();
		add(btnRes);
		add(txtRes);
		
		// Evento sobre el bot�n
		btnRes.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				int op1, op2;
				try
				{
					op1 = Integer.parseInt(txtOp1.getText());
					op2 = Integer.parseInt(txtOp2.getText());	
					
					if (((String)(operadores.getSelectedItem())).equals("+"))
						txtRes.setText("" + (op1 + op2));
					else if (((String)(operadores.getSelectedItem())).equals("-"))
						txtRes.setText("" + (op1 - op2));
					else if (((String)(operadores.getSelectedItem())).equals("*"))
						txtRes.setText("" + (op1 * op2));					
				} catch (Exception ex) {
					txtRes.setText("ERROR EN LOS OPERANDOS");
				}
			}
		});
	}
	
	// Funcion principal
	public static void main (String[] args)
	{
		Calculadora c = new Calculadora();
		c.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			}
		});
		c.show();
	}
	
	
}