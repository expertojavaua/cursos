import java.awt.*;
import java.awt.event.*;

public class Formatos extends Frame implements ActionListener, ItemListener
{
	// Area de texto
	TextArea txt;
	
	// Flags para negrita y cursiva
	boolean negrita = false, cursiva = false;
		
	public Formatos()
	{
		// Men�
		
		MenuBar mb = new MenuBar();

		Menu m = new Menu("Formato");

		MenuItem mi = new MenuItem("Color Negro");
		mi.addActionListener(this);
		m.add(mi);
		mi = new MenuItem("Color Rojo");
		mi.addActionListener(this);
		m.add(mi);

		CheckboxMenuItem cmi = new CheckboxMenuItem("Negrita");
		cmi.addItemListener(this);
		m.add(cmi);
		cmi = new CheckboxMenuItem("Cursiva");
		cmi.addItemListener(this);
		m.add(cmi);

		mb.add(m);

		setMenuBar(mb);
		
		// Area de texto
		
		txt = new TextArea();
		txt.setFont(new Font("Arial", Font.PLAIN, 16));
		add(txt, BorderLayout.CENTER);
	}
	
	public void actionPerformed(ActionEvent e)
	{
		if (e.getActionCommand().equals("Color Negro"))
		{
			txt.setForeground(Color.black);
		} else if (e.getActionCommand().equals("Color Rojo")) {
			txt.setForeground(Color.red);
		}
	}
	
	public void itemStateChanged(ItemEvent e)
	{
		String item = (String)(e.getItem());
		if (item.equals("Negrita"))
			negrita = !negrita;
		else if (item.equals("Cursiva"))
			cursiva = !cursiva;

		txt.setFont(new Font("Arial", (negrita?Font.BOLD:0) | (cursiva?Font.ITALIC:0), 16));
	}
			
	public static void main(String[] args)
	{
		Formatos f = new Formatos();
		f.setSize(200, 200);
		f.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			}
		});
		f.show();
	}
}