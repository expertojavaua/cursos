import java.io.*;
import java.util.*;

public class Ej5
{
	public Ej5()
	{
	}
	
	public static void main(String[] args)
	{
		new Ej5();
	}
}