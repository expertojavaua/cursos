import java.io.*;
import java.util.*;

public class Ej4
{
	String cabecera = "# Esto es la cabecera del fichero que hay que introducir\r\n";
	
	public Ej4()
	{
	}
	
	public void leeEscribeStream()
	{
	}
	
	public void leeEscribeWriter()
	{
	}
	
	public static void main(String[] args)
	{
		Ej4 e = new Ej4();
		e.leeEscribeStream();
		e.leeEscribeWriter();
	}
}