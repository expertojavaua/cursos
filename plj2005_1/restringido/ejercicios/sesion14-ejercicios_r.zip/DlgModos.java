import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
  * Esta clase muestra un cuadro de dialogo para elegir uno 
  * de los modos graficos disponibles
  */
public class DlgModos extends JDialog
{
	DisplayMode [] modes;				// Modos graficos disponibles
	DisplayMode modoSeleccionado;		// Modo grafico finalmente seleccionado
	String [] smodes;					// Cadenas descriptivas de cada modo grafico
	JList lstModos;						// Lista de modos graficos
	JDialog dlg = this;					// Puntero a este dialogo
	
	public DlgModos(GraphicsDevice gd, JFrame padre)
	{
		super(padre, true);
		setSize (300, 300);
		
		// Obtenemos los modos graficos, los pasamos a cadena, y los metemos en la lista
		modes = gd.getDisplayModes();
		smodes = new String[modes.length];
		for(int i=0;i<modes.length;i++) 
			smodes[i] = modes[i].getWidth() + "x" + modes[i].getHeight() + ", " + modes[i].getBitDepth() + "bpp, " + modes[i].getRefreshRate() + " Hz";
		lstModos = new JList(smodes);		
		JScrollPane scrll = new JScrollPane(lstModos);
		
		// Boton para confirmar la eleccion de un modo grafico
		JButton btnAceptar = new JButton("Aceptar");
		btnAceptar.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				if (lstModos.getSelectedIndex() != -1)
				{
					System.out.println ("Cambiando a modo " + smodes[lstModos.getSelectedIndex()]);
					modoSeleccionado = modes[lstModos.getSelectedIndex()];
					dlg.hide();
				}
			}
		});
		
		// Colocamos los componentes
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(scrll, BorderLayout.CENTER);
		getContentPane().add(btnAceptar, BorderLayout.SOUTH);
	}
}
