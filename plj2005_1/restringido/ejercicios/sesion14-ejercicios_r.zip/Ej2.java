import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Ej2 extends JFrame implements Runnable
{
	public static final int ANCHO = 320;
	public static final int ALTO = 240;
	MiCanvas mc = new MiCanvas();
	Thread t = new Thread(this);
	int yObj = 0;
	int anchoPantalla;
	int altoPantalla;
	Image figura = null;
	
	public Ej2()
	{
		setSize(ANCHO, ALTO);				
		getContentPane().add(mc);
				
		t.start();

		// Quitamos la barra superior de la ventana
		this.setUndecorated(true);
		
		// Tomamos el dispositivo grafico
		GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
		GraphicsDevice gd = ge.getDefaultScreenDevice();
		
		// Mostramos dialogo para elegir un modo grafico
		DlgModos dlg = new DlgModos(gd, this);
		dlg.show();
		anchoPantalla = dlg.modoSeleccionado.getWidth();
		altoPantalla = dlg.modoSeleccionado.getHeight();
		
		// Cargamos la figura
		Toolkit tk = Toolkit.getDefaultToolkit();
		figura = tk.createImage("figura.png");

		// Evento de teclado
		addKeyListener(new KeyAdapter()
		{
			public void keyPressed(KeyEvent e)
			{
				if (e.getKeyCode()==KeyEvent.VK_ESCAPE)
				{
					System.exit(0);
				} else if (e.getKeyCode()==KeyEvent.VK_UP) {
					if (yObj > 0)
						yObj--;
				} else if (e.getKeyCode()==KeyEvent.VK_DOWN) {
					if (yObj < ALTO)
						yObj++;
				}
			}
		});

		// Obtenemos la pantalla completa, mostrando previamente si se puede tener o no:
		System.out.println ("Pantalla completa soportada: " + (gd.isFullScreenSupported()?"SI":"NO"));
		try
		{ 
			Thread.currentThread().sleep(3000);
		} catch (Exception e) {}
		gd.setFullScreenWindow(this);
		gd.setDisplayMode(dlg.modoSeleccionado);

	}
	
	public void run()
	{	
		while (true)
		{
			mc.repaint();
			try
			{
				Thread.currentThread().sleep(100);
			} catch (Exception ex) {}
		}		
	}
	
	public static void main(String[] args)
	{
		Ej2 e2 = new Ej2();
		e2.show();
	}
	
	class MiCanvas extends Canvas
	{
		Image backbuffer = null;			
		
		public MiCanvas()
		{
		}

		public void update(Graphics g)
		{
			paint(g);
		}
		
		public void paint(Graphics g)
		{
			if(backbuffer == null)
				backbuffer = createImage(ANCHO, ALTO);
	
			// Dibujamos los gr�ficos en el backbuffer
	
			Graphics off_g = backbuffer.getGraphics();
			off_g.clearRect(0, 0, ANCHO, ALTO);
			off_g.drawImage(figura, 0, yObj, figura.getWidth(this), figura.getHeight(this), this);
	
			// Volcamos el backbuffer a pantalla, segun el tama�o de la misma
	
			g.drawImage(backbuffer, 0, 0, anchoPantalla, altoPantalla, this);
			g.dispose();

		}
	}
}
