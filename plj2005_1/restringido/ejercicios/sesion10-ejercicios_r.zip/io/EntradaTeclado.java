package io;

import java.io.*;

public class EntradaTeclado
{
	BufferedReader in = null;
	
	public EntradaTeclado()
	{
		in = new BufferedReader( new InputStreamReader( System.in ) );		
	}
	
	public String leeTeclado()
	{
		try
		{
			return in.readLine();
		} catch (Exception e) {
			return null;
		}
	}
}