package geom;

public abstract class Figura implements java.io.Serializable
{
	public abstract String imprime();
}