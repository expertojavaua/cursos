package geom;

public class Circulo extends Figura implements java.io.Serializable
{
	int x;
	int y;
	int radio;
	
	public Circulo(int x, int y, int radio)
	{
		this.x = x;
		this.y = y;
		this.radio = radio;
	}
	
	public int getX()
	{
		return x;
	}
	
	public int getY()
	{
		return y;
	}
	
	public int getRadio()
	{
		return radio;
	}
	
	public void setX(int x)
	{
		this.x = x;
	}
	
	public void setY(int y)
	{
		this.y = y;
	}
	
	public void setRadio(int radio)
	{
		this.radio = radio;
	}

	public String imprime()
	{
		return "CIRCULO: (" + x + ", " + y + "), r = " + radio;
	}
}