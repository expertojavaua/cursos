import io.*;
import geom.*;
import java.util.*;

public class AplicGeom
{
	public static final String NUEVA = "1";
	public static final String BORRAR = "2";
	public static final String GUARDAR = "3";
	public static final String FIN = "4";
	
	EntradaTeclado et;
	String fichero;
	ArrayList figuras;
	
	public AplicGeom(String fichero)
	{
		this.fichero = fichero;
		et = new EntradaTeclado();
		figuras = new ArrayList();
		Figura[] fig = IOFiguras.leeFiguras(fichero);
		if (fig != null)
			for(int i = 0; i < fig.length; i++)
				figuras.add(fig[i]);
	}
	
	public void iniciar()
	{
		menu();
		String linea = et.leeTeclado();
		while (!linea.equals(FIN))
		{
			if (linea.equals(NUEVA))
			{
				System.out.println("Elige figura (1 - 3):");
				System.out.println("1. CIRCULO");
				System.out.println("2. RECTANGULO");
				System.out.println("3. LINEA");
				String num = et.leeTeclado();
				if (num.equals("1"))
				{
					String x, y, radio;
					System.out.println ("Introduce X:");
					x = et.leeTeclado();
					System.out.println ("Introduce Y:");
					y = et.leeTeclado();
					System.out.println ("Introduce Radio:");
					radio = et.leeTeclado();
					figuras.add(new Circulo(Integer.parseInt(x), Integer.parseInt(y), Integer.parseInt(radio)));
				} else if (num.equals("2")) {
					String x1, y1, x2, y2;
					System.out.println ("Introduce X1:");
					x1 = et.leeTeclado();
					System.out.println ("Introduce Y1:");
					y1 = et.leeTeclado();
					System.out.println ("Introduce X2:");
					x2 = et.leeTeclado();
					System.out.println ("Introduce Y2:");
					y2 = et.leeTeclado();
					figuras.add(new Rectangulo(Integer.parseInt(x1), Integer.parseInt(y1), Integer.parseInt(x2), Integer.parseInt(y2)));
				} else if (num.equals("3")) {
					String x1, y1, x2, y2;
					System.out.println ("Introduce X1:");
					x1 = et.leeTeclado();
					System.out.println ("Introduce Y1:");
					y1 = et.leeTeclado();
					System.out.println ("Introduce X2:");
					x2 = et.leeTeclado();
					System.out.println ("Introduce Y2:");
					y2 = et.leeTeclado();
					figuras.add(new Linea(Integer.parseInt(x1), Integer.parseInt(y1), Integer.parseInt(x2), Integer.parseInt(y2)));
				}
			} else if (linea.equals(BORRAR)) {
				System.out.println("Elige numero figura:");
				for (int i = 0; i < figuras.size(); i++)
				{
					Figura f = (Figura)(figuras.get(i));
					System.out.println("" + i + " - " + f.imprime());
				}
				String num = et.leeTeclado();
				figuras.remove(Integer.parseInt(num));
			} else if (linea.equals(GUARDAR)) {
				IOFiguras.guardaFiguras((Figura[])(figuras.toArray(new Figura[0])), fichero);
			}
			
			menu();
			linea = et.leeTeclado();
		}	
	}
	
	public void menu()
	{
		System.out.println("Figuras actuales:");
		for (int i = 0; i < figuras.size(); i++)
		{
			Figura f = (Figura)(figuras.get(i));
			System.out.println(f.imprime());
		}
		System.out.println("");		
		System.out.println("1. Introducir nueva figura");
		System.out.println("2. Borrar figura");
		System.out.println("3. Guardar datos");
		System.out.println("4. Salir");
		System.out.println("");		
		System.out.println("Elige una opci�n (1 - 4):");
	}
	
	public static void main(String[] args)
	{
		if (args.length == 0)
		{
			System.out.println("Uso: java AplicGeom <fichero>");
			System.exit(-1);
		}
		AplicGeom ag = new AplicGeom(args[0]);
		ag.iniciar();
	}
}