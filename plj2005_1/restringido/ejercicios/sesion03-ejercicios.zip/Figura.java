package modulo1.sesion3;
public abstract class Figura {
    double area;

    public abstract double getArea();
}
