package modulo1.sesion3;

public class Circulo extends Figura {
    double radio;

    public Circulo(double radio) {
        this.radio = radio;
    }

    public double getArea() {
        area = 3.14 * (radio * radio);
        return (area);
    };
}