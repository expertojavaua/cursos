package modulo1.sesion3;
public class Contador {
    static int acumulador = 0;
    int valor;
    
    static public int acumulador() {
        return acumulador;
    }

    public Contador(int valor) {
        this.valor = valor;
        acumulador += valor;
        // no es valido this.acumulador
        // es valido Contador.acumulador
    }    
    
    public void inc() {
       valor++;
       acumulador++;
    }
    
    public int getValor(){
        return valor;
    }
}
