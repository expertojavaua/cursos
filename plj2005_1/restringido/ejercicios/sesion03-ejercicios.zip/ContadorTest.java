
package modulo1.sesion3;
public class ContadorTest {

    public static void main(String[] args) {
        Contador c1, c2, c3;
        
        System.out.println("El valor del acumulador es: " + Contador.acumulador());          

        c1 = new Contador(3);
        c2 = new Contador(10);
        
        c1.inc();
        c1.inc();
        c2.inc();

        System.out.println("El valor de c1 es: " + c1.getValor());
        System.out.println("El valor de c2 es: " + c2.getValor());
        System.out.println("El valor del acumulador es: " + Contador.acumulador());          
    }
}
