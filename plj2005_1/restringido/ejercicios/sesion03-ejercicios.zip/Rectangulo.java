
package modulo1.sesion3;
public class Rectangulo extends Figura {
    double lado;
    double altura;

    public Rectangulo(double lado, double altura) {
        this.lado = lado;
        this.altura = altura;
    }

    public double getArea() {
        area = lado * altura;
        return (area);
    }
}