
// ------------------------------------------------------------------------------------
// 	Clase encargada de almacenar los datos de cada fase
// ------------------------------------------------------------------------------------

public class DatosFase {

	public int n_bolas;

	public int [] bola_x;

	public int [] bola_y;

	public int [] bola_tam;
	
	public double [] bola_vx;

	public String [] bola_color;

	public String img_background;

	public String music;

	public String nombre;
}