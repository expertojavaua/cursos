package sesion07;

import java.util.*;

public class Ej2
{
	public static void main(String[] args)
	{
		System.out.println ("CreaYBorraEnmedio:");
		creaYBorraEnmedio(10000);
		System.out.println ("CreaYBorraFinal:");
		creaYBorraFinal(10000000);
	}
	
	public static void creaYBorraEnmedio(int N)
	{
		// Creamos un Vector con 10000 cadenas 
		Vector v = new Vector();
		for (int i = 0; i < 10000; i++)
			v.addElement("Hola" + i);

		// Creamos una LinkedList con 10000 cadenas 
		LinkedList ll = new LinkedList();
		for (int i = 0; i < 10000; i++)
			ll.addLast("Hola" + i);

		// Hacemos "cantidad" operaciones de inserci�n y "cantidad" de borrado en el medio del vector
		// y anotamos el tiempo
		long t1 = System.currentTimeMillis();
		for (int i = 0; i < N; i++)
		{
			v.add(v.size()/2, "Hola" + i);
			v.remove(v.size()/2);
		}
		long t2 = System.currentTimeMillis();
		System.out.println("Tiempo con vector (enmedio): " + (t2 - t1) + " ms");
		
		// Hacemos lo mismo con la LinkedList
		t1 = System.currentTimeMillis();
		for (int i = 0; i < N; i++)
		{
			ll.add(ll.size()/2, "Hola" + i);
			ll.remove(ll.size()/2);
		}
		t2 = System.currentTimeMillis();
		System.out.println("Tiempo con LinkedList (enmedio): " + (t2 - t1) + " ms");
	}
	
	public static void creaYBorraFinal(int N)
	{
		// Creamos un Vector con 10000 cadenas 
		Vector v = new Vector();
		for (int i = 0; i < 10000; i++)
			v.addElement("Hola" + i);

		// Creamos una LinkedList con 10000 cadenas 
		LinkedList ll = new LinkedList();
		for (int i = 0; i < 10000; i++)
			ll.addLast("Hola" + i);

		// Hacemos "cantidad" operaciones de inserci�n y "cantidad" de borrado al final del vector
		// y anotamos el tiempo
		long t1 = System.currentTimeMillis();
		for (int i = 0; i < N; i++)
		{
			v.add(v.size()-1, "Hola" + i);
			v.remove(v.size()-1);
		}
		long t2 = System.currentTimeMillis();
		System.out.println("Tiempo con vector (final): " + (t2 - t1) + " ms");
		
		// Hacemos lo mismo con la LinkedList
		t1 = System.currentTimeMillis();
		for (int i = 0; i < N; i++)
		{
			ll.addLast("Hola" + i);
			ll.removeLast();
		}
		t2 = System.currentTimeMillis();
		System.out.println("Tiempo con LinkedList (final): " + (t2 - t1) + " ms");
	}
}