package sesion07;

import java.util.*;

public class Ej1
{
	public static void main(String[] args)
	{
		// Creamos un Vector con 10 cadenas 
		Vector v = new Vector();
		for (int i = 0; i < 10; i++)
			v.addElement("Hola" + i);
		
		// Recorrido mediante Enumeration
		
		// Recorrido mediante Iterator
		
		// Recorrido mediante un bucle for, accediendo a mano a cada posici�n del vector
	}
}