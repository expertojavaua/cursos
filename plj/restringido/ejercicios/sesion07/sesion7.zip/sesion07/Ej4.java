package sesion07;

import java.util.*;

public class Ej4
{
	public static void main(String[] args)
	{
		ArrayList al = new ArrayList();
		
		// A�adir los elementos en la lista
		
		for (int i = 0; i < 10; i++)
		{
			al.add(new Parametro("Clave" + i, "Valor" + i));
		}
		
		// Buscar el elemento que se pasa como parametro
		
		int i = 0;
		boolean encontrado = false;
		while (!encontrado && i < al.size())
		{
			Parametro p = (Parametro)(al.get(i));
			if (p.getNombre().equals(args[0]))
				encontrado = true;
			else
				++i;
		}
		if (encontrado)
			System.out.println ("Finalizado. Encontrado en posicion " + i);
		else
			System.out.println ("Finalizado. No encontrado.");
		
		// Imprimir todos los elementos por pantalla, con su nombre y su valor
		
		for (i = 0; i < al.size(); i++)
		{
			Parametro p = (Parametro)(al.get(i));
			System.out.println (p.getNombre() + " = " + p.getValor());
		}
		
	}
}

class Parametro
{
	String nombre;
	String valor;
	
	public Parametro (String n, String v)
	{
		nombre = n;
		valor = v;
	}
	
	public String getNombre()
	{
		return nombre;
	}
	
	public String getValor()
	{
		return valor;
	}
}