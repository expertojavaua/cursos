package sesion07;

import java.util.*;

public class Ej3
{
	Vector v;
	HashSet hs;
	
	public Ej3()
	{
		v = new Vector();
		v.add("a1");
		v.add("a2");
		v.add("a3");

		hs = new HashSet();
		hs.add("a1");
		hs.add("a2");
		hs.add("a3");
	}
	
	public static void main(String[] args)
	{
		Ej3 e3 = new Ej3();
		
		e3.anyadeVector(args[0]);
		e3.anyadeConjunto(args[0]);
	}
	
	public void anyadeVector(String cadena)
	{		
	}
	
	public void anyadeConjunto(String cadena)
	{
	}

}