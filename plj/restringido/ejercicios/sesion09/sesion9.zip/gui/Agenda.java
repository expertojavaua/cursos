package gui;

public class Agenda extends JFrame
{
	public Agenda(String fich)
	{		
	}
	
	
	public static void main(String[] args)
	{
		if (args.length != 1)
		{
			System.out.println ("Uso: java Agenda <fichero>");
			System.exit(-1);
		} else {	
			Agenda a = new Agenda(args[0]);
			a.show();
		}
	}
}