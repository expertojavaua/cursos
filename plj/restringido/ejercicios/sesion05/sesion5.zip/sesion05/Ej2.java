package sesion05;

public class Ej2
{
	int valor;
	
	public Ej2()
	{
		MiHilo t = new MiHilo("Hilo 1");	
		t.start();		

		do
		{
			System.out.print("Hilo 1 = " + t.contador + "\r");
			try {
				Thread.currentThread().sleep(100);
			} catch(InterruptedException e) { }

		} while (t.isAlive());
	}
	
	public static void main(String[] args)
	{
		Ej2 e2 = new Ej2();
	}
}

class MiHilo extends Thread
{
	String nombre = null;
	int contador = 1;
	
	public MiHilo(String nombre)
	{
		this.nombre = nombre;
	}
	
	public void run()
	{		
		for (contador = 1; contador <= 1000; contador++)
		{
			System.gc();
		}
	}
}