package sesion2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Numeros {
   static int[] numeros;

   public static void main(String[] args) {
      int i, j;
      String line;
      
      // Leo el n�mero escrito por el usuario
      do {
         System.out.print("Cu�ntos n�meros?: ");
         BufferedReader in = new BufferedReader(
               new InputStreamReader(System.in));
         try {
            line = in.readLine();
            i = Integer.parseInt(line);
         } catch (IOException e) {
            i = 0;
            System.out.println("IOException: "+ e);
         }
      } while (i > 100);

      numeros = new int[i];

      for (j = 0; j < i; j++) {
         double d = Math.random() * 800;
         System.out.println(d);
         numeros[j] = (int) d;
      }
      int nPares = 0;
      for (j = 0; j < numeros.length; j++) {
         int n = numeros[j];
         if (n % 2 == 0) {
            System.out.println(n);
            nPares++;
         }
      }
      System.out.println("Total pares: " + nPares);
   }
}