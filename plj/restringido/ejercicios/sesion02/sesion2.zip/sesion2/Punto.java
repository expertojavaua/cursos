package sesion2;

public class Punto {
	public double x, y;
	
	public Punto(double x, double y) {
		this.x = x;
		this.y = y;
	}
	
	public String toString() {
		return "Punto: ["+x+","+y+"]";
	}	
}
