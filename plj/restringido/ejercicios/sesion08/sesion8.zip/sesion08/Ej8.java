package sesion08;

import java.io.*;

public class Ej8
{
	public Ej8()
	{
	}
	
	public static void main (String[] args)
	{
		new Ej8();
	}
}