package sesion08;

import java.io.*;
import java.util.*;

public class Ej7
{
	public Ej7()
	{
	}
	
	public static void main(String[] args)
	{
		new Ej7();
	}
}