package sesion08;

import java.io.*;
import java.util.*;

public class Ej6
{
	String cabecera = "# Esto es la cabecera del fichero que hay que introducir\r\n";
	
	public Ej6()
	{
	}
	
	public void leeEscribeStream()
	{
	}
	
	public void leeEscribeWriter()
	{
	}
	
	public static void main(String[] args)
	{
		Ej6 e = new Ej6();
		e.leeEscribeStream();
		e.leeEscribeWriter();
	}
}