package sesion06;

import java.util.Calendar;

public class Ej8
{
	Calendar c;
	
	public Ej8()
	{
		c = Calendar.getInstance();
		
		// ... Configurar un DateFormat con el patron de fecha que queremos
		
		// ... Crear un hilo (Thread) y lanzarlo. 
		
		// Bucle infinito para el programa principal, donde:			
		// - Duerma 1000 ms
		// - Imprima por pantalla la fecha actual del campo c, formateada debidamente

	}

	// Deberemos hacer que esta clase implemente Runnable y 
	// definir un metodo run para el hilo, que haga un bucle infinito donde:
	// - Duerma 200 ms
	// - Actualice el valor del campo c a la fecha actual
		
	public static void main(String[] args)
	{
		new Ej8();
	}
}