package sesion06;

public class Ej7
{
	public static void main(String[] args)
	{
	}
}