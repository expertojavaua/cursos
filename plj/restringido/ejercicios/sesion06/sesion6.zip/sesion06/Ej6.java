package sesion06;

public class Ej6
{
	public static void main(String[] args)
	{
	}
}