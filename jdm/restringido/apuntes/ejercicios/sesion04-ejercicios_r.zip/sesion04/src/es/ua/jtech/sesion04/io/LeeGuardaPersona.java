package es.ua.jtech.sesion04.io;

import java.util.*;
import java.io.*;
import es.ua.jtech.sesion04.datos.*;

public class LeeGuardaPersona
{
	public static ArrayList leePersonas(String fichero)
	{
		ArrayList al = new ArrayList();
		try
		{
		   ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fichero));
		   while (true)
		   {
		      Persona p = (Persona)(ois.readObject());
		      al.add(p);
		   }
		} catch (Exception e) {
			e.printStackTrace();
		}
		return al;
	}
	
	public static void guardaPersonas(String fichero, ArrayList personas)
	{
		try
		{
		   ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fichero));
		   for (int i = 0; i < personas.size(); i++)
		   {
		      Persona p = (Persona)(personas.get(i));
		      oos.writeObject(p);
		   }
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args)
	{
		ArrayList al = new ArrayList();
		
		al.add(new Persona("Marta", "Garc�a", "Hern�ndez", "C/Aloma - 22", "634253456"));
		al.add(new Persona("Eva", "Sim�n", "Mas", "Camino del Prado - 30", "966124627"));
		al.add(new Persona("Rafael", "Garc�a", "Hern�ndez", "C/Aloma - 1", "601123546"));
		al.add(new Persona("Manuel", "Bravo", "Murillo", "C/La Huerta - 22", "965123456"));
		al.add(new Persona("Carolina", "Garc�a", "Rodr�guez", "Avda. Doctor Rico", "661228844"));
		
		guardaPersonas("ficheroPersonas.dat", al);
		ArrayList al2 = leePersonas("ficheroPersonas.dat");
		
		for (int i = 0; i < al2.size(); i++)
			System.out.println((Persona)(al2.get(i)));
	}
}