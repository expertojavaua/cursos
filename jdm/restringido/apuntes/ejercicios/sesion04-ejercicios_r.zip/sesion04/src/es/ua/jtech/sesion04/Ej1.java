package es.ua.jtech.sesion04;

import java.io.*;
import java.util.*;

public class Ej1
{
	String cabecera = "# Esto es la cabecera del fichero que hay que introducir\r\n";
	
	public Ej1()
	{
	}
	
	public void leeEscribeStream()
	{
		FileInputStream in=null;
		FileOutputStream out=null;
		try
		{
			in = new FileInputStream("entrada.dat");
			out = new FileOutputStream("salidaStream.dat");
			
			byte[] b = cabecera.getBytes();
			out.write(b);
			
			int c;
			while ((c = in.read()) != -1)
			{
			   out.write(c);
			}
		} catch (Exception ex){ 
			ex.printStackTrace();
		} finally {
			try
			{
				in.close();
				out.close();
			} catch (Exception ex2){}
		}
	}
	
	public void leeEscribeWriter()
	{
		BufferedReader br =  null;
		PrintWriter pw = null;
		
		try
		{
			br =  new BufferedReader(new FileReader("entrada.dat"));
			pw = new PrintWriter(new FileWriter("salidaWriter.dat"));

			pw.print(cabecera);
			
			String linea = "";
			while ((linea = br.readLine()) != null)
			{
			   pw.println(linea);
			}
						
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try
			{
				br.close();
				pw.close();
			} catch (Exception ex2) {}
		}
	}
	
	public static void main(String[] args)
	{
		Ej1 e = new Ej1();
		e.leeEscribeStream();
		e.leeEscribeWriter();
	}
}