package es.ua.jtech.sesion04;

import java.io.*;

public class Ej3
{
	public Ej3()
	{
		try
		{
			StreamTokenizer st =  new StreamTokenizer(new FileReader("matriz.txt"));
			st.commentChar(';');
			int filas, columnas;
			
			st.nextToken();
			filas = (int)(st.nval);            // Filas

			st.nextToken();
			columnas = (int)(st.nval);         // Columnas
			
			int[][] matriz = new int[filas][columnas];
			int t;
						
			for (int i = 0; i < filas; i++)
			   for (int j = 0; j < columnas; j++)
			   {
			      t = st.nextToken();
			      if (t != StreamTokenizer.TT_EOF)
			      {
			         matriz[i][j] = (int)(st.nval);
			      }
			   }	

			for (int i = 0; i < filas; i++)
				   for (int j = 0; j < columnas; j++)
					   matriz[i][j]=(int)(Math.pow(matriz[i][j],2));
			
			PrintWriter pw = new PrintWriter(new FileWriter("matrizSal.txt"));
			pw.println("; Matriz resultado");
			pw.println("" + filas + " " + columnas);
			for (int i = 0; i < filas; i++)
			{
				for (int j = 0; j < columnas; j++)
					pw.print(""+matriz[i][j]+" ");
				pw.println("");
			}
			pw.close();

		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public static void main (String[] args)
	{
		new Ej3();
	}
}