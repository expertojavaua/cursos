package es.ua.jtech.sesion04;

import java.io.*;
import java.util.*;

public class Ej2
{
	public Ej2()
	{
		try
		{
			Properties p = new Properties();
			p.load(new FileInputStream("prop.txt"));
			
			Enumeration en = p.propertyNames();
			BufferedReader in =  new BufferedReader(new InputStreamReader(System.in));
			while (en.hasMoreElements())
			{
			   String prop = (String)(en.nextElement());
			   System.out.println("Introduzca valor para propiedad " + prop);
			   String valor = in.readLine();
			   p.setProperty(prop, valor);
			}
			
			in.close();
			p.store(new FileOutputStream("prop.txt"), "Cabecera del fichero");
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}
	
	public static void main(String[] args)
	{
		new Ej2();
	}
}