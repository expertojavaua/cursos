package es.ua.jtech.sesion6;

import java.io.*;
import java.sql.*;

public class AplicAlumnos 
{
	Connection con = null;
	Statement stmt = null;
	
	public AplicAlumnos()
	{
	}
	
	public boolean conectaBD()
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost/alumnos", "root", "root");
			stmt = con.createStatement();
			return true;
		} catch (Exception ex) {
			ex.printStackTrace();
			return false;
		}
	}
	
	public int insertaAlumno(int exp, String nombre, String sexo) 
	{
		try
		{
			return stmt.executeUpdate("INSERT INTO alumnos(exp, nombre, sexo) VALUES (" + exp + ",'" + nombre + "','" + sexo + "')");
		} catch (Exception ex) {
			ex.printStackTrace();
			return 0;
		}
	}
	
	public int borraAlumno(int exp)
	{
		try
		{
			return stmt.executeUpdate("DELETE FROM alumnos WHERE exp = " + exp);
		} catch (Exception ex) {
			ex.printStackTrace();
			return 0;
		}		
	}
	
	public int modificaAlumno (int exp, String nombre, String sexo)
	{
		try
		{
			return stmt.executeUpdate("UPDATE alumnos SET nombre='" + nombre + "', sexo ='" + sexo + "' WHERE exp=" + exp);
		} catch (Exception ex) {
			ex.printStackTrace();
			return 0;
		}

	}
	
	public ResultSet listaAlumnos()
	{
		try
		{
			return stmt.executeQuery("SELECT * FROM alumnos");
		} catch (Exception ex) {
			ex.printStackTrace();
			return null;
		}
	}
	
	public void menu()
	{
		System.out.println("1. Listar alumnos");
		System.out.println("2. Insertar alumno");
		System.out.println("3. Borrar alumno");
		System.out.println("4. Editar alumno");
		System.out.println("5. Salir");
	}
		
	public static void main(String[] args) 
	{
		AplicAlumnos aa = new AplicAlumnos();
		if (!aa.conectaBD())
		{
			System.err.println("Error conectando con la BD");
			System.exit(-1);
		}
		
		BufferedReader ent = new BufferedReader(new InputStreamReader(System.in));
		aa.menu();
		
		try
		{

		String resp = ent.readLine();
		
		while (!resp.equals(5))
		{
		
			if (resp.equals("1"))
			{
				// Listar
				ResultSet rs = aa.listaAlumnos();
				if (rs != null)
				{
					try
					{
						while (rs.next())
						{
							int exp = rs.getInt("exp");
							String nom = rs.getString("nombre");
							String sexo = rs.getString("sexo");
							System.out.println("" + exp + " - " + nom + " - " + sexo);
						}
						rs.close();
					} catch (Exception ex) {}
				}
			} else if (resp.equals("2")) {

				// Insertar
				System.out.println("Expediente:");
				String exp = ent.readLine();
				System.out.println("Nombre:");
				String nom = ent.readLine();
				System.out.println("Sexo:");
				String sexo = ent.readLine();
				
				if (aa.insertaAlumno(Integer.parseInt(exp), nom, sexo) <= 0)
				{
					System.err.println("Error al insertar el alumno");
				}
				
			} else if (resp.equals("3")) {

				// Borrar
				System.out.println("Expediente:");
				String exp = ent.readLine();
				
				if (aa.borraAlumno(Integer.parseInt(exp)) <= 0)
				{
					System.err.println("Error al borrar el alumno");
				}

			} else if (resp.equals("4")) {

				// Editar
				System.out.println("Expediente:");
				String exp = ent.readLine();
				System.out.println("Nombre:");
				String nom = ent.readLine();
				System.out.println("Sexo:");
				String sexo = ent.readLine();
				
				if (aa.modificaAlumno(Integer.parseInt(exp), nom, sexo) <= 0)
				{
					System.err.println("Error al modificar el alumno");
				}

			} else {
				// Salir
				System.exit(0);
			}
			
			aa.menu();
			resp = ent.readLine();
		}
		
		} catch (Exception ex) {
			ex.printStackTrace();
		}
	}

}
