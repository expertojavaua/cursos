package es.ua.jtech.jdm.sesion10.midlet;

import java.util.Timer;
import java.util.TimerTask;

import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

public class MIDletTemporizador extends MIDlet {

	protected void startApp() throws MIDletStateChangeException {		
		Timer temp = new Timer();
		TimerTask tarea = new MiTarea();
		
		temp.schedule(tarea, 10000);

		System.out.println("Temporizador programado");
	}

	protected void pauseApp() {

	}

	protected void destroyApp(boolean cond) throws MIDletStateChangeException {

	}

	class MiTarea extends TimerTask {
		public void run() {
			System.out.println("Se ha disparado la alarma");
		}
	}
	
}
