package es.ua.jtech.sesion02;

public class Ej1
{
	public static void main(String[] args)
	{
	}
}