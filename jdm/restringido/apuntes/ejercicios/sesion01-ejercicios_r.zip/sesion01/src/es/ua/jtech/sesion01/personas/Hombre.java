package es.ua.jtech.sesion01.personas;


/**
  * Ejemplo de herencias y clases abstractas
  */
public class Hombre implements Persona
{	 
	
	public String clase()
	{ 
		return "mamiferos"; 
	} 
	
	/**
	  * Devuelve el genero de la persona (este metodo si hay que
	  * definirlo porque es abstracto en la clase padre)
	  */
	public String genero()
	{
		return "masculino";
	}

	/**
	  * Devuelve la edad de la persona (este metodo si hay que definirlo
	  * porque es abstracto en la clase padre)
	  */
	public String edad()
	{
		return "40";
	}
}
