package es.ua.jtech.sesion01;

import es.ua.j2ee.animales.*;
import es.ua.j2ee.insectos.Mosca;
import es.ua.j2ee.plantas.*;

/**
 * @author Miguel Angel
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Prueba {

	public static void main(String[] args) 
	{
		// Datos del insecto
		Mosca m = new Mosca();
		m.nombre();
		int edad3 = m.edad() + 2;
		System.out.println ("Edad Insecto: " + edad3);

		// Datos del animal
		Elefante e = new Elefante();
		e.nombre();
		int edad2 = e.edad() + 5;
		System.out.println ("Edad Animal: " + edad2);

		// Datos de la planta
		Geranio g = new Geranio();
		g.nombre();
		int edad5 = g.edad();
		System.out.println ("Edad Planta: " + edad5);
	}
	
}
