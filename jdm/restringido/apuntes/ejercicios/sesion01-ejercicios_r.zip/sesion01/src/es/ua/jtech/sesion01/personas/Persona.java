package es.ua.jtech.sesion01.personas;

/**
  * Ejemplo de herencias y clases abstractas
  */
public interface Persona
{	  
	/**
	  * Devuelve la clase a la que pertenecen las personas
	  */
	public String clase(); 

	/**
	  * Devuelve el genero de la persona
	  */
	public String genero();

	/**
	  * Devuelve la edad de la persona
	  */
	public String edad();
}
