package es.ua.jtech.sesion01;

/**
  * Esqueleto para el ejercicio de la ecuacion de segundo grado
  */
public class Ecuacion
{
	/**
	  * Constructor
	  */
	public Ecuacion()
	{
	}
	
	/**
	  * Obtiene un array con las dos soluciones a la ecuacion
	  */
	public double[] solucion (double a, double b, double c)
	{ 
		// ... Colocad aqui vuestro codigo
		double[] sol = new double[2];
		
		double raiz = Math.pow(b, 2.0) - 4 * a * c;
		
		if (raiz < 0)
			return null;
		else
		{
			if (a == 0)
			{
				if (b == 0)
					return null;		// Si a y b son 0 no hay ecuacion
				else
					sol[0] = sol[1] = -c / b;
			} else {
				sol[0] = (-b + Math.sqrt(raiz)) / (2*a);
				sol[1] = (-b - Math.sqrt(raiz)) / (2*a);
			}
		}
		
		return sol;
	} 

	/**
	  * Main
	  */
	public static void main(String[] args) 
	{ 
		Ecuacion ec = new Ecuacion();
		double[] sol = ec.solucion(4.0, 1.0, -6.0);
		System.out.println ("X1 = " + sol[0] + ", X2 = " + sol[1]); 
	} 
}
