package es.ua.jtech.sesion01.personas;


/**
  * Ejemplo de herencias y clases abstractas
  */
public class Anciano extends Hombre
{	 
	/* 
	   No hace falta definir ningun metodo, s�lo aquellos en los 
	   que queramos devolver cosas distintas. En este caso, la edad
	*/
	
	/**
	  * Devuelve la edad de la persona 
	  */
	public String edad()
	{
		return "75";
	}
}
