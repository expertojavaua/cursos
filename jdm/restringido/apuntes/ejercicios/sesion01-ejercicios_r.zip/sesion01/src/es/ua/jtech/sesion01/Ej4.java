package es.ua.jtech.sesion01;

import es.ua.jtech.sesion01.personas.*;

/**
  * Ejemplo de herencias y clases abstractas
  */
public class Ej4
{	 
	/**
	  * Main
	  */
	public static void main(String[] args)
	{
		Hombre h = new Hombre();
		Anciano a = new Anciano();
		Persona p = (Persona)a;
		
		System.out.println ("Edad del anciano: " + a.edad());		
		System.out.println ("Edad del hombre: " + h.edad());		
		System.out.println ("Genero del anciano: " + a.genero());
		System.out.println ("Clase de la persona: " + p.clase());
	}
}
