package es.ua.jtech.jdm.sesion10.prueba;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.media.*;

public class MIDletPrueba extends MIDlet {

	protected void startApp() throws MIDletStateChangeException {
		Form f = new Form(getAppProperty("msg.bienvenida"));
		try {
			f.append(Image.createImage("/logo.png"));
		} catch(Exception e) {}

		try {
			Manager.playTone(80, 1000, 100);
		} catch(MediaException e) {}
		
		Display d = Display.getDisplay(this);
		d.setCurrent(f);
	}

	protected void pauseApp() {
	}

	protected void destroyApp(boolean arg0) throws MIDletStateChangeException {
	}
}
