package ejercicios;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class ServletAlumno extends HttpServlet
{
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String exp = request.getParameter("exp");
		String nombre = request.getParameter("nombre");
		String sexo = request.getParameter("sexo");
		
		if (exp == null || nombre == null || sexo == null || exp.equals("") || nombre.equals("") || sexo.equals(""))
		{
			response.sendRedirect("../error.html");
		} else {
			response.setContentType("text/html");
			PrintWriter out = response.getWriter();
			out.println("<html><body>");
			out.println("Expediente: " + exp + "<br />");
			out.println("Nombre: " + nombre + "<br />");
			out.println("Sexo: " + sexo + "<br />");
			out.println("</body></html>");
		}
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doGet(request, response);
	}
}