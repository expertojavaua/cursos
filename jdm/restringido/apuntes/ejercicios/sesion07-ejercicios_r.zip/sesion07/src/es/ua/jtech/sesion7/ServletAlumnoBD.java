package es.ua.jtech.sesion7;

import es.ua.jtech.sesion6.*;
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class ServletAlumnoBD extends HttpServlet
{
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		if (request.getParameter("accion").equals("listar"))
		{
			try
			{
				AplicAlumnos aa = new AplicAlumnos();
				response.setContentType("text/html");
				PrintWriter out = response.getWriter();
				out.println("<html><body>");
				if (aa.conectaBD())
				{
					ResultSet rs = aa.listaAlumnos();
					while (rs.next())
					{
						int exp = rs.getInt("exp");
						String nom = rs.getString("nombre");
						String sexo = rs.getString("sexo");
						out.println("Exp: " + exp + ", Nombre: " + nom + ", Sexo: " + sexo + "<a href=\"alumnoBD?accion=borrar&exp="+exp+"\">Borrar</a><br />");
					}
				}
				out.println("</body></html>");
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		} else if (request.getParameter("accion").equals("insertar")) {
			try
			{
				AplicAlumnos aa = new AplicAlumnos();
				PrintWriter out = response.getWriter();
				if (aa.conectaBD())
				{
					int exp = Integer.parseInt(request.getParameter("exp"));
					String nombre = request.getParameter("nombre");
					String sexo = request.getParameter("sexo");
					aa.insertaAlumno(exp, nombre, sexo);
					response.sendRedirect("alumnoBD?accion=listar");
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		} else if (request.getParameter("accion").equals("borrar")) {
			try
			{
				AplicAlumnos aa = new AplicAlumnos();
				PrintWriter out = response.getWriter();
				if (aa.conectaBD())
				{
					int exp = Integer.parseInt(request.getParameter("exp"));
					aa.borraAlumno(exp);
					response.sendRedirect("alumnoBD?accion=listar");
				}
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doGet(request, response);
	}
}