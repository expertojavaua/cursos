package es.ua.jtech.jdm.sesion12.midlet;

import javax.microedition.lcdui.Display;
import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

public class MIDletDibujo extends MIDlet {

	protected void startApp() throws MIDletStateChangeException {
		Display d = Display.getDisplay(this);
		CanvasDibujo cd = new CanvasDibujo();
		d.setCurrent(cd);
	}

	protected void pauseApp() {
	}

	protected void destroyApp(boolean arg0) throws MIDletStateChangeException {
	}

}
