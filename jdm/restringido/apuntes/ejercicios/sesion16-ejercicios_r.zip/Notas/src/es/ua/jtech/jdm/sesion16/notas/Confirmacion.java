package es.ua.jtech.jdm.sesion16.notas;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class Confirmacion extends Form implements CommandListener {

	Command cmdAceptar;
	Command cmdCancelar;

	private boolean contestado = false;
	private boolean respuesta;

	MIDlet owner;

	public Confirmacion(MIDlet owner, String mensaje) {
		super("Confirmacion");
		this.owner = owner;
		
		// A�ade mensaje de confirmaci�n
		this.append(mensaje);
		
		// Crea comandos
		cmdAceptar = new Command("Aceptar", Command.OK, 1);
		cmdCancelar = new Command("Cancelar", Command.CANCEL, 1);
		this.addCommand(cmdAceptar);
		this.addCommand(cmdCancelar);
		this.setCommandListener(this);
	}

	public synchronized boolean acepta() {

		// Bloquea al llamador hasta que el usuario acepta o cancela
		try {
			while(!contestado) {
				wait();
			}
		} catch(InterruptedException e) {
			return false;
		}
		
		return respuesta;
	}

	public synchronized void commandAction(Command cmd, Displayable disp) {

		// Notifica que el usuario ha respondido
		if(cmd == cmdAceptar) {
			contestado = true;
			respuesta = true;
			notifyAll();
		} else if (cmd == cmdCancelar) {
			contestado = true;
			respuesta = false;
			notifyAll();
		}
	}

}
