package es.ua.jtech.jdm.sesion16.notas;

import java.io.*;

public class Mensaje {

	int rmsID;

	String asunto;

	String texto;
	
	public Mensaje() {
	}
	
	public int getRmsID() {
		return rmsID;
	}

	public void setRmsID(int rmsID) {
		this.rmsID = rmsID;
	}

	public String getAsunto() {
		return asunto;
	}

	public void setAsunto(String asunto) {
		this.asunto = asunto;
	}

	public String getTexto() {
		return texto;
	}

	public void setTexto(String texto) {
		this.texto = texto;
	}
	
	public void serialize(DataOutputStream dos) throws IOException {
		dos.writeUTF(asunto);
		dos.writeUTF(texto);
	}

	public static Mensaje deserialize(DataInputStream dis) throws IOException {
		Mensaje msg = new Mensaje();

		msg.asunto = dis.readUTF();
		msg.texto = dis.readUTF();
		
		return msg;
	}

}