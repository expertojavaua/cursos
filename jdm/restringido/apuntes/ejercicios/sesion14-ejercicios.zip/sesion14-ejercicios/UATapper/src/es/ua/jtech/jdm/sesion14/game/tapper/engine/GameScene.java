/*
 * Created on 25/06/2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package es.ua.jtech.jdm.sesion14.game.tapper.engine;

import java.util.Enumeration;
import java.util.Random;
import java.util.Vector;

import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.game.GameCanvas;
import javax.microedition.lcdui.game.Sprite;

import es.ua.jtech.jdm.sesion14.game.tapper.data.CommonData;
import es.ua.jtech.jdm.sesion14.game.tapper.data.Resources;
import es.ua.jtech.jdm.sesion14.game.tapper.data.StageData;

/**
 * @author Miguel Angel and Boyan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class GameScene implements Scene {

	// Control de estados
	public static int E_INICIO = 0;
	public static int E_JUGANDO = 1;
	public static int E_MUERTO = 2;
	public static int E_CONSEGUIDO = 3;
	int state;

	int numLives;
	int stage;

	// Objetivo de la fase:
	// Cada nivel tiene un número de clientes a los que tiene que servir.
	// clientsToServe se inicializa en cada Stage, y tiene que llegar a 0 para completar el Stage.
	int clientsToServe;  
	
	Background bg;
	
	public GameScene() {
		
		bg = new Background(); // Debe iniciarse primero el background, y después los Sprites
		//barman = new BarmanSprite();
		//cervezas...
		//clientes...
		
		
		reset();
	}
	
	// Reinicio de la partida
	public void reset() {
		numLives = CommonData.NUM_LIVES;
		stage = 0;

		reset(stage);
	}
	
	// Reinicio de una fase
	public void reset(int nStage, boolean newLevel) {
		StageData staged = Resources.stageData[nStage];
		bg = new Background(); // Debe iniciarse primero el background, y después los Sprites
		bg.reset(staged);
		//barman.reset();
		
		this.setState(E_INICIO);
	}
	
	public void reset(int nStage) {
		reset(nStage, false);
	}
	
	public void setState(int state) {
		this.state = state;

	}
	
	public void tick(int keyState) {
	
	}

	public void render(Graphics g) {
	
	}

}
