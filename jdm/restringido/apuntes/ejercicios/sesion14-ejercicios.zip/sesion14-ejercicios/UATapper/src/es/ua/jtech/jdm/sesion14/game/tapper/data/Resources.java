/*
 * Resources.java
 * Copyright (C) 2004 Miguel Angel Lozano
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package es.ua.jtech.jdm.sesion14.game.tapper.data;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.microedition.lcdui.Image;

import es.ua.jtech.jdm.sesion14.game.tapper.MIDletTapper;

/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class Resources {

	public static final int IMG_TIT_TITULO = 0;
	public static final int IMG_SPR_BARMAN = 1;
	public static final int IMG_BG_STAGE_1 = 2;
	public static final int IMG_SPR_BEER = 3;
	public static final int IMG_SPR_CLIENTES = 4;
	public static final int IMG_FACE_LIVES = 5;

	public static Image[] img;
	public static Image[] fondos;
	public static Image splashImage;
	public static StageData[] stageData;

	public static MIDletTapper midlet;

	private static String[] imgNames =
		{
			"/title.png",
			"/sprite.png",
			"/fondo48x18transp2.png",
			"/beer.png",
			"/clientes.png",
			"/face.png"
		};
	private static final String[] fondoNames = 
		{
			"/fondo0.jpg",
			"/fondo1.jpg",
			"/fondo2.jpg",
			"/fondo3.jpg",
			"/fondo4.jpg",
			"/fondo5.jpg"
		};
	private static String splashImageFile = "/logojava.png";
	private static String stageFile = "/tapper.dat";

	public static Image getImage(int imgIndex) {
		return img[imgIndex];
	}

	public static Image getFondo(int imgIndex) {
		return fondos[imgIndex];
	}

	public static StageData getStage(int stageIndex) {
		return stageData[stageIndex];
	}
	
	public static void init() throws IOException {
		// Carga imagenes
		loadCommonImages();

		// Carga datos de niveles
		InputStream in = stageFile.getClass().getResourceAsStream(stageFile);
		stageData = loadStageData(in);
	}

	public static void initSplash(MIDletTapper pMidlet) throws IOException {
		midlet = pMidlet;
		splashImage = Image.createImage(splashImageFile);
	}

	private static void loadCommonImages() throws IOException {
		// Carga imagenes
		img = new Image[imgNames.length];
		fondos = new Image[fondoNames.length];
		for (int i = 0; i < imgNames.length; i++) {
			img[i] = Image.createImage(imgNames[i]);
		}
		for (int i = 0; i < fondoNames.length; i++) {
			fondos[i] = Image.createImage(fondoNames[i]);
		}
	}

	public static StageData[] loadStageData(InputStream in)
		throws IOException {

		StageData[] stages = null;

		DataInputStream dis = new DataInputStream(in);

		int stageNum = dis.readInt();
		CommonData.NUM_STAGES = stageNum;
		stages = new StageData[stageNum];
		for (int i = 0; i < stageNum; i++) {
			stages[i] = StageData.deserialize(dis);
			stages[i].numStage = (byte)i;
		}

		return stages;
	}

}
