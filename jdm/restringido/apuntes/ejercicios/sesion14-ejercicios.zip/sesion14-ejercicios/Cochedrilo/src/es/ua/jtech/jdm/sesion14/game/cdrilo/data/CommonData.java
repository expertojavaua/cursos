/*
 * CommonData.java
 * Copyright (C) 2004 Miguel Angel Lozano
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package es.ua.jtech.jdm.sesion14.game.cdrilo.data;

import javax.microedition.lcdui.Font;

/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class CommonData {

	// Numero de vidas total
	public static final int NUM_LIVES = 3;

	// Dimensiones de la pantalla
	public final static int SCREEN_WIDTH = 176;
	public final static int SCREEN_HEIGHT = 208;

	// Dimensiones de las celdas del fondo
	public final static int BG_TILE_WIDTH = 50;
	public final static int BG_TILE_HEIGHT = 25;

	// Dimensiones de la matriz de celdas del fondo (ancho x alto)
	public final static int BG_H_TILES = 4;
	public final static int BG_V_TILES = 9;

	// Numero de filas de celdas de hierba que se 
	// generan en la parte superior de la pantalla
	public final static int BG_V_TOP_TILES = 2;

	// Indices de los tipos de celdas del fondo
	public final static int BG_TILE_CENTER = 1;
	public final static int BG_TILE_BOTTOM = 2;
	public final static int BG_TILE_TOP = 3;
	public final static int BG_TILE_GRASS = 4;
	
	// Dimensiones del sprite
	public final static int SPRITE_WIDTH = 16;
	public final static int SPRITE_HEIGHT = 22;

	// Rectangulo de colision del sprite
	public final static int SPRITE_CROP_X = 3;
	public final static int SPRITE_CROP_Y = 0;
	public final static int SPRITE_CROP_WIDTH = 9;
	public final static int SPRITE_CROP_HEIGHT = 14;	
	
	// Secuencias de frames de los movimientos del personaje
	public final static int SPRITE_STAY_DOWN = 0;
	public final static int[] SPRITE_MOVE_DOWN = { 1, 2, 3 };
	public final static int SPRITE_STAY_UP = 4;
	public final static int[] SPRITE_MOVE_UP = { 5, 6, 7 };
	public final static int SPRITE_STAY_LEFT = 8;
	public final static int[] SPRITE_MOVE_LEFT = { 9, 10, 11 };
	public final static int SPRITE_STAY_RIGHT = 12;
	public final static int[] SPRITE_MOVE_RIGHT = { 13, 14, 15 };
	public final static int SPRITE_STAY_DIED = 16;

	// Posicion inicial del personaje
	public final static int SPRITE_INI_X = 80;
	public final static int SPRITE_INI_Y = 180;

	// Velocidad del personaje (numero de pixels que avanza en cada tick)
	public final static int SPRITE_STEP = 2;
	
	// Meta de la fase. Cuando la coordenada Y del personaje
	// sea menor que esta, habra completado el nivel
	public final static int SPRITE_END_Y = 20;
		
	// Dimensiones de la imagen de la cara para el contador de vidas
	public final static int FACE_WIDTH = 25;
	public final static int FACE_HEIGHT = 15;

	// Dimensiones de los sprites de los coches.
	// La anchura depende del tipo de coche (3 tipos)
	public static final int SPRITE_CAR_HEIGHT = 15;
	public static final int [] SPRITE_CAR_WIDTH = { 20, 34, 63 };
	
	// Posiciones de los coches en los carriles.
	// La posicion BASE se utilizara para ubicar el coche
	// del primer carril, y se ira sumando STEP a esta 
	// posicion para cada siguiente carril.
	public static final int SPRITE_CAR_BASE_Y = 55;
	public static final int SPRITE_CAR_STEP_Y = 25;
	
	// Datos del texto de titulo de fase
	public final static int STAGE_TITLE_X = 88;	
	public final static int STAGE_TITLE_Y = 100;	
	public static final int STAGE_TITLE_COLOR = 0x0FFFF00;
	public static final Font STAGE_TITLE_FONT = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_BOLD, Font.SIZE_SMALL);
	public static final String STAGE_COMPLETED_TEXT = "Nivel completado";

	// Datos del texto de la pantalla de titulo
	public static final int GAME_START_X = 88;
	public static final int GAME_START_Y = 150;
	public static final String GAME_START_TEXT = "PULSA START PARA COMENZAR";
	public static final int GAME_START_COLOR = 0x0FFFF00;
	public static final Font GAME_START_FONT = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_BOLD, Font.SIZE_SMALL);

}
