/*
 * Created on 25/06/2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package es.ua.jtech.jdm.sesion14.game.cdrilo.engine;

import javax.microedition.lcdui.Graphics;

/**
 * @author Miguel Angel
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class GameScene implements Scene {

	public void tick(int keyState) {
		// TODO: Implementar logica del juego
	}

	public void render(Graphics g) {
		// TODO: Volcar graficos del juego
	}

}
