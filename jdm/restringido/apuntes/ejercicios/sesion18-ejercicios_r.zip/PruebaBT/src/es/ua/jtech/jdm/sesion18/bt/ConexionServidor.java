package es.ua.jtech.jdm.sesion18.bt;

import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Vector;

import javax.microedition.lcdui.StringItem;

public class ConexionServidor implements ConexionChat {
	
	Vector clientes;

	Vector msgEntrada;
	boolean msgDisponible;
	
	public ConexionServidor() {
		clientes = new Vector();
		msgEntrada = new Vector();
		msgDisponible = false;
	}

	public void addCliente(DataInputStream dis, DataOutputStream dos) {
		Cliente c = new Cliente(dis, dos);
		clientes.addElement(c);
		
		Thread t = new Thread(c);
		t.start();
	}
	
	public void envia(String texto) throws IOException {
		synchronized(msgEntrada) {
			msgEntrada.addElement(texto);
			msgDisponible = true;
			msgEntrada.notifyAll();
		}

		difunde(texto);
	}

	public String recibe() throws IOException {

		String texto = null;
		
		synchronized(msgEntrada) {
			if(!msgDisponible) {
				try {
					msgEntrada.wait();
				} catch (InterruptedException e) {
					e.printStackTrace();
					return "Error: " + e.getMessage();
				}
			}
			
			texto = (String)msgEntrada.firstElement();
			msgEntrada.removeElementAt(0);
			if(msgEntrada.size()==0) {
				msgDisponible = false;
			}
		}
	
		return texto;
	}

	public void difunde(String texto) throws IOException {
		for(int i=0;i<clientes.size();i++) {
			Cliente c = (Cliente)clientes.elementAt(i);
			c.dos.writeUTF(texto);
		}
	}
	
	class Cliente implements Runnable {
		
		public Cliente(DataInputStream dis, DataOutputStream dos) {
			this.dis = dis;
			this.dos = dos;
		}
		
		public DataInputStream dis;
		public DataOutputStream dos;
		
		public void run() {
			while(true) {
				try {
					String texto = dis.readUTF();
					synchronized(msgEntrada) {
						msgEntrada.addElement(texto);
						msgDisponible = true;
						msgEntrada.notifyAll();
					}
					difunde(texto);
				} catch (IOException e) {
					e.printStackTrace();
					break;
				}			
			}
		}
	}
	
}
