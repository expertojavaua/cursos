package es.ua.jtech.jdm.sesion18.bt;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.StringItem;
import javax.microedition.lcdui.TextField;

public class FormChat extends Form implements CommandListener, Runnable {

	ConexionChat con;
	
	TextField txtEnviar;
	
	Command cmdEnviar;
	
	public FormChat(ConexionChat con) {
		super("Chat");
		this.con = con;
		
		txtEnviar = new TextField("Mensaje:", "", 100, TextField.ANY);
		this.append(txtEnviar);
		
		cmdEnviar = new Command("Enviar", Command.SCREEN, 1);
		this.addCommand(cmdEnviar);
		
		this.setCommandListener(this);
		
		Thread t = new Thread(this);
		t.start();
	}

	public void commandAction(Command cmd, Displayable d) {

		if(cmd == cmdEnviar) {
			String texto = txtEnviar.getString();
			try {
				con.envia(texto);				
				//this.insert(1,new StringItem("Enviado:", texto));
				txtEnviar.setString("");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	public void run() {

		while(true) {
			try {
				String texto = con.recibe();
				this.insert(1,new StringItem("Recibido:", texto));
			} catch (IOException e) {
				e.printStackTrace();
				break;
			}			
		}
	}
}
