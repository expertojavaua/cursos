package es.ua.jtech.jdm.sesion18.bt;

import java.io.IOException;

public interface ConexionChat {

	public void envia(String texto) throws IOException;
	
	public String recibe() throws IOException;
}
