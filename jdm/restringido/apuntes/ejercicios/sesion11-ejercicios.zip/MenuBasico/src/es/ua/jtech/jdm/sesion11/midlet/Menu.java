package es.ua.jtech.jdm.sesion11.midlet;

import javax.microedition.lcdui.ChoiceGroup;
import javax.microedition.lcdui.List;

public class Menu extends List {

	public Menu() {
		super("Menu", ChoiceGroup.IMPLICIT);
		
		this.append("Nuevo juego", null);
		this.append("Continuar partida", null);
		this.append("Salir", null);
	}
}
