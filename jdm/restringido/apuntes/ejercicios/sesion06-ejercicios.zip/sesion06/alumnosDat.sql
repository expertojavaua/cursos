INSERT INTO `alumnos` (`exp`,`nombre`,`sexo`) VALUES (1,'Manuel Garc�a P�rez','M');
INSERT INTO `alumnos` (`exp`,`nombre`,`sexo`) VALUES (2,'Rafael Mart�nez Rodr�guez','M');
INSERT INTO `alumnos` (`exp`,`nombre`,`sexo`) VALUES (3,'Mar�a Rueda Garc�a','F');
INSERT INTO `alumnos` (`exp`,`nombre`,`sexo`) VALUES (4,'Julio Gonz�lez Chamorro','M');
INSERT INTO `alumnos` (`exp`,`nombre`,`sexo`) VALUES (5,'Olga S�nchez Ortiz','F');
