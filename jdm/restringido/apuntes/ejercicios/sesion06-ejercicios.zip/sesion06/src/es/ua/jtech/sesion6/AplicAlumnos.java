package es.ua.jtech.sesion6;

public class AplicAlumnos 
{
	
	public AplicAlumnos()
	{
	}
	
	public boolean conectaBD()
	{
		return false;
	}
	
	public int insertaAlumno(int exp, String nombre, String sexo) 
	{
		return 0;
	}
	
	public int borraAlumno(int exp)
	{
		return 0;
	}
	
	public int modificaAlumno (int exp, String nombre, String sexo)
	{
		return 0;
	}
	
	public ResultSet listaAlumnos()
	{
		return null;
	}
		
	public static void main(String[] args) 
	{
		AplicAlumnos aa = new AplicAlumnos();
		if (!aa.conectaBD())
		{
			System.err.println("Error conectando con la BD");
			System.exit(-1);
		}
		
	}

}
