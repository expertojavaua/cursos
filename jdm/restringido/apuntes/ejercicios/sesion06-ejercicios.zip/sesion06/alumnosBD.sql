
CREATE DATABASE IF NOT EXISTS `alumnos`;

DROP TABLE IF EXISTS `alumnos`.`alumnos`;
CREATE TABLE `alumnos`.`alumnos` (
  `exp` INTEGER NOT NULL,
  `nombre` VARCHAR(200) NULL,
  `sexo` VARCHAR(10) NULL,
  PRIMARY KEY (`exp`)
)
