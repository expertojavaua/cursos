package es.ua.jtech.jdm.sesion17.chat;

import java.io.*;
import java.util.*;
import javax.microedition.io.*;
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class ListaMensajes extends Form implements CommandListener {

	public final static int PERIODO = 5;
	public final static int CAPACIDAD = 5;

	MIDlet owner;
	Displayable previo;

	Command cmdAtras;
	Command cmdEnviar;
	
	String url;

	public ListaMensajes(MIDlet owner, Displayable previo, String url) throws IOException {
		super("Chat");
		
		this.owner = owner;
		this.previo = previo;
		this.url = url;
		
		actualizaLista(url);

		// Crea los comandos
		cmdAtras = new Command("Atras", Command.BACK, 1);
		cmdEnviar = new Command("Enviar", Command.SCREEN, 1);
		this.addCommand(cmdAtras);
		this.addCommand(cmdEnviar);
		this.setCommandListener(this);

		// Temporizador para refrescar la lista periodicamente
		Timer temp = new Timer();
		Actualiza actualiza = new Actualiza();
		temp.schedule(actualiza, 5000,5000);
	}	
	
	private synchronized void actualizaLista(String url) throws IOException {

		// Actualiza la lista de mensajes leyendo del servidor
		HttpConnection con = (HttpConnection)Connector.open(url + "?accion=lista");
		InputStream in = con.openInputStream();
		DataInputStream dis = new DataInputStream(in);
		
		try {
			while(true) {
				String nick = dis.readUTF();
				String msg = dis.readUTF();

				if(this.size() >= CAPACIDAD) {
					this.delete(0);
				}
				this.append(new StringItem("<" + nick + ">", msg));			
			}
			
		} catch(EOFException e) {}

		dis.close();
		in.close();
		con.close();
	}
	
	public void commandAction(Command cmd, Displayable disp) {
		if(cmd == cmdAtras) {

			// Vuelve a la pantalla anterior
			Display d = Display.getDisplay(owner);
			d.setCurrent(previo);

		} else if(cmd == cmdEnviar) {

			// Va a la pantalla de enviar mensaje
			EnviarMensaje em = new EnviarMensaje(owner, this, url);
			Display d = Display.getDisplay(owner);
			d.setCurrent(em);			
		}
	}

	// Tarea de refresco automatico de la lista de mensajes

 	class Actualiza extends TimerTask {
		public void run() {
			try {
				actualizaLista(url);
			} catch (IOException e) {
			}
		}
	}
}
