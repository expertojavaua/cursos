/*
 * Created on 25/06/2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package es.ua.jtech.jdm.sesion14.game.tapper.engine;

import java.util.Enumeration;
import java.util.Random;
import java.util.Vector;

import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;
import javax.microedition.lcdui.game.GameCanvas;
import javax.microedition.lcdui.game.Sprite;

import es.ua.jtech.jdm.sesion14.game.tapper.data.CommonData;
import es.ua.jtech.jdm.sesion14.game.tapper.data.Resources;
import es.ua.jtech.jdm.sesion14.game.tapper.data.StageData;

/**
 * @author Miguel Angel and Boyan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class GameScene implements Scene {

	// Control de estados
	public static int E_INICIO = 0;
	public static int E_JUGANDO = 1;
	public static int E_MUERTO = 2;
	public static int E_CONSEGUIDO = 3;
	int state;
	int timer;
	boolean serving; // Mientras está sirviendo se detiene por unos ticks.
	int servingtimer;

	int numLives;
	int stage;

	// Objetivo de la fase:
	// Cada nivel tiene un número de clientes a los que tiene que servir.
	// clientsToServe se inicializa en cada Stage, y tiene que llegar a 0 para completar el Stage.
	int clientsToServe;  
	// probClients y Return regula la probabilidad de los eventos de aparecer un nuevo cliente y
	// de que devuelva su cerveza, en caso de tenerla ya.
	int probClients;
	int probReturn;
	
	int cx, cy; //Center of the screen
	
	Background bg;
	BarmanSprite barman;
	Vector beers,clients;
	Image face,cerv; // Para imprimir información de estado en la parte superior de la pantalla
	
	Random random; // Para los eventos aleatorios
	
	public GameScene() {
		cx = CommonData.SCREEN_WIDTH/2;
		cy = CommonData.SCREEN_HEIGHT/2;
		
		bg = new Background(); // Debe iniciarse primero el background, y después los Sprites
		barman = new BarmanSprite();
		beers = new Vector();
		clients = new Vector();
		face = Resources.getImage(Resources.IMG_FACE_LIVES);
		cerv = Resources.getImage(Resources.IMG_SPR_BEER);
		cerv = Image.createImage(cerv, 0, 0, CommonData.BEER_WIDTH, CommonData.BEER_HEIGHT, Sprite.TRANS_NONE);
		random = new Random();
		
		reset();
	}
	
	// Reinicio de la partida
	public void reset() {
		numLives = CommonData.NUM_LIVES;
		stage = 0;
		beers.removeAllElements();
		reset(stage);
	}
	
	// Reinicio de una fase
	public void reset(int nStage, boolean newLevel) {
		StageData staged = Resources.stageData[nStage];
		bg = new Background(); // Debe iniciarse primero el background, y después los Sprites
		bg.reset(staged);
		barman.reset();
		// Si se ha reiniciado la fase (stage) por muerte y no por subir de nivel,
		// entonces se dejan las cervezas rotas en el suelo y se quitan las de la barra.
		// Si es nivel nuevo, se quitan también las rotas.
		if(newLevel)
			beers.removeAllElements();
		else{
			//Quita las cervezas que no estén rotas
			Enumeration enumeration = beers.elements();
			while(enumeration.hasMoreElements()) {
				BeerSprite beer = (BeerSprite)enumeration.nextElement();
				if(!beer.isbroken())
					beers.removeElement(beer);
			}
		}
		// Inicialización de otras variables que cambian con cada nuevo Stage
		clientsToServe = staged.numClients;
		probClients = staged.probClients;
		probReturn = staged.probReturn;
		clients.removeAllElements();
		
		this.setState(E_INICIO);
	}
	
	public void reset(int nStage) {
		reset(nStage, false);
	}
	
	public void setState(int state) {
		this.state = state;

		if(state==E_INICIO) {
			timer = 15;
		} else if(state==E_MUERTO) {
			// Si lo acababa de conseguir, no matarlo para que pase de fase
			if( this.state == E_CONSEGUIDO )
				return;
			timer = 30;
			barman.die();
		} else if(state==E_CONSEGUIDO) {
			timer = 50;
		}
		
		servingtimer = 0;
		serving = false;
	}
	
	public void tick(int keyState) {
		// Decrementa el tiempo de espera
		if(state==E_INICIO || state==E_MUERTO || state==E_CONSEGUIDO) {
			timer--;
		}

		// Comienza el juego
		if(state==E_INICIO && timer <= 0) {
			this.setState(E_JUGANDO);
		}
		
		// Reinicia el nivel o termina el juego
		if(state==E_MUERTO && timer <= 0) {
			numLives--;
			if(numLives<0) {
				Resources.midlet.showTitle();
			} else {
				this.reset(stage);
				return;
			}
		}
		
		if(state==E_CONSEGUIDO && timer <= 0) {
			stage++;
			if(stage >= Resources.stageData.length) {
				stage = 0;
			}

			this.reset(stage,true);
			return;
		}
		
		if(state==E_JUGANDO) {
			// Control del sprite
			
			if( serving ){ // Detenerlo por unos ticks si está sirviendo cerveza
				servingtimer--;
				if(servingtimer == CommonData.BEER_TIMER_SERVE){
					barman.nextFrame();
				}else if(servingtimer == 0){
					serving = false;
					barman.endserve();
					//Dejar una cerveza
					beers.addElement(new BeerSprite(CommonData.BARRAS_XFin[barman.getBarra()]-CommonData.BG_TILE_WIDTH, barman.getBarra(), true));
				}
			} else if( (keyState & GameCanvas.UP_PRESSED)!=0 ) {
				barman.moveUp();
			} else if( (keyState & GameCanvas.DOWN_PRESSED)!=0 ) {
				barman.moveDown();
			} else if( (keyState & GameCanvas.LEFT_PRESSED)!=0 && barman.getX() > 0) {
				barman.moveLeft();
			} else if( (keyState & GameCanvas.RIGHT_PRESSED)!=0 && barman.getX() < CommonData.SCREEN_WIDTH - CommonData.SPRITE_WIDTH) {
				barman.moveRight();
			} else if( (keyState & GameCanvas.FIRE_PRESSED)!=0 && (Math.abs(barman.getX()-CommonData.BARRAS_XFin[barman.getBarra()])<CommonData.BG_TILE_WIDTH)){
				// Servir una cerveza
				barman.serve();
				serving = true;
				servingtimer = CommonData.BEER_TIMER_FILL;
			} else {
				// Si no se ha pulsado nada, se queda parado.
				barman.stay();
			}
			// Control de la probabilidad de sucesos a través del teclado con GAME_A y GAME_B
			if( (keyState & GameCanvas.GAME_B_PRESSED)!=0 ) {
				CommonData.PROB_PERCENTAGE++;
				if(CommonData.PROB_PERCENTAGE>CommonData.PROB_MAX_PERCENTAGE)
					CommonData.PROB_PERCENTAGE = CommonData.PROB_MAX_PERCENTAGE;
			}else if( (keyState & GameCanvas.GAME_A_PRESSED)!=0 ) {
				CommonData.PROB_PERCENTAGE--;
				if(CommonData.PROB_PERCENTAGE<CommonData.PROB_MIN_PERCENTAGE)
					CommonData.PROB_PERCENTAGE = CommonData.PROB_MIN_PERCENTAGE;
			}
		}

		// Actualiza cervezas
		Enumeration enumeration = beers.elements();
		while(enumeration.hasMoreElements()) {
			BeerSprite beer = (BeerSprite)enumeration.nextElement();
			beer.tick(); // Moverla hacia donde corresponda.
			if(!beer.isbroken()){ // Solo comprobar las que no estén rotas
				boolean recogida = false;
				if(!beer.isFull()){ // Si además está vacía, la debe recoger el camarero
					if(beer.collidesWith(barman, false)){ // La recoge
						beers.removeElement(beer);
						recogida = true;
					}
				}
				if(!beer.isOnBar() && !recogida){ // Si no está en la barra, estado muerto.
					this.setState(E_MUERTO);
				}
			}
		}
		
		//Crea nuevos clientes
		int numero = (Math.abs(random.nextInt()) % (CommonData.PROB_PERCENTAGE*10));
		if( numero < probClients ){
			int nbarra = (Math.abs(random.nextInt()) % CommonData.NUM_BARRAS);
			// El abanico de tipos de clientes es más amplio en cada nueva fase
			int tipocl = (Math.abs(random.nextInt()) % (CommonData.NUM_CLIENT_TYPES*(1+stage) / CommonData.NUM_STAGES) );
			int step = CommonData.NUM_BARRAS - nbarra;
			clients.addElement(new ClientSprite(tipocl,nbarra,step));
		}

		
		// Actualiza clientes
		enumeration = clients.elements();
		while(enumeration.hasMoreElements()) {
			ClientSprite client = (ClientSprite)enumeration.nextElement();
			
			//Comprueba si ha venido una cerveza (no rota y llena) para el cliente
			if(!client.hasABeer() && client.comes()){
				Enumeration enumeration2 = beers.elements();
				while(enumeration2.hasMoreElements()) {
					BeerSprite beer = (BeerSprite)enumeration2.nextElement();
					if(!beer.isbroken() && beer.isFull() && beer.collidesWith(client, false)){ //Cliente obtiene cerveza
							beers.removeElement(beer);
							client.vuelve();
							//Actualiza el contador del objetivo
							clientsToServe--;
							if(clientsToServe==0)
								setState(E_CONSEGUIDO);
					}
				}
				
			}else if(client.hasABeer() && !client.comes()){ //Ver si se la devolvemos o no, aleatoriamente
				
				numero = (Math.abs(random.nextInt()) % (CommonData.PROB_PERCENTAGE*10));
				if( numero < probReturn ){
					client.tiraVaso();
					beers.addElement(new BeerSprite(client.getX(),client.getBarra(),false));
				}
			}
			
			// Mover cliente hacia donde corresponda
			client.tick();
			
			if(client.isAlive() && !client.isOnBar()){ // Comprobar si se ha ido
				if(client.comes()){ //Ha llegado al final de la barra sin ser atendido, hemos fallado
					this.setState(E_MUERTO);
					barman.setPosition(CommonData.BARRAS_XFin[client.getBarra()], CommonData.BARRAS_Y[client.getBarra()]);
					client.die();
				}else
					clients.removeElement(client); //Este ya ha vuelto bien al principio de la barra, lo quitamos.
			}
			
		}
		return;
	}

	public void render(Graphics g) {
		//Pintar imagen de fondo el fondo (las barras).
		g.setColor(255, 255, 255);
		g.fillRect(0, 0, CommonData.SCREEN_WIDTH, CommonData.SCREEN_HEIGHT);
		g.drawImage(bg.imagen, cx, cy, Graphics.VCENTER | Graphics.HCENTER);
		bg.paint(g);
		
		//Pintar todos los sprites por orden de barra para conseguir la superposición correcta
		//Para evitar recorrer las listas "b" veces, los sprites se pueden tener en un Vector de Vectores,
		//con un Vector de sprites por cada una de las barras.
		//Se deja así por claridad del código en la función tick().
		for( int b=0; b<CommonData.NUM_BARRAS; b++){
			Enumeration enumeration = clients.elements();
			while(enumeration.hasMoreElements()) {
				ClientSprite client = (ClientSprite)enumeration.nextElement();
				if(client.getBarra()==b)
					client.paint(g);
			}	
	
			enumeration = beers.elements();
			while(enumeration.hasMoreElements()) {
				BeerSprite beer = (BeerSprite)enumeration.nextElement();
				if(beer.getBarra()==b)
					beer.paint(g);
			}	
			if(barman.getBarra()==b)
				barman.paint(g);
		}


		//Print some state information
		g.setColor(CommonData.STAGE_TITLE_COLOR);
		
		for(int i=0;i<this.numLives;i++) {
			g.drawImage(face, i*(CommonData.FACE_WIDTH+1), 0, Graphics.TOP | Graphics.LEFT);
		}
		g.drawImage(cerv, 0, CommonData.FACE_HEIGHT+2, Graphics.TOP | Graphics.LEFT);
		g.setFont(CommonData.POINTS_FONT);
		g.drawString(""+clientsToServe, CommonData.BEER_WIDTH+2, CommonData.FACE_HEIGHT+2, Graphics.TOP | Graphics.LEFT);
		g.drawString("P="+(CommonData.PROB_MAX_PERCENTAGE-CommonData.PROB_PERCENTAGE+CommonData.PROB_MIN_PERCENTAGE), CommonData.SCREEN_WIDTH-10, CommonData.FACE_HEIGHT+2, Graphics.TOP | Graphics.RIGHT);

		if(state==E_INICIO) {
			g.setFont(CommonData.STAGE_TITLE_FONT);
			g.drawString(Resources.stageData[stage].title, CommonData.SCREEN_WIDTH/2, CommonData.STAGE_TITLE_Y, Graphics.HCENTER | Graphics.TOP);			
		}

		if(state==E_CONSEGUIDO) {
			g.setFont(CommonData.STAGE_TITLE_FONT);
			g.drawString(CommonData.STAGE_COMPLETED_TEXT, CommonData.SCREEN_WIDTH/2, CommonData.STAGE_TITLE_Y, Graphics.HCENTER | Graphics.TOP);			
		}
	
	}

}
