/*
 * Created on 26/04/2009
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package es.ua.jtech.jdm.sesion14.game.tapper.engine;

import java.util.Random;

import javax.microedition.lcdui.game.Sprite;

import es.ua.jtech.jdm.sesion14.game.tapper.data.CommonData;
import es.ua.jtech.jdm.sesion14.game.tapper.data.Resources;

/**
 * @author Miguel Angel and Boyan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class BeerSprite extends Sprite {
	boolean llena;
	int nbarra;
	boolean broken;
	/*
	 * Lógica:
	 * Si la cerveza está llena, va hacia la izquierda (lanzada por el camarero a los clientes;
	 * si está vacía, va hacia la derecha (lanzada por los clientes al camarero).
	 * Si está rota en el suelo hay que dejarla ahi sin comprobar colisiones.
	 * Se rompe tanto si se sale de la barra por un lado, como por el otro.
	 * Eliminar la cerveza: si está llena se elimina cuando la coge un cliente,
	 * y entonces al sprite del cliente se le cambia el frame, como que está bebiendo.
	 * Si el cliente que está bebiendo quiere devolver el vaso, se crea una nueva cerveza vacía.
	 * La cerveza vacía se elimina si entra en colisión con el camarero (la recoge).
	 */
	public BeerSprite(int x, int nbarra, boolean llena) {
		super(Resources.getImage(Resources.IMG_SPR_BEER),CommonData.BEER_WIDTH, CommonData.BEER_HEIGHT);
		this.llena = llena;
		this.broken = false;
		this.nbarra = nbarra;
		this.setPosition(x,CommonData.BARRAS_Y[nbarra]+10);
		if(llena)
			this.setFrame(0);
		else
			this.setFrame(1);
			
	}
	
	public void tick() {
		if( !broken ){
			if(llena){
				this.move(-CommonData.BEER_STEP,0);
			}else{
				this.move(CommonData.BEER_BACK_STEP, 0);
			}
		}
	}
	
	public void breakme(){
		this.broken = true;
		this.setFrame(2);
		Random r = new Random();
		int saltoH = (Math.abs(r.nextInt()) % 7) + 1;
		int saltoV = (Math.abs(r.nextInt()) % 5) + 1;
		if(llena){
			this.move(-CommonData.BEER_STEP*saltoH,20+saltoV);
		}else{
			this.move(CommonData.BEER_STEP*saltoH, 20+saltoV);
		}
	}
	
	public boolean isbroken(){
		return broken;
	}
	
	public boolean isFull(){
		return llena;
	}
	public int getBarra(){
		return nbarra;
	}
	
	public boolean isOnBar(){
		if(llena){
			if(getX()>CommonData.BARRAS_XIni[nbarra])
				return true;
			else{
				breakme();
				return false;
			}
		}else{
			if(getX()<CommonData.BARRAS_XFin[nbarra])
				return true;
			else{
				breakme();
				return false;
			}
				
			
		}
	}

}
