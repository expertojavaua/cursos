/*
 * Created on 26/04/2009
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package es.ua.jtech.jdm.sesion14.game.tapper.engine;

import javax.microedition.lcdui.game.Sprite;

import es.ua.jtech.jdm.sesion14.game.tapper.data.CommonData;
import es.ua.jtech.jdm.sesion14.game.tapper.data.Resources;

/**
 * @author Miguel Angel and Boyan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ClientSprite extends Sprite {
	boolean hasBeer,isComing,isDead;
	int nbarra;
	int freq, cycles;
	int tipoCliente;
	static final int[] deadSequence = {0,CommonData.NUM_CLIENT_TYPES+1}; // La paloma
	
	/*
	 * Lógica:
	 * Por cada tipo de cliente hay 3 frames posibles: ir, volver, y volver bebiendo.
	 * Además hay 2 frames que sirven para dibujar una paloma, que indica que el cliente
	 * ha llegado al fin de la barra sin cerveza y por tanto "ha muerto" y se va.
	 * Cuando el cliente va hacia el fin de la barra esperando una cerveza, está con el icono de ir.
	 * Cuando recibe una cerveza por colisión con un sprite de cerveza llena, empieza a volver
	 * con el icono de volver bebiendo. Si decide devolver la cerveza vacia, sigue en estado de volver,
	 * pero se le cambia el icono al de volver sin cerveza. Cuando vuelve a llegar al inicio de la barra,
	 * tanto si es con cerveza como si no, se elimina.
	 */
	public ClientSprite(int tipoCliente, int nbarra, int frecuencia) {
		super(Resources.getImage(Resources.IMG_SPR_CLIENTES),CommonData.CLIENT_WIDTH, CommonData.CLIENT_HEIGHT);
		this.setFrame(tipoCliente+1);
		this.tipoCliente = tipoCliente;
		this.hasBeer = false;
		this.isComing = true;
		this.isDead = false;
		this.nbarra = nbarra;
		this.freq = frecuencia;
		this.cycles = 0;
		this.setPosition(CommonData.BARRAS_XIni[nbarra],CommonData.BARRAS_Y[nbarra]+3);
	}
	
	public void setFreq(int f){
		freq = f;
	}
	
	public void tick() {
		cycles++;
		if(cycles == freq){
			cycles = 0;
			if(isComing)
				this.move(1, 0);
			else
				this.move(-1, 0);
		}
		if(isDead)
			this.nextFrame();
	}
	
	public void vuelve(){
		hasBeer = true;
		isComing = false;
		this.setFrame(tipoCliente+2*CommonData.NUM_CLIENT_TYPES+3);
	}

	public void tiraVaso(){
		hasBeer = false;
		isComing = false;
		this.setFrame(tipoCliente+CommonData.NUM_CLIENT_TYPES+2);
	}

	public void die(){
		hasBeer = false;
		isComing = true;
		isDead = true;
		this.setFrameSequence(deadSequence);
	}
	
	public boolean isAlive(){
		return !isDead;
	}
	
	public boolean comes(){
		return isComing;
	}

	public boolean hasABeer(){
		return hasBeer;
	}
	
	public int getBarra(){
		return nbarra;
	}
	
	public boolean isOnBar(){
		if(!isComing){
			if(getX()>CommonData.BARRAS_XIni[nbarra])
				return true;
			else{
				return false;
			}
		}else{
			if(getX()<CommonData.BARRAS_XFin[nbarra]-15)
				return true;
			else{
				return false;
			}
				
			
		}
	}

}
