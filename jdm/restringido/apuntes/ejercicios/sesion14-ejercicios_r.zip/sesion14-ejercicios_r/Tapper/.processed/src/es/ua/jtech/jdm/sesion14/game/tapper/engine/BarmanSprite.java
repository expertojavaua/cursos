/*
 * Created on 26/06/2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package es.ua.jtech.jdm.sesion14.game.tapper.engine;

import javax.microedition.lcdui.game.Sprite;

import es.ua.jtech.jdm.sesion14.game.tapper.data.CommonData;
import es.ua.jtech.jdm.sesion14.game.tapper.data.Resources;

/**
 * @author Miguel Angel and Boyan
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class BarmanSprite extends Sprite {

	public final static int MOVE_UP = 0;
	public final static int MOVE_DOWN = 1;
	public final static int MOVE_LEFT = 2;
	public final static int MOVE_RIGHT = 3;
	public final static int MOVE_STAY = 4;
	public final static int MOVE_SERVE = 5;
	
	int barra;
	int lastMove;
	
	/*
	 * Lógica:
	 * El Barman puede moverse por las barras de derecha a izquierda, y puede subir y bajar de barra 
	 * sólo si está cerca del final de la barra. También, cuando esté cerca del final de la barra, podrá
	 * "servir" cerveza, acción que lo bloquea durante varios ticks con el dibujo (frame) correspondiente
	 * a estar sirviendo.
	 * También tiene un frame de "muerto" (en este caso más bien avergonzado), que se establece cuando
	 * cae alguna cerveza o cuando se va un cliente sin ser atendido. Eso lo controla la lógica del juego
	 * en GameScene.tick().
	 */
	
	public BarmanSprite() {
		super(Resources.getImage(Resources.IMG_SPR_BARMAN), CommonData.SPRITE_WIDTH, CommonData.SPRITE_HEIGHT);
		this.defineCollisionRectangle(CommonData.SPRITE_COLLISION_X, CommonData.SPRITE_COLLISION_Y, CommonData.SPRITE_COLLISION_WIDTH, CommonData.SPRITE_COLLISION_HEIGHT);
	}

	public void reset() {
		// Inicializa frame y movimiento actual
		lastMove = MOVE_STAY;
		barra = 0;
		this.setFrameSequence(null);
		this.setFrame(CommonData.SPRITE_STAY_LEFT);

		// Inicializa posici�n
		this.setPosition(CommonData.BARRAS_XFin[barra], CommonData.BARRAS_Y[barra]);
	}
	
	public void stay() {
		switch(lastMove) {
			case MOVE_LEFT:
				this.setFrameSequence(null);
				this.setFrame(CommonData.SPRITE_STAY_LEFT);
				break;
			case MOVE_RIGHT:
				this.setFrameSequence(null);
				this.setFrame(CommonData.SPRITE_STAY_RIGHT);
				break;
		}
		lastMove = MOVE_STAY;
	}
	
	public void die() {
		this.setFrameSequence(null);
		this.setFrame(CommonData.SPRITE_STAY_DEAD);
		lastMove = MOVE_STAY;
	}

	public void moveUp() {
		if(lastMove != MOVE_UP) {
			lastMove = MOVE_UP;
			if(Math.abs(this.getX()-CommonData.BARRAS_XFin[barra])<CommonData.BG_TILE_WIDTH){
				barra--; if(barra<0) barra = CommonData.NUM_BARRAS-1;
				this.setPosition(CommonData.BARRAS_XFin[barra], CommonData.BARRAS_Y[barra]);	
			}
		}
	}

	public void moveDown() {
		if(lastMove != MOVE_DOWN) {
			lastMove = MOVE_DOWN;
			if(Math.abs(this.getX()-CommonData.BARRAS_XFin[barra])<CommonData.BG_TILE_WIDTH){
				barra++; if(barra>=CommonData.NUM_BARRAS) barra = 0;
				this.setPosition(CommonData.BARRAS_XFin[barra], CommonData.BARRAS_Y[barra]);	
			}
		}
	}

	public void moveLeft() {
		if(lastMove != MOVE_LEFT) {
			this.setFrameSequence(CommonData.SPRITE_MOVE_LEFT);			
		}
		lastMove = MOVE_LEFT;
		if(this.getX()<=CommonData.BARRAS_XIni[barra])
			this.setPosition(CommonData.BARRAS_XIni[barra], CommonData.BARRAS_Y[barra]);
		else
			this.move(-CommonData.SPRITE_STEP,0);
		this.nextFrame();
	}

	public void moveRight() {
		if(lastMove != MOVE_RIGHT) {
			this.setFrameSequence(CommonData.SPRITE_MOVE_RIGHT);			
		}
		lastMove = MOVE_RIGHT;
		if(this.getX()>=CommonData.BARRAS_XFin[barra])
			this.setPosition(CommonData.BARRAS_XFin[barra], CommonData.BARRAS_Y[barra]);
		else
			this.move(CommonData.SPRITE_STEP,0);
		this.nextFrame();
	}

	public int getBarra(){
		return barra;
	}
	public void setBarra(int b){
		barra = b;
	}

	public void serve() {
		lastMove = MOVE_SERVE;
		this.setPosition(CommonData.BARRAS_XFin[barra], CommonData.BARRAS_Y[barra]);
		this.setFrameSequence(CommonData.SPRITE_SERVE);
		this.setFrame(0);
	}
	public void endserve(){
		lastMove = MOVE_LEFT;
		stay();
	}
}
