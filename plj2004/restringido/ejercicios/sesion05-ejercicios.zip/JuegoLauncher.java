package modulo1.sesion5;
import java.io.*;

public class JuegoLauncher {

    public static void main(String[] args) throws IOException{
        JuegoLaberinto jl;
        
        jl = new JuegoLaberinto();
        jl.juega();
        }
}
