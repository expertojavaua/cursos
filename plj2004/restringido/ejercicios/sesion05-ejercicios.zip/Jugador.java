
package modulo1.sesion5;

public class Jugador {
    
    static int LIBRE = 0;
    static int COGIDO = 1;
    
    Posicion pos;
    int estado;
    
    public Jugador(Posicion pos){
        this.pos = pos;
    }
    
    public Jugador(int fila, int columna) {
        this(new Posicion(fila,columna));
   }
    
    public Posicion getPos () {
        return pos;
    }
    
    
    public void mueve(int direccion){
        pos.mueve(direccion);
    }
    
    public String toString() {
         return(pos.toString());
    }
}
