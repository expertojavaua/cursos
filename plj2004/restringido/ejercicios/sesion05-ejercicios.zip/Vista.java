package modulo1.sesion5;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Vista {
    EstadoJuego estado;
    char etiqJugador = '*';
    char etiqEnemigo = '-';
    BufferedReader in;

    public Vista(EstadoJuego estado) {
        this.estado = estado;
        in = new BufferedReader(new InputStreamReader(System.in));
    }

    public String toString() {
        Jugador jugador, enemigo;
        Laberinto lab;
        
        jugador = estado.jugador;
        lab = estado.laberinto;
        
        Posicion p1 = jugador.getPos();
        String s = "";

        for (int i = 0; i < lab.filas; i++) {
            for (int j = 0; j < lab.columnas; j++) {
                if (lab.ocupado(i, j))
                    s = s + '#';
                else {
                    if (p1.fila == i && p1.columna == j)  s = s + etiqJugador;
                    else  s = s + ' ';
                }
            }
            s = s + '\n';
        }
        if (estado.finJuego) {
            s = s + "FIN DE JUEGO\n";
            if (estado.ganador)
                s = s + "HAS LLEGADO A LA SALIDA!! \n";
        }
        return (s);
    }
    
    public void muestra() {
        System.out.println(this.toString());
    }

    public int obtenEntradaUsuario() throws IOException {
        boolean entradaOK = false;
        int salida = -1;

        while (!entradaOK) {
            entradaOK = true;
            System.out.print("INTRODUCE MOVIMIENTO (A,B,D,I,S)>");
            String line = in.readLine();
            if (line.equals("A"))
                salida = JuegoLaberinto.ARRIBA;
            else if (line.equals("B"))
                salida = JuegoLaberinto.ABAJO;
            else if (line.equals("D"))
                salida = JuegoLaberinto.DERECHA;
            else if (line.equals("I"))
                salida = JuegoLaberinto.IZQUIERDA;
            else if (line.equals("S"))
                salida = JuegoLaberinto.SALIR;
            else
                entradaOK = false;
        }
        return salida;
    }
}