package modulo1.sesion5;
import java.io.IOException;


public class JuegoLaberinto {
    Vista vista;
    Controlador control;
    EstadoJuego estado;

    // laberinto
    
    String[] strLab = {"# #############",
                       "#       #     #",
                       "# ### # # ### #",
                       "#   # #   ### #", 
                       "### ########  #",
                       "#   #   ####  #",
                       "# ### ###### ##",
                       "# #    ##### ##", 
                       "#   ##     # ##",
                       "############ ##"};
    
    // constantes: comandos del juego
    public static final int ARRIBA = 0;
    public static final int ABAJO = 1;
    public static final int IZQUIERDA = 2;
    public static final int DERECHA = 3;
    public static final int SALIR = 4;
       
    public JuegoLaberinto() {
        this.inicializa();
    }
    
    public void inicializa() {        
        Posicion posLibre, posOcupada;
        Laberinto laberinto;
        Jugador jugador, enemigo;
        
        laberinto = new Laberinto(strLab);
        posLibre = laberinto.posLibreAleatoria();
        enemigo = new Jugador(posLibre);
        laberinto.ocupa(posLibre);
        posOcupada = posLibre;
        posLibre = laberinto.posLibreAleatoria();
        laberinto.libera(posOcupada);
        jugador = new Jugador(posLibre);
        
        estado = new EstadoJuego();
        estado.jugador = jugador;
        estado.laberinto = laberinto;
        estado.finJuego = false;

        vista = new Vista(estado);
        control = new Controlador(estado);        
    }
    
    public Laberinto getLaberinto() {
        return estado.laberinto;
    }
    
    public Jugador getJugador() {
        return estado.jugador;
    }
     
    public EstadoJuego getEstado() {
        return estado;
    }
    
    public Controlador getControlador() {
        return control;
    }
    
    public Vista getVista() {
        return vista;
    }
    
    public void juega() throws IOException {
        for (;;) {
            vista.muestra();
            int comando = vista.obtenEntradaUsuario();
            control.pasoEjecucion(comando);
            if (control.finJuego()) {
                vista.muestra();
                break;
            }
        }
    }
}
