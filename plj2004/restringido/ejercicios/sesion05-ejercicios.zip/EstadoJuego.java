
package modulo1.sesion5;

public class EstadoJuego {
    public boolean finJuego = false;
    public boolean ganador = false;
    public Laberinto laberinto;
    public Jugador jugador;
}
