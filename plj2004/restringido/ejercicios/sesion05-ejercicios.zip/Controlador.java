package modulo1.sesion5;

public class Controlador {
    EstadoJuego estado;
    
    public Controlador(EstadoJuego estado) {
        this.estado = estado;
    }

    public void pasoEjecucion(int comando) {
        Jugador jugador, enemigo;
        Laberinto lab;
        Posicion posJugador, posEnemigo, posAux;

        if (comando == JuegoLaberinto.SALIR) {
            estado.finJuego = true;
            estado.ganador = false;
            return;
        }
        
        jugador = estado.jugador;
        lab = estado.laberinto;

        // realizo el movimiento del jugador
        posJugador = jugador.getPos();
        posAux = new Posicion(posJugador.fila, posJugador.columna);
        posAux.mueve(comando);
        
        if (!lab.ocupado(posAux)) {
            posJugador.mueve(comando);
        }

        // El jugador ha salido del laberinto

        if (posJugador.columna == 0
                || posJugador.columna == lab.getColumnas() - 1
                || posJugador.fila == 0
                || posJugador.fila == lab.getFilas() - 1) {
            estado.finJuego = true;
            estado.ganador = true;
        }
    }
    
    public boolean finJuego() {
        return estado.finJuego;
    }

}