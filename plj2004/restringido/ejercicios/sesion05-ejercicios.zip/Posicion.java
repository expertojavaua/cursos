package modulo1.sesion5;

public class Posicion {
    public int fila;
    public int columna;
    
    public static Posicion Aleatoria(int maxFila, int maxColumna) {
        int fila = (int)(Math.random()*maxFila);
        int columna = (int) (Math.random()*maxColumna);
        return new Posicion(fila,columna);
    }
    
    public Posicion(int fila, int columna) {
        this.fila = fila;
        this.columna = columna;
    }
    
    public void mueve(int dir) {
        if (dir == JuegoLaberinto.ARRIBA) fila--;
        else if (dir == JuegoLaberinto.ABAJO) fila++;
        else if (dir == JuegoLaberinto.IZQUIERDA) columna--;
        else if (dir == JuegoLaberinto.DERECHA) columna++;
    }
    
    public boolean equals(Posicion pos) {
        return (pos.fila == this.fila && 
                pos.columna == this.columna);
    }
    
    public String toString() {
        String s = "[" + fila + "," + columna + "]";
        return(s);
    }
}
