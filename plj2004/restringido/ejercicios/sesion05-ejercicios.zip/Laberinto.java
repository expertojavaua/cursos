package modulo1.sesion5;

public class Laberinto {
    int filas, columnas;
    boolean[][] celdas;

    /*
     * Para crear un laberinto hay que pasar la 
     * distribucion de las paredes usando un array
     * strings como el que sigue:
     * "# #############"
     * "#       #     #"
     * "# ### # # ### #"
     * "#   # #   ### #"
     * "### ########  #"
     * "#   #   ####  #"
     * "# ### ###### ##"
     * "# #    ##### ##"
     * "#   ##     # ##"
     * "############ ##"
     */
    public Laberinto(String[] strings) {
        this.filas = strings.length; // longitud del array
        this.columnas = strings[0].length(); // longitud de un
        celdas = new boolean[filas][columnas];

        // actualizo el array de celdas

        for (int i = 0; i < filas; i++)
            for (int j = 0; j < columnas; j++) {
                if (strings[i].charAt(j) == '#')
                    celdas[i][j] = true;
                else
                    celdas[i][j] = false;
            }
    }
    
    public void ocupa(Posicion pos) {
        ocupa(pos.fila, pos.columna);
    }

    public void ocupa(int fila, int col) {
        celdas[fila][col] = true;
    }

    public void libera(Posicion pos) {
        libera(pos.fila, pos.columna);
    }

    public void libera(int fila, int col) {
        celdas[fila][col] = false;
    }
    
    public int getFilas(){
        return filas;
    }
    
    public int getColumnas() {
        return columnas;
    }
    
    public boolean ocupado(Posicion pos) {
        return ocupado (pos.fila,pos.columna);
    }
    
    public boolean ocupado(int fila, int columna) {
        return celdas[fila][columna];
    }
    
    public Posicion posLibreAleatoria() {
        Posicion pos;
        
        for(;;) {
            pos = Posicion.Aleatoria(filas,columnas);
            if (!ocupado(pos)) break;
        }
        return pos;
    }
    
    /*
     * Dada una posicion definida por (fila,columna) devuelve true si la
     * posicion definida por la direccion est� libre. El par�metro direccion
     * puede tener el valor ARRIBA, ABAJO, DERECHA, IZQUIERDA.
     * Suponemos que el valor (fila,columna) es una posicion libre
     */
    public boolean ocupadoDireccion(int fila, int columna, int direccion) {
        return true;
    }

    public String toString() {
        String s = new String("");
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                if (celdas[i][j])
                    s = s + '#';
                else
                    s = s + ' ';
            }
            s = s + '\n';
        }
        return (s);
    }

}