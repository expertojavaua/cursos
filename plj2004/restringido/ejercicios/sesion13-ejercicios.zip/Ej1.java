import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Ej1 extends JFrame
{
	MiPanel mp = new MiPanel();			// Panel propio
	MiCanvas mc = new MiCanvas();		// Canvas propio
	
	// Constructor
	public Ej1()
	{
		setSize(300, 300);
		getContentPane().setLayout(new GridLayout(2, 1));
				
		getContentPane().add(mp);
		getContentPane().add(mc);
				
		this.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			}
		});		
	}
	
	// Funcion main
	public static void main(String[] args)
	{
		Ej1 e1 = new Ej1();
		e1.show();
	}
	

	// Clase propia para redefinir un panel
	class MiPanel extends JPanel
	{
		public MiPanel()
		{
		}
	}
	
	// Clase propia para redefinir un canvas
	class MiCanvas extends Canvas
	{
		public MiCanvas()
		{
		}
	}
}
