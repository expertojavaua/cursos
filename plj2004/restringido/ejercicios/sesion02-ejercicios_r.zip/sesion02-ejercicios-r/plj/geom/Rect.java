package plj.geom;

/**
 * Esta clase representa un rectangulo. Sus campos representan las coordenadas
 * de las esquinas del rect�ngulo. Sus m�todos define operaciones que se pueden
 * realizar sobre los objetos Rect.
 *  
 */
public class Rect {
	// Estos son los campos de la clase
	public double x1, y1, x2, y2;

	/**
	 * Este es el constructor principal de la clase
	 */
	public Rect(double x1, double y1, double x2, double y2) {
		this.x1 = x1;
		this.y1 = y1;
		this.x2 = x2;
		this.y2 = y2;
	}

	/**
	 * Este es otro constructor en el que se proporciona la base y la altura.
	 * LLama al constructor definido anteriormente.
	 */
	public Rect(double width, double height) {
		this(0, 0, width, height);
	}

	/** Otro constructor m�s	 */
	public Rect() {
		this(0, 0, 0, 0);
	}

	/** Mueve el rect�ngulo la cantidad especificada */
	public void move(double deltax, double deltay) {
		x1 += deltax;
		x2 += deltax;
		y1 += deltay;
		y2 += deltay;
	}

	/** Comprueba si un punto especificado est� dentro del rect�ngulo */
	public boolean isInside(double x, double y) {
		return ((x >= x1) && (x <= x2) && (y >= y1) && (y <= y2));
	}

	/**
	 * Devuelve la uni�n de este rect�ngulo con otro. Esto es, devuelve el 
	 * rect�ngulo que incluye a los dos.
	 */
	public Rect union(Rect r) {
		return new Rect((this.x1 < r.x1) ? this.x1 : r.x1,
				(this.y1 < r.y1) ? this.y1 : r.y1, (this.x2 > r.x2) ? this.x2
						: r.x2, (this.y2 > r.y2) ? this.y2 : r.y2);
	}

	/**
	 * Devuelve la intersecci�n de este rect�ngulo con otro.
	 */
	public Rect intersection(Rect r) {
		Rect result = new Rect((this.x1 > r.x1) ? this.x1 : r.x1,
				(this.y1 > r.y1) ? this.y1 : r.y1, (this.x2 < r.x2) ? this.x2
						: r.x2, (this.y2 < r.y2) ? this.y2 : r.y2);
		if (result.x1 > result.x2) {
			result.x1 = result.x2 = 0;
		}
		if (result.y1 > result.y2) {
			result.y1 = result.y2 = 0;
		}
		return result;
	}

	/**
	 * Este es un m�todo de la superclase Object. Aqu� lo sobrecargamos
	 * para que los objetos rect�ngulos puedan convertirse a Strings.
	 */
	public String toString() {
		return "[" + x1 + "," + y1 + "; " + x2 + "," + y2 + "]";
	}
	
}