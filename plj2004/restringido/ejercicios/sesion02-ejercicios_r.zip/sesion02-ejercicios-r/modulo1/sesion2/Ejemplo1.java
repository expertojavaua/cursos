package modulo1.sesion2;
public class Ejemplo1 {
	public static void main(String[] args) {
                System.out.println("Hola mundo");
	}
}
