package modulo1.sesion2;
import plj.geom.Rect;

public class RectTest {

	public static void main(String[] args) {
		Rect r1, r2, r3;

		r1 = new Rect(0, 0, 10, 10);
		r2 = new Rect(15, 15);
		r3 = r1.intersection(r2);
		System.out.println(r1.toString() + " INTERSECTADO CON " + r2.toString()
				+ " = " + r3.toString());
		r3 = r1.union(r2);

		System.out.println(r1.toString() + " UNIDO CON " + r2.toString()
				+ " = " + r3.toString());
	}
}