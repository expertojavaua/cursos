package modulo1.sesion2;
public class Reverse {
    public static void main(String[] args) {
        int i = args.length-1;
        while (i >= 0) {
            String str = args[i];
            System.out.print(args[i]);
            System.out.print(":");
            i--;
        }
        System.out.println();
    }
}
