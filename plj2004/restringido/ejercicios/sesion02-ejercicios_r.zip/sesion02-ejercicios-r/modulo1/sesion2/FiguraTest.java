package modulo1.sesion2;
import java.util.Stack;

import modulo1.sesion3.Circulo;
import modulo1.sesion3.Figura;
import modulo1.sesion3.Rectangulo;

public class FiguraTest {
    public static void main(String args[]) {
        Figura f;

        Rectangulo rect = new Rectangulo(10, 15);
        System.out.println("El area del rectangulo es: " + rect.getArea());

        Circulo circ = new Circulo(3);
        System.out.println("El area del circulo es: " + circ.getArea());

        Stack pila = new Stack();
        pila.push(rect);
        pila.push(circ);

        while (!pila.isEmpty()) {
            f = (Figura) pila.pop();
            System.out.println("El area de la figura es: " + f.getArea());
        }
    }
}