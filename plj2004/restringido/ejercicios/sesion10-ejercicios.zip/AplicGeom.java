import io.*;
import geom.*;
import java.util.*;

public class AplicGeom
{
	EntradaTeclado et;
	String fichero;
	ArrayList figuras;
	
	public AplicGeom(String fichero)
	{
	}
	
	public void iniciar()
	{
	}
		
	public static void main(String[] args)
	{
		if (args.length == 0)
		{
			System.out.println("Uso: java AplicGeom <fichero>");
			System.exit(-1);
		}
		AplicGeom ag = new AplicGeom(args[0]);
		ag.iniciar();
	}
}