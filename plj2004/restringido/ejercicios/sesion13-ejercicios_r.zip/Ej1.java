import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Ej1 extends JFrame implements Runnable
{
	MiPanel mp = new MiPanel();
	MiCanvas mc = new MiCanvas();
	Thread t = new Thread(this);
	int yObj = 0;
	
	public Ej1()
	{
		setSize(300, 300);
		getContentPane().setLayout(new GridLayout(2, 1));
				
		getContentPane().add(mp);
		getContentPane().add(mc);
		
		mp.repaint();
		mc.repaint();
		
		this.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			}
		});
		
		t.start();
	}
	
	public void run()
	{	
		while (yObj < 100)
		{
			yObj++;
			mp.repaint();
			mc.repaint();
			try
			{
				Thread.currentThread().sleep(100);
			} catch (Exception ex) {}
		}
		
		System.out.println ("Finalizado");
		
	}
	
	public static void main(String[] args)
	{
		Ej1 e1 = new Ej1();
		e1.show();
	}

	class MiPanel extends JPanel
	{
		public MiPanel()
		{
		}
		
		public void update(Graphics g)
		{
			paint(g);
		}
		
		public void paint(Graphics g)
		{
			g.clearRect(0, 0, getWidth(), getHeight());
			g.setColor(Color.blue);
			g.fillRect(5, yObj, 100, 25);
			g.setColor(Color.green);
			g.fillOval(125, yObj, 100, 50);
		}
	}
	
	class MiCanvas extends Canvas
	{
		Image backbuffer = null;			
		
		public MiCanvas()
		{
		}

		public void update(Graphics g)
		{
			paint(g);
		}
		
		public void paint(Graphics g)
		{
			if(backbuffer == null)
				backbuffer = createImage(getWidth(), getHeight());
	
			// Dibujamos los gr�ficos en el backbuffer
	
			Graphics off_g = backbuffer.getGraphics();
			off_g.clearRect(0, 0, getWidth(), getHeight());
			off_g.setColor(Color.blue);
			off_g.fillRect(5, yObj, 100, 25);
			off_g.setColor(Color.green);
			off_g.fillOval(125, yObj, 100, 50);
	
			// Volcamos el backbuffer a pantalla
	
			g.drawImage(backbuffer, 0, 0, getWidth(), getHeight(), this);
			g.dispose();

		}
	}
}
