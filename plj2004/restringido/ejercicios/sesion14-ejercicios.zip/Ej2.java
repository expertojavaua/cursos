import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Ej2 extends JFrame implements Runnable
{
	public static final int ANCHO = 320;
	public static final int ALTO = 240;
	MiCanvas mc = new MiCanvas();
	Thread t = new Thread(this);
	int yObj = 0;
	
	public Ej2()
	{
		setSize(ANCHO, ALTO);
				
		getContentPane().add(mc);
		
		this.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			}
		});
		
		t.start();
	}
	
	public void run()
	{	
		while (yObj < 100)
		{
			yObj++;
			mc.repaint();
			try
			{
				Thread.currentThread().sleep(100);
			} catch (Exception ex) {}
		}
		
		System.out.println ("Finalizado");
		
	}
	
	public static void main(String[] args)
	{
		Ej2 e2 = new Ej2();
		e2.show();
	}
	
	class MiCanvas extends Canvas
	{
		Image backbuffer = null;			
		
		public MiCanvas()
		{
		}

		public void update(Graphics g)
		{
			paint(g);
		}
		
		public void paint(Graphics g)
		{
			if(backbuffer == null)
				backbuffer = createImage(ANCHO, ALTO);
	
			// Dibujamos los gr�ficos en el backbuffer
	
			Graphics off_g = backbuffer.getGraphics();
			off_g.clearRect(0, 0, ANCHO, ALTO);
			off_g.setColor(Color.blue);
			off_g.fillRect(5, yObj, 100, 25);
			off_g.setColor(Color.green);
			off_g.fillOval(125, yObj, 100, 50);
	
			// Volcamos el backbuffer a pantalla
	
			g.drawImage(backbuffer, 0, 0, ANCHO, ALTO, this);
			g.dispose();

		}
	}
}
