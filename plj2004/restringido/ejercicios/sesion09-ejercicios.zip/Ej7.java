import java.io.*;
import java.util.*;

public class Ej7
{
	public Ej7()
	{
	}
	
	public static void main (String[] args)
	{
		new Ej7();
	}
}

class ObjetoFichero implements Serializable
{
	String cadena;
	int valorInt;
	double valorDouble;
	Vector cadenas;
	
	public ObjetoFichero(String cadena, int valorInt, double valorDouble)
	{
		this.cadena = cadena;
		this.valorInt = valorInt;
		this.valorDouble = valorDouble;
		cadenas = new Vector();
		cadenas.addElement(cadena);
	}
	
	public void addCadena(String cadena)
	{
		cadenas.addElement(cadena);
	}
	
	public String imprimeObj()
	{
		String res =  "Cadena = " + cadena + "\r\n";
		res += "valorInt = " + valorInt + "\r\n";
		res += "valorDouble = " + valorDouble + "\r\n";
		res += "vector:\r\n";
		
		for (int i = 0; i < cadenas.size(); i++)
			res += (String)(cadenas.elementAt(i)) + "\r\n";
		
		return res;
	}
}