import java.io.*;

public class Ej6
{
	public Ej6()
	{
	}
	
	public static void main (String[] args)
	{
		new Ej6();
	}
}