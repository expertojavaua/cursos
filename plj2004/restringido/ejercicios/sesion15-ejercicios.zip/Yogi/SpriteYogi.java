import java.awt.*;

/**
  * Clase que representa la imagen de Yogi en pantalla
  */
class SpriteYogi
{
	public static final int ALTO = 65;		// Altura de Yogi
	public static final int ANCHO = 35;		// Anchura de Yogi

	Image sprites;							// Conjunto de sprites de Yogi
	int x;									// Posicion del sprite que se dibujara en cada momento
	int width;								// Anchura del conjunto de sprites
	int height;								// Altura del conjunto de sprites
	
	/**
	  * Constructor. Carga los sprites, su ancho y su alto, y establece la x del sprite inicial
	  */
	public SpriteYogi()
	{
		Toolkit tk = Toolkit.getDefaultToolkit();
		sprites = tk.createImage("yogi.png");
		width = 210;
		height = 64;
		x = 0;
	}
	
	/**
	  * Cambia a un determinado sprite de Yogi
	  */
	public void setFrame(int frame)
	{
		x = frame * ANCHO;		
	}
}
