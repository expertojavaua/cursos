import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
  * Juego del oso Yogi cogiendo comida que cae del cielo
  */
public class Yogi extends JFrame implements Runnable
{	
	public static final int INC_MOV_YOGI = 3;			// Incremento de movimientos, o distancia en pixeles entre dos posiciones consecutivas (de Yogi)
	public static final int ANCHO = 400;				// Anchura del area grafica
	public static final int ALTO = 300;					// Altura del area grafica
	int ancho;											// Anchura de pantalla completa
	int alto;											// Altura de pantalla completa
	
	Image backbuffer = null;							// Imagen para hacer el doble buffer al dibujar cada frame de la animacion
	SpriteYogi sprn = null;								// Sprites de Yogi	
	int numFrame = 0;									// Frame actual de animacion de Yogi
	int xIni = ANCHO/2;									// Posicion X actual de Yogi
	
	// Secuencias animacion Yogi
	int[] secuenciaDer = { 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2};
	int[] secuenciaIzq = { 3, 3, 3, 3, 3, 4, 4, 4, 4, 4, 5, 5, 5, 5, 5};
	
	// Hilo que va generando animaciones
	Thread t = new Thread(this);
	
	/**
	  * Constructor: establece el dispositivo, elige el modo grafico e inicia la animacion
	  */
	public Yogi()
	{		
		// Quitamos la barra superior de la ventana
		this.setUndecorated(true);
				
		// Tomamos el dispositivo grafico
		GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
		GraphicsDevice gd = ge.getDefaultScreenDevice();
		
		// Mostramos dialogo para elegir un modo grafico
		DlgModos dlg = new DlgModos(gd, this);
		dlg.show();
		DisplayMode modo = dlg.modoSeleccionado;
		if (modo != null)
		{
			ancho = modo.getWidth();
			alto = modo.getHeight();
		}
		
		// Cargamos las imagenes
		sprn = new SpriteYogi();
		
		// Eventos de teclado
		addKeyListener(new KeyAdapter()
		{
			public void keyPressed(KeyEvent e)
			{
				if (e.getKeyCode()==KeyEvent.VK_LEFT) {
					// Pulsar flecha izq: mover a Yogi hacia la izq. (si se puede)
					sprn.setFrame(secuenciaIzq[numFrame]);
					if (xIni > 0 + INC_MOV_YOGI)
						xIni -= INC_MOV_YOGI;
					numFrame = (numFrame+1) % secuenciaIzq.length;
				} else if (e.getKeyCode()==KeyEvent.VK_RIGHT) {
					// Pulsar flecha der: mover a Yogi hacia la der. (si se puede)
					sprn.setFrame(secuenciaDer[numFrame]);
					if (xIni < ANCHO - SpriteYogi.ANCHO - INC_MOV_YOGI)
						xIni += INC_MOV_YOGI;
					numFrame = (numFrame+1) % secuenciaIzq.length;
				} else if (e.getKeyCode() == KeyEvent.VK_ESCAPE) {
					System.exit(0);
				}
			}
		});
		
		gd.setFullScreenWindow(this);		
		gd.setDisplayMode(dlg.modoSeleccionado);
		
		// Comenzamos la animacion
		sprn.setFrame(numFrame);	
		
		t.start();	
	}
	
	/**
	  * Actualiza el contexto gr�fico del frame: en nuestro caso, solo llama a paint
	  */
	public void update(Graphics g)
	{
		paint(g);
	}
	
	/**
	  * Redibuja el contexto grafico del frame: dibuja la imagen en el backbuffer, 
	  * y luego la vuelca sobre el frame
	  */
	public void paint(Graphics g)
	{
		if(backbuffer == null)
			backbuffer = createImage(ANCHO, ALTO);

		// Dibujamos los gr�ficos en el backbuffer

		Graphics off_g = backbuffer.getGraphics();
		dibuja(off_g);

		// Volcamos el backbuffer a pantalla

		g.drawImage(backbuffer, 0, 0, ancho, alto, this);
		g.dispose();
	}
	
	/**
	  * Dibuja cada frame de animacion
	  */
	public void dibuja(Graphics g)
	{		
		// Limpiar area
		g.clearRect(0, 0, ANCHO, ALTO);
						
		// Dibujar a Yogi
		Shape clip = g.getClip();
		g.setClip(xIni, ALTO - SpriteYogi.ALTO, SpriteYogi.ANCHO, SpriteYogi.ALTO);		
		g.drawImage(sprn.sprites, xIni - sprn.x, ALTO - SpriteYogi.ALTO, sprn.width, sprn.height, this);
		g.setClip(clip);
				
		// Liberar recursos
		g.dispose();
	}
	
	/**
	  * Metodo principal del hilo
	  */
	public void run()
	{		
		while (true)
		{			
			repaint();
			
			try
			{
				Thread.currentThread().sleep(100);
			} catch (Exception e) {}
		}
	}
	
	/**
	  * Metodo principal
	  */
	public static void main(String[] args)
	{
		Yogi y = new Yogi();
		y.show();
	}
}
