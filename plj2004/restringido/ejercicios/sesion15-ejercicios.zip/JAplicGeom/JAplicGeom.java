
public class JAplicGeom extends JFrame
{
}