import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;

public class JFormatos extends JFrame implements ActionListener
{
	// Area de texto
	JTextArea txt;
	
	// Flags para negrita y cursiva
	boolean negrita = false, cursiva = false;
	
	// Fichero donde guardar
	String fichero = "guardar.txt";
	
	// Actual frame
	JFrame frame = this;
		
	public JFormatos()
	{
		// Men�
		
		JMenuBar mb = new JMenuBar();

		JMenu m = new JMenu("Formato");

		JMenuItem mi = new JMenuItem("Color Negro");
		mi.addActionListener(this);
		m.add(mi);
		mi = new JMenuItem("Color Rojo");
		mi.addActionListener(this);
		m.add(mi);

		JCheckBoxMenuItem cmi = new JCheckBoxMenuItem("Negrita");
		cmi.addActionListener(this);
		m.add(cmi);
		cmi = new JCheckBoxMenuItem("Cursiva");
		cmi.addActionListener(this);
		m.add(cmi);

		mb.add(m);

		setJMenuBar(mb);
		
		// Area de texto
		
		txt = new JTextArea();
		txt.setFont(new Font("Arial", Font.PLAIN, 16));
		getContentPane().add(txt, BorderLayout.CENTER);
		
		// Timer

		Timer tim = new Timer (10000, new ActionListener() 
		{
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					PrintWriter pw = new PrintWriter(new FileWriter(fichero));
					pw.println(txt.getText());
					pw.close();
				} catch (Exception ex) {}
			}
		});
		tim.setRepeats(true);
		tim.start();
		
		// Icono
		
		JButton btnSave = new JButton("Guardar", new ImageIcon("save.jpg"));
		btnSave.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				JFileChooser jfc = new JFileChooser(".");
				int res = jfc.showSaveDialog(frame);
				if (res == JFileChooser.APPROVE_OPTION)
					fichero = jfc.getSelectedFile().getAbsolutePath();
			}
		});
		getContentPane().add(btnSave, BorderLayout.SOUTH);
	}
	
	public void actionPerformed(ActionEvent e)
	{
		if (e.getActionCommand().equals("Color Negro"))
		{
			txt.setForeground(Color.black);
		} else if (e.getActionCommand().equals("Color Rojo")) {
			txt.setForeground(Color.red);
		} else if (e.getActionCommand().equals("Negrita")) {
			negrita = !negrita;
		} else if (e.getActionCommand().equals("Cursiva")) {
			cursiva = !cursiva;
		}
		
		txt.setFont(new Font("Arial", Font.PLAIN | (negrita?Font.BOLD:0) | (cursiva?Font.ITALIC:0), 16));
	}
	
	public static void main(String[] args)
	{
		JFormatos f = new JFormatos();
		f.setSize(200, 200);
		f.addWindowListener(new WindowAdapter()
		{
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			}
		});
		f.show();
	}
}