/*
 * MIDletPanj.java
 * Copyright (C) 2004 Miguel Angel Lozano
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package es.ua.j2ee.game.panj;

import java.io.IOException;

import javax.microedition.lcdui.Display;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

import es.ua.j2ee.game.panj.data.Resources;
import es.ua.j2ee.game.panj.engine.PanjEngine;
import es.ua.j2ee.game.panj.engine.SplashScreen;

/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class MIDletPanj extends MIDlet {

	private void loadGame() {

		Display d = Display.getDisplay(this);

		// Muesta splash screen mientras carga recursos
		try {
			Resources.initSplash(this);

			SplashScreen ss = new SplashScreen();
			d.setCurrent(ss);

			// Bloquea hasta fin de la animacion
			ss.join();

			Resources.init();

			startGame();

		} catch(IOException e) {
			Form error = new Form("Error al cargar recursos");
			d.setCurrent(error);
		}
		
	}
	
	public void startGame() {

		Display d = Display.getDisplay(this);
		PanjEngine engine = new PanjEngine(); 
		d.setCurrent(engine); 

	}
	
	public void exitGame() {
		try {
			this.destroyApp(true);
		} catch(MIDletStateChangeException e) {
		}

		this.notifyDestroyed();
	}

	/* (non-Javadoc)
	 * @see javax.microedition.midlet.MIDlet#startApp()
	 */
	protected void startApp() throws MIDletStateChangeException {

		Display d = Display.getDisplay(this);
		Displayable current = d.getCurrent();

		if(current == null) {
			this.loadGame();
		} else {
			// Reanudar
			Displayable prev = d.getCurrent();
			if(prev instanceof PanjEngine) {
				PanjEngine pe = (PanjEngine)prev;
				pe.start();
			}
		}
	}

	/* (non-Javadoc)
	 * @see javax.microedition.midlet.MIDlet#pauseApp()
	 */
	protected void pauseApp() {

		Display d = Display.getDisplay(this);
		Displayable current = d.getCurrent();
		if(current instanceof PanjEngine) {
			PanjEngine pe = (PanjEngine)current;
			pe.start();
		}
		
	}

	/* (non-Javadoc)
	 * @see javax.microedition.midlet.MIDlet#destroyApp(boolean)
	 */
	protected void destroyApp(boolean arg0) throws MIDletStateChangeException {
		// TODO Auto-generated method stub

	}

}
