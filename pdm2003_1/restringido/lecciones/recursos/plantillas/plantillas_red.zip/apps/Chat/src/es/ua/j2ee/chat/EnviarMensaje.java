package es.ua.j2ee.chat;

import java.io.*;
import javax.microedition.io.*;
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class EnviarMensaje extends TextBox implements CommandListener {

	MIDlet owner;
	Displayable previo;
	String url;

	Command cmdAtras;
	Command cmdEnviar;

	public EnviarMensaje(MIDlet owner, Displayable previo, String url) {
		super("Mensaje", "", 140, TextField.ANY);

		this.owner = owner;
		this.previo = previo;
		this.url = url;
		
		// Crea los comandos
		cmdAtras = new Command("Atras", Command.BACK, 1);
		cmdEnviar = new Command("OK", Command.OK, 1);
		this.addCommand(cmdAtras);
		this.addCommand(cmdEnviar);
		this.setCommandListener(this);

	}

	private void envia(String msg) throws IOException {

		// TODO: Establecer una conexion con el servidor y enviar el mensaje en el POST

		// TODO: Comprobar que se ha enviado correctamente (que la respuesta es OK)

	}

	public void commandAction(Command cmd, Displayable disp) {

		if(cmd == cmdAtras) {

			// Vuelve a la pantalla anterior
			Display d = Display.getDisplay(owner);
			d.setCurrent(previo);
		} else if(cmd == cmdEnviar) {

			// Envia el mensaje
			try {
				envia(this.getString());

				Display d = Display.getDisplay(owner);
				d.setCurrent(previo);			
			} catch(IOException e) {
				Alert a = new Alert("Error", "Error en la conexion", null, AlertType.ERROR);

				Display d = Display.getDisplay(owner);
				d.setCurrent(a, previo);			
			}
		}

	}

}
