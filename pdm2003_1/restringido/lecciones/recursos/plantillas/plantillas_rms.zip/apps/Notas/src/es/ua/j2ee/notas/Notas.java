package es.ua.j2ee.notas;

import java.io.*;
import java.util.*;
import javax.microedition.rms.*;

public class Notas {

	public final static String RS_NAME = "notas";

	Vector notas;
	
	Vector listeners;
	
	public Notas() throws RecordStoreException {
		// Inicializa la lista de notas
		notas = new Vector();
		listeners = new Vector();

		// TODO: Abrir RecordStore RS_NAME y leer las notas almacenadas en el
	}

	public Nota getNota(int indice) {
		// Devuelve una nota
		return (Nota)notas.elementAt(indice);
	}

	public void eliminaNota(int indice) throws RecordStoreException {

		// TODO: Eliminar la nota del RecordStore

		notas.removeElementAt(indice);
		notifyEliminada(indice);
	}
	
	public void cambiaNota(int indice, Nota nota) throws RecordStoreException, IOException {

		// TODO: Modificar la nota en el RecordStore

		notas.setElementAt(nota, indice);
		notifyModificada(indice, nota);
	}
	
	public void nuevaNota(Nota nota) throws RecordStoreException, IOException {

		// TODO: Agregar una nueva nota al RecordStore

		notas.addElement(nota);
		notifyCreada(nota);
	}

	public int numNotas() {
		// Devuelve el numero de notas
		return notas.size(); 
	}

	public void addNotasListener(NotasListener nl) {
		// A�ade un listener sobre las notas
		listeners.addElement(nl);
	}
	
	public void notifyCreada(Nota nota) {
		// Notifica a los listeners que se ha creado una nota
		for(int i=0;i<listeners.size();i++) {
			NotasListener nl = (NotasListener)listeners.elementAt(i);
			nl.notaCreada(nota);
		}
	}
	
	public void notifyEliminada(int indice) {
		// Notifica a los listeners que se ha eliminado una nota
		for(int i=0;i<listeners.size();i++) {
			NotasListener nl = (NotasListener)listeners.elementAt(i);
			nl.notaEliminada(indice);
		}
	}

	public void notifyModificada(int indice, Nota nota) {
		// Notifica a los listeners que se ha modificado una nota
		for(int i=0;i<listeners.size();i++) {
			NotasListener nl = (NotasListener)listeners.elementAt(i);
			nl.notaModificada(indice, nota);
		}
	}

	public int getMem() {

		// TODO: Devolver memoria ocupada por el almacen

		return 0;
	}

	public int getFree() {

		// TODO: Devolver memoria libre

		return 0;
	}

}
