package es.ua.j2ee.notas;

import java.io.*;

public class Nota {

	int id;
	String nombre;
	String texto;
	
	public Nota(String nombre, String texto) {
		this.nombre = nombre;
		this.texto = texto;
	}
	
	public void serialize(OutputStream out) throws IOException {
		DataOutputStream dos = new DataOutputStream(out);
		
		dos.writeUTF(nombre);
		dos.writeUTF(texto);		
	}
	
	public static Nota deserialize(InputStream in) throws IOException {
		DataInputStream dis = new DataInputStream(in);
		
		String nombre = dis.readUTF();
		String texto = dis.readUTF();
		
		return new Nota(nombre, texto);
	}
}
