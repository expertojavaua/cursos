package es.ua.j2ee.video;
 
import java.io.*;
import javax.microedition.lcdui.*;
import javax.microedition.media.*;
import javax.microedition.media.control.*;

public class VisorVideo extends Canvas implements CommandListener, PlayerListener {

	Command cmdSnap;
	Command cmdStart;
	Command cmdStop;

	Image snap = null;

	VideoControl vc;
	Player p; 

	public VisorVideo() {

		// Crea comandos
		cmdStart = new Command("Start", Command.SCREEN, 1);
		cmdStop = new Command("Stop", Command.SCREEN, 1);
		cmdSnap = new Command("Snap", Command.SCREEN, 1);
		this.addCommand(cmdStart);
		this.setCommandListener(this);

		try {

			// Crea reproductor
			InputStream in = getClass().getResourceAsStream("/video.3gp");
			p = Manager.createPlayer(in, "video/3gpp");
			p.realize();
			p.addPlayerListener(this);

			// Crea control de video
			vc = (VideoControl)p.getControl("VideoControl");
			vc.initDisplayMode(VideoControl.USE_DIRECT_VIDEO, this);
			vc.setDisplayLocation(0,0);
			vc.setDisplaySize(this.getWidth(), this.getHeight());
			vc.setVisible(true);

		} catch(Exception e) {
			System.err.println("Error al crear video");
		}

	}

	protected void paint(Graphics g) {

		// Dibuja la imagen capturada (si la hubiese)
		g.setColor(0x00ffffff);
		g.fillRect(0,0,getWidth(), getHeight());
		if(snap != null) {
			g.drawImage(snap, 20, 20, Graphics.TOP | Graphics.LEFT);
		}
	}

	public void commandAction(Command cmd, Displayable disp) {
		if(cmd == cmdSnap) {

			// Captura imagen
			try {
				byte [] img = vc.getSnapshot(null);
				snap = Image.createImage(img, 0, img.length);
				p.stop();
				repaint();
			} catch(Exception e) {
				System.err.println("Error al capturar");
			}
		} else if(cmd == cmdStop) {

			// Detiene el video
			try {
				p.stop();
			} catch(Exception e) {
				System.err.println("Error al detener");
			}
		} else if(cmd == cmdStart) {

			// Comienza la reproducci�n
			try {
				p.start();
			} catch(Exception e) {
				System.err.println("Error al reproducir");
			}
		}
	}
	
	public void playerUpdate(Player p, String e, Object d) {

		// Actualiza comandos
		if(e == PlayerListener.STARTED) {
			this.removeCommand(cmdStart);
			this.addCommand(cmdStop);
			this.addCommand(cmdSnap);
			vc.setVisible(true);
		} else if(e == PlayerListener.STOPPED) {
			this.removeCommand(cmdSnap);
			this.removeCommand(cmdStop);
			this.addCommand(cmdStart);
			vc.setVisible(false);
			repaint();			
		} else if(e == PlayerListener.END_OF_MEDIA) {
			this.removeCommand(cmdSnap);
			this.removeCommand(cmdStop);
			this.addCommand(cmdStart);			
			vc.setVisible(false);
			repaint();			
		}
	}
}
