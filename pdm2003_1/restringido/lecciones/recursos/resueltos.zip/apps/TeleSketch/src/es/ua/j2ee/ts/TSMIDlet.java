package es.ua.j2ee.ts;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class TSMIDlet extends MIDlet {

	protected void startApp() throws MIDletStateChangeException {
		// TODO Auto-generated method stub
		Display d = Display.getDisplay(this);
		AreaDibujo ad = new AreaDibujo();		
		d.setCurrent(ad);
	}

	protected void pauseApp() {

	}

	protected void destroyApp(boolean arg0) throws MIDletStateChangeException {

	}

}
