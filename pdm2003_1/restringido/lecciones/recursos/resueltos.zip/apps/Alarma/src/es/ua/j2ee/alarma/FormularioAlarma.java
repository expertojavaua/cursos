package es.ua.j2ee.alarma;

import java.util.*;
import javax.microedition.lcdui.*;
import javax.microedition.midlet.*;

public class FormularioAlarma extends Form implements CommandListener {
	Command cmdFijar;
	Command cmdAnular;

	Timer temp = null;

	MIDlet owner;

	DateField fecha;
	StringItem estado;

	public FormularioAlarma(MIDlet owner) {
		super("Alarma");
		
		this.owner = owner;
		
		// Crea campos
		fecha = new DateField("Hora alarma: ", DateField.DATE_TIME);
		fecha.setDate(new Date());
		estado = new StringItem("Estado: ", "Desactivada");
		this.append(fecha);
		this.append(estado);

		// Crea comandos
		cmdFijar = new Command("Fijar alarma", Command.ITEM, 1);
		cmdAnular = new Command("Anular alarma", Command.ITEM, 1);
		this.addCommand(cmdFijar);
		this.addCommand(cmdAnular);
		this.setCommandListener(this); 
	}

	public void commandAction(Command cmd, Displayable d) {
		if(cmd == cmdFijar) {

			// Fijar alarma
			if(temp != null) {
				temp.cancel();
			}
			temp = new Timer();
			Alarma alarma = new Alarma();
			temp.schedule(alarma, fecha.getDate());			
			estado.setText("Activada");

		} else if(cmd == cmdAnular) {

			// Anular alarma
			if(temp != null) {
				temp.cancel();
			}
			estado.setText("Desactivada");
		}
	}

	private void disparaAlarma() {

		// Muestra alerta con la alarma y reproduce sonido
		Alert a = new Alert("Alarma", "Se ha disparado la alarma", null, AlertType.ALARM);
		a.setTimeout(Alert.FOREVER);

		Display d = Display.getDisplay(owner);
		d.setCurrent(a, d.getCurrent());
		AlertType.ALARM.playSound(d);
	}
	
	// Tarea de alarma
	
	class Alarma extends TimerTask {
		public void run() {
			 disparaAlarma();
		}
	}

}
