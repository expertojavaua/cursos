package es.ua.j2ee.notas;

import java.io.*;
import java.util.*;
import javax.microedition.rms.*;

public class Notas implements RecordListener {

	public final static String RS_NAME = "notas";

	RecordStore rs;

	Vector notas;
	
	Vector listeners;
	
	public Notas() throws RecordStoreException {
		// Inicializa la lista de notas
		notas = new Vector();
		listeners = new Vector();

		rs = RecordStore.openRecordStore(RS_NAME, true);		
	
		RecordEnumeration enum = rs.enumerateRecords(null, null, false);

		while(enum.hasNextElement()) {
			int id = enum.nextRecordId();
			ByteArrayInputStream bais = new ByteArrayInputStream(rs.getRecord(id));
			try {
				Nota nota = Nota.deserialize(bais);
				nota.id = id;
				notas.addElement(nota);
			} catch(IOException e) {}
		}

		rs.addRecordListener(this);
	}

	public Nota getNota(int indice) {
		// Devuelve una nota
		return (Nota)notas.elementAt(indice);
	}

	public void eliminaNota(int indice) throws RecordStoreException {
		// Elimina una nota
		rs.deleteRecord(this.getNota(indice).id);
		//notas.removeElementAt(indice);
		//notifyEliminada(indice);
	}
	
	public void cambiaNota(int indice, Nota nota) throws RecordStoreException, IOException {
		// Modifica una nota
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		nota.serialize(baos);
		byte [] datos = baos.toByteArray();

		rs.setRecord(this.getNota(indice).id, datos, 0, datos.length);
		//notas.setElementAt(nota, indice);
		//notifyModificada(indice, nota);
	}
	
	public void nuevaNota(Nota nota) throws RecordStoreException, IOException {
		// Agrega una nueva nota
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		nota.serialize(baos);
		byte [] datos = baos.toByteArray();

		rs.addRecord(datos, 0, datos.length);
		//notas.addElement(nota);
		//notifyCreada(nota);
	}

	public int numNotas() {
		// Devuelve el numero de notas
		return notas.size(); 
	}

	public void addNotasListener(NotasListener nl) {
		// A�ade un listener sobre las notas
		listeners.addElement(nl);
	}
	
	public void notifyCreada(Nota nota) {
		// Notifica a los listeners que se ha creado una nota
		for(int i=0;i<listeners.size();i++) {
			NotasListener nl = (NotasListener)listeners.elementAt(i);
			nl.notaCreada(nota);
		}
	}
	
	public void notifyEliminada(int indice) {
		// Notifica a los listeners que se ha eliminado una nota
		for(int i=0;i<listeners.size();i++) {
			NotasListener nl = (NotasListener)listeners.elementAt(i);
			nl.notaEliminada(indice);
		}
	}

	public void notifyModificada(int indice, Nota nota) {
		// Notifica a los listeners que se ha modificado una nota
		for(int i=0;i<listeners.size();i++) {
			NotasListener nl = (NotasListener)listeners.elementAt(i);
			nl.notaModificada(indice, nota);
		}
	}

	private int buscaID(int id) {
		for(int i=0;i<notas.size();i++) {
			Nota nota = (Nota)notas.elementAt(i);
			if(nota.id == id) {
				return i;
			}
		}
		
		return -1;
	}

	private Nota leeID(int id) throws RecordStoreException, IOException {
		ByteArrayInputStream bais = new ByteArrayInputStream(rs.getRecord(id));
		Nota nota = Nota.deserialize(bais);
		nota.id = id;

		return nota;
	}

	public int getMem() throws RecordStoreException {
		return rs.getSize();
	}

	public int getFree() throws RecordStoreException {
		return rs.getSizeAvailable();
	}

	public void cerrar() throws RecordStoreException {
		rs.closeRecordStore();
	}

	// Eventos de RecordListener

	public void recordAdded(RecordStore rs, int id) {
		try {
			Nota nota = leeID(id);
			notas.addElement(nota);
			notifyCreada(nota);
		} catch(Exception e) { }
	}

	public void recordChanged(RecordStore rs, int id) {
		try {
			Nota nota = leeID(id);
			int indice = buscaID(id);
			notas.setElementAt(nota, indice);
			notifyModificada(indice, nota);
		} catch(Exception e) { }
	}

	public void recordDeleted(RecordStore rs, int id) {
		try {
			int indice = buscaID(id);
			notas.removeElementAt(indice);
			notifyEliminada(indice);
		} catch(Exception e) { }
	}

}
