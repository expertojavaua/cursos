package es.ua.j2ee.chat;

import java.io.*;
import javax.microedition.io.*;
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class PantallaLogin extends TextBox implements CommandListener {

	private final static String URL_LOGIN = "http://j2ee.ua.es/pdm/servlet/ServletChat";

	MIDlet owner;

	Command cmdOK;

	public PantallaLogin(MIDlet owner) {
		super("Login", "", 8, TextField.ANY);

		this.owner = owner;

		// Crea comandos
		cmdOK = new Command("OK", Command.OK, 1);
		this.addCommand(cmdOK);
		this.setCommandListener(this);
	}

	public void commandAction(Command cmd, Displayable disp) {
		if(cmd == cmdOK) {

			// Introduce el login
			
			try {
				String url = login(this.getString()); 

				if(url != null) {
					Display d = Display.getDisplay(owner);
					ListaMensajes lm = new ListaMensajes(owner, this, url);
					d.setCurrent(lm);
				}
			} catch(IOException e) {
				Alert a = new Alert("Error", "Error en la conexion", null, AlertType.ERROR);
				Display d = Display.getDisplay(owner);
				d.setCurrent(a, d.getCurrent());
			}
		}
	}

	private String login(String nick) throws IOException {

		// Se registra en el servidor y obtiene la URL reescrita
		HttpConnection con = (HttpConnection)Connector.open(URL_LOGIN + "?accion=login&id=" + nick);
		if(con.getResponseCode() == HttpConnection.HTTP_OK) {
			return con.getHeaderField("URL-Reescrita");
		} else {
			throw new IOException("Error al validar");
		}
	}
}
