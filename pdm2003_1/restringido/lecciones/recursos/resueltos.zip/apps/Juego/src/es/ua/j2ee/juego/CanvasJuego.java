package es.ua.j2ee.juego;

import java.io.*;
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.lcdui.game.*;

public class CanvasJuego extends GameCanvas implements Runnable {

	private final static int CICLO = 100;

	MIDlet owner; 

	public CanvasJuego(MIDlet owner) {
		super(true);
		
		this.owner = owner;
	}

	public void showNotify() {
		Thread t = new Thread(this);
		t.start();
	}

	private TiledLayer creaFondo(Image imgFondo) throws IOException {

		InputStream in = getClass().getResourceAsStream("/datos");
		DataInputStream dis = new DataInputStream(in);

		int cols = dis.readInt();
		int rows = dis.readInt();

		TiledLayer fondo = new TiledLayer(cols, rows, imgFondo, 20, 20);

		for(int i=0;i<rows;i++) {
			for(int j=0;j<cols;j++) {
				byte valor = dis.readByte();
				fondo.setCell(j,i,valor);
			}
		}

		return fondo;
	}

	public void run() {
		Graphics g = getGraphics();
		long t1, t2, td;
		int vel = 5;

		// Carga fondo		

		Image imgFondo = null;

		try {
			imgFondo = Image.createImage("/fondo.png");
		} catch(IOException e) {
		}

		TiledLayer fondo = null;
		try {
			fondo = creaFondo(imgFondo);
		} catch(IOException e) {
		}

		// Carga sprites

		Image imgCoche = null;

		try {
			imgCoche = Image.createImage("/coche.png");
		} catch(IOException e) {
		}

		Sprite coche = new Sprite(imgCoche);
		coche.setPosition(40,50);

		// Crea LayerManager

		LayerManager lm = new LayerManager();
		lm.append(coche);
		lm.append(fondo);
		lm.setViewWindow(0, 0, 100, 80);
		
		// Centra la pantalla

		int centro_x = getWidth() / 2;		
		int centro_y = getHeight() / 2;		

		int ini_x = centro_x - 50;
		int ini_y = centro_y - 40;

		fondo.setPosition(0, 80 - fondo.getHeight());

		while(true) {
			t1 = System.currentTimeMillis();

			// Lee entrada del teclado
			
			int keyState = getKeyStates();

			if ((keyState & LEFT_PRESSED) != 0) {
				coche.move(-vel, 0);
			}
			else if ((keyState & RIGHT_PRESSED) != 0) {
				coche.move(vel, 0);
			}
			else if ((keyState & UP_PRESSED) != 0) {
				coche.move(0, -vel);
			}
			else if ((keyState & DOWN_PRESSED) != 0) {
				coche.move(0, vel);
			}

			// Mueve el fondo

			fondo.move(0, 5);
			if(fondo.getY() >= 0) {
				System.out.println("Nivel completado");
				Display d = Display.getDisplay(owner);
				Alert a = new Alert("Nivel completado");
				d.setCurrent(a, d.getCurrent());
				return;
			} 

			// Comprueba colisiones
			
			if(coche.collidesWith(fondo, true)) {
				System.out.println("Colision");
				Display d = Display.getDisplay(owner);
				Alert a = new Alert("Colision");
				d.setCurrent(a, d.getCurrent());
				return;			
			}

			// Dibuja los graficos
			
			g.setColor(0x00000000);
			g.fillRect(ini_x, ini_y, 100, 80);

			lm.paint(g, ini_x, ini_y);
			
			flushGraphics();

			// Controla el tiempo del ciclo

			t2 = System.currentTimeMillis();
			td = t2 - t1;
			td = td>CICLO?CICLO:td;

			try {
				Thread.sleep(CICLO - td);
			} catch(InterruptedException e) {
			}

		}
	}
}
