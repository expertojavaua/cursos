/*
 * Created on 13-sep-2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package es.ua.j2ee.chat;

import java.util.*;
import java.io.*;

/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ListaMensajes extends LinkedList {

	int capacidad;
	long ts;

	public ListaMensajes(int capacidad) {
		this.capacidad = capacidad;
		this.ts = 0;
	}
	
	public synchronized void nuevoMensaje(String nick, String msg) {
		if(this.size() > capacidad) {
			this.removeFirst();
		}
		this.addLast(new Mensaje(nick, msg, ts++));
	}
	
	public synchronized Mensaje [] leeMensajes() {
		int tam = this.size();
		Mensaje [] msgs = new Mensaje[tam];
		this.toArray(msgs);
		
		return msgs;
	}
	
	public synchronized long serialize(OutputStream out, long ts_ini) throws IOException {
		DataOutputStream dos = new DataOutputStream(out);

		int i=0;
		int tam = this.size();
		
		for(i=0;i<tam;i++) {
			if ( ((Mensaje)this.get(i)).ts >= ts_ini) {
				break;
			}
		}

		for(;i<tam;i++) {
			((Mensaje)this.get(i)).serialize(dos);
		}
		
		return tam;
	}
	
	public synchronized long getTimeStamp() {
		return ts;
	}
}
