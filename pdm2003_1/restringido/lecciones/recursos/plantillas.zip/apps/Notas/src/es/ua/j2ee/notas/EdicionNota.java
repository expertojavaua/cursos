package es.ua.j2ee.notas;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class EdicionNota extends Form implements CommandListener {

	Command cmdAceptar;
	Command cmdCancelar;

	TextField txtNombre;
	TextField txtTexto;

	private int nota;
	private boolean nueva;

	MIDlet owner;
	Displayable previo;
	Notas notas;

	public EdicionNota(MIDlet owner, Displayable previo, Notas notas, int nota) {
		super("Edicion");
		this.owner = owner;
		this.previo = previo;

		this.notas = notas;
		this.nueva = false;
		this.nota = nota;

		init(notas.getNota(nota).nombre, notas.getNota(nota).texto);
	}

	public EdicionNota(MIDlet owner, Displayable previo, Notas notas) {
		super("Nueva nota");
		this.owner = owner;
		this.previo = previo;

		this.notas = notas;
		this.nueva = true;

		init("", "");
	}

	public void init(String nombre, String texto) {

		// A�adimos elementos al formulario		
		txtNombre = new TextField("Nombre", nombre, 8, TextField.ANY);
		txtTexto = new TextField("Texto", texto, 140, TextField.ANY);
		this.append(txtNombre);
		this.append(txtTexto);
		
		// Creamos comandos
		cmdAceptar = new Command("Aceptar", Command.OK, 1);
		cmdCancelar = new Command("Cancelar", Command.CANCEL, 1);
		this.addCommand(cmdAceptar);
		this.addCommand(cmdCancelar);
		this.setCommandListener(this);		
	}

	public String getNombre() {
		// Devuelve el nombre introducido
		return txtNombre.getString();
	}

	public String getTexto() {
		// Devuelve el texto introducido
		return txtTexto.getString();
	}

	public synchronized void commandAction(Command cmd, Displayable disp) {

		if(cmd == cmdAceptar) {

			// Acepta los cambios
			Display d = Display.getDisplay(owner);
			
			try {
				if(nueva) {
					notas.nuevaNota(new Nota(this.getNombre(), this.getTexto()));
				} else {
					notas.cambiaNota(nota, new Nota(this.getNombre(), this.getTexto()));
				}
			} catch(Exception e) {
				Alert a = new Alert("Error", "No se puede guardar", null, AlertType.ERROR);
				d.setCurrent(a, previo);
				return;					
			}

			d.setCurrent(previo);

		} else if (cmd == cmdCancelar) {

			// Cancela y vuelve a la pantalla anterior
			Display d = Display.getDisplay(owner);
			d.setCurrent(previo);
		}
	}

}
