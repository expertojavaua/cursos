package es.ua.j2ee.notas;

public interface NotasListener {

	public void notaCreada(Nota nota);
	
	public void notaEliminada(int indice);
	
	public void notaModificada(int indice, Nota nota);
}
