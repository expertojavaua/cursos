/*
 * BallSprite.java
 * Copyright (C) 2004 Miguel Angel Lozano
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package es.ua.j2ee.game.panj.engine;

import javax.microedition.lcdui.game.Sprite;

import es.ua.j2ee.game.panj.data.CommonData;
import es.ua.j2ee.game.panj.data.Resources;

public class BallSprite extends Sprite 
{
	// Velocidad x e y del sprite
	public int vx, vy;
	
	public int altura = CommonData.BALL_MAX_HEIGHT;
	public boolean sube = false;

	// Descendientes del sprite (cuando la bola se parte en 2)
	public BallSprite desc1, desc2;

	public BallSprite(byte tam, byte color, int vx) {
		super(Resources.img[Resources.IMG_SPR_BALL_1 + tam], CommonData.BALL_SIZE[tam], CommonData.BALL_SIZE[tam]);

		// Establece tama�o, velocidad e imagen del sprite
		this.vx = vx;
		this.vy = 0;

		// Si no tiene el tama�o minimo, crea dos descendientes de tama�o inferior

		if(tam > 0) {
			desc1 = new BallSprite((byte)(tam - 1), color, vx);
			desc2 = new BallSprite((byte)(tam - 1), color, -vx);
		} else {
			desc1 = desc2 = null;
		}
		
		// Establece el frame de la imagen correspondiente al color indicado
		this.setFrame(color);
	}

	public void tick() {
		// Mover bolas
		this.setPosition(this.getX() + this.vx, CommonData.BALL_BASE - this.getHeight() - CommonData.BALL_ARC[this.altura]);

		// Cambio de altura
		if(this.altura==0) {
			this.sube = true;
		}
		if(this.altura==CommonData.BALL_MAX_HEIGHT) {
			this.sube = false;
		}
		if(this.sube) {
			this.altura ++;
		} else {
			this.altura --;
		}

		// Colision con muros verticales
		if(this.getX() < 0 || this.getX() > CommonData.SCREEN_WIDTH - this.getWidth()) {
			this.vx = -this.vx;
		}
		
	}
}