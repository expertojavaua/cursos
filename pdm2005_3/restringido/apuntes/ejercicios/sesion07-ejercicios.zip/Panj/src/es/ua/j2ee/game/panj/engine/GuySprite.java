/*
 * GuySprite.java
 * Copyright (C) 2004 Miguel Angel Lozano
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package es.ua.j2ee.game.panj.engine;

import javax.microedition.lcdui.game.Sprite;

import es.ua.j2ee.game.panj.data.CommonData;
import es.ua.j2ee.game.panj.data.Resources;

public class GuySprite extends Sprite
{
	public final static int MOVE_LEFT = 0;
	public final static int MOVE_RIGHT = 1;
	public final static int MOVE_STAY = 2;
	
	int lastMove;
	
	public GuySprite() {
		super(Resources.img[Resources.IMG_SPR_PERS], CommonData.SPRITE_WIDTH, CommonData.SPRITE_HEIGHT);
	}
	
	public void reset() {
		this.setFrameSequence(null);
		this.setFrame(CommonData.SPRITE_STAY);
		this.lastMove = MOVE_STAY;
		
		this.setPosition(CommonData.SPRITE_INI_X, CommonData.SPRITE_INI_Y);		
	}

	public void stepLeft() {
		// Alterna los frames del sprite andando hacia la izquierda
		if(lastMove!=MOVE_LEFT) {
			this.setFrameSequence(CommonData.SPRITE_MOVE_LEFT);
			lastMove = MOVE_LEFT;
		}
		this.nextFrame();
		this.move(-CommonData.SPRITE_STEP,0);
	}

	public void stepRight() {
		// Alterna los frames del sprite andando hacia la derecha
		if(lastMove!=MOVE_RIGHT) {
			this.setFrameSequence(CommonData.SPRITE_MOVE_RIGHT);
			lastMove = MOVE_RIGHT;
		}
		this.nextFrame();
		this.move(CommonData.SPRITE_STEP,0);
	}

	public void stay() {
		// Establece el frame del sprite parado
		if(lastMove!=MOVE_STAY) {
			this.setFrameSequence(null);
			lastMove = MOVE_STAY;
		}
		this.setFrame(CommonData.SPRITE_STAY);
	}

	public void die() {
		// Establece el frame del sprite muriendo
		this.setFrameSequence(null);
		this.setFrame(CommonData.SPRITE_DIE);
	}


}