/*
 * Created on 13-sep-2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package es.ua.j2ee.chat;

import java.io.*;

/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class Mensaje {
	long ts;
	String nick;
	String texto;
	
	public Mensaje(String nick, String texto, long ts) {
		this.nick = nick;
		this.texto = texto;
		this.ts = ts;
	}
	
	public void serialize(DataOutputStream out) throws IOException {
		out.writeUTF(nick);
		out.writeUTF(texto);
	}
}
