/*
 * Created on 13-sep-2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package es.ua.j2ee.mensajes;

import java.util.*;
import java.io.*;

/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ListaMensajes extends ArrayList {

	long ts;

	public ListaMensajes() {
		this.ts = 0;
	}
	
	public synchronized void addMensaje(Mensaje msg) {
		msg.setTs(ts++);
		this.add(msg);
	}
	
	public synchronized Mensaje [] getMensajes() {
		int tam = this.size();
		Mensaje [] mensajes = new Mensaje[tam];
		this.toArray(mensajes);
		
		return mensajes;
	}
	
	public synchronized Mensaje [] getMensajes(long tsCliente) {
		ArrayList nuevosMensajes = new ArrayList();
		
		Iterator iter = this.iterator();
		while(iter.hasNext()) {
			Mensaje msg = (Mensaje)iter.next();
			if(msg.ts >= tsCliente) {
				nuevosMensajes.add(msg);
			}
		}

		int tam = nuevosMensajes.size();
		Mensaje [] mensajes = new Mensaje[tam];
		nuevosMensajes.toArray(mensajes);
		
		return mensajes;
	}
	
	public synchronized long getTimeStamp() {
		return ts;
	}
	
	public synchronized SyncItem sincroniza(SyncItem datosCliente) throws IOException {
		long tsCliente = datosCliente.getTs();
		Mensaje [] mensajesCliente = datosCliente.getMensajes();
		
		Mensaje [] mensajesServidor = this.getMensajes(tsCliente);
		
		for(int i=0;i<mensajesCliente.length;i++) {
			this.addMensaje(mensajesCliente[i]);
		}
		
		long tsServidor = getTimeStamp();
		
		SyncItem datosServidor = new SyncItem(tsServidor, mensajesServidor);
		
		return datosServidor;
	}
}
