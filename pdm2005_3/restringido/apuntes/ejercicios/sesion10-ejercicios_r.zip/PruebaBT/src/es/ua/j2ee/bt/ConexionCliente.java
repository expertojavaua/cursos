package es.ua.j2ee.bt;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

public class ConexionCliente implements ConexionChat {

	DataInputStream dis;
	DataOutputStream dos;
	
	public ConexionCliente(DataInputStream dis, DataOutputStream dos) {
		this.dis = dis;
		this.dos = dos;
	}
	
	public void envia(String texto) throws IOException {
		dos.writeUTF(texto);
		dos.flush();
	}

	public String recibe() throws IOException {
		String texto = dis.readUTF();
		return texto;
	}

}
