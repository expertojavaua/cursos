package es.ua.j2ee.notas;

import java.io.*;
import java.util.*;

import javax.microedition.rms.*;

public class AdaptadorRMS {

	// Nombres de los almacenes
	
	public final static String RS_DATOS = "rs_datos";

	// Almacenes de registros
	
	RecordStore rsDatos;

	public AdaptadorRMS() throws RecordStoreException {
		// TODO: Abrir el almacen de registros
	}

	public Mensaje[] listaMensajes() throws RecordStoreException, IOException {
		// TODO: Obtener todos los mensajes y devolverlos		
		return null;
	}

	public int addMensaje(Mensaje msg) throws IOException, RecordStoreException {
		// TODO: Agregar un nuevo mensaje y devolver su ID de RMS
		return 0;
	}

	public void updateMensaje(Mensaje msg) throws IOException, RecordStoreException {
		// TODO: Actualizar un mensaje
	}

	public void removeMensaje(int id) throws RecordStoreException {
		// TODO: Eliminar un mensaje dado su ID
	}

	public Mensaje getMensaje(int id) throws RecordStoreException, IOException {
		// TODO: Obtener un mensaje dado su ID y devolverlo
		return null;
	}

	public void cerrar() throws RecordStoreException {
		// TODO: Cerrar el almacen de registros
	}

	public int getOcupado() throws RecordStoreNotOpenException {
		// TODO: Devolver espacio ocupado
		return 0;
	}

	public int getLibre() throws RecordStoreNotOpenException {
		// TODO: Devolver espacio libre
		return 0;
	}
}