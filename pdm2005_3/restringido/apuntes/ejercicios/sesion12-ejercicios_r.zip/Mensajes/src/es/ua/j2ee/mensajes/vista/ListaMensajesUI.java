package es.ua.j2ee.mensajes.vista;

import javax.microedition.lcdui.ChoiceGroup;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.List;

import es.ua.j2ee.mensajes.modelo.Mensaje;
import es.ua.j2ee.mensajes.modelo.Recursos;

public class ListaMensajesUI extends List implements CommandListener {

	ControladorUI controlador;

	Mensaje [] mensajes;
	
	Command cmdSelec;
	Command cmdVolver;
	int eventoSelec = ControladorUI.EVENTO_MUESTRA_DATOS_MENSAJE;
	int eventoVolver = ControladorUI.EVENTO_MUESTRA_MENU;
	
	public ListaMensajesUI(ControladorUI controlador) {
		super(controlador.getString(Recursos.STR_LISTA_MENSAJES_TITULO), ChoiceGroup.IMPLICIT);
		
		this.controlador = controlador;
		
		cmdSelec = new Command(controlador.getString(Recursos.STR_CMD_SELECCIONAR), Command.OK, 1);
		cmdVolver = new Command(controlador.getString(Recursos.STR_CMD_VOLVER), Command.BACK, 1);
		this.addCommand(cmdSelec);
		this.addCommand(cmdVolver);
		
		this.setCommandListener(this);
	}

	private void setMensajes(Mensaje [] mensajes) {

		this.mensajes = mensajes;		

		// Vacia la lista
		for(int i=this.size()-1; i>=0; i--) {
			this.delete(i);
		}

		// Agrega los nuevos mensajes
		for(int i=0;i<mensajes.length;i++) {
			this.append(mensajes[i].getAsunto(), null);
		}
	}
	
	private Mensaje getSelectedMensaje() {
		return mensajes[this.getSelectedIndex()];
	}
	
	public void reset(Mensaje [] mensajes, int eventoSelec, int eventoVolver) {
		this.setMensajes(mensajes);
		this.eventoSelec = eventoSelec;
		this.eventoVolver = eventoVolver;
	}
	
	public void commandAction(Command cmd, Displayable disp) {
		if(cmd==cmdSelec || cmd==List.SELECT_COMMAND) {
			if(this.getSelectedIndex()>=0 && this.getSelectedIndex()<mensajes.length) {
				controlador.procesaEvento(eventoSelec, this.getSelectedMensaje());				
			}
		} else if(cmd==cmdVolver) {
			controlador.procesaEvento(eventoVolver, null);
		}
	}

}
