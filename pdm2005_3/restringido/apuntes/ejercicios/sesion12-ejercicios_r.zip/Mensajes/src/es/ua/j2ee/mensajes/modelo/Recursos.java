package es.ua.j2ee.mensajes.modelo;

public class Recursos {

	public final static int STR_MENU_TITULO = 0;
	public final static int STR_MENU_ITEM_VER = 1;
	public final static int STR_MENU_ITEM_AGREGAR = 2;
	public final static int STR_MENU_ITEM_SALIR = 3;
	public final static int STR_MENU_ITEM_SINCRONIZAR = 4;
	public final static int STR_MENU_ITEM_CONFIGURAR = 5;
	public final static int STR_DATOS_TITULO = 6;
	public final static int STR_DATOS_ITEM_ASUNTO = 7;
	public final static int STR_DATOS_ITEM_TEXTO = 8;
	public final static int STR_LISTA_MENSAJES_TITULO = 9;
	public final static int STR_CONFIG_TITULO = 10;
	public final static int STR_CONFIG_ITEM_MODO = 11;
	public final static int STR_CONFIG_ITEM_MODO_ONLINE = 12;
	public final static int STR_CONFIG_ITEM_MODO_OFFLINE = 13;
	public final static int STR_BARRA_PROGRESO_TITULO = 14;
	public final static int STR_PROGRESO_CARGA_LISTA = 15;
	public final static int STR_PROGRESO_SINCRONIZA = 16;
	public final static int STR_CMD_SALIR = 17;
	public final static int STR_CMD_VOLVER = 18;
	public final static int STR_CMD_SELECCIONAR = 19;
	public final static int STR_CMD_ACEPTAR = 20;
	public final static int STR_CMD_CANCELAR = 21;

	String [] texto = {
		"Mensajes",
		"Ver mensajes",
		"Enviar mensaje",
		"Salir",
		"Sincronizar",
		"Configurar",
		"Datos del mensaje",
		"Asunto",
		"Texto",
		"Lista de mensajes",
		"Configuracion",
		"Modo",
		"Online",
		"Offline",
		"Progreso",
		"Cargando lista de mensajes",
		"Sincronizando",
		"Salir",
		"Atras",
		"Seleccionar",
		"Aceptar",
		"Cancelar"
	};

	public Recursos() {		
	}
	
	public String getString(int i) {
		return texto[i];
	}
}
