package es.ua.j2ee.agenda.modelo;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Date;
import java.util.Vector;

import javax.microedition.rms.RecordComparator;
import javax.microedition.rms.RecordEnumeration;
import javax.microedition.rms.RecordFilter;
import javax.microedition.rms.RecordStore;
import javax.microedition.rms.RecordStoreException;

public class AdaptadorRMS {

	// Nombres de los almacenes
	
	public final static String RS_INDICE = "rs_indice";

	public final static String RS_DATOS = "rs_datos";

	public final static String RS_CONFIG = "rs_config";

	// Almacenes de registros
	
	RecordStore rsIndice;

	RecordStore rsDatos;

	RecordStore rsConfig;

	public AdaptadorRMS() throws RecordStoreException {
		rsIndice = RecordStore.openRecordStore(RS_INDICE, true);
		rsDatos = RecordStore.openRecordStore(RS_DATOS, true);
		rsConfig = RecordStore.openRecordStore(RS_CONFIG, true);
	}

	/*
	 * Obtiene los datos de configuracion local
	 */
	public InfoLocal getInfoLocal() throws RecordStoreException, IOException {
		byte[] datos = rsConfig.getRecord(1);

		ByteArrayInputStream bais = new ByteArrayInputStream(datos);
		DataInputStream dis = new DataInputStream(bais);

		return InfoLocal.deserialize(dis);
	}

	/*
	 * Guarda los datos de configuracion local
	 */
	public void setInfoLocal(InfoLocal info) throws RecordStoreException,
			IOException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(baos);

		info.serialize(dos);
		byte[] datos = baos.toByteArray();

		try {
			rsConfig.setRecord(1, datos, 0, datos.length);
		} catch (RecordStoreException e) {
			int id = rsConfig.addRecord(datos, 0, datos.length);
		}
	}

	/*
	 * Obtiene todas las citas
	 */
	public Cita[] listaCitas() throws RecordStoreException, IOException {
		RecordEnumeration re = rsDatos.enumerateRecords(null,
				new OrdenIndice(), false);

		Vector citas = new Vector();

		while (re.hasNextElement()) {
			int id = re.nextRecordId();
			byte[] datos = rsDatos.getRecord(id);

			ByteArrayInputStream bais = new ByteArrayInputStream(datos);
			DataInputStream dis = new DataInputStream(bais);

			Cita cita = Cita.deserialize(dis);
			cita.setRmsID(id);
			citas.addElement(cita);
		}

		Cita[] result = new Cita[citas.size()];
		citas.copyInto(result);

		return result;
	}

	/*
	 * Busca citas con alarma posterior a la fecha indicada
	 */
	public IndiceCita[] buscaCitas(Date fecha, boolean alarma)
			throws RecordStoreException, IOException {
		RecordEnumeration re = rsIndice.enumerateRecords(new FiltroIndice(
				fecha, alarma), new OrdenIndice(), false);

		Vector indices = new Vector();

		while (re.hasNextElement()) {
			int id = re.nextRecordId();
			byte[] datos = rsIndice.getRecord(id);

			ByteArrayInputStream bais = new ByteArrayInputStream(datos);
			DataInputStream dis = new DataInputStream(bais);

			IndiceCita indice = IndiceCita.deserialize(dis);
			indice.setRmsID(id);
			indices.addElement(indice);
		}

		IndiceCita[] result = new IndiceCita[indices.size()];
		indices.copyInto(result);

		return result;
	}

	/*
	 * Busca citas pendientes de ser enviadas al servidor
	 */
	public IndiceCita[] listaCitasPendientes() throws RecordStoreException,
			IOException {
		RecordEnumeration re = rsIndice.enumerateRecords(new FiltroPendientes(
				true), new OrdenIndice(), false);

		Vector indices = new Vector();

		while (re.hasNextElement()) {
			int id = re.nextRecordId();
			byte[] datos = rsIndice.getRecord(id);

			ByteArrayInputStream bais = new ByteArrayInputStream(datos);
			DataInputStream dis = new DataInputStream(bais);

			IndiceCita indice = IndiceCita.deserialize(dis);
			indice.setRmsID(id);
			indices.addElement(indice);
		}

		IndiceCita[] result = new IndiceCita[indices.size()];
		indices.copyInto(result);

		return result;
	}

	public int addCita(Cita cita) throws IOException, RecordStoreException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(baos);

		cita.serialize(dos);
		byte[] datos = baos.toByteArray();

		int id = rsDatos.addRecord(datos, 0, datos.length);
		cita.setRmsID(id);
		return id;
	}

	public int addIndice(IndiceCita indice) throws IOException,
			RecordStoreException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(baos);

		indice.serialize(dos);
		byte[] datos = baos.toByteArray();

		int id = rsIndice.addRecord(datos, 0, datos.length);
		indice.setRmsID(id);
		return id;
	}

	public void updateCita(Cita cita) throws IOException, RecordStoreException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(baos);

		cita.serialize(dos);
		byte[] datos = baos.toByteArray();

		rsDatos.setRecord(cita.getRmsID(), datos, 0, datos.length);
	}

	public void updateIndice(IndiceCita indice) throws IOException,
			RecordStoreException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(baos);

		indice.serialize(dos);
		byte[] datos = baos.toByteArray();

		rsIndice.setRecord(indice.getRmsID(), datos, 0, datos.length);
	}

	public void removeCita(int id) throws RecordStoreException {
		rsDatos.deleteRecord(id);
	}

	public void removeIndice(int id) throws RecordStoreException {
		rsIndice.deleteRecord(id);
	}

	public Cita getCita(int id) throws RecordStoreException, IOException {
		byte[] datos = rsDatos.getRecord(id);

		ByteArrayInputStream bais = new ByteArrayInputStream(datos);
		DataInputStream dis = new DataInputStream(bais);

		Cita cita = Cita.deserialize(dis);
		cita.setRmsID(id);

		return cita;
	}

	public IndiceCita getIndice(int id) throws RecordStoreException,
			IOException {
		byte[] datos = rsIndice.getRecord(id);

		ByteArrayInputStream bais = new ByteArrayInputStream(datos);
		DataInputStream dis = new DataInputStream(bais);

		IndiceCita indice = IndiceCita.deserialize(dis);
		indice.setRmsID(id);

		return indice;
	}

	public void cerrar() throws RecordStoreException {
		rsIndice.closeRecordStore();
		rsDatos.closeRecordStore();
		rsConfig.closeRecordStore();
	}

	/*
	 * Filtra fechas posteriores con alarma
	 */
	class FiltroIndice implements RecordFilter {
		Date fecha;

		boolean alarma;

		public FiltroIndice(Date fecha, boolean alarma) {
			this.fecha = fecha;
			this.alarma = alarma;
		}

		public boolean matches(byte[] datos) {

			try {
				ByteArrayInputStream bais = new ByteArrayInputStream(datos);
				DataInputStream dis = new DataInputStream(bais);
				IndiceCita indice = IndiceCita.deserialize(dis);

				return indice.isAlarma() == this.alarma
						&& indice.getFecha().getTime() >= this.fecha.getTime();

			} catch (IOException e) {
				e.printStackTrace();
				return false;
			}

		}
	}

	/*
	 * Filtra citas pendientes de ser enviadas al servidor
	 */
	class FiltroPendientes implements RecordFilter {

		boolean pendiente;

		public FiltroPendientes(boolean pendiente) {
			this.pendiente = pendiente;
		}

		public boolean matches(byte[] datos) {

			try {
				ByteArrayInputStream bais = new ByteArrayInputStream(datos);
				DataInputStream dis = new DataInputStream(bais);
				IndiceCita indice = IndiceCita.deserialize(dis);

				return indice.isPendiente();

			} catch (IOException e) {
				e.printStackTrace();
				return false;
			}

		}
	}

	/*
	 * Ordena registros por fechas
	 */
	class OrdenIndice implements RecordComparator {
		public int compare(byte[] c1, byte[] c2) {

			try {
				ByteArrayInputStream bais1 = new ByteArrayInputStream(c1);
				DataInputStream dis1 = new DataInputStream(bais1);
				IndiceCita cita1 = IndiceCita.deserialize(dis1);

				ByteArrayInputStream bais2 = new ByteArrayInputStream(c2);
				DataInputStream dis2 = new DataInputStream(bais2);
				IndiceCita cita2 = IndiceCita.deserialize(dis2);

				if (cita1.getFecha().getTime() < cita2.getFecha().getTime()) {
					return RecordComparator.PRECEDES;
				} else if (cita1.getFecha().getTime() > cita2.getFecha()
						.getTime()) {
					return RecordComparator.FOLLOWS;
				} else {
					return RecordComparator.EQUIVALENT;
				}
			} catch (IOException e) {
				return RecordComparator.EQUIVALENT;
			}
		}
	}

}