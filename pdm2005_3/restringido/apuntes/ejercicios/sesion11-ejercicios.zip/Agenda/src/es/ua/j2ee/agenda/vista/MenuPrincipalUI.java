package es.ua.j2ee.agenda.vista;

import javax.microedition.lcdui.ChoiceGroup;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.List;

import es.ua.j2ee.agenda.modelo.Recursos;

public class MenuPrincipalUI extends List implements CommandListener {

	int itemNuevaCita;
	int itemListaCitas;
	int itemListaAlarmas;
	int itemSincronizar;
	int itemConfigurar;
	int itemSalir;
	
	ControladorUI controlador;
	
	public MenuPrincipalUI(ControladorUI controlador) {
		super(controlador.getString(Recursos.STR_MENU_TITULO), ChoiceGroup.IMPLICIT);
		
		this.controlador = controlador;
		
		itemNuevaCita = this.append(controlador.getString(Recursos.STR_MENU_ITEM_AGREGAR), null);
		itemListaCitas = this.append(controlador.getString(Recursos.STR_MENU_ITEM_VER), null);
		itemListaAlarmas = this.append(controlador.getString(Recursos.STR_MENU_ITEM_VER_ALARMAS), null);
		itemSincronizar = this.append(controlador.getString(Recursos.STR_MENU_ITEM_SINCRONIZAR), null);
		itemConfigurar = this.append(controlador.getString(Recursos.STR_MENU_ITEM_CONFIGURAR), null);
		itemSalir = this.append(controlador.getString(Recursos.STR_MENU_ITEM_SALIR), null);
		
		this.setCommandListener(this);
	}
	
	public void commandAction(Command cmd, Displayable disp) {
		if(cmd == List.SELECT_COMMAND) {
			if(this.getSelectedIndex() == itemNuevaCita) {
				controlador.procesaEvento(ControladorUI.EVENTO_MUESTRA_NUEVA_CITA, null);
			} else if(this.getSelectedIndex() == itemListaCitas) {
				controlador.procesaEvento(ControladorUI.EVENTO_MUESTRA_LISTA_CITAS, null);
			} else if(this.getSelectedIndex() == itemListaAlarmas) {
				controlador.procesaEvento(ControladorUI.EVENTO_MUESTRA_LISTA_ALARMAS_PENDIENTES, null);
			} else if(this.getSelectedIndex() == itemSincronizar) {
				controlador.procesaEvento(ControladorUI.EVENTO_SINCRONIZAR, null);
			} else if(this.getSelectedIndex() == itemConfigurar) {
				controlador.procesaEvento(ControladorUI.EVENTO_MUESTRA_CONFIG, null);
			} else if(this.getSelectedIndex() == itemSalir) {
				controlador.procesaEvento(ControladorUI.EVENTO_SALIR, null);
			}
		}
	}

}
