package es.ua.j2ee.agenda.modelo;

import java.util.Timer;
import java.util.TimerTask;


import es.ua.j2ee.agenda.vista.ControladorUI;

public class GestorAlarmas {

	ControladorUI controlador;

	public GestorAlarmas(ControladorUI controlador) {
		this.controlador = controlador;
	}
	
	/*
	 * Programa una alarma para una cita
	 */
	public void programaAlarma(Cita cita) {
		if(cita.isAlarma() && cita.getFecha().getTime() > System.currentTimeMillis()) {
			Timer t = new Timer();
			t.schedule(new TareaAlarma(cita), cita.getFecha());
		}
	}
	
	class TareaAlarma extends TimerTask {
		
		Cita cita;
		
		public TareaAlarma(Cita cita) {
			this.cita = cita;
		}
		
		public void run() {
			controlador.showAlert(cita);
		}
	}

}
