package es.ua.j2ee.agenda.modelo;

public class SyncItem {

	long timeStamp;

	Cita[] citas;

	public Cita[] getCitas() {
		return citas;
	}

	public void setCitas(Cita[] citas) {
		this.citas = citas;
	}

	public long getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(long timeStamp) {
		this.timeStamp = timeStamp;
	}
}