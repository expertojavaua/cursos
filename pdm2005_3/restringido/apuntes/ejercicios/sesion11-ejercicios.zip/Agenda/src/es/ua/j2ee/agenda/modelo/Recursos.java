package es.ua.j2ee.agenda.modelo;

public class Recursos {

	public final static int STR_MENU_TITULO = 0;
	public final static int STR_MENU_ITEM_VER = 1;
	public final static int STR_MENU_ITEM_VER_ALARMAS = 2;
	public final static int STR_MENU_ITEM_AGREGAR = 3;
	public final static int STR_MENU_ITEM_SINCRONIZAR = 4;
	public final static int STR_MENU_ITEM_CONFIGURAR = 5;
	public final static int STR_MENU_ITEM_SALIR = 6;
	public final static int STR_DATOS_TITULO = 7;
	public final static int STR_DATOS_ITEM_FECHA = 8;
	public final static int STR_DATOS_ITEM_ASUNTO = 9;
	public final static int STR_DATOS_ITEM_DESCRIPCION = 10;
	public final static int STR_DATOS_ITEM_CONTACTO = 11;
	public final static int STR_DATOS_ITEM_LUGAR = 12;
	public final static int STR_DATOS_ITEM_ALARMA = 13;
	public final static int STR_DATOS_ITEM_ALARMA_ON = 14;
	public final static int STR_DATOS_ITEM_ALARMA_OFF = 15;
	public final static int STR_LISTA_CITAS_TITULO = 16;
	public final static int STR_CONFIG_TITULO = 17;
	public final static int STR_CONFIG_ITEM_MODO = 18;
	public final static int STR_CONFIG_ITEM_MODO_ONLINE = 19;
	public final static int STR_CONFIG_ITEM_MODO_OFFLINE = 20;
	public final static int STR_ALARMA_TITULO = 21;
	public final static int STR_BARRA_PROGRESO_TITULO = 22;
	public final static int STR_PROGRESO_CARGA_LISTA = 23;
	public final static int STR_PROGRESO_SINCRONIZA = 24;
	public final static int STR_CMD_SALIR = 25;
	public final static int STR_CMD_VOLVER = 26;
	public final static int STR_CMD_SELECCIONAR = 27;
	public final static int STR_CMD_ACEPTAR = 28;
	public final static int STR_CMD_CANCELAR = 29;

	String [] texto = {
		"Agenda",
		"Ver citas",
		"Ver alarmas pendientes",
		"Agregar cita",
		"Sincronizar",
		"Configurar",
		"Salir",
		"Datos de la cita",
		"Fecha",
		"Asunto",
		"Descripcion",
		"Contacto",
		"Lugar",
		"Alarma",
		"Encendida",
		"Apagada",
		"Lista de citas",
		"Configuracion",
		"Modo",
		"Online",
		"Offline",
		"Alarma",
		"Progreso",
		"Cargando lista de citas",
		"Sincronizando",
		"Salir",
		"Atras",
		"Seleccionar",
		"Aceptar",
		"Cancelar"
	};

	public Recursos() {		
	}
	
	public String getString(int i) {
		return texto[i];
	}
}
