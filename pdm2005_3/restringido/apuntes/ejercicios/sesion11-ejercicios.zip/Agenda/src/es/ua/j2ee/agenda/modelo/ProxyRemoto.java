package es.ua.j2ee.agenda.modelo;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;

import javax.microedition.io.Connector;
import javax.microedition.io.HttpConnection;

public class ProxyRemoto {

	public final static String URL_SERVLET = "http://www.jtech.ua.es/ejemplos/servlet/ServletCitas";

	public ProxyRemoto() {

	}

	public SyncItem sincroniza(SyncItem datosCliente) throws IOException {
		HttpConnection con = (HttpConnection) Connector.open(URL_SERVLET);

		// Envia datos al servidor
		DataOutputStream dos = con.openDataOutputStream();
		Cita[] citasCliente = datosCliente.getCitas();
		dos.writeLong(datosCliente.getTimeStamp());
		if (citasCliente == null) {
			dos.writeInt(0);
		} else {
			dos.writeInt(citasCliente.length);
			for (int i = 0; i < citasCliente.length; i++) {
				citasCliente[i].serialize(dos);
			}
		}

		// Recibe datos del servidor
		DataInputStream dis = con.openDataInputStream();
		long tsServidor = dis.readLong();
		int nCitasServidor = dis.readInt();
		Cita[] citasServidor = new Cita[nCitasServidor];
		for (int i = 0; i < nCitasServidor; i++) {
			citasServidor[i] = Cita.deserialize(dis);
		}

		SyncItem datosServidor = new SyncItem();
		datosServidor.setTimeStamp(tsServidor);
		datosServidor.setCitas(citasServidor);

		return datosServidor;
	}

}