/*
 * Created on 08/06/2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package es.ua.j2ee.game.cdrilo.data;

import java.io.DataInputStream;
import java.io.IOException;


/**
 * @author Miguel Angel
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class TrackData {

	public byte velocity;
	public short distance;
	public byte carType;

	public static TrackData deserialize(DataInputStream dis) throws IOException {
		TrackData data = new TrackData();
		data.velocity = dis.readByte();
		data.distance = dis.readShort();
		data.carType = dis.readByte();

		return data;
	}

}
