/*
 * Created on 26/06/2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package es.ua.j2ee.game.cdrilo.engine;

import javax.microedition.lcdui.game.Sprite;

import es.ua.j2ee.game.cdrilo.data.CommonData;
import es.ua.j2ee.game.cdrilo.data.Resources;

/**
 * @author Miguel Angel
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class CrocSprite extends Sprite {

	public final static int MOVE_UP = 0;
	public final static int MOVE_DOWN = 1;
	public final static int MOVE_LEFT = 2;
	public final static int MOVE_RIGHT = 3;
	public final static int MOVE_STAY = 4;
	
	int lastMove;
	
	public CrocSprite() {
		super(Resources.getImage(Resources.IMG_SPR_CROC), CommonData.SPRITE_WIDTH, CommonData.SPRITE_HEIGHT);
		this.defineCollisionRectangle(CommonData.SPRITE_CROP_X, CommonData.SPRITE_CROP_Y, CommonData.SPRITE_CROP_WIDTH, CommonData.SPRITE_CROP_HEIGHT);
		reset();
	}

	public void reset() {
		// Inicializa frame y movimiento actual
		lastMove = MOVE_STAY;
		this.setFrameSequence(null);
		this.setFrame(CommonData.SPRITE_STAY_UP);

		// Inicializa posici�n
		this.setPosition(CommonData.SPRITE_INI_X, CommonData.SPRITE_INI_Y);
	}
	
	public void stay() {
		switch(lastMove) {
			case MOVE_UP:
				this.setFrameSequence(null);
				this.setFrame(CommonData.SPRITE_STAY_UP);
				break;
			case MOVE_DOWN:
				this.setFrameSequence(null);
				this.setFrame(CommonData.SPRITE_STAY_DOWN);
				break;
			case MOVE_LEFT:
				this.setFrameSequence(null);
				this.setFrame(CommonData.SPRITE_STAY_LEFT);
				break;
			case MOVE_RIGHT:
				this.setFrameSequence(null);
				this.setFrame(CommonData.SPRITE_STAY_RIGHT);
				break;
		}
		lastMove = MOVE_STAY;
	}
	
	public void die() {
		this.setFrameSequence(null);
		this.setFrame(CommonData.SPRITE_STAY_DIED);
		lastMove = MOVE_STAY;
	}

	public void moveUp() {
		if(lastMove != MOVE_UP) {
			this.setFrameSequence(CommonData.SPRITE_MOVE_UP);			
		}
		lastMove = MOVE_UP;
		this.move(0,-CommonData.SPRITE_STEP);
		this.nextFrame();
	}

	public void moveDown() {
		if(lastMove != MOVE_DOWN) {
			this.setFrameSequence(CommonData.SPRITE_MOVE_DOWN);			
		}
		lastMove = MOVE_DOWN;
		this.move(0,CommonData.SPRITE_STEP);
		this.nextFrame();
	}

	public void moveLeft() {
		if(lastMove != MOVE_LEFT) {
			this.setFrameSequence(CommonData.SPRITE_MOVE_LEFT);			
		}
		lastMove = MOVE_LEFT;
		this.move(-CommonData.SPRITE_STEP,0);
		this.nextFrame();
	}

	public void moveRight() {
		if(lastMove != MOVE_RIGHT) {
			this.setFrameSequence(CommonData.SPRITE_MOVE_RIGHT);			
		}
		lastMove = MOVE_RIGHT;
		this.move(CommonData.SPRITE_STEP,0);
		this.nextFrame();
	}

}
