/*
 * Created on 26/06/2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package es.ua.j2ee.game.cdrilo.engine;

import javax.microedition.lcdui.game.Sprite;

import es.ua.j2ee.game.cdrilo.data.CommonData;
import es.ua.j2ee.game.cdrilo.data.Resources;

/**
 * @author Miguel Angel
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class CarSprite extends Sprite {

	int velocity;
	
	public CarSprite(int carType, int x, int y, int velocity) {
		super(Resources.getImage(Resources.IMG_CAR_TYPE_1 + carType));
		
		this.setPosition(x,y);
		this.velocity = velocity;
	}
	
	public boolean tick() {
		this.move(velocity,0);

		if(this.getX() > CommonData.SCREEN_WIDTH) {
			return true;
		}
		return false;
	}

}
