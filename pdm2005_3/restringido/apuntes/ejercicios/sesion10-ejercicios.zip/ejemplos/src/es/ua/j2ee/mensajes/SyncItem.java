package es.ua.j2ee.mensajes;

public class SyncItem {

	Mensaje [] mensajes;
	long ts;
	
	public SyncItem(long ts, Mensaje [] mensajes) {
		this.ts = ts;
		this.mensajes = mensajes;
	}
	
	public Mensaje[] getMensajes() {
		return mensajes;
	}
	public void setMensajes(Mensaje[] mensajes) {
		this.mensajes = mensajes;
	}
	public long getTs() {
		return ts;
	}
	public void setTs(long ts) {
		this.ts = ts;
	}
}
