/*
 * Created on 19/06/2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package es.ua.j2ee.m3d;

import java.io.IOException;

import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Graphics;
import javax.microedition.m3g.Graphics3D;
import javax.microedition.m3g.Loader;
import javax.microedition.m3g.Object3D;
import javax.microedition.m3g.World;

public class Visor3DRetained extends Canvas implements Runnable {

	MIDlet3D owner;
	
	Graphics3D g3d;
	
	World mundo;
	
	long tiempoInicial;
	
	public Visor3DRetained(MIDlet3D owner) {
		this.owner = owner;
		
		init3D();
	}

	public void init3D() {
		
		g3d = Graphics3D.getInstance();
		
		try {
			Object3D [] objs = Loader.load("/caja.m3g");  
			mundo = (World)objs[0];
		} catch (IOException e) {
			System.out.println("Error al cargar modelo 3D: " + e.getMessage());
		}
	}
	
	protected void showNotify() {
		tiempoInicial = System.currentTimeMillis();

		Thread t = new Thread(this);
		t.start();
	}

	public void run() {
		while(true) {
			long tiempo = System.currentTimeMillis() - tiempoInicial;
			int restante = mundo.animate(((int)tiempo) % 16000);
			
			repaint();
			
			try {
				Thread.sleep(40);
			} catch (InterruptedException e) {
			}
		}
	}
	
	protected void paint(Graphics g) {
		try {
			g3d.bindTarget(g);
			g3d.render(mundo);
		} finally {
			g3d.releaseTarget();			
		}
	}

}