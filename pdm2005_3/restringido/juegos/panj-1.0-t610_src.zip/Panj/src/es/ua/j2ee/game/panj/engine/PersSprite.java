/*
 * PersSprite.java
 * Copyright (C) 2004 Miguel Angel Lozano
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package es.ua.j2ee.game.panj.engine;

import es.ua.j2ee.game.common.Sprite;

import es.ua.j2ee.game.panj.data.CommonData;
import es.ua.j2ee.game.panj.data.Resources;

// ------------------------------------------------------------------------------------
// 	Sprite del personaje
// ------------------------------------------------------------------------------------

public class PersSprite extends Sprite
{

	public PersSprite() {
		super(Resources.img[Resources.IMG_SPR_PERS], CommonData.SPRITE_WIDTH, CommonData.SPRITE_HEIGHT);
		this.setPosition(CommonData.SPRITE_INI_X, CommonData.SPRITE_INI_Y);
	}

	public void stepLeft() {

		// Alterna los frames del sprite andando hacia la izquierda

		if(this.getFrame() == 1) {
			this.setFrame(2);
		} else {
			this.setFrame(1);
		}

	}

	public void stepRight() {

		// Alterna los frames del sprite andando hacia la derecha

		if(this.getFrame() == 3) {
			this.setFrame(4);
		} else {
			this.setFrame(3);
		}

	}

	public void stay() {

		// Establece el frame del sprite parado
		this.setFrame(0);

	}

	public void die() {

		// Establece el frame del sprite muriendo
		this.setFrame(5);

	}


}