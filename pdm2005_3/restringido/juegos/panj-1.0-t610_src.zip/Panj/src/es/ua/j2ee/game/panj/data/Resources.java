/*
 * Resources.java
 * Copyright (C) 2004 Miguel Angel Lozano
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package es.ua.j2ee.game.panj.data;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.microedition.lcdui.Image;

import es.ua.j2ee.game.panj.MIDletPanj;

/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class Resources {

	// Nombres de los ficheros de imagenes que vamos a utilizar
	public static final int IMG_TIT_TITULO = 0;
	public static final int IMG_TIT_FONDO = 1;
	public static final int IMG_SPR_RAYO = 2;
	public static final int IMG_SPR_PERS = 3;
	public static final int IMG_SPR_BALL_1 = 4;
	public static final int IMG_SPR_BALL_2 = 5;
	public static final int IMG_SPR_BALL_3 = 6;
	public static final int IMG_SPR_BALL_4 = 7;
	public static final int IMG_CARA = 8;

	public static final int SND_SCREAM = 0;
	public static final int SND_POP = 1;	

	public static Image[] img;
	public static Image blankImage;
	public static Image splashImage;
	public static StageData[] stageData;

	public static MIDletPanj midlet;

	private static String[] imgNames =
		{
			"/titulo.png",
			"/fondo.png",
			"/rayo.png",
			"/pers.png",
			"/ball1.png",
			"/ball2.png",
			"/ball3.png",
			"/ball4.png",
			"/cara.png" };

	private static String[] sndNames = {
		"/grito.wav",
		"/pop.wav"
	};

	private static String splashImageFile = "/logojava.png";

	private static String stageFile = "/stages.dat";

	public static void init() throws IOException {

		loadCommonImages();
		loadCommonSounds();

		InputStream in = stageFile.getClass().getResourceAsStream(stageFile);
		stageData = loadStageData(in);
	}

	public static void initSplash(MIDletPanj pMidlet) throws IOException {
		midlet = pMidlet;
		splashImage = Image.createImage(splashImageFile);
	}

	private static void loadCommonImages() throws IOException {
		// Carga imagenes
		int nImg = imgNames.length;

		img = new Image[nImg];

		for (int i = 0; i < nImg; i++) {
			img[i] = Image.createImage(imgNames[i]);
		}
		
		blankImage = Image.createImage(1,1);
	}

	private static void loadCommonSounds() throws IOException {
		int nSnd = sndNames.length;
/*		
		snd = new Sound[nSnd];
		
		snd[Resources.SND_POP] = new Sound(100,25);
		snd[Resources.SND_SCREAM] = new Sound(200, 500);

		/* Comentado para serie 40 (no soporta WAV)		
		Class ref = sndNames.getClass();

		for(int i=0;i<nSnd;i++) {
			InputStream in = ref.getResourceAsStream(sndNames[i]);
			ByteArrayOutputStream baos = new ByteArrayOutputStream();

			// Lee el sonido en memoria
			int c;
			while((c=in.read())!=-1) {
				baos.write(c);
			}
			
			// Crea el sonido
			byte [] sndData = baos.toByteArray();
			snd[i] = new Sound(sndData,Sound.FORMAT_WAV);
		}
*/
	}

	public static StageData[] loadStageData(InputStream in)
		throws IOException {

		StageData[] stages = null;

		DataInputStream dis = new DataInputStream(in);

		int stageNum = dis.readInt();
		stages = new StageData[stageNum];

		for (int i = 0; i < stageNum; i++) {
			stages[i] = new StageData();
			stages[i].name = dis.readUTF();
			stages[i].imgBackgroundName = dis.readUTF();
			stages[i].ballsNumber = dis.readInt();
			stages[i].balls = new BallData[stages[i].ballsNumber];
			for (int j = 0; j < stages[i].ballsNumber; j++) {
				stages[i].balls[j] = new BallData();
				stages[i].balls[j].x = dis.readInt();
				stages[i].balls[j].y = dis.readInt();
				stages[i].balls[j].size = dis.readByte();
				stages[i].balls[j].vx = dis.readInt();
				stages[i].balls[j].color = dis.readByte();
			}

			//stages[i].loadResources();
		}

		return stages;
	}

}
