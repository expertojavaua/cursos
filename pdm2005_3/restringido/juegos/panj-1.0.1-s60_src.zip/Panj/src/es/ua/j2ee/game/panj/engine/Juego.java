/*
 * Juego.java
 * Copyright (C) 2004 Miguel Angel Lozano
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package es.ua.j2ee.game.panj.engine;

import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

import es.ua.j2ee.game.panj.data.*;

// ------------------------------------------------------------------------------------
// 	Escena de juego
// ------------------------------------------------------------------------------------

public class Juego implements Escena
{
	// Posibles transiciones de estado
	public static final int T_CONTINUA = 0;
	public static final int T_TERMINA = 1;
	public static final int T_SALIR = 2;

	// Puntuacion y vidas restantes
	int puntuacion;
	int vidas;

	// Fase actual, n�mero de la fase y datos de todas las fases
	Fase fase;
	int num_fase;

	// Cara a mostrar como numero de vidas
	Image cara;

	public Juego() {
		// Comienza con la primera fase
		cara = Resources.img[Resources.IMG_CARA];

		reset();
	} 

	public void reset() {
		// Reinicia el estado del juego para comenzar nueva partida
		num_fase = 0;
		fase = new Fase(Resources.stageData[num_fase]);
		puntuacion = 0;
		vidas = CommonData.NUM_LIVES;
	}

	public int tick(int keyState) {

		// Controla las transiciones entre los estados de la fase
		int trans = fase.tick(keyState);

		// El personaje a muerto, resta una vida o termina el juego

		if(trans == Fase.T_MUERTO) {
			vidas--;
			if(vidas<0) {
				return T_TERMINA;
			} else {
				fase = new Fase(Resources.stageData[num_fase]);
			}
		}

		// La fase se ha completado, pasa a la siguiente

		if(trans == Fase.T_COMPLETADA) {
			num_fase++;

			if(num_fase == Resources.stageData.length) {
				return T_TERMINA;
			} else {
				fase = new Fase(Resources.stageData[num_fase]);
			}
		}

		return T_CONTINUA;
	}

	public void render(Graphics g) {

		// Dibuja los graficos de la fase
		fase.render(g);

		// Dibuja el numero de vidas (caras)
		for(int i=0;i<vidas;i++) {
			g.drawImage(cara, i*CommonData.FACE_WIDTH, 0, Graphics.LEFT | Graphics.TOP);
		}
	}

}