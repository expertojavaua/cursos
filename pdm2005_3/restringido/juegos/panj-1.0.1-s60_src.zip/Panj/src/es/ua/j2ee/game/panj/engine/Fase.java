/*
 * Fase.java
 * Copyright (C) 2004 Miguel Angel Lozano
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package es.ua.j2ee.game.panj.engine;
import java.util.Vector;

import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.game.GameCanvas;

import es.ua.j2ee.game.panj.data.*;

// ------------------------------------------------------------------------------------
// 	Fase del juego (Clase que implementa el comportamiento del juego)
// ------------------------------------------------------------------------------------

public class Fase
{
	// Posibles transiciones de estados
	public static final int T_COMPLETADA = 0;
	public static final int T_MUERTO = 1;
	public static final int T_SALIR = 2;
	public static final int T_CONTINUA = 3;

	// Posibles estados dentro de la fase
	public static final int E_JUGANDO = 0;
	public static final int E_INICIO = 1;
	public static final int E_MURIENDO = 2;

	// Sprites del juego
	Vector bolas;
	PersSprite pers;
	RayoSprite rayo;
	Escenario escenario;

	// Datos y estado de la fase
	int estado;
	int frame;
	String nombre_fase;
	boolean dibujar_nombre;
	boolean hay_rayo;

	public Fase(StageData df) {

		// Construye las bolas necesarias para la fase
		bolas = new Vector();
		BallSprite bola = null;

		for(int i=0;i<df.ballsNumber;i++) {
			BallData ballData = df.balls[i];

			bola = new BallSprite(ballData.size, ballData.color, ballData.vx);
			bola.setPosition(ballData.x, CommonData.BALL_BASE - bola.getHeight() - CommonData.BALL_ARC[bola.altura]);
			bolas.addElement(bola);

		}
		
		// Carga el escenario de fondo
		escenario = new Escenario(df.imgBackground);
		nombre_fase = df.name;

		// Construye los sprites del personaje y del rayo
		pers = new PersSprite();
		rayo = new RayoSprite();

		// Fija el estado inicial del juego
		estado = E_INICIO;
		frame = 0;
		hay_rayo = false;
	
	}

	public int tick(int keyState) {

		// Estado iniciando la fase (parpadea el nombre de la fase)
		if(estado == E_INICIO) {
			if(frame < 50) {

				dibujar_nombre = (frame % 10) < 7;
				frame++;
				return T_CONTINUA;

			} else {
				estado = E_JUGANDO;
			}
		}

		// Estado muriendo el personaje (el personaje cae muerto)
		if(estado == E_MURIENDO) {

			if(frame < 20) {
				pers.setPosition(pers.getX() + CommonData.DIE_X_INCR, CommonData.SPRITE_INI_Y - CommonData.DIE_ARC[frame]);
				frame++;
				return T_CONTINUA;

			} else {
				return T_MUERTO;
			}
		}

		// Entrada del teclado (movimiento del personaje y disparos)

		if ( (keyState & GameCanvas.RIGHT_PRESSED)!=0 && pers.getX() < CommonData.SCREEN_WIDTH - CommonData.SPRITE_WIDTH) {
			pers.stepRight();
			pers.move(CommonData.SPRITE_STEP,0);
		} else if ( (keyState & GameCanvas.LEFT_PRESSED)!=0 && pers.getX() > 0) {
			pers.stepLeft();
			pers.move(-CommonData.SPRITE_STEP,0);
		} else {
			pers.stay();
		}

		if(hay_rayo) {
			rayo.move(0,CommonData.RAY_INCR);
			rayo.nextFrame();
			if(rayo.getY() < CommonData.RAY_MAX) {
				hay_rayo = false;
			}
		} else {
			if( (keyState & GameCanvas.FIRE_PRESSED)!=0 ) {
				rayo.setPosition(pers.getX() + CommonData.RAY_SPRITE_OFFSET, CommonData.RAY_BASE);
				hay_rayo = true;
				pers.stay();
			}
		}

		// Movimiento y colisiones de las bolas

		BallSprite bola = null;

		for(int i=0;i<bolas.size();i++) {
			bola = (BallSprite) bolas.elementAt(i);

			// Mover bolas
			bola.setPosition(bola.getX() + bola.vx, CommonData.BALL_BASE - bola.getHeight() - CommonData.BALL_ARC[bola.altura]);

			// Cambio de altura
			if(bola.altura==0) {
				bola.sube = true;
			}
			if(bola.altura==CommonData.BALL_MAX_HEIGHT) {
				bola.sube = false;
			}
			if(bola.sube) {
				bola.altura ++;
			} else {
				bola.altura --;
			}

			// Colision con muros verticales

			if(bola.getX() < 0 || bola.getX() > CommonData.SCREEN_WIDTH - bola.getWidth()) {
				bola.vx = -bola.vx;
			}


			// Colision con el personaje

			if(bola.collidesWith(pers,false)) {
				estado = E_MURIENDO;
				frame = 0;
				pers.die();
				SoundEngine.play(Resources.snd[Resources.SND_SCREAM]);
			}

			// Colision con el rayo

			if(hay_rayo) {
				if(bola.collidesWith(rayo,false)) {
					if(bola.desc1 != null && bola.desc2 != null) {
						int n_x = bola.getX();
						int n_y = bola.getY();

						bola.desc1.setPosition(n_x, n_y);
						bola.desc2.setPosition(n_x, n_y);

						bola.desc1.vy = bola.vy;
						bola.desc2.vy = bola.vy;
						
						bola.desc1.altura = bola.altura;
						bola.desc2.altura = bola.altura;

						bola.desc1.sube = true;
						bola.desc2.sube = true;

						bolas.addElement(bola.desc1);
						bolas.addElement(bola.desc2);
						
					}

					bolas.removeElement(bola);
					hay_rayo = false;
					i--;

					if(bolas.size() == 0) {
						return T_COMPLETADA;
					}

					SoundEngine.play(Resources.snd[Resources.SND_POP]);
				}
			}
		}

		return T_CONTINUA;

	}

	public void render(Graphics g) {
		// Dibuja el escenario
		escenario.render(g);

		// Dibuja el rayo si lo hubiese
		if(hay_rayo) {

			g.setClip(rayo.getX(), rayo.getY(), rayo.getWidth(), CommonData.BALL_BASE - rayo.getY());
			rayo.paint(g);
			g.setClip(0,0,CommonData.SCREEN_WIDTH, CommonData.SCREEN_HEIGHT);
		}

		// Dibuja el personaje
		pers.paint(g);

		// Dibuja las bolas
		for(int i=0;i<bolas.size();i++) {
			((BallSprite)bolas.elementAt(i)).paint(g);
		}

		// Dibuja el nombre de la fase durante el inicio
		if(dibujar_nombre) {
			g.setColor(CommonData.STAGE_TITLE_COLOR);
			g.setFont(CommonData.STAGE_TITLE_FONT);
			g.drawString(nombre_fase, CommonData.STAGE_TITLE_X, CommonData.STAGE_TITLE_Y, Graphics.HCENTER | Graphics.TOP);
		}

	}
}