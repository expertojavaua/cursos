/*
 * StageData.java
 * Copyright (C) 2004 Miguel Angel Lozano
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package es.ua.j2ee.game.panj.data;

import java.io.IOException;

import javax.microedition.lcdui.Image;

// ------------------------------------------------------------------------------------
// 	Clase encargada de almacenar los datos de cada fase
// ------------------------------------------------------------------------------------

public class StageData {

	public int ballsNumber;
	public BallData [] balls;

	public String imgBackgroundName;
	public Image imgBackground;

	public String name;
	
	public void loadResources() throws IOException {
		imgBackground = Image.createImage(imgBackgroundName);
	}
	
	public void unloadResources() {
		imgBackground = null;
	}
}