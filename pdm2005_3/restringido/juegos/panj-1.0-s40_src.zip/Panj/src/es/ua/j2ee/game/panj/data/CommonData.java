/*
 * CommonData.java
 * Copyright (C) 2004 Miguel Angel Lozano
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package es.ua.j2ee.game.panj.data;

import javax.microedition.lcdui.Font;

/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class CommonData {

	// Numero de vidas total
	public static final int NUM_LIVES = 3;
	
	// Ruta de la imagen del titulo
	public final static int [][] RUTA_TITULO = { 
		{ 64, 10 },
		{ 62, 11 },
		{ 58, 13 },
		{ 58, 15 },
		{ 62, 16 },
		{ 64, 16 },
		{ 66, 15 },
		{ 70, 13 },
		{ 70, 11 },
		{ 66, 10 }
	};

	// Ruta y posicion de las bolas
	public final static int[] BALL_ARC =
		{
			0,
			11,
			22,
			33,
			43,
			52,
			61,
			69,
			76,
			83,
			90,
			95,
			100,
			105,
			109,
			112,
			115,
			117,
			118,
			119,
			120 };
	public final static int BALL_MAX_HEIGHT = BALL_ARC.length - 1;
	public final static int BALL_BASE = 124;


	// Ruta trazada por el esqueleto al morir
	public final static int DIE_X_INCR = 3;
	public final static int[] DIE_ARC =
		{
			0,
			5,
			10,
			15,
			19,
			22,
			25,
			27,
			28,
			29,
			30,
			29,
			28,
			27,
			25,
			22,
			19,
			15,
			10,
			5 };

	// Dimensiones de la pantalla
	public final static int SCREEN_WIDTH = 128;
	public final static int SCREEN_HEIGHT = 128;

	// Datos del sprite del personaje
	public final static int SPRITE_WIDTH = 20;
	public final static int SPRITE_HEIGHT = 30;
	public final static int SPRITE_STEP = 3;
	public final static int SPRITE_INI_X = 54;
	public final static int SPRITE_INI_Y = 94;

	// Datos de los sprites de las bolas
	public final static int[] BALL_SIZE = { 5, 10, 20, 40 };

	// Datos de la image de la cara para el contador de vidas
	public final static int FACE_WIDTH = 10;
	public final static int FACE_HEIGHT = 10;

	// Datos del sprite del rayo
	public final static int RAY_WIDTH = 8;
	public final static int RAY_HEIGHT = 170;
	public final static int RAY_BASE = 124;
	public final static int RAY_MAX = -25;
	public final static int RAY_INCR = -6;	
	public final static int RAY_SPRITE_OFFSET = 6;		
	public final static int RAY_NUM_FRAMES = 3;
	
	// Datos del texto de titulo de fase
	public final static int STAGE_TITLE_X = 64;	
	public final static int STAGE_TITLE_Y = 50;	
	public static final int STAGE_TITLE_COLOR = 0x0FFFF00;
	public static final Font STAGE_TITLE_FONT = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_BOLD, Font.SIZE_SMALL);

	// Datos del texto de la pantalla de titulo
	public static final int GAME_START_X = 64;
	public static final int GAME_START_Y = 100;
	public static final String GAME_START_TEXT = "PULSA START";
	public static final int GAME_START_COLOR = 0x0FFFF00;
	public static final Font GAME_START_FONT = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_BOLD, Font.SIZE_SMALL);

}
