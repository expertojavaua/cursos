/*
 * SplashScreen.java
 * Copyright (C) 2004 Miguel Angel Lozano
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package es.ua.j2ee.game.panj.engine;

import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Graphics;
import javax.microedition.lcdui.Image;

import com.nokia.mid.ui.FullCanvas;

import es.ua.j2ee.game.panj.data.Resources;

/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class SplashScreen extends FullCanvas implements Runnable {

	public final static int CICLO = 25;

	int screenWidth;
	int screenHeight;

	int logoX;
	int logoY;
	int topY;
	int stepY;

	int textX;
	int textY;
	int textSep;

	Image logo;
	Font font;

	Thread t;

	String[] lineasTexto =
		{
			"Miguel Angel Lozano",
			"(c) 2004",
			"malozano@dccia.ua.es",
			"",
			"Juego exclusivo para",
			"alumnos del curso PDM.",
			"Mas informacion en:",
			"",
			"www.j2ee.ua.es/pdm" };

	public SplashScreen() {
		screenWidth = this.getWidth();
		screenHeight = this.getHeight();

		int imageW = 0;
		int imageH = 0;

		logo = Resources.splashImage;

		imageW = logo.getWidth();
		imageH = logo.getHeight();

		logoX = screenWidth / 2;
		logoY = screenHeight;
		topY = 5;
		stepY = 2;

		textX = screenWidth / 2;
		textY = imageH + 10;

		font =
			Font.getFont(Font.FACE_SYSTEM, Font.STYLE_PLAIN, Font.SIZE_SMALL);

		textSep = font.getHeight();
	}

	/* (non-Javadoc)
	 * @see javax.microedition.lcdui.Displayable#paint(javax.microedition.lcdui.Graphics)
	 */
	protected void paint(Graphics g) {

		// Dibuja el logo
		g.setColor(0x0000000);
		g.fillRect(0, 0, screenWidth, screenHeight);
		g.drawImage(logo, logoX, logoY, Graphics.HCENTER | Graphics.TOP);

		// Si el logo ya se ha parado, escribe el texto
		if (logoY <= topY) {
			g.setColor(0x0FFFFFF);
			g.setFont(font);
			for (int i = 0; i < lineasTexto.length; i++) {
				g.drawString(
					lineasTexto[i],
					textX,
					textY + i * textSep,
					Graphics.TOP | Graphics.HCENTER);
			}
		}
	}

	public void run() {
		long tIni, tCiclo;

		while (t == Thread.currentThread()) {

			tIni = System.currentTimeMillis();

			// Actualiza la posicion del logo
			if (logoY > topY) {				
				logoY -= stepY;
			} else {
				t = null;
				logoY = topY;
				synchronized(this) {
					notify();				
				}
			}

			this.repaint();

			tCiclo = System.currentTimeMillis() - tIni;

			// Duerme el tiempo restante
			if (tCiclo < CICLO) {
				try {
					Thread.sleep(CICLO - tCiclo);
				} catch (InterruptedException e) {
				}
			}
		}

	}
	
	public void join() {

		// Bloquea hasta terminar la animacion
		synchronized(this) {
			while(logoY > topY) {
				try {
					this.wait();
				} catch(InterruptedException e) {
				}
			}
		}
	}

	protected void hideNotify() {
		t = null;
	}

	protected void showNotify() {
		t = new Thread(this);
		t.start();
	}

}
