/*
 * PanjEngine.java
 * Copyright (C) 2004 Miguel Angel Lozano
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package es.ua.j2ee.game.panj.engine;

import javax.microedition.lcdui.Font;
import javax.microedition.lcdui.Graphics;

import com.siemens.mp.color_game.GameCanvas;

import es.ua.j2ee.game.panj.data.CommonData;
import es.ua.j2ee.game.panj.data.Resources;


/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class PanjEngine extends GameCanvas implements Runnable {

	// Estados del juego
	public final static int E_TITULO = 0;
	public final static int E_JUEGO = 1;

	// Milisegundos que transcurren entre dos instantes / frames consecutivos
	public final static int CICLO = 50;

	// Escena y estado actual (pantalla de titulo, juego, etc)
	Escena escena;
	int estado;
	
	// Estado de pausa
	boolean isPaused;

	// Hilo del juego
	Thread t;
	
	// Fuente pausa
	Font font;

	public PanjEngine() {
		super(false);
		//this.setFullscreenMode(true);

		// Crea la escena de titulo inicial. Partimos de dicho estado

		escena = new Titulo();
		estado = E_TITULO;

		// Inicializa fuente para el texto de la pausa
		font = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_BOLD, Font.SIZE_MEDIUM);
	}

	public void showNotify() {
		start();
	}
	
	public void hideNotify() {
		stop();
	}

	public void keyPressed(int keyCode) {
		// Llamamos a super por compatibilidad con la librer�a de MIDP 1.0
		//System.out.println("Pulsada " + keyCode);
		
		if(isPaused) {

			if(keyCode == -1) {
				start();
			} else if(keyCode == -4) {
				Resources.midlet.exitGame();
			}

		} else {

			if(keyCode == -1 || keyCode == -4) {
				stop();
			} else {
				super.keyPressed(keyCode);				
			}
		}
	}

	public synchronized void stop() {
		t = null; 

		isPaused = true;
		repaint();
	}

	public synchronized void start() {
		isPaused = false;

		t = new Thread(this);
		t.start();		
	}

	public void run() {

		// Obtiene contexto gr�fico
		Graphics g = getGraphics();

		// Transicion entre estados
		int trans = 0;

		while (t == Thread.currentThread()) {

			long t_ini, t_dif;
			t_ini = System.currentTimeMillis();

			// Lee las teclas
			int keyState = this.getKeyStates();

			// Actualiza la escena

			trans = escena.tick(keyState);
			switch (estado) {
				case E_TITULO :
					switch (trans) {
						case Titulo.T_CONTINUA :
							break;
						case Titulo.T_JUEGO :
							escena = new Juego();
							estado = E_JUEGO;
							break;
						case Titulo.T_SALIR :
							Resources.midlet.exitGame();
					}

					break;

				case E_JUEGO :

					switch (trans) {
						case Juego.T_TERMINA :
							escena = new Titulo();
							estado = E_TITULO;
							break;
						case Juego.T_SALIR :

							Resources.midlet.exitGame();
					}

					break;
			}

			// Repinta los gr�ficos (MIDP 2.0)
			//render(g);
			//flushGraphics();

			// Repinta los gr�ficos (MIDP 1.0)
			repaint();

			t_dif = System.currentTimeMillis() - t_ini;

			// Duerme hasta el siguiente frame

			if (t_dif < CICLO) {
				try {
					Thread.sleep(CICLO - t_dif);
				} catch (InterruptedException e) {
				}
			}
		}
	}

	public void render(Graphics g) {

		escena.render(g);
		
		if(isPaused) {
			g.setColor(0x000000);
			for(int i=0;i<CommonData.SCREEN_HEIGHT;i+=2) {
				g.drawLine(0,i,CommonData.SCREEN_WIDTH,i);
			}

			g.setColor(0x0FFFF00);
			g.setFont(font);
			g.drawString("Reanudar", 0, CommonData.SCREEN_HEIGHT, Graphics.LEFT | Graphics.BOTTOM);
			g.drawString("Salir", CommonData.SCREEN_WIDTH, CommonData.SCREEN_HEIGHT, Graphics.RIGHT | Graphics.BOTTOM);
			g.drawString("PAUSADO", CommonData.SCREEN_WIDTH/2, CommonData.SCREEN_HEIGHT/2, Graphics.HCENTER | Graphics.BOTTOM);
		}

	}

	// Dibujado para MIDP 1.0 (comentar en MIDP 2.0)
	public void paint(Graphics g) {
		g.setClip(0,0,CommonData.SCREEN_WIDTH, CommonData.SCREEN_HEIGHT);
		render(g);
	}

}
