/*
 * CommonData.java
 * Copyright (C) 2004 Miguel Angel Lozano
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package es.ua.j2ee.game.panj.data;

import javax.microedition.lcdui.Font;

/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class CommonData {

	// Numero de vidas total
	public static final int NUM_LIVES = 3;
	
	// Ruta de la imagen del titulo
	public final static int [][] RUTA_TITULO = { 
		{ 50, 10 },
		{ 48, 11 },
		{ 44, 13 },
		{ 44, 15 },
		{ 48, 16 },
		{ 50, 16 },
		{ 52, 15 },
		{ 56, 13 },
		{ 56, 11 },
		{ 52, 10 }
	};

	// Ruta y posicion de las bolas
	public final static int[] BALL_ARC =
		{
			0,
			6,
			13,
			19,
			25,
			30,
			35,
			40,
			44,
			48,
			52,
			55,
			58,
			61,
			63,
			65,
			67,
			68,
			69,
			69,
			70 };

	public final static int BALL_MAX_HEIGHT = BALL_ARC.length - 1;
	public final static int BALL_BASE = 78;


	// Ruta trazada por el esqueleto al morir
	public final static int DIE_X_INCR = 3;
	public final static int[] DIE_ARC =
		{
			0,
			3,
			7,
			10,
			12,
			15,
			16,
			18,
			19,
			19,
			20,
			19,
			19,
			18,
			16,
			14,
			12,
			10,
			7,
			3 };

	// Dimensiones de la pantalla
	public final static int SCREEN_WIDTH = 101;
	public final static int SCREEN_HEIGHT = 80;

	// Datos del sprite del personaje
	public final static int SPRITE_WIDTH = 20;
	public final static int SPRITE_HEIGHT = 30;
	public final static int SPRITE_STEP = 4;
	public final static int SPRITE_INI_X = 40;
	public final static int SPRITE_INI_Y = 48;

	// Datos de los sprites de las bolas
	public final static int[] BALL_SIZE = { 5, 10, 20, 40 };

	// Datos de la image de la cara para el contador de vidas
	public final static int FACE_WIDTH = 10;
	public final static int FACE_HEIGHT = 10;

	// Datos del sprite del rayo
	public final static int RAY_WIDTH = 8;
	public final static int RAY_HEIGHT = 125;
	public final static int RAY_BASE = 78;
	public final static int RAY_MAX = -20;
	public final static int RAY_INCR = -5;	
	public final static int RAY_SPRITE_OFFSET = 6;		
	public final static int RAY_NUM_FRAMES = 3;
	
	// Datos del texto de titulo de fase
	public final static int STAGE_TITLE_X = 50;	
	public final static int STAGE_TITLE_Y = 30;	
	public static final int STAGE_TITLE_COLOR = 0x0FFFF00;
	public static final Font STAGE_TITLE_FONT = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_BOLD, Font.SIZE_SMALL);

	// Datos del texto de la pantalla de titulo
	public static final int GAME_START_X = 50;
	public static final int GAME_START_Y = 60;
	public static final String GAME_START_TEXT = "PULSA START";
	public static final int GAME_START_COLOR = 0x0FFFF00;
	public static final Font GAME_START_FONT = Font.getFont(Font.FACE_SYSTEM, Font.STYLE_BOLD, Font.SIZE_SMALL);

}
