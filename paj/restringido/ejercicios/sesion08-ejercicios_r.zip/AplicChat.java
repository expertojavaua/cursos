import java.awt.BorderLayout;
import java.awt.GridLayout;
import javax.swing.*;
import java.awt.event.*;
import chat.ClienteChat;
import usuarios.*;

/**
  * Aplicacion para chat
  */
public class AplicChat extends JFrame implements Runnable
{
	/**
	  * Puntero al frame (para el hilo)
	  */
	AplicChat frame = this;

	/**
	  * Direccion IP del servidor
	  */
	JTextField txtIP;

	/**
	  * Login del usuario
	  */
	JTextField txtLogin;

	/**
	  * Password del usuario
	  */
	JPasswordField txtPassword;

	/**
	  * Texto a enviar al chat
	  */
	JTextField txtMensaje;

	/**
	  * Buffer de mensajes del chat
	  */
	JTextArea txtBuffer;
	
	/**
	  * Cliente de chat 
	  */
	ClienteChat chat;

	/**
	  * Hilo para recibir mensajes del servidor 
	  */
	Thread t;

	/**
	  * Botones
	  */
	JButton btnConectar;
	JButton btnRegistrar;
	JButton btnValidar;
	JButton btnEnviar;
	
	/**
	  * Constructor
	  */
	public AplicChat()
	{
		init();
	}
	
	/**
	  * Metodo para inicializar los componentes
	  */
	public void init()
	{
		getContentPane().setLayout(new BorderLayout());
		
		/******** Panel superior para validar el usuario *********/
		
		JPanel panelSup = new JPanel();
		panelSup.setLayout(new GridLayout(3, 3));
		
		// Conexion al servidor
		
		JLabel lblIP = new JLabel ("IP Servidor:");
		txtIP = new JTextField();
		panelSup.add(lblIP);
		panelSup.add(txtIP);

		// Boton de conexion con el servidor
	
		btnConectar = new JButton ("Conectar");
		btnConectar.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					chat = new ClienteChat(txtIP.getText());
					btnRegistrar.setEnabled(true);
					btnValidar.setEnabled(true);
				} catch (Exception ex) {
					txtBuffer.setText("Error al conectar\n");
				}
			}
		});
		panelSup.add(btnConectar);

		
		// Login del usuario
		
		JLabel lblLogin = new JLabel("Login:");
		txtLogin = new JTextField();
		panelSup.add(lblLogin);
		panelSup.add(txtLogin);

		// Boton de registrar un nuevo usuario
			
		btnRegistrar = new JButton ("Registrar");
		btnRegistrar.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try {
					chat.registraUsuario(txtLogin.getText(), new String(txtPassword.getPassword()));
				} catch(Exception ex) {
					System.err.println(ex.getMessage());
					txtBuffer.append("Error al registrar el usuario\n");
				}
			}
		});
		panelSup.add(btnRegistrar);
					
		// Password del usuario
		
		JLabel lblPassword = new JLabel("Password:");
		txtPassword = new JPasswordField();
		panelSup.add(lblPassword);
		panelSup.add(txtPassword);		

		// Boton de validacion de usuario
			
		btnValidar = new JButton ("Validar");
		btnValidar.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try {
					chat.loginUsuario(txtLogin.getText(), new String(txtPassword.getPassword()));
				} catch(Exception ex) {
					System.err.println(ex.getMessage());
					txtBuffer.append("Error al validar el usuario\n");
					return;
				}

				t = new Thread(frame);
				t.start();
				btnEnviar.setEnabled(true);
			}
		});
		panelSup.add(btnValidar);

		getContentPane().add(panelSup, BorderLayout.NORTH);


		/******** Panel central con el buffer del chat *********/

		txtBuffer = new JTextArea("", 10, 450);
		JScrollPane scrllBuffer = new JScrollPane(txtBuffer);
		getContentPane().add(scrllBuffer, BorderLayout.CENTER);
		

		/******** Panel inferior para enviar mensajes al chat *********/
		
		JPanel panelInf = new JPanel();
		panelInf.setLayout(new GridLayout(2, 1));
		
		txtMensaje = new JTextField();
		txtMensaje.addKeyListener(new KeyAdapter() {
			public void keyPressed(KeyEvent e)
			{
				if (e.getKeyCode() == KeyEvent.VK_ENTER)
				{
					chat.enviaMensaje(txtMensaje.getText());				
					txtMensaje.setText("");
				}					
			}
		});
		panelInf.add(txtMensaje);
		
		btnEnviar = new JButton("Enviar");
		btnEnviar.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				chat.enviaMensaje(txtMensaje.getText());
				txtMensaje.setText("");
			}
		});
		panelInf.add(btnEnviar);
		
		getContentPane().add(panelInf, BorderLayout.SOUTH);		

		btnRegistrar.setEnabled(false);
		btnValidar.setEnabled(false);
		btnEnviar.setEnabled(false);
	}

	/**
	  * Funcion principal del hilo 
	  */
	public void run() 
	{
		// Recibe los mensajes del servidor
		
		String msg = null;
		try
		{
			while( (msg=chat.recibeMensaje()) != null ) 
			{
				txtBuffer.append(msg + "\n");
			}
		} catch (Exception ex) {
			txtBuffer.append("Error al enviar mensaje\n");
		}
	}
	
	/**
	  * Main
	  */
	public static void main (String[] args)
	{
		AplicChat ac = new AplicChat();
		ac.setSize(400, 300);
		ac.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			}
		});
		ac.show();
	}
}