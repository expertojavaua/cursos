import java.awt.*;
import java.awt.event.*;
import chat.ClienteChat;
import usuarios.*;

/**
  * Aplicacion para chat
  */
public class AplicChat extends Frame implements Runnable
{
	/**
	  * Puntero al frame (para el hilo)
	  */
	AplicChat frame = this;

	/**
	  * Direccion IP del servidor
	  */
	TextField txtIP;

	/**
	  * Login del usuario
	  */
	TextField txtLogin;

	/**
	  * Password del usuario
	  */
	TextField txtPassword;

	/**
	  * Texto a enviar al chat
	  */
	TextField txtMensaje;

	/**
	  * Buffer de mensajes del chat
	  */
	TextArea txtBuffer;
	
	/**
	  * Cliente de chat 
	  */
	ClienteChat chat;

	/**
	  * Hilo para recibir mensajes del servidor 
	  */
	Thread t;
	
	/**
	  * Constructor
	  */
	public AplicChat()
	{
		init();
	}
	
	/**
	  * Metodo para inicializar los componentes
	  */
	public void init()
	{
		setLayout(new BorderLayout());
		
		/******** Panel superior para validar el usuario *********/
		
		Panel panelSup = new Panel();
		panelSup.setLayout(new GridLayout(3, 3));
		
		// Conexion al servidor
		
		Label lblIP = new Label ("IP Servidor:");
		txtIP = new TextField();
		panelSup.add(lblIP);
		panelSup.add(txtIP);

		// Boton de conexion con el servidor
	
		Button btnConectar = new Button ("Conectar");
		btnConectar.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try
				{
					chat = new ClienteChat(txtIP.getText());
				} catch (Exception ex) {
					txtBuffer.append("Error al conectar con el servidor\n");
				}
			}
		});
		panelSup.add(btnConectar);

		
		// Login del usuario
		
		Label lblLogin = new Label("Login:");
		txtLogin = new TextField();
		panelSup.add(lblLogin);
		panelSup.add(txtLogin);

		// Boton de registrar un nuevo usuario
			
		Button btnRegistrar = new Button ("Registrar");
		btnRegistrar.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try {
					chat.registraUsuario(txtLogin.getText(), txtPassword.getText());
				} catch(Exception ex) {
					System.err.println(ex.getMessage());
					txtBuffer.append("Error al registrar el usuario\n");
				}
			}
		});
		panelSup.add(btnRegistrar);
					
		// Password del usuario
		
		Label lblPassword = new Label("Password:");
		txtPassword = new TextField();
		panelSup.add(lblPassword);
		panelSup.add(txtPassword);		

		// Boton de validacion de usuario
			
		Button btnValidar = new Button ("Validar");
		btnValidar.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try {
					chat.loginUsuario(txtLogin.getText(), txtPassword.getText());
				} catch(Exception ex) {
					System.err.println(ex.getMessage());
					txtBuffer.append("Error al validar el usuario\n");
					return;
				}

				t = new Thread(frame);
				t.start();
			}
		});
		panelSup.add(btnValidar);

		add(panelSup, BorderLayout.NORTH);


		/******** Panel central con el buffer del chat *********/

		txtBuffer = new TextArea("", 10, 450, TextArea.SCROLLBARS_BOTH);
		txtBuffer.setEditable(false);
		add(txtBuffer, BorderLayout.CENTER);
		

		/******** Panel inferior para enviar mensajes al chat *********/
		
		Panel panelInf = new Panel();
		panelInf.setLayout(new GridLayout(2, 1));
		
		txtMensaje = new TextField();
		panelInf.add(txtMensaje);
		
		Button btnEnviar = new Button("Enviar");
		btnEnviar.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				chat.enviaMensaje(txtMensaje.getText());
			}
		});
		panelInf.add(btnEnviar);
		
		add(panelInf, BorderLayout.SOUTH);		
	}

	/**
	  * Funcion principal del hilo 
	  */
	public void run() 
	{
		// Recibe los mensajes del servidor
		
		String msg = null;
		try
		{
			while( (msg=chat.recibeMensaje()) != null ) 
			{
				txtBuffer.append(msg + "\n");
			}
		} catch (Exception ex) {
			txtBuffer.append("Error al enviar mensaje \n");
		}
	}
	
	/**
	  * Main
	  */
	public static void main (String[] args)
	{
		AplicChat ac = new AplicChat();
		ac.setSize(400, 300);
		ac.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			}
		});
		ac.show();
	}
}