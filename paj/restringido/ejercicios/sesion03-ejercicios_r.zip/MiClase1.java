public class MiClase1 
{
	public MiClase1() 
	{
	}

	public void imprime() 
	{
		System.out.println ("Imprimiendo en MiClase1");
	}
}