public class MiClase1b
{
	public MiClase1b(String param) 
	{
	}

	public void imprime(String param) 
	{
		System.out.println ("Imprimiendo en MiClase1b con metodo con parametro: " + param);
	}
}