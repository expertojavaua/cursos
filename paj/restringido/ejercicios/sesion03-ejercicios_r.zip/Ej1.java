public class Ej1 {

	public static double logaritmo(double num) {
		return Math.log(num);
	}

	public static void main(String [] args) {

		double num=0;

		try {
			num = Double.parseDouble(args[0]);
		} catch(ArrayIndexOutOfBoundsException e1) {
			System.err.println("Debe proporcionarse un par�metro");
			System.exit(1);
		} catch(NumberFormatException e2) {
			System.err.println("El par�metro debe ser de tipo entero");
			System.exit(1);
		}

		System.out.println("Logaritmo = " + logaritmo(num));

	}
}