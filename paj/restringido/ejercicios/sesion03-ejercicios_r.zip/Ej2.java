public class Ej2 {

	// Declarar que el m�todo logaritmo puede lanzar excepciones

	public static double logaritmo(double num) throws WrongParameterException
	{

		if(num <= 0) 
		{
			// Lanzar excepcion con mensaje descriptivo

			throw new WrongParameterException("El logaritmo solo puede aplicarse a numeros positivos");

		}

		return Math.log(num);
	}

	public static void main(String [] args) 
	{

		double num = Double.parseDouble(args[0]);

		try {
			System.out.println("Logaritmo = " + logaritmo(num));
		} catch(WrongParameterException e) {
			System.out.println(e.getMessage());
			System.exit(1);
		}

	}
}