import java.lang.reflect.*;

public class Ej5 
{
	public static void main(String [] args) 
	{
		if(args.length!=1) 
		{
			System.err.println("Uso: java Ej5 [MiClase1b|MiClase2b]");
			System.exit(1);
		}

		try
		{
			Class c = Class.forName(args[0]);
			Constructor[] constructores = c.getDeclaredConstructors();
			Object[] parametros = new Object[1];
			parametros[0] = "Hola";
			Object o = constructores[0].newInstance(parametros);
			Method[] metodos = c.getMethods();
			parametros[0] = "Imprimiendo";
			metodos[0].invoke(o, parametros);
		} catch (Exception e) {}
	}
}