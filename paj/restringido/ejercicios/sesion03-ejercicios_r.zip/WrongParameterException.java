
public class WrongParameterException extends Exception 
{

	public WrongParameterException(String msg) {
		super(msg);
	}

}