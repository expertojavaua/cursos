import java.io.*;

public class Ej2 {

	public Ej2(String origen, String destino) {
		copia(origen, destino);
	}

	public void copia(String origen, String destino) {
    		int c;

		/* A�adir aqu� el c�digo necesario para que compile */

		try {

			// Abre fichero de entrada y de salida

        		FileInputStream in = new FileInputStream(origen);
	      		FileOutputStream out = new FileOutputStream(destino);

			// Copia caracter a caracter

        		while( (c = in.read()) != -1)
        		{
            			out.write(c);
        		}

			// Cierra ficheros

        		in.close();
        		out.close();

		} catch(FileNotFoundException e1) {
			System.out.println("Fichero no encontrado");
			System.exit(1);
		} catch(IOException e2) {
			System.out.println("Error en la E/S");
			System.exit(1);
		}

		/* A�adir aqu� el c�digo necesario para que compile */

	}

	public static void main(String [] args) {
		if(args.length != 2) {
			System.err.println("Uso: java Ej2 fichero_origen fichero_destino");
			System.exit(1);
		}

		new Ej2(args[0], args[1]);
	}
}
