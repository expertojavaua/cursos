import java.io.*;
import java.net.*;
import java.io.*;
import chat.*;
import es.*;
import usuarios.*;

public class Ej3 implements Runnable {
	ClienteChat chat;
	EntradaConsola in;
	Thread t;

	public Ej3(String ip) {
		try {
			chat = new ClienteChat(ip);
		} catch(UnknownHostException e1) {
			System.out.println("Host desconocido");
			System.exit(1);
		} catch(IOException e2) {
			System.out.println("Error al conectar con el servidor");
			System.exit(1);
		}

		in = new EntradaConsola();

		menu();
	}

	public void run() {
		String msg = null;

		try {
			while( (msg=chat.recibeMensaje()) != null ) {
				System.out.println(msg);
			}
		} catch(IOException e) {
			System.err.println("Error en la E/S");
			System.exit(1);
		}
	}

	private void chat() {
		String msg = null;

		t = new Thread(this);
		t.start();

		while( (msg=in.readLine()) != null ) {
			chat.enviaMensaje(msg);
		}
	}

	private void menu() {

		String texto = "Elija una opcion:\n" + 
				"\t1. Entrar al chat\n" +
				"\t2. Registrar nuevo usuario\n" +
				"\t0. Salir\n";
		String resp;

		resp = in.promptLine(texto);

		if(resp.trim().equals("1")) {
			entrar();
		} else if(resp.trim().equals("2")) {
			registrar();
		} else if(resp.trim().equals("0")) {
			System.exit(0);
		} else {
			menu();
		}

	}

	private void entrar() {

		String login = in.promptLine("Login: ");
		String password = in.promptLine("Password: ");

		try {
			chat.loginUsuario(login, password);
		} catch(LoginInvalidoException e1) {
			System.err.println(e1.getMessage());
			menu();
			return;
		} catch(IOException e2) {
			System.err.println("Error en la E/S");
			System.exit(1);
		}

		chat();
	}

	private void registrar() {

		String login = in.promptLine("Login: ");
		String password = in.promptLine("Password: ");

		try {
			chat.registraUsuario(login, password);
		} catch(LoginInvalidoException e1) {
			System.err.println(e1.getMessage());
		} catch(IOException e2) {
			System.err.println("Error en la E/S");
		}

		menu();
	}

	public static void main(String [] args) {
		if(args.length != 1) {
			System.err.println("Uso: java Ej3 ip_servidor");
			System.exit(1);
		}

		new Ej3(args[0]);
	}
}
