package plantas;

/**
  * Ejemplo de clase Java en un paquete
  */
public class Geranio
{
	String nombre;
	int edad;

	/**
	  * Constructor
	  */
	public Geranio()
	{
		nombre = "Geranio";
		edad = 8;
	}

	/**
	  * Metodo
	  */
	public void nombre()
	{
		System.out.println ("Nombre Planta: " + nombre);
	}

	/**
	  * Metodo
	  */
	public int edad()
	{
		return edad;
	}
}
