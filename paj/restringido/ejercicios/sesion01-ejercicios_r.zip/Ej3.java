
/**
  * Esqueleto para el ejercicio de la ecuacion de segundo grado
  */
public class Ej3
{	  
	/**
	  * Obtiene un array con las dos soluciones a la ecuacion
	  */
	public static double[] solucion (double a, double b, double c)
	{ 
		double[] sol = new double[2];
		
		double raiz = Math.pow(b, 2.0) - 4 * a * c;
		
		if (raiz < 0)
			return null;
		else
		{
			if (a == 0)
			{
				if (b == 0)
					return null;		// Si a y b son 0 no hay ecuacion
				else
					sol[0] = sol[1] = -c / b;
			} else {
				sol[0] = (-b + Math.sqrt(raiz)) / (2*a);
				sol[1] = (-b - Math.sqrt(raiz)) / (2*a);
			}
		}
		
		return sol;
	} 

	/**
	  * Main
	  */
	public static void main(String[] args) 
	{ 
		double[] sol = solucion(4.0, 1.0, -6.0);
		if (sol == null)
			System.out.println ("No hay solucion para 4, 1, -6");
		else
			System.out.println ("Solucion para 4, 1, -6: X1 = " + sol[0] + ", X2 = " + sol[1]); 

		sol = solucion(4.0, 1.0, 6.0);
		if (sol == null)
			System.out.println ("No hay solucion para 4, 1, 6");
		else
			System.out.println ("Solucion para 4, 1, 6: X1 = " + sol[0] + ", X2 = " + sol[1]); 

		sol = solucion(0.0, 3.0, -1.0);
		if (sol == null)
			System.out.println ("No hay solucion para 0, 3, -1");
		else
			System.out.println ("Solucion para 0, 3, -1: X1 = " + sol[0] + ", X2 = " + sol[1]); 

		sol = solucion(2.0, 0.0, -1.0);
		if (sol == null)
			System.out.println ("No hay solucion para 2, 0, -1");
		else
			System.out.println ("Solucion para 2, 0, -1: X1 = " + sol[0] + ", X2 = " + sol[1]); 

		sol = solucion(2.0, 2.0, 0.0);
		if (sol == null)
			System.out.println ("No hay solucion para 2, 2, 0");
		else
			System.out.println ("Solucion para 2, 2, 0: X1 = " + sol[0] + ", X2 = " + sol[1]); 
	} 
}
