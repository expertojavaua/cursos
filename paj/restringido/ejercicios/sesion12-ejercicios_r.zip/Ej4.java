import java.awt.Frame;
import java.awt.event.*;
import java.awt.image.renderable.ParameterBlock;
import java.io.IOException;
import javax.media.jai.JAI;
import javax.media.jai.RenderedOp;
import com.sun.media.jai.codec.FileSeekableStream;
import javax.media.jai.widget.ScrollingImagePanel;


/**
  * Ejercicio de JAI para aplicar un filtro de mediana
  */
public class Ej4
{
	public static void main(String[] args)
	{
		// ... Leer la imagen del fichero correspondiente

		FileSeekableStream stream1 = null;
		try
		{
			stream1 = new FileSeekableStream("puentru.jpg");
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(0);
		}

		// ... Crear el operador que tome la imagen de entrada

		RenderedOp img1 = JAI.create("stream", stream1);
		
		// ... Definir los par�metros del filtro de mediana (la imagen de entrada)

		ParameterBlock params = new ParameterBlock();
		params.addSource(img1);

		// ... Crear el operador de filtro de mediana, pasarle los parametros y obtener el resultado

		RenderedOp imgres = JAI.create("medianfilter", params);

		// ... Visualizar la imagen resultado

		ScrollingImagePanel panel = new ScrollingImagePanel(imgres, imgres.getWidth(), imgres.getHeight());
		Frame window = new Frame("JAI Sample Program");
		window.addWindowListener(new WindowAdapter() 
		{
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			}
		});
		window.add(panel);
		window.pack();
		window.show();				
	}
}
