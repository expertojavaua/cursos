import java.awt.Frame;
import java.awt.event.*;
import java.awt.image.renderable.ParameterBlock;
import java.io.IOException;
import javax.media.jai.JAI;
import javax.media.jai.RenderedOp;
import com.sun.media.jai.codec.FileSeekableStream;
import javax.media.jai.widget.ScrollingImagePanel;


/**
  * Ejercicio de JAI para sumar dos imagenes
  */
public class Ej3
{
	public static void main(String[] args)
	{
		// ... Leer las im�genes de los ficheros correspondientes

		FileSeekableStream stream1 = null;
		try
		{
			stream1 = new FileSeekableStream("lena.jpg");
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(0);
		}

		FileSeekableStream stream2 = null;
		try
		{
			stream2 = new FileSeekableStream("lena2.jpg");
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(0);
		}
		
		// ... Crear operadores que tomen las im�genes de entrada

		RenderedOp img1 = JAI.create("stream", stream1);
		RenderedOp img2 = JAI.create("stream", stream2);

		// ... Definir los par�metros (las imagenes de entrada)

		ParameterBlock params = new ParameterBlock();
		params.addSource(img1);
		params.addSource(img2);

		// ... Crear el operador de suma de imagenes, pasarle los parametros y obtener el resultado

		RenderedOp imgres = JAI.create("add", params);
		
		// ... Visualizar la imagen resultado

		ScrollingImagePanel panel = new ScrollingImagePanel(imgres, imgres.getWidth(), imgres.getHeight());
		Frame window = new Frame("JAI Sample Program");
		window.addWindowListener(new WindowAdapter() 
		{
			public void windowClosing(WindowEvent e)
			{
				System.exit(0);
			}
		});
		window.add(panel);
		window.pack();
		window.show();		
	}
}
