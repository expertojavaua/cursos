package chat;

import java.io.*;
import java.net.*;
import usuarios.*;
import es.*;

/**
  * La clase <code>ClienteChat</code> implementa la funcionalidad b�sica del chat en
  * el lado del cliente.
  */
public class ClienteChat {

	// Objeto socket para la comunicaci�n de datos
	ConexionSocket socket;

	/**
	  * Crea un objeto <code>ClientChat</code>
	  * @param ip Direccion IP del servidor
	  */
	public ClienteChat(String ip) throws UnknownHostException, IOException {
		socket = new ConexionSocket(ip, ServidorChat.PUERTO_CHAT);
	}

	/** 
	  * Recibe un mensaje para mostrar en el chat
	  * @return Mensaje recibido
	  */
	public String recibeMensaje() throws IOException {
		return socket.recibe();
	}

	/**
	  * Envia un mensaje al chat
	  * @param mensaje Mensaje a enviar
	  */
	public void enviaMensaje(String mensaje) {
		socket.envia(mensaje);
	}

	/**
	  * Registra un nuevo usuario para el chat
	  * @param login Login del nuevo usuario
	  * @param password Password del nuevo usuario
	  */
	public void registraUsuario(String login, String password) throws LoginInvalidoException, IOException {
		socket.envia(ServidorChat.CMD_REG);
		socket.envia(login);
		socket.envia(password);

		String res = socket.recibe();

		// Si hay error recibe el mensaje de error

		if(res.equals(ServidorChat.RES_ERROR)) {
			res = socket.recibe();
			throw new LoginInvalidoException(res);
		}
	}

	/**
	  * Entra en el chat. Si el login y password son correctos entrar� a comunicarse
	  * con el resto de usuarios conectados al chat.
	  * @param login Login del usuario
	  * @param password Password del usuario
	  */
	public void loginUsuario(String login, String password) throws LoginInvalidoException, IOException {
		socket.envia(ServidorChat.CMD_LOGIN);
		socket.envia(login);
		socket.envia(password);

		String res = socket.recibe();

		// Si hay error recibe el mensaje de error

		if(res.equals(ServidorChat.RES_ERROR)) {
			res = socket.recibe();
			throw new LoginInvalidoException(res);
		}
	}

}
