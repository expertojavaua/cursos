
import java.awt.*;
import javax.swing.*;

public class Ej1 extends JFrame {

	public final static String TEXTO = "Este texto debe poderse ver perfectamente sin parpadeos.";

	public Ej1() {

		// Establece las dimensiones de la ventana
		setSize(200,100);

		// Crea el area de dibujo que hemos definido
		AreaDibujo area = new AreaDibujo();
		getContentPane().add(area, BorderLayout.CENTER);

		// Cuando cerremos la ventana saldr� de la aplicaci�n
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	class AreaDibujo extends Canvas implements Runnable {

		// Fuente y m�tricas
		Font f;
		FontMetrics fm;

		// Imagen que har� de backbuffer
		Image backbuffer = null;

		// Ancho y alto del componente
		int w, h;

		// Posicion del texto
		int x, y;

		// Hilo para la animaci�n
		Thread t;

		public AreaDibujo() {

			// Crea la fuente y obtiene sus metricas
			f = new Font("Arial", Font.PLAIN, 20);
			fm = getFontMetrics(f);

			// Ejecuta el hilo para la animacion
			t = new Thread(this);
			t.start();
		}


		public void update(Graphics g) {
			// Sobrescribimos update para evitar el parpadeo
			paint(g);
		}

		public void paint(Graphics g) {

			// Si no hay backbuffer o el area ha cambiado de tama�o
			// volvemos a crear el backbuffer y a establecer las coordenadas

			if(backbuffer == null || w!=getWidth() || h!=getHeight()) {
				w = getWidth();
				h = getHeight();
				x = w;
				y = h - 10;

				// Crea el backbuffer
				backbuffer = createImage(w, h);
			}

			// Obtiene el contexto grafico del backbuffer
			Graphics off_g = backbuffer.getGraphics();
	
			// Vacia el contenido del backbuffer
			off_g.clearRect(0, 0, w, h);
	
			// Dibuja el texto
			off_g.setFont(f);
			off_g.setColor(Color.black);
			off_g.drawString(TEXTO, x, y);
	
			// Libera recursos
			off_g.dispose();
	
			// Vuelca el backbuffer a pantalla
			g.drawImage(backbuffer, 0, 0, this);
		}

		public void run() {
			while(t == Thread.currentThread()) {

				// Desplaza el texto a la izquierda
				x--;
	
				// Si ha desaparecido completamente vuelve a la derecha
				if(x < -fm.stringWidth(TEXTO)) {
					x = getWidth();
				}
	
				// Solicitamos que se repinte el nuevo frame
				repaint();
	
				try {
					Thread.currentThread().sleep(10);
				} catch(InterruptedException e) {}
			}
		}

	}

	public static void main(String [] args) {
		Ej1 ej1 = new Ej1();

		ej1.show();
	}

}