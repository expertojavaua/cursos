
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Ej3 extends JFrame implements MouseMotionListener, MouseListener {

	// Dimensiones de la aplicaci�n
	public final static int WIDTH = 400;
	public final static int HEIGHT = 400;

	// Extremos del rect�ngulo que se est� dibujando
	int ini_x, ini_y;
	int fin_x, fin_y;

	// Area de dibujo en memoria
	Image area_dibujo = null;

	public Ej3() {

		// Registra el componente como listener para eventos de raton
		addMouseMotionListener(this);
		addMouseListener(this);

		// Establece las dimensiones y el color de fondo
		setSize(WIDTH, HEIGHT);
		setBackground(Color.white);

		// Cuando cerremos la ventana saldr� de la aplicaci�n
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public void mousePressed(MouseEvent e) {
		// Las coordenadas de inicio y fin coinciden
		fin_x = ini_x = e.getX();
		fin_y = ini_y = e.getY();

		// Dibuja el rectangulo (con XOR)
		dibuja(ini_x, ini_y, fin_x, fin_y, true);
		repaint();
	}

	public void mouseReleased(MouseEvent e) {
		// Dibuja el rectangulo definitivo (sin XOR)
		dibuja(ini_x, ini_y, fin_x, fin_y, false);
		repaint();
	}

	public void mouseClicked(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mouseEntered(MouseEvent e) {}
	public void mouseMoved(MouseEvent e) {}

	public void mouseDragged(MouseEvent e) {

		// Vuelve a dibuja el rectangulo anterior (con XOR)
		dibuja(ini_x, ini_y, fin_x, fin_y, true);

		// Lee las nuevas coordenadas de fin de la posicion del raton
		fin_x = e.getX();
		fin_y = e.getY();

		// Dibuja el nuevo rect�ngulo (con XOR)
		dibuja(ini_x, ini_y, fin_x, fin_y, true);

		repaint();
	}

	public void dibuja(int ini_x, int ini_y, int fin_x, int fin_y, boolean xor) {
		int x,y,w,h;

		// Las imagenes no se crean correctamente en el constructor de la clase
		// Tenemos que crearlas aqui, una vez la clase est� construida

		if(area_dibujo == null)
			area_dibujo = createImage(WIDTH, HEIGHT);

		x = y = w = h = 0;

		// Establece las coordenadas y dimensiones del rectangulo a partir
		// de sus extremos inicio y fin.

		if(ini_x < fin_x) {
			x = ini_x;
			w = fin_x - ini_x;
		} else {
			x = fin_x;
			w = ini_x - fin_x;
		}
		if(ini_y < fin_y) {
			y = ini_y;
			h = fin_y - ini_y;
		} else {
			y = fin_y;
			h = ini_y - fin_y;
		}

		// Dibuja el rectangulo en el �rea en memoria

		Graphics g = area_dibujo.getGraphics();

		// Establece el modo paint o XOR

		if(xor) {
			g.setXORMode(Color.white);
		} else {
			g.setPaintMode();
		}

		g.setColor(Color.black);
		g.drawRect(x, y, w, h);
		g.dispose();
	}

	public void update(Graphics g) {
		// Sobrescribimos para evitar parpadeo
		paint(g);
	}

	public void paint(Graphics g) {
		// Vuelca la imagen en memoria a pantalla
		if(area_dibujo != null) 
			g.drawImage(area_dibujo, 0, 0, null);
	}

	public static void main(String [] args) {

		Ej3 ej3 = new Ej3();
		ej3.show();

	}

}