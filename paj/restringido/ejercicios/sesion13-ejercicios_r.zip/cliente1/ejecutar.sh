export CLASSPATH=./interfaz.jar:.
java -Djava.security.policy=java.policy ClienteNumeros $1 $2
