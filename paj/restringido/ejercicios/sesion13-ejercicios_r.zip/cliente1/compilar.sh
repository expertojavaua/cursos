export CLASSPATH=./interfaz.jar:.
javac ClienteNumeros.java
