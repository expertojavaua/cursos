
/**
  * Cliente RMI que se conecta a un objeto InterfazServidorNumeros
  */
public class ClienteNumeros
{
	public static void main(String[] args) 
	{
    	if (System.getSecurityManager() == null) 
       		System.setSecurityManager(new java.rmi.RMISecurityManager());
		try
		{
			InterfazServidorNumeros isn = (InterfazServidorNumeros)java.rmi.Naming.lookup("//" + args[0] + ":" + args[1] +"/ServidorNumeros");
			long num = isn.ultimoNumero();
			System.out.println ("Valor devuelto: " + num);
		} catch (Exception e) { System.out.println (e.getMessage()); }
	}
}
