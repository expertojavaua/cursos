export CLASSPATH=./compartido.jar:.
javac Datos.java
javac MiInterfazDesconocida.java
rm *.jar
jar cvf compartido.jar MiInterfazDesconocida.class Datos.class
javac MiObjetoDesconocido.java
rmic -d . MiObjetoDesconocido