
/**
  * Interfaz de un servidor desconocido para el cliente del ejercicio
  */
public interface MiInterfazDesconocida extends java.rmi.Remote
{
	public Datos datos() throws java.rmi.RemoteException;
}
