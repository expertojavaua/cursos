
/**
  * Servidor RMI desconocido para el cliente
  */
public class MiObjetoDesconocido extends java.rmi.server.UnicastRemoteObject 
                     		 	 implements MiInterfazDesconocida
{
	// Constructor
	
	public MiObjetoDesconocido() throws java.rmi.RemoteException
	{
	}

	// Metodo remoto
	
	public Datos datos() throws java.rmi.RemoteException
	{
		Datos d = new Datos("Pepe Ruiz", 33, "pepe@uncorreo.com");
		return d;
	}

	// Main

	public static void main(String[] args)
	{
		if (System.getSecurityManager() == null)
			System.setSecurityManager(new java.rmi.RMISecurityManager());
		try
		{
			MiInterfazDesconocida mid = new MiObjetoDesconocido();
			java.rmi.Naming.rebind("//" + java.net.InetAddress.getLocalHost().getHostAddress() + ":" + args[0] + "/Desconocido", mid);
			System.out.println ("Servidor enlazado");
		} catch (Exception e) { e.printStackTrace(); }
	}
}
