
/**
  * Clase serializable que se intercambian cliente y servidor
  */
public class Datos implements java.io.Serializable
{
	String nombre;				// Nombre de la persona
	int edad;					// Edad de la persona
	String email;				// E-mail de la persona
	
	// Constructor
	
	public Datos(String nombre, int edad, String email)
	{
		this.nombre = nombre;
		this.edad = edad;
		this.email = email;
	}
	
	// Obtiene una cadena con todos los datos de la persona
	
	public String cadena()
	{
		return ("Nombre: " + nombre + ", Edad: " + edad + ", E-mail: " + email);
	}
}
