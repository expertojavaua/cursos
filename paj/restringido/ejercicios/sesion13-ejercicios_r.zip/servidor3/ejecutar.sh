export CLASSPATH=./compartido.jar:.
rmiregistry $1 &
java -Djava.security.policy=java.policy MiObjetoDesconocido $1
