export CLASSPATH=./interfaz.jar:.
javac InterfazServidorNumeros.java
rm *.jar
jar cvf interfaz.jar InterfazServidorNumeros.class
javac ServidorPrimos.java
rmic -d . ServidorPrimos
