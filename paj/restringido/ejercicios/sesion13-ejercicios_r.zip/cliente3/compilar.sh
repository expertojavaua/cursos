export CLASSPATH=./compartido.jar:.
javac Ej3.java
