
/**
  * Cliente RMI que se conecta a un servidor desconocido
  */
public class Ej3
{
	public static void main(String[] args) 
	{
    	if (System.getSecurityManager() == null) 
       		System.setSecurityManager(new java.rmi.RMISecurityManager());
		try
		{
			MiInterfazDesconocida mid = (MiInterfazDesconocida)java.rmi.Naming.lookup("//" + args[0] + ":" + args[1] +"/Desconocido");
			Datos d = mid.datos();
			System.out.println ("Cadena devuelta: " + d.cadena());
		} catch (Exception e) { System.out.println (e.getMessage()); }
	}
}
