export CLASSPATH=./compartido.jar:.
java -Djava.security.policy=java.policy Ej3 $1 $2
