
/**
  * Servidor RMI. Implementa la interfaz InterfazServidorNumeros para decir cuantas veces se le ha solicitado un metodo
  */
public class ServidorVeces	 extends java.rmi.server.UnicastRemoteObject 
                     		 implements InterfazServidorNumeros
{
	int contador = 0;					// Veces que se ha solicitado el metodo
	
	// Constructor
	
	public ServidorVeces() throws java.rmi.RemoteException
	{
	}

	// Metodo remoto
	
	public long ultimoNumero() throws java.rmi.RemoteException
	{
		contador++;
		return contador;
	}

	// Main

	public static void main(String[] args)
	{
		if (System.getSecurityManager() == null)
			System.setSecurityManager(new java.rmi.RMISecurityManager());
		try
		{
			InterfazServidorNumeros isn = new ServidorVeces();
			java.rmi.Naming.rebind("//" + java.net.InetAddress.getLocalHost().getHostAddress() + ":" + args[0] + "/ServidorNumeros", isn);
			System.out.println ("Servidor enlazado");
		} catch (Exception e) { e.printStackTrace(); }
	}
}
