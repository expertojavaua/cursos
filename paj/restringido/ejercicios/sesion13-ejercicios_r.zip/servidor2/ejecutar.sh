export CLASSPATH=./interfaz.jar:.
rmiregistry $1 &
java -Djava.security.policy=java.policy ServidorVeces $1
