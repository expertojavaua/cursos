export CLASSPATH=./interfaz.jar:.
javac ServidorVeces.java
rmic -d . ServidorVeces
