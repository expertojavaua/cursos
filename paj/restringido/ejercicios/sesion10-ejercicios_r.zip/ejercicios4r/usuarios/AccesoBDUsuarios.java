package usuarios;

import java.io.*;
import java.util.*;
import java.sql.*;

/**
  * La clase <code>AccesoBDUsuarios</code> accede a los datos de los usuarios en una
  * BD MySQL.
  */
public class AccesoBDUsuarios implements AccesoUsuarios 
{
	// Objetos para la conexi�n a la BD y ejecucion de sentencias

	Connection con;
	Statement stmt;

	/** 
	  * Crea un nuevo objeto <code>AccesoBDUsuarios</code> estableciendo la conexi�n
	  * a la BD de usuarios
	  */
	public AccesoBDUsuarios() 
	{
		try {
			Class.forName("org.gjt.mm.mysql.Driver");
			con = DriverManager.getConnection( "jdbc:mysql://localhost/paj", null, null);
			stmt = con.createStatement();	
		} catch(Exception e) {
			e.printStackTrace();
		}		
	}

	/**
	  * Comprueba si el login y el password son validos (est�n en la BD)
	  * @param login Login del usuario a validar
	  * @param password Password a validar
	  * @return true si el login y password son correctos, o false en otro caso.
	  */
	public boolean valida(String login, String password) 
	{
		String query = "SELECT * FROM usuarios WHERE login='" + login.trim() + 
				"' AND password='" + password.trim() + "'";

		try {
			ResultSet rs = stmt.executeQuery(query);

			if(rs.next()) {
				return true;
			} else {
				return false;
			}
		} catch(SQLException e) {
			System.err.println(e.getMessage());
			return false;
		}

	}

	/**
	  * A�ade un nuevo usuario (login y password) a la BD de usuarios
	  * @param login Login del usuario a registrar
	  * @param password Password del usuario a registrar
	  */
	public void registra(String login, String password) throws LoginInvalidoException 
	{
		Usuario aux = busca(login);

		if(aux!=null) 
		{
			throw new LoginInvalidoException("El usuario " + 
						aux.login + " ya esta registrado");
		}
		if(login.trim().equals("")) {
			throw new LoginInvalidoException("El login no puede estar vacio");
		}

		String insert = "INSERT INTO usuarios(login, password) VALUES('" + 
					login.trim() + "', '" + password.trim() + "')";
	
		/* Ejecutar sentencia de insercion */

		try {
			stmt.executeUpdate(insert);
		} catch(SQLException e) {
			throw new LoginInvalidoException("Error al insertar usuario en la BD");
		}
	}

	// ---------------------------------------------------------------------------------
	//  Busca un determinado login en el Vector de usuarios
	// ---------------------------------------------------------------------------------

	private Usuario busca(String login) {
		Usuario aux = null;

		String query = "SELECT * FROM usuarios WHERE login='" + login.trim() + "'";

		try {
			ResultSet rs = stmt.executeQuery(query);
	
			if(rs.next()) {
				return new Usuario(rs.getString("login"), rs.getString("password"));
			} else {
				return null;
			}
		} catch(SQLException e) {
			System.err.println(e.getMessage());
			return null;
		}
	}

	// ---------------------------------------------------------------------------------
	//  Clase que encapsula los datos de los usuarios
	// ---------------------------------------------------------------------------------

	class Usuario {
		public String login;
		public String password;

		public Usuario(String login, String password) {
			this.login = login;
			this.password = password;
		}
	}
}