package usuarios;

public class LoginInvalidoException extends Exception {

	public LoginInvalidoException(String msg) {
		super(msg);
	}

}