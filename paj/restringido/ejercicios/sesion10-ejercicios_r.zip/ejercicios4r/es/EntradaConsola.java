package es;

import java.io.*;

public class EntradaConsola 
{

	BufferedReader in;

	public EntradaConsola() {
		in = new BufferedReader( new InputStreamReader( System.in ) );
	}

	public String promptLine(String message) {
		System.out.print(message);
		return readLine();
	}

	public String readLine() {
		try {
			return in.readLine();
		} catch(IOException e) {
			return null;
		}
	}

}