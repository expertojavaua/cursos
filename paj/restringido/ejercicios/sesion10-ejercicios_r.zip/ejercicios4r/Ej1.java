
import java.sql.*;

public class Ej1 {

	Connection con;

	public Ej1() {


		try {
			Class.forName("org.gjt.mm.mysql.Driver");
		} catch(ClassNotFoundException e1) {
			System.err.println("No se encuentra el driver");
			System.exit(1);
		}

		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost/paj", null, null);
		} catch(SQLException e1) {
			System.err.println("Error al conectar a la BD");
			System.exit(1);
		}

		listaUsuarios();

	}

	private void listaUsuarios() {

		String query = "SELECT * FROM usuarios";

		/* Ejecutar query y mostrar resultados */

		try {
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(query);

			while(rs.next()) {
				System.out.println("Login: " + rs.getString("login") +
						", Password: " + rs.getString("password"));
			}
		} catch(SQLException e) {
			System.err.println(e.getMessage());
			System.exit(1);
		}
	}

	public static void main(String [] args) {

		new Ej1();

	}
}