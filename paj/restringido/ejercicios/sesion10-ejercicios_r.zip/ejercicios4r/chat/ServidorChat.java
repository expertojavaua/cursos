package chat;

import java.io.*;
import java.net.*;
import java.util.Vector;
import usuarios.*;
import es.*;

/**
  * La clase <code>ServidorChat</code> implementa un servidor para una aplicaci�n de chat.
  */
public class ServidorChat {

	// Tipos de mensajes que acepta y envia el servidor

	public static final String CMD_LOGIN = "LOGIN";

	public static final String CMD_REG = "REG";

	public static final String RES_OK = "OK";

	public static final String RES_ERROR = "ERROR";

	// Fichero con los datos de los usuarios

	public static final String FICHERO_USUARIOS = "datos" + File.separator + "usuarios";

	// Puerto en el que atiende el servidor

	public static final int PUERTO_CHAT = 4444;

	// Lista de usuarios conectados al servidor

	private Vector conexiones;

	// Objeto utilizado para el acceso a los datos de los usuarios

	private AccesoUsuarios usuarios;

	/**
	  * Construye un nuevo objeto <code>ServidorChat</code>
	  */
	public ServidorChat() {

		conexiones = new Vector();

		usuarios = new AccesoBDUsuarios();

		try {
			ServerSocket server_socket = new ServerSocket(PUERTO_CHAT);
			Socket sock;
			Thread t;

			/* Acepta peticiones de los cliente y crea y ejecuta un HiloServidor para atender cada una de ellas */

			while(true) {
				sock = server_socket.accept();
				t = new HiloServidor(sock);
				t.start();
			}

		} catch(IOException e2) {
			System.err.println("Error en la E/S");
			System.exit(1);
		}

	}

	/**
	  * Difunde un mensaje a todos los clientes conectados
	  * @param msg Mensaje a difundir
	  */
	public void difunde(String msg) {
		HiloServidor hs = null;

		for(int i=0;i<conexiones.size();i++) {
			hs = (HiloServidor)conexiones.elementAt(i);

			hs.envia(msg);
		}
	}

	/** 
	  * A�ade un nuevo cliente a la lista de cliente conectados
	  * @param hs Hilo que atiende al cliente
	  */
	public void agregaCliente(HiloServidor hs) {
		conexiones.addElement(hs);
	}

	/**
	  * Elimina un usuario que se desconecta del chat
	  * @param hs Hilo que atiende al cliente
	  */
	public void eliminaCliente(HiloServidor hs) {
		conexiones.removeElement(hs);
	}

	/**
	  * M�todo principal, que ejecuta el servidor de chat
	  * @param args Parametros proporcionados en la linea de comando
	  */
	public static void main(String [] args) {
		new ServidorChat();
	}

	/**
	  * Hilo encargado de atende a cada cliente
	  */
	class HiloServidor extends Thread {

		// Socket de conexi�n con el cliente
		ConexionSocket socket;

		// Nick del usuario conectado
		String nick;

		/** 
		  * Construye un objeto <code>HiloServidor</code> para atender a un cliente
		  * @param sock Socket que mantiene la conexi�n con el cliente
		  */
		public HiloServidor(Socket sock) throws IOException {
			socket = new ConexionSocket(sock);
		}

		/**
		  * Codigo para atender al cliente
		  */
		public void run() {
			String msg = null;

			// Fase de registro

			try {
				nick = registroUsuario();
				if(nick == null) 
					return;
			} catch(Exception e1) {
				return;
			}

			// Fase de chat

			agregaCliente(this);
			System.out.println("Conectado <" + nick + ">");

			try {
				while( (msg = socket.recibe()) != null) {
					difunde("<" + nick + "> " + msg);
				}
			} catch(Exception e2) {
			} finally {
				eliminaCliente(this);
				System.out.println("Desconectado <" + nick + ">");
			}
		}

		/**
		  * Se comunica con el cliente en la fase de registro
		  * @return Nick del usuario conectado, o null si no llega a entrar al chat
		  */
		private String registroUsuario() throws IOException {

			String login, password, msg;

			while(true)
			{
				msg = socket.recibe();

				if(msg==null)
					return null;

				if(msg.equals(CMD_LOGIN)) {
					login = socket.recibe();
					password = socket.recibe();
	
					if(usuarios.valida(login,password)) {
						socket.envia(RES_OK);
						return login;
					} else {
						socket.envia(RES_ERROR);
						socket.envia("Login y password no validos");
					}
	
				} else if(msg.equals(CMD_REG)) {
					login = socket.recibe();
					password = socket.recibe();
	
					try {
						usuarios.registra(login,password);
						socket.envia(RES_OK);
					} catch(LoginInvalidoException e) {
						socket.envia(RES_ERROR);
						socket.envia(e.getMessage());
					}
				}
			}
		}

		/** 
	 	  * Envia un mensaje al usuario que atiende este hilo
		  * @param msg Mensaje a enviar al usuario
		  */
		public void envia(String msg) {
			socket.envia(msg);
		}
	}
}
