/**
  * Ejemplo que muestra un texto por pantalla
  */
public class Ejemplo1
{
   public static void main(String[] args)
   {
      System.out.println ("Mi programa Java");
   }
}
