/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package es.ua.jtech.ssl.multas.dao;

/**
 *
 * @author malozano
 */
public class GestorDAO {

    public IMultasDAO getMultasDAO() {
        return new MemoryMultasDAO();
    }
}
