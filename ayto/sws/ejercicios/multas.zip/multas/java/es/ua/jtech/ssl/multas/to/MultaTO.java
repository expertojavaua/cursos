/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package es.ua.jtech.ssl.multas.to;

/**
 *
 * @author malozano
 */
public class MultaTO {

    public MultaTO(float importe, String descripcion) {
        this.importe = importe;
        this.descripcion = descripcion;
    }

    public MultaTO() {
        
    }

    float importe;
    String descripcion;

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public float getImporte() {
        return importe;
    }

    public void setImporte(float importe) {
        this.importe = importe;
    }

    
}
