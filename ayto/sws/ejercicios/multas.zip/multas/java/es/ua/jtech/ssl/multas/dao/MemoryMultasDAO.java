/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package es.ua.jtech.ssl.multas.dao;

import es.ua.jtech.ssl.multas.to.MultaTO;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 *
 * @author malozano
 */
public class MemoryMultasDAO implements IMultasDAO {

    static HashMap<String, List<MultaTO>> tablaMultas;
    static {
        tablaMultas = new HashMap<String, List<MultaTO>>();

        String nif0 = "00000000T";
        List<MultaTO> lista0 = new ArrayList<MultaTO>();
        lista0.add(new MultaTO(100.0f, "Sacar la basura fuera del horario"));
        lista0.add(new MultaTO(60.0f, "Tirar papeles"));
        lista0.add(new MultaTO(150.0f, "Estacionamiento en zona azul"));

        String nif1 = "11111111H";
        List<MultaTO> lista1 = new ArrayList<MultaTO>();
        lista1.add(new MultaTO(1000.0f, "Obras sin permiso"));

        tablaMultas.put(nif0, lista0);
        tablaMultas.put(nif1, lista1);
    }

    public List<MultaTO> getMultas(String nif) throws DAOException {
        return tablaMultas.get(nif);
    }

}
