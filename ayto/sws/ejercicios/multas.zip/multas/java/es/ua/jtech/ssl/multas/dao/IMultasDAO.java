/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package es.ua.jtech.ssl.multas.dao;

import es.ua.jtech.ssl.multas.to.MultaTO;
import java.util.List;

/**
 *
 * @author malozano
 */
public interface IMultasDAO {
    public List<MultaTO> getMultas(String nif) throws DAOException;
}
