package es.ua.jtech.cw.sesion04.chat.listener;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import es.ua.jtech.cw.sesion04.chat.to.ColaMensajes;

/**
 * Application Lifecycle Listener implementation class ListenerContexto
 *
 */
public class ListenerContexto implements ServletContextListener {

	/**
     * @see ServletContextListener#contextInitialized(ServletContextEvent)
     */
    public void contextInitialized(ServletContextEvent sce) {
    	ServletContext sc = sce.getServletContext();
    	ColaMensajes cm = new ColaMensajes();
    	sc.setAttribute("es.ua.jtech.cw.sesion04.chat.mensajes", cm);
    }

	/**
     * @see ServletContextListener#contextDestroyed(ServletContextEvent)
     */
    public void contextDestroyed(ServletContextEvent sce) {
    }
	
}
