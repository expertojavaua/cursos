package es.ua.jtech.cw.sesion04.chat;

import javax.servlet.*;
import javax.servlet.http.*;

import es.ua.jtech.cw.sesion04.chat.to.ColaMensajes;
import es.ua.jtech.cw.sesion04.chat.to.Mensaje;

import java.io.*;

public class ListaMensajesServlet extends HttpServlet {

	private static final long serialVersionUID = 427199619647569137L;

	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		HttpSession sesion = req.getSession();
		ServletContext sc = this.getServletContext();
		
		// A�adir cabecera para actualizar cada 5 segundos
		res.setHeader("Refresh", "5");
		res.setContentType("text/html");

		PrintWriter out = res.getWriter();
		
		// Incluir /chat/cabecera.htmlf
		RequestDispatcher rd = sc.getRequestDispatcher("/chat/cabecera.htmlf");
		rd.include(req, res);
		
		// Mostrar mensajes del chat
		String nick = (String)sesion.getAttribute("es.ua.jtech.cw.sesion04.chat.nick");
		
		ColaMensajes cm = (ColaMensajes)sc.getAttribute("es.ua.jtech.cw.sesion04.chat.mensajes");
		for(Mensaje m: cm) {
			if(m.getEmisor().equals(nick)) {
				out.println("<strong>&lt;" + m.getEmisor() + "&gt;</strong> " + m.getTexto() + "<br/>");				
			} else {
				out.println("&lt;" + m.getEmisor() + "&gt; " + m.getTexto() + "<br/>");								
			}
		}

		// Incluir /chat/pie.htmlf
		rd = sc.getRequestDispatcher("/chat/pie.htmlf");
		rd.include(req, res);
		
		out.flush();
		out.close();
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		doGet(req,res);
	}
}
