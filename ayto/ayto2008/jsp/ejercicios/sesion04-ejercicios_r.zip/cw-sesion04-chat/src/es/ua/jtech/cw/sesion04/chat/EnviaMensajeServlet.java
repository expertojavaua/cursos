package es.ua.jtech.cw.sesion04.chat;

import javax.servlet.*;
import javax.servlet.http.*;

import es.ua.jtech.cw.sesion04.chat.to.ColaMensajes;
import es.ua.jtech.cw.sesion04.chat.to.Mensaje;

import java.io.*;

public class EnviaMensajeServlet extends HttpServlet {

	private static final long serialVersionUID = -481257371131179080L;

	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		// Si no hay usuario, redireccionar a /chat/error.html
		HttpSession sesion = req.getSession();
		ServletContext sc = this.getServletContext();
		
		String nick = (String)sesion.getAttribute("es.ua.jtech.cw.sesion04.chat.nick");
		if(nick==null) {
			RequestDispatcher rd = sc.getRequestDispatcher("/chat/error.html");
			rd.forward(req, res);
			
			return;
		}
		
		// Agregar mensaje enviado a la cola de mensajes
		String texto = req.getParameter("texto");

		ColaMensajes cm = (ColaMensajes)sc.getAttribute("es.ua.jtech.cw.sesion04.chat.mensajes");
		cm.add(new Mensaje(nick, texto));
		
		// Redireccionar a /chat/enviaMensaje.html
		res.setContentType("text/html");
		
		RequestDispatcher rd = sc.getRequestDispatcher("/chat/enviaMensaje.html");
		rd.include(req, res);
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		doGet(req,res);
	}
}
