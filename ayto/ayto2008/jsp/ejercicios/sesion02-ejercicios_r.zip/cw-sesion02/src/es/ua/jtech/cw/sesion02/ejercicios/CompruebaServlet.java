package es.ua.jtech.cw.sesion02.ejercicios;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class CompruebaServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	static Log logger = LogFactory.getLog(CompruebaServlet.class);

	public CompruebaServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		logger.info("IP Remota: " + request.getRemoteAddr());
		logger.info("Metodo: " + request.getMethod());
		logger.info("Agente: " + request.getHeader("User-Agent"));
		
		String [] params = {"nick", "password", "email"};
		
		for(String param: params) {
			String valor = request.getParameter(param);
			if(valor==null || valor.trim().equals("")) {
				response.sendRedirect("ErrorCompruebaServlet");
				return;
			}
		}

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<p>Formulario validado correctamente</p>");
		out.flush();
		out.close();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}

}
