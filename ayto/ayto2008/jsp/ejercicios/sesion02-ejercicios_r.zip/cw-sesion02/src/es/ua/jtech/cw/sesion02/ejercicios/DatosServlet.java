package es.ua.jtech.cw.sesion02.ejercicios;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DatosServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public DatosServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		
		out.println("<html><head><title>Parametros de inicio</title></head>");
		out.println("<body><table>");
		out.println("<tr><th>Nombre</th><th>Valor</th></tr>");			
		
		Enumeration<String> e = request.getParameterNames();
		while(e.hasMoreElements()) {
			String param = e.nextElement();
			String valor = request.getParameter(param);
			
			out.println("<tr><td>" + param + "</td><td>" + valor + "</td></tr>");			
		}
		
		out.println("</table></body></html>");
		out.flush();
		out.close();

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {		// TODO Auto-generated method stub
		this.doGet(request, response);
	}

}
