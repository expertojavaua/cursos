package es.ua.jtech.cw.sesion02.ejercicios;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LibroServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	ArrayList<String> libros = new ArrayList<String>();

    public LibroServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String cadena = request.getParameter("cadena");
		
		response.setContentType("text/html");
		
		PrintWriter out = response.getWriter();
		for(String libro: libros) {
			if(libro.toLowerCase().indexOf(cadena.toLowerCase())!=-1) {
				out.println("<p>" + libro + "</p>");
			}
		}
		
		out.flush();
		out.close();
	}

	@Override
	public void init() throws ServletException {
		super.init();

		// Lee libros del fichero
		InputStream is = getClass().getResourceAsStream("/libros.txt");
		BufferedReader br = new BufferedReader(new InputStreamReader(is));
		String libro;
		try {
			while( (libro=br.readLine())!=null ) {
				libros.add(libro);
			}
		} catch (IOException e) { }

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}
}
