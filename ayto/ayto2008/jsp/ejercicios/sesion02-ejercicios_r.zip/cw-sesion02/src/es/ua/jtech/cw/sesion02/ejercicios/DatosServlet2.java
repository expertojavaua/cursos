package es.ua.jtech.cw.sesion02.ejercicios;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DatosServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public DatosServlet2() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String [] params = {"nombre", "apellidos", "email"};
		
		for(String param: params) {
			String valor = request.getParameter(param);
			if(valor==null || valor.trim().equals("")) {
				response.sendRedirect("form_datos2.html");
				return;
			}
		}
		
		response.sendRedirect("bienvenida.html");
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}

}
