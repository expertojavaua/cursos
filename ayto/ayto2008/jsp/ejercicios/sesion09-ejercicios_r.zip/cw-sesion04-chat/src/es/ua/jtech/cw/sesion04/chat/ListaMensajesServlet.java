package es.ua.jtech.cw.sesion04.chat;

import javax.servlet.*;
import javax.servlet.http.*;

import es.ua.jtech.cw.sesion04.chat.to.ColaMensajes;

import java.io.*;

public class ListaMensajesServlet extends HttpServlet {

	private static final long serialVersionUID = 427199619647569137L;

	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		ServletContext sc = this.getServletContext();
		
		ColaMensajes cm = (ColaMensajes)sc.getAttribute("es.ua.jtech.cw.sesion04.chat.mensajes");
		req.setAttribute("es.ua.jtech.cw.sesion05.chat.mensajes", cm);
		
		RequestDispatcher rd = sc.getRequestDispatcher("/jsp/listaMensajes.jsp");
		rd.forward(req, res);
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		doGet(req,res);
	}
}
