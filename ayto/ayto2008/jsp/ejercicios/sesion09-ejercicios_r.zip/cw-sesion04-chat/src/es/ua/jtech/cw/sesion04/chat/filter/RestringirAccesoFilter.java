package es.ua.jtech.cw.sesion04.chat.filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet Filter implementation class RestringirAccesoFilter
 */
public class RestringirAccesoFilter implements Filter {

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// Se intenta acceder a la zona restringida

		// Solo podemos comprobar la sesi�n en el caso de tener una petici�n
		// HTTP
		if (request instanceof HttpServletRequest
				&& response instanceof HttpServletResponse) {

			HttpServletRequest http_request = (HttpServletRequest) request;
			HttpServletResponse http_response = (HttpServletResponse) response;

			// *********** Comprobamos si el usuario se ha registrado
			// ***********
			// En nuestra aplicaci�n si el usuario se ha registrado habremos
			// establecido
			// el atributo usuario de la sesion al nombre del usuario, si no
			// ser� null.

			if (http_request.getSession().getAttribute("es.ua.jtech.cw.sesion04.chat.nick") != null) {
				// Continuamos de forma normal con la petici�n
				chain.doFilter(request, response);
			} else {
				// Redireccionamos a la p�gina de login
				http_response.sendRedirect(http_request.getContextPath() 
						+ "/index.html");
			}

		} else {
			// Si no es una petici�n HTTP simplemente procesamos la petici�n
			chain.doFilter(request, response);
		}
	}

	public void init(FilterConfig fConfig) throws ServletException {
	}

	public void destroy() {		
	}

}
