package es.ua.jtech.cw.sesion09.ranking.dao;

public class DAOException extends Exception {

	private static final long serialVersionUID = 3108924852583224320L;

	public DAOException(String msg, Throwable causa) {
		super(msg, causa);
		
	}

}
