package es.ua.jtech.cw.sesion09.ranking.servlet;

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

import es.ua.jtech.cw.sesion09.ranking.dao.DAOException;
import es.ua.jtech.cw.sesion09.ranking.dao.PaginasDAO;
import es.ua.jtech.cw.sesion09.ranking.to.PaginaTO;

public class RankingPaginasServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void doGet(HttpServletRequest request, HttpServletResponse response)
		throws IOException, ServletException {

		PaginasDAO dao = new PaginasDAO();
		
		ArrayList<PaginaTO> lista;
		try {
			lista = dao.listaPaginas();
		} catch (DAOException e) {
			lista = new ArrayList<PaginaTO>();
			this.getServletContext().log("Error en la BD: " + e.getMessage());
		}

		PrintWriter out = response.getWriter();

		out.println("<html><head><title>Ranking de paginas</title></head>");
		out.println("<body>");

		out.println("<table>");
		out.println("<tr>");
		out.println("<td><b>Ruta</b></td>");
		out.println("<td><b>Titulo</b></td>");
		out.println("<td><b>Accesos</b></td>");
		out.println("</tr>");

		for(PaginaTO pagina: lista) {
			out.println("<tr>");
			out.println("<td>" + pagina.getRuta() + "</td>");
			out.println("<td>" + pagina.getTitulo() + "</td>");
			out.println("<td>" + pagina.getAccesos() + "</td>");
			out.println("</tr>");
		}

		out.println("</table>");
		out.println("</body>");
		out.println("</html>");

		out.close();
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res)
		throws ServletException, IOException {
		doGet(req, res);
	}

	/**
	  * Destruye el servlet. Cierra conexin a base de datos
	  */

	public void destroy() {

	}

	/**
	  * Inicializa el servlet. Abre conexin a BD y lee par�etros.
	  * @param servletConfig Configuracin del servlet y de la aplicacin.
	  */

	public void init(ServletConfig servletConfig) throws ServletException {

	}

}
