package es.ua.jtech.cw.sesion04.chat;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class EnviaMensajeServlet extends HttpServlet {

	private static final long serialVersionUID = -481257371131179080L;

	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		// TODO: Si no hay usuario, redireccionar a /chat/error.html
		
		// TODO: Agregar mensaje enviado a la cola de mensajes
		
		// TODO: Redireccionar a /chat/enviaMensaje.html
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		doGet(req,res);
	}
}
