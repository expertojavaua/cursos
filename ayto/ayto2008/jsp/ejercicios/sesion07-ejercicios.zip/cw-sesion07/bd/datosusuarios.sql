DROP DATABASE IF EXISTS datosusuarios;
CREATE DATABASE datosusuarios;
USE datosusuarios;
CREATE TABLE usuarios(nombre varchar(100) NOT NULL, email varchar(100), login varchar(20), password varchar(20), telefono varchar(10), PRIMARY KEY (nombre));
INSERT INTO USUARIOS VALUES('Pepe','pepe@pepe.com','unlogin','unpassword','965123456')