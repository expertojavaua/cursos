package es.ua.jtech.cw.sesion04.chat;

import javax.servlet.*;
import javax.servlet.http.*;

import es.ua.jtech.cw.sesion04.chat.to.ColaMensajes;

import java.io.*;

public class ListaMensajesServlet extends HttpServlet {

	private static final long serialVersionUID = 427199619647569137L;

	public void doGet(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		ServletContext sc = this.getServletContext();
		String formato = req.getParameter("formato");

		ColaMensajes cm = (ColaMensajes)sc.getAttribute("es.ua.jtech.cw.sesion04.chat.mensajes");

		if(formato==null || formato.equals("0")) {
			req.setAttribute("es.ua.jtech.cw.sesion05.chat.mensajes", cm);
			RequestDispatcher rd = sc.getRequestDispatcher("/jsp/listaMensajes.jsp");
			rd.forward(req, res);			
		} else if(formato.equals("1")) {
			req.setAttribute("es.ua.jtech.cw.sesion05.chat.mensajes", cm);
			RequestDispatcher rd = sc.getRequestDispatcher("/jsp/listaMensajesXml.jsp");
			rd.forward(req, res);			
		} else if(formato.equals("2")) {
			res.setContentType("application/x-java-serialized-object");
			ObjectOutputStream oos = new ObjectOutputStream(res.getOutputStream());
			oos.writeObject(cm);
			oos.flush();
			oos.close();
		}
		
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res)
			throws ServletException, IOException
	{
		doGet(req,res);
	}
}
