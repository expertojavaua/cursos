package es.ua.jtech.cw.sesion01.ejercicios;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class FechaServlet extends HttpServlet
{
	private static final long serialVersionUID = -9004080270649416898L;

	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		// ...
	}
}