package es.ua.jtech.cw.sesion01.ejercicios;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// Ejemplo de servlet que genera texto plano

public class ServletLog4J2 extends HttpServlet
{
	private static final long serialVersionUID = 4466756963133948179L;

	// Metodo para procesar una peticion GET
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		PrintWriter out = response.getWriter();
		out.println ("Hola, este es un servlet sencillo de prueba para logging (2)");
	}
}