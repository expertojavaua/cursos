package es.ua.jtech.cw.sesion09.ranking.filter;

import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.ua.jtech.cw.sesion09.ranking.dao.DAOException;
import es.ua.jtech.cw.sesion09.ranking.dao.PaginasDAO;
import es.ua.jtech.cw.sesion09.ranking.parser.AnalisisHTML;
import es.ua.jtech.cw.sesion09.ranking.wrapper.GenericResponseWrapper;

public final class AccesoPaginaFilter implements Filter {

	private FilterConfig filterConfig = null;

	/**
	 * Efectua el filtrado de una peticin.
	 * 
	 * @param request
	 *            Peticin realizada al servidor
	 * @param response
	 *            Respuesta para enviar al cliente
	 * @param chain
	 *            Cadena de filtros para procesar la peticin
	 * @throws  
	 */

	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {

		// TODO: Si la pagina solicitada esta registrada, incrementa el numero de accesos

		// TODO: Si no, registra la pagina (ruta, titulo) en la base de datos
	}

	/**
	 * Destruye el filtro. Cierra conexin a base de datos
	 */

	public void destroy() {
		this.filterConfig = null;
	}

	/**
	 * Inicializa el filtro. Abre conexi�n a BD y lee par�metros.
	 * 
	 * @param filterConfig
	 *            Configuraci�n del filtro y de la aplicaci�n.
	 */

	public void init(FilterConfig filterConfig) throws ServletException {
		this.filterConfig = filterConfig;
	}

}
