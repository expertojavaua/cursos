package es.ua.jtech.cw.sesion09.ranking.dao;

import java.sql.*;

public class FuenteDatosJDBC {

	public static final String DB_DRIVER = "com.mysql.jdbc.Driver";
	public static final String DB_URL = "jdbc:mysql://localhost/ranking";
	public static final String DB_LOGIN = "root";
	public static final String DB_PASSWORD = "root";
	
	static FuenteDatosJDBC instance = null;
	
	String driver;
	String url;
	String login;
	String password;
	
	public FuenteDatosJDBC(String driver, String url, String login,
			String password) {
		this.driver = driver;
		this.url = url;
		this.login = login;
		this.password = password;
	}

	public Connection createConnection() throws SQLException, ClassNotFoundException {
		Class.forName(driver);
		return DriverManager.getConnection(url, login, password);
	}
	
	public static FuenteDatosJDBC getInstance() {
		if(instance!=null) {
			return instance;
		} else {
			return new FuenteDatosJDBC(DB_DRIVER, DB_URL, DB_LOGIN, DB_PASSWORD);
		}
	}
}
