package es.ua.jtech.cw.sesion09.ranking.dao;

import java.sql.*;
import java.util.*;

import es.ua.jtech.cw.sesion09.ranking.to.PaginaTO;


public class PaginasDAO {

	public PaginasDAO() {
	}

	public synchronized boolean estaRegistrada(String url) throws DAOException {
		Connection conn=null;
		String query = "SELECT * FROM paginas WHERE ruta='" + url + "'";
		boolean result = false;

		try {
			conn = FuenteDatosJDBC.getInstance().createConnection();
			Statement stmt = conn.createStatement();

			ResultSet rs = stmt.executeQuery(query);
			result = rs.next();
		} catch (Exception e) {
			throw new DAOException("Error al comprobar URL", e);
		} finally {
			try {
				conn.close();
			} catch(Exception e) {}
		}

		return result;
	}

	public synchronized void registraPagina(String url, String titulo) throws DAOException {
		Connection conn=null;
		String query =
			"INSERT INTO paginas(ruta, titulo, accesos) values('"
				+ url
				+ "', '"
				+ titulo
				+ "', 1)";

		try {
			conn = FuenteDatosJDBC.getInstance().createConnection();
			Statement stmt = conn.createStatement();

			stmt.executeUpdate(query);
		} catch (Exception e) {
			throw new DAOException("Error al registrar pagina", e);
		} finally {
			try {
				conn.close();
			} catch(Exception e) {}
		}
	}

	public synchronized void incrementaAccesos(String url) throws DAOException {
		Connection conn=null;
		String query =
			"UPDATE paginas SET accesos=accesos+1 WHERE ruta='" + url + "'";

		try {
			conn = FuenteDatosJDBC.getInstance().createConnection();
			Statement stmt = conn.createStatement();

			stmt.executeUpdate(query);
		} catch (Exception e) {
			throw new DAOException("Error al incrementar accesos", e);
		} finally {
			try {
				conn.close();
			} catch(Exception e) {}
		}
	}

	public synchronized ArrayList<PaginaTO> listaPaginas() throws DAOException {
		Connection conn=null;
		String query = "SELECT * FROM paginas ORDER BY accesos DESC";
		ArrayList<PaginaTO> lista = new ArrayList<PaginaTO>();

		String ruta, titulo;
		int accesos;
		PaginaTO pagina;

		try {
			conn = FuenteDatosJDBC.getInstance().createConnection();
			Statement stmt = conn.createStatement();
			
			ResultSet rs = stmt.executeQuery(query);

			while (rs.next()) {
				ruta = rs.getString("ruta");
				titulo = rs.getString("titulo");
				accesos = rs.getInt("accesos");

				pagina = new PaginaTO(ruta, titulo, accesos);
				lista.add(pagina);
			}
		} catch (Exception e) {
			throw new DAOException("Error al obtener listado de paginas", e);
		} finally {
			try {
				conn.close();
			} catch(Exception e) {}
		}

		return lista;
	}
}
