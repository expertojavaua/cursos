package es.ua.jtech.cw.sesion03.ejercicios;
import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;

public class PersonalizaServlet extends HttpServlet
{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String color = req.getParameter("color");
		String nombre = req.getParameter("nombre");
		
		Cookie cColor = new Cookie("color", color);
		Cookie cNombre = new Cookie("nombre", nombre);
		
		resp.addCookie(cColor);
		resp.addCookie(cNombre);
		
		resp.sendRedirect("form_pers.html");
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		this.doGet(req, resp);
	}
	
}