package es.ua.jtech.cw.sesion03.ejercicios;
import java.io.*;

import javax.servlet.*;
import javax.servlet.http.*;

public class PrincipalServlet extends HttpServlet
{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String color=null;
		String nombre=null;
		
		Cookie [] cookies = req.getCookies();
		for(Cookie cookie: cookies) {
			if(cookie.getName().equals("color")) {
				color = cookie.getValue();
			} else if(cookie.getName().equals("nombre")) {
				nombre = cookie.getValue();
			}
		}

		if(color==null) {
			color="white";
		}
		if(nombre==null) {
			nombre = "desconocido";
		}
		
		PrintWriter out = resp.getWriter();
		out.println("<html><head><title>Pagina personalizada</title></head>");
		out.println("<body bgcolor='" + color + "'><h1>Hola " + nombre + "</h1></body></html>");
		out.flush();
		out.close();
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		this.doGet(req, resp);
	}

}