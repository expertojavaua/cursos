package es.ua.jtech.cw.sesion03.ejercicios;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.*;
import javax.servlet.http.*;

public class CarroServlet extends HttpServlet
{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String articulo = req.getParameter("articulo");
		int precio = Integer.parseInt(req.getParameter("precio"));
		
		HttpSession sesion = req.getSession();

		List<ObjetoCarro> lista = (List<ObjetoCarro>)sesion.getAttribute("lista");;		
		if(lista==null) {
			lista = new ArrayList<ObjetoCarro>();
			sesion.setAttribute("lista", lista);
		}

		lista.add(new ObjetoCarro(articulo, precio));
		
		PrintWriter out = resp.getWriter();
		out.println("<html><body><table>");
		out.println("<tr><th>Articulo</th><th>Precio</th></tr>");
		int total = 0;
		
		for(ObjetoCarro oc: lista) {
			out.println("<tr><td>" + oc.getArticulo() + "</td><td>" + oc.getPrecio() + "</td></tr>");
			total += oc.getPrecio();
		}
		out.println("</table><p><strong>Total: " + total + "</strong></p>");
		out.println("<a href='form_carro.html'>Seguir comprando</a></body></html>");
		out.flush();
		out.close();
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		this.doGet(req, resp);
	}

	class ObjetoCarro
	{
		private String articulo;
		private int precio;

		public ObjetoCarro(String articulo, int precio)
		{
			this.articulo = articulo;
			this.precio = precio;
		}

		public String getArticulo()
		{
			return articulo;
		}

		public int getPrecio()
		{
			return precio;
		}
	}
}