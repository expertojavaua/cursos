package es.ua.jtech.cw.sesion01.ejercicios;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ParamIniServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public ParamIniServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ServletConfig sc = this.getServletConfig();
		
		PrintWriter out = response.getWriter();
		
		out.println("<html><head><title>Parametros de inicio</title></head>");
		out.println("<body><table>");
		out.println("<tr><th>Nombre</th><th>Valor</th></tr>");			
		
		Enumeration nombres = sc.getInitParameterNames();
		while (nombres.hasMoreElements())
		{
			String nombre = (String)(nombres.nextElement());
			String valor = sc.getInitParameter(nombre);
			out.println("<tr><td>" + nombre + "</td><td>" + valor + "</td></tr>");			
		}
		
		out.println("</table></body></html>");
		out.flush();
		out.close();
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}

}
