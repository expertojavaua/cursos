/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package es.ua.jtech.servcweb.vuelos.dao;

import es.ua.jtech.servcweb.vuelos.jpa.Reserva;
import es.ua.jtech.servcweb.vuelos.jpa.Vuelo;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author Miguel Angel
 */
public class VuelosDAO {

    private static final String PERSISTENCE_UNIT = "servcweb-sesion03-vuelosPU";
    
    public Vuelo getVuelo(int id) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT);
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        Vuelo v = em.find(Vuelo.class, id);
        em.getTransaction().commit();
        em.close();
        emf.close();

        return v;
    }

    public boolean realizaReserva(int vuelo, String nif, String nombre) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT);
        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        try {
            Vuelo v = em.find(Vuelo.class, vuelo);
            if (v != null && v.getDisponibles() > 0) {
                Reserva r = new Reserva();
                r.setNif(nif);
                r.setNombre(nombre);
                r.setVueloId(v);
                v.getReservasCollection().add(r);
                v.setDisponibles(v.getDisponibles() - 1);

                return true;
            }
        } finally {
            em.getTransaction().commit();
            em.close();
            emf.close();
        }
        return false;
    }
}
