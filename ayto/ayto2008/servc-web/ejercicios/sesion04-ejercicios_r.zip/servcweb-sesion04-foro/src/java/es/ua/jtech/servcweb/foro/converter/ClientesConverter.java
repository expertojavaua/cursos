/*
 *  ClientesConverter
 *
 * Created on 13 de mayo de 2008, 17:30
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package es.ua.jtech.servcweb.foro.converter;

import es.ua.jtech.servcweb.foro.jpa.Cliente;
import java.net.URI;
import java.util.Collection;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlAttribute;
import java.util.ArrayList;


/**
 *
 * @author Miguel Angel
 */

@XmlRootElement(name = "clientes")
public class ClientesConverter {
    private Collection<Cliente> entities;
    private Collection<ClienteRefConverter> references;
    private URI uri;
    
    /** Creates a new instance of ClientesConverter */
    public ClientesConverter() {
    }

    /**
     * Creates a new instance of ClientesConverter.
     *
     * @param entities associated entities
     * @param uri associated uri
     */
    public ClientesConverter(Collection<Cliente> entities, URI uri) {
        this.entities = entities;
        this.uri = uri;
    }

    /**
     * Returns a collection of ClienteRefConverter.
     *
     * @return a collection of ClienteRefConverter
     */
    @XmlElement(name = "clienteRef")
    public Collection<ClienteRefConverter> getReferences() {
        references = new ArrayList<ClienteRefConverter>();
        if (entities != null) {
            for (Cliente entity : entities) {
                references.add(new ClienteRefConverter(entity, uri, true));
            }
        }
        return references;
    }

    /**
     * Sets a collection of ClienteRefConverter.
     *
     * @param a collection of ClienteRefConverter to set
     */
    public void setReferences(Collection<ClienteRefConverter> references) {
        this.references = references;
    }

    /**
     * Returns the URI associated with this converter.
     *
     * @return the uri
     */
    @XmlAttribute(name = "uri")
    public URI getResourceUri() {
        return uri;
    }

    /**
     * Returns a collection Cliente entities.
     *
     * @return a collection of Cliente entities
     */
    @XmlTransient
    public Collection<Cliente> getEntities() {
        entities = new ArrayList<Cliente>();
        if (references != null) {
            for (ClienteRefConverter ref : references) {
                entities.add(ref.getEntity());
            }
        }
        return entities;
    }
}
