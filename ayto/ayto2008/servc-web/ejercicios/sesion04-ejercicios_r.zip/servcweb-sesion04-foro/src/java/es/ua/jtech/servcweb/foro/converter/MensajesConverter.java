/*
 *  MensajesConverter
 *
 * Created on 13 de mayo de 2008, 17:30
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package es.ua.jtech.servcweb.foro.converter;

import es.ua.jtech.servcweb.foro.jpa.Mensaje;
import java.net.URI;
import java.util.Collection;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlAttribute;
import java.util.ArrayList;


/**
 *
 * @author Miguel Angel
 */

@XmlRootElement(name = "mensajes")
public class MensajesConverter {
    private Collection<Mensaje> entities;
    private Collection<MensajeRefConverter> references;
    private URI uri;
    
    /** Creates a new instance of MensajesConverter */
    public MensajesConverter() {
    }

    /**
     * Creates a new instance of MensajesConverter.
     *
     * @param entities associated entities
     * @param uri associated uri
     */
    public MensajesConverter(Collection<Mensaje> entities, URI uri) {
        this.entities = entities;
        this.uri = uri;
    }

    /**
     * Returns a collection of MensajeRefConverter.
     *
     * @return a collection of MensajeRefConverter
     */
    @XmlElement(name = "mensajeRef")
    public Collection<MensajeRefConverter> getReferences() {
        references = new ArrayList<MensajeRefConverter>();
        if (entities != null) {
            for (Mensaje entity : entities) {
                references.add(new MensajeRefConverter(entity, uri, true));
            }
        }
        return references;
    }

    /**
     * Sets a collection of MensajeRefConverter.
     *
     * @param a collection of MensajeRefConverter to set
     */
    public void setReferences(Collection<MensajeRefConverter> references) {
        this.references = references;
    }

    /**
     * Returns the URI associated with this converter.
     *
     * @return the uri
     */
    @XmlAttribute(name = "uri")
    public URI getResourceUri() {
        return uri;
    }

    /**
     * Returns a collection Mensaje entities.
     *
     * @return a collection of Mensaje entities
     */
    @XmlTransient
    public Collection<Mensaje> getEntities() {
        entities = new ArrayList<Mensaje>();
        if (references != null) {
            for (MensajeRefConverter ref : references) {
                entities.add(ref.getEntity());
            }
        }
        return entities;
    }
}
