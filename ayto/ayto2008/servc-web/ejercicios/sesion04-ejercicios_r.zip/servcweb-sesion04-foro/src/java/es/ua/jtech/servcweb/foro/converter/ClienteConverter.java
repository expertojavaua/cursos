/*
 *  ClienteConverter
 *
 * Created on 13 de mayo de 2008, 17:30
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package es.ua.jtech.servcweb.foro.converter;

import es.ua.jtech.servcweb.foro.jpa.Cliente;
import java.net.URI;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlAttribute;


/**
 *
 * @author Miguel Angel
 */

@XmlRootElement(name = "cliente")
public class ClienteConverter {
    private Cliente entity;
    private URI uri;
    
    /** Creates a new instance of ClienteConverter */
    public ClienteConverter() {
        entity = new Cliente();
    }

    /**
     * Creates a new instance of ClienteConverter.
     *
     * @param entity associated entity
     * @param uri associated uri
     */
    public ClienteConverter(Cliente entity, URI uri) {
        this.entity = entity;
        this.uri = uri;
    }

    /**
     * Getter for id.
     *
     * @return value for id
     */
    @XmlElement
    public Integer getId() {
        return entity.getId();
    }

    /**
     * Setter for id.
     *
     * @param value the value to set
     */
    public void setId(Integer value) {
        entity.setId(value);
    }

    /**
     * Getter for nombre.
     *
     * @return value for nombre
     */
    @XmlElement
    public String getNombre() {
        return entity.getNombre();
    }

    /**
     * Setter for nombre.
     *
     * @param value the value to set
     */
    public void setNombre(String value) {
        entity.setNombre(value);
    }

    /**
     * Getter for email.
     *
     * @return value for email
     */
    @XmlElement
    public String getEmail() {
        return entity.getEmail();
    }

    /**
     * Setter for email.
     *
     * @param value the value to set
     */
    public void setEmail(String value) {
        entity.setEmail(value);
    }

    /**
     * Getter for direccion.
     *
     * @return value for direccion
     */
    @XmlElement
    public String getDireccion() {
        return entity.getDireccion();
    }

    /**
     * Setter for direccion.
     *
     * @param value the value to set
     */
    public void setDireccion(String value) {
        entity.setDireccion(value);
    }

    /**
     * Getter for mensajeCollection.
     *
     * @return value for mensajeCollection
     */
    @XmlElement(name = "mensajes")
    public MensajesConverter getMensajeCollection() {
        if (entity.getMensajeCollection() != null) {
            return new MensajesConverter(entity.getMensajeCollection(), uri.resolve("mensajes/"));
        }
        return null;
    }

    /**
     * Setter for mensajeCollection.
     *
     * @param value the value to set
     */
    public void setMensajeCollection(MensajesConverter value) {
        if (value != null) {
            entity.setMensajeCollection(value.getEntities());
        }
    }

    /**
     * Returns the URI associated with this converter.
     *
     * @return the uri
     */
    @XmlAttribute(name = "uri")
    public URI getResourceUri() {
        return uri;
    }

    /**
     * Returns the Cliente entity.
     *
     * @return an entity
     */
    @XmlTransient
    public Cliente getEntity() {
        return entity;
    }

    /**
     * Sets the Cliente entity.
     *
     * @param entity to set
     */
    public void setEntity(Cliente entity) {
        this.entity = entity;
    }

    /**
     * Returns reference to GoogleMapResource resource.
     */
    @XmlElement(name = "googleMapRef")
    public GenericRefConverter getGoogleMapRef() {
        return new GenericRefConverter(uri.resolve("googleMap/"));
    }
}
