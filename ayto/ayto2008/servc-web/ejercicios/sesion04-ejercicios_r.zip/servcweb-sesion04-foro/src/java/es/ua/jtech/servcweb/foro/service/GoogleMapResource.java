/*
 * GoogleMapResource.java
 *
 * Created on 13 de mayo de 2008, 17:31
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package es.ua.jtech.servcweb.foro.service;
import javax.ws.rs.ProduceMime;
import javax.ws.rs.DefaultValue;
import javax.ws.rs.QueryParam;
import java.io.IOException;
import java.net.URLEncoder;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.Path;
import javax.ws.rs.GET;


/**
 * GoogleMap Resource
 *
 * @author Miguel Angel
 */
@Path("googleMap/")
public class GoogleMapResource {
    private Integer zoom;
    private String address;
    private String apiKey;
    
    /**
     * Returns HTML text to access GoogleMap API.
     * @param address address string to generate map for.
     */
    public String execute(String key, String address, Integer zoom) {
        try {
            String encoded = URLEncoder.encode(address, "UTF-8");
            GeoCoder coder = new GeoCoder(encoded, key);
            GeoCode code = coder.invoke();
            
            String mapRep =
                    "<!DOCTYPE html PUBLIC '-//W3C//DTD XHTML 1.0 Strict//EN'\n"+
                    "  'http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd'>\n"+
                    "<html xmlns='http://www.w3.org/1999/xhtml'>\n"+
                    "  <head>\n"+
                    "    <meta http-equiv='content-type' content='text/html; charset=utf-8'/>\n"+
                    "    <title>Google Maps JavaScript API Example</title>\n"+
                    "    <script src='http://maps.google.com/maps?file=api&amp;v=2&amp;key="+key+"'\n"+
                    "      type='text/javascript'></script>\n"+
                    "    <script type='text/javascript'>\n"+
                    "    //<![CDATA[\n"+
                    "    function load() {\n"+
                    "      if (GBrowserIsCompatible()) {\n"+
                    "        var map = new GMap2(document.getElementById('map'));\n"+
                    "        var point = new GLatLng("+code.getLatitude()+", "+code.getLongitude()+");\n"+
                    "        map.addControl(new GSmallMapControl());\n"+
                    "        map.addControl(new GMapTypeControl());\n"+
                    "        map.setCenter(point, " + zoom + ");\n"+
                    "        var marker = createMarker(point);\n"+
                    "        map.addOverlay(marker);\n"+
                    "        marker.openInfoWindowHtml(\"" + address + "\");\n"+
                    "      }\n"+
                    "    }\n"+
                    "    function createMarker(point) {\n" +
                    "      var marker = new GMarker(point);\n"+
                    "      GEvent.addListener(marker, \"click\", function() {\n"+
                    "         marker.openInfoWindowHtml(\"" + address + "\");\n"+
                    "      });\n"+
                    "      return marker;\n"+
                    "    }\n"+
                    "    //]]>\n"+
                    "    </script>\n"+
                    "  </head>\n"+
                    "  <body onload='load()' onunload='GUnload()'>\n"+
                    "    <div id='map' style='width: 500px; height: 300px'></div>\n"+
                    "  </body>\n"+
                    "</html>";
            return mapRep;
        } catch (IOException ex) {
            throw new WebApplicationException(ex);
        }
    }
    
    public static class GeoCoder {
        
        public final static String GEOCODE_URL = "http://maps.google.com/maps/geo";
        private String location;
        private String key;
        
        /** Creates a new instance of GeoCoder */
        public GeoCoder(String location, String key) {
            this.location = location;
            this.key = key;
        }
        
        /**
         *
         * @return geocode
         */
        public GeoCode invoke() throws IOException {
            RestConnection cl = new RestConnection();
            
            String[][] params = new String[][] {
                {"q", location},
                {"output", "xml"},
                {"key", key}
            };
            String codeStr = cl.connect(GEOCODE_URL, params);
            return new GeoCode(codeStr);
        }
    }
    
    public static class GeoCode {
        
        private double longitude ;
        private double latitude;
        
        /** Creates a new instance of GeoCode */
        public GeoCode(String xmlStr) {
            int ts = xmlStr.indexOf("<coordinates>");
            int te = xmlStr.indexOf("</coordinates>");
            String codeStr = "";
            if(ts != -1 && te != -1)
                codeStr = xmlStr.substring(ts+13, te);
            String[] codes = codeStr.split(",");
            if(codes.length>1) {
                this.longitude = Double.parseDouble(codes[0]);
                this.latitude = Double.parseDouble(codes[1]);
            }
        }
        
        /**
         *
         * @return longitude
         */
        public double getLongitude() {
            return this.longitude;
        }
        
        /**
         *
         * @return latitude
         */
        public double getLatitude() {
            return this.latitude;
        }
        
    }

    public GoogleMapResource(String apiKey, String address, Integer zoom) {
        if (apiKey != null) {
            this.apiKey = apiKey;
        }
        if (address != null) {
            this.address = address;
        }
        if (zoom != null) {
            this.zoom = zoom;
        }
    }

    /**
     * Retrieves representation of an instance of es.ua.jtech.servcweb.foro.service.GoogleMapResource
     * @param apiKey resource URI parameter
     * @param address resource URI parameter
     * @param zoom resource URI parameter
     * @return an instance of java.lang.String
     */
    @GET
    @ProduceMime("text/html")
    public String getHtml(@QueryParam("apiKey")
    @DefaultValue("ABQIAAAA4Yag3Up7Ofp9wZoQKluFcxTwM0brOpm-All5BF6PoaKBxRWWERTKWy17fvtjOUmhdiYgaCHqc6BZUw")
    String apiKey, @QueryParam("address")
    @DefaultValue("16 Network Circle, Menlo Park")
    String address, @QueryParam("zoom")
    @DefaultValue("15")
    Integer zoom) {
        if (this.apiKey != null) {
            apiKey = this.apiKey;
        }
        if (this.address != null) {
            address = this.address;
        }
        if (this.zoom != null) {
            zoom = this.zoom;
        }
        return execute(apiKey, address, zoom);
    }
}
