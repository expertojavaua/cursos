/*
 *  MensajeRefConverter
 *
 * Created on 13 de mayo de 2008, 17:30
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package es.ua.jtech.servcweb.foro.converter;

import es.ua.jtech.servcweb.foro.jpa.Mensaje;
import java.net.URI;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlAttribute;
import javax.ws.rs.core.UriBuilder;


/**
 *
 * @author Miguel Angel
 */

@XmlRootElement(name = "mensajeRef")
public class MensajeRefConverter {
    private Mensaje entity;
    private boolean isUriExtendable;
    private URI uri;
    
    /** Creates a new instance of MensajeRefConverter */
    public MensajeRefConverter() {
    }

    /**
     * Creates a new instance of MensajeRefConverter.
     *
     * @param entity associated entity
     * @param uri associated uri
     * @param isUriExtendable indicates whether the uri can be extended
     */
    public MensajeRefConverter(Mensaje entity, URI uri, boolean isUriExtendable) {
        this.entity = entity;
        this.uri = uri;
        this.isUriExtendable = isUriExtendable;
    }

    /**
     * Getter for id.
     *
     * @return value for id
     */
    @XmlElement
    public Integer getId() {
        return entity.getId();
    }

    /**
     * Returns the URI associated with this reference converter.
     *
     * @return the converted uri
     */
    @XmlAttribute(name = "uri")
    public URI getResourceUri() {
        if (isUriExtendable) {
            return UriBuilder.fromUri(uri).path(entity.getId() + "/").build();
        }
        return uri;
    }

    /**
     * Sets the URI for this reference converter.
     *
     */
    public void setResourceUri(URI uri) {
        this.uri = uri;
    }

    /**
     * Returns the Mensaje entity.
     *
     * @return Mensaje entity
     */
    @XmlTransient
    public Mensaje getEntity() {
        MensajeConverter result = UriResolver.getInstance().resolve(MensajeConverter.class, uri);
        if (result != null) {
            return result.getEntity();
        }
        return null;
    }
}
