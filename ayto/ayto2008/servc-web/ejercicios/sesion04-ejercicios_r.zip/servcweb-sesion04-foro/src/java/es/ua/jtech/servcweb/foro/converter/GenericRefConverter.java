/*
 * RefConverter.java
 *
 * Created on 13 de mayo de 2008, 17:31
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package es.ua.jtech.servcweb.foro.converter;

import java.net.URI;
import javax.xml.bind.annotation.XmlAttribute;

/**
 * Converter class for reference.
 *
 * @author Miguel Angel
 */

public class GenericRefConverter {
    
    private URI uri;
    
    public GenericRefConverter() {
    }
    
    /**
     * Creates a new instance of ZipInfoRefConverter.
     *
     * @param uri associated uri
     */
    
    public GenericRefConverter(URI uri) {
        this.uri = uri;
    }
    
    /**
     * Returns the URI associated with this reference converter.
     *
     * @return the converted uri
     */
    @XmlAttribute
    public URI getUri() {
        return uri;
    }
    
    /**
     * Sets the URI for this reference converter.
     *
     */
    
    public void setUri(URI uri) {
        this.uri = uri;
    }
}
