/*
 *  MensajeConverter
 *
 * Created on 13 de mayo de 2008, 17:30
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package es.ua.jtech.servcweb.foro.converter;

import es.ua.jtech.servcweb.foro.jpa.Mensaje;
import java.net.URI;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;
import javax.xml.bind.annotation.XmlAttribute;


/**
 *
 * @author Miguel Angel
 */

@XmlRootElement(name = "mensaje")
public class MensajeConverter {
    private Mensaje entity;
    private URI uri;
    
    /** Creates a new instance of MensajeConverter */
    public MensajeConverter() {
        entity = new Mensaje();
    }

    /**
     * Creates a new instance of MensajeConverter.
     *
     * @param entity associated entity
     * @param uri associated uri
     */
    public MensajeConverter(Mensaje entity, URI uri) {
        this.entity = entity;
        this.uri = uri;
    }

    /**
     * Getter for id.
     *
     * @return value for id
     */
    @XmlElement
    public Integer getId() {
        return entity.getId();
    }

    /**
     * Setter for id.
     *
     * @param value the value to set
     */
    public void setId(Integer value) {
        entity.setId(value);
    }

    /**
     * Getter for asunto.
     *
     * @return value for asunto
     */
    @XmlElement
    public String getAsunto() {
        return entity.getAsunto();
    }

    /**
     * Setter for asunto.
     *
     * @param value the value to set
     */
    public void setAsunto(String value) {
        entity.setAsunto(value);
    }

    /**
     * Getter for texto.
     *
     * @return value for texto
     */
    @XmlElement
    public String getTexto() {
        return entity.getTexto();
    }

    /**
     * Setter for texto.
     *
     * @param value the value to set
     */
    public void setTexto(String value) {
        entity.setTexto(value);
    }

    /**
     * Getter for clienteId.
     *
     * @return value for clienteId
     */
    @XmlElement(name = "clienteRef")
    public ClienteRefConverter getClienteId() {
        if (entity.getClienteId() != null) {
            return new ClienteRefConverter(entity.getClienteId(), uri.resolve("cliente/"), false);
        }
        return null;
    }

    /**
     * Setter for clienteId.
     *
     * @param value the value to set
     */
    public void setClienteId(ClienteRefConverter value) {
        if (value != null) {
            entity.setClienteId(value.getEntity());
        }
    }

    /**
     * Returns the URI associated with this converter.
     *
     * @return the uri
     */
    @XmlAttribute(name = "uri")
    public URI getResourceUri() {
        return uri;
    }

    /**
     * Returns the Mensaje entity.
     *
     * @return an entity
     */
    @XmlTransient
    public Mensaje getEntity() {
        return entity;
    }

    /**
     * Sets the Mensaje entity.
     *
     * @param entity to set
     */
    public void setEntity(Mensaje entity) {
        this.entity = entity;
    }
}
