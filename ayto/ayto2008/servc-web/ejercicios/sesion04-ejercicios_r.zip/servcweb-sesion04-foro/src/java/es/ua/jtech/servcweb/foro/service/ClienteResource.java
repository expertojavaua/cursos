/*
 *  ClienteResource
 *
 * Created on 13 de mayo de 2008, 17:30
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package es.ua.jtech.servcweb.foro.service;

import es.ua.jtech.servcweb.foro.jpa.Cliente;
import javax.ws.rs.Path;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.DELETE;
import javax.ws.rs.ProduceMime;
import javax.ws.rs.ConsumeMime;
import javax.ws.rs.WebApplicationException;
import javax.persistence.NoResultException;
import java.util.Collection;
import es.ua.jtech.servcweb.foro.jpa.Mensaje;
import es.ua.jtech.servcweb.foro.converter.ClienteConverter;
import javax.ws.rs.core.UriInfo;


/**
 *
 * @author Miguel Angel
 */

public class ClienteResource {
    private Integer id;
    private UriInfo context;
    
    /** Creates a new instance of ClienteResource */
    public ClienteResource() {
    }

    /**
     * Constructor used for instantiating an instance of dynamic resource.
     *
     * @param context HttpContext inherited from the parent resource
     */
    public ClienteResource(Integer id, UriInfo context) {
        this.id = id;
        this.context = context;
    }

    /**
     * Get method for retrieving an instance of Cliente identified by id in XML format.
     *
     * @param id identifier for the entity
     * @return an instance of ClienteConverter
     */
    @GET
    @ProduceMime({"application/xml", "application/json"})
    public ClienteConverter get() {
        try {
            return new ClienteConverter(getEntity(), context.getAbsolutePath());
        } finally {
            PersistenceService.getInstance().close();
        }
    }

    /**
     * Put method for updating an instance of Cliente identified by id using XML as the input format.
     *
     * @param id identifier for the entity
     * @param data an ClienteConverter entity that is deserialized from a XML stream
     */
    @PUT
    @ConsumeMime({"application/xml", "application/json"})
    public void put(ClienteConverter data) {
        PersistenceService service = PersistenceService.getInstance();
        try {
            service.beginTx();
            updateEntity(getEntity(), data.getEntity());
            service.commitTx();
        } finally {
            service.close();
        }
    }

    /**
     * Delete method for deleting an instance of Cliente identified by id.
     *
     * @param id identifier for the entity
     */
    @DELETE
    public void delete() {
        PersistenceService service = PersistenceService.getInstance();
        try {
            service.beginTx();
            Cliente entity = getEntity();
            service.removeEntity(entity);
            service.commitTx();
        } finally {
            service.close();
        }
    }

    /**
     * Returns a dynamic instance of MensajesResource used for entity navigation.
     *
     * @param id identifier for the parent entity
     * @return an instance of MensajesResource
     */
    @Path("mensajes/")
    public MensajesResource getMensajesResource() {
        final Cliente parent = getEntity();
        return new MensajesResource(context) {

            @Override
            protected Collection<Mensaje> getEntities(int start, int max) {
                Collection<Mensaje> result = new java.util.ArrayList<Mensaje>();
                int index = 0;
                for (Mensaje e : parent.getMensajeCollection()) {
                    if (index >= start && (index - start) < max) {
                        result.add(e);
                    }
                    index++;
                }
                return result;
            }

            @Override
            protected void createEntity(Mensaje entity) {
                super.createEntity(entity);
                entity.setClienteId(parent);
            }
        };
    }

    /**
     * Returns an instance of Cliente identified by id.
     *
     * @param id identifier for the entity
     * @return an instance of Cliente
     */
    protected Cliente getEntity() {
        try {
            return (Cliente) PersistenceService.getInstance().createQuery("SELECT e FROM Cliente e where e.id = :id").setParameter("id", id).getSingleResult();
        } catch (NoResultException ex) {
            throw new WebApplicationException(new Throwable("Resource for " + context.getAbsolutePath() + " does not exist."), 404);
        }
    }

    /**
     * Updates entity using data from newEntity.
     *
     * @param entity the entity to update
     * @param newEntity the entity containing the new data
     * @return the updated entity
     */
    protected Cliente updateEntity(Cliente entity, Cliente newEntity) {
        newEntity.setId(entity.getId());
        entity.getMensajeCollection().removeAll(newEntity.getMensajeCollection());
        for (Mensaje value : entity.getMensajeCollection()) {
            value.setClienteId(null);
        }
        entity = PersistenceService.getInstance().mergeEntity(newEntity);
        for (Mensaje value : entity.getMensajeCollection()) {
            value.setClienteId(entity);
        }
        return entity;
    }

    /**
     * Returns GoogleMapResource sub-resource.
     */
    @Path("googleMap/")
    public GoogleMapResource getGoogleMap() {
        try {
            String apiKey = "ABQIAAAA4Yag3Up7Ofp9wZoQKluFcxTwM0brOpm-All5BF6PoaKBxRWWERTKWy17fvtjOUmhdiYgaCHqc6BZUw";
            String address = this.getEntity().getDireccion();
            Integer zoom = null;
            return new GoogleMapResource(apiKey, address, zoom);
        } finally {
            PersistenceService.getInstance().close();
        }
    }
    
    
}
