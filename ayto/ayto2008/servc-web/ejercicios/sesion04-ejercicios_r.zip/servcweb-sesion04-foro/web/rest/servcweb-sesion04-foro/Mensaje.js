/*
* Support js for Mensaje
*/

function Mensaje(uri_) {
    this.Mensaje(uri_, false);
}

function Mensaje(uri_, initialized_) {
    this.uri = uri_;
    this.id = '';
    this.asunto = '';
    this.texto = '';
    this.clienteRef = '';

    this.initialized = initialized_;
}

Mensaje.prototype = {

   getUri : function() {
      return this.uri;
   },

   getId : function() {
      if(!this.initialized)
         this.init();
      return this.id;
   },

   setId : function(id_) {
      this.id = id_;
   },

   getAsunto : function() {
      if(!this.initialized)
         this.init();
      return this.asunto;
   },

   setAsunto : function(asunto_) {
      this.asunto = asunto_;
   },

   getTexto : function() {
      if(!this.initialized)
         this.init();
      return this.texto;
   },

   setTexto : function(texto_) {
      this.texto = texto_;
   },

   getClienteId : function() {
      if(!this.initialized)
         this.init();
      return this.clienteRef;
   },

   setClienteId : function(clienteRef_) {
      this.clienteRef = clienteRef_;
   },



   init : function() {
      var remote = new MensajeRemote(this.uri);
      var c = remote.getJson();
      if(c != -1) {
         var myObj = eval('(' +c+')');
         var mensaje = myObj.mensaje;
         this.uri = mensaje['@uri'];
         this.id = this.findValue(this.id, mensaje['id']);
         this.asunto = this.findValue(this.asunto, mensaje['asunto']);
         this.texto = this.findValue(this.texto, mensaje['texto']);
         this.clienteRef = new Cliente(mensaje['clienteRef']['@uri']);

         this.initialized = true;
      }
   },

   findValue : function(field, value) {
      if(value == undefined)
          return field;
      else
         return value;
   },

   flush : function() {
      var remote = new MensajeRemote(this.uri);
      return remote.putJson('{'+this.toString()+'}');
   },

   delete_ : function() {
      var remote = new MensajeRemote(this.uri);
      return remote.delete_();
   },

   toString : function() {
      if(!this.initialized)
         this.init();
      var myObj = 
         '"mensaje":'+
         '{'+
         '"@uri":"'+this.uri+'",'+
                  '"id":"'+this.id+'",'+
         '"asunto":"'+this.asunto+'",'+
         '"texto":"'+this.texto+'",'+
         '"clienteRef":{"@uri":"'+this.clienteRef.getUri()+'", "cliente"::"'+eval("this.clienteRef.get"+this.clienteRef.getFields()[0].substring(0,1).toUpperCase()+this.clienteRef.getFields()[0].substring(1)+"()")+'"}'+

         '}';
      return myObj;
   },

   getFields : function() {
      var fields = [];
         fields.push('id');
         fields.push('asunto');
         fields.push('texto');

      return fields;
   }

}

function MensajeRemote(uri_) {
    this.uri = uri_;
}

MensajeRemote.prototype = {

/* Default getJson() method used by Container/Containee init() methods. Do not remove. */
   getJson : function() {
      return rjsSupport.get(this.uri, 'application/json');
   },

   getXml : function() {
      return rjsSupport.get(this.uri, 'application/xml');
   },

   getXml : function() {
      return rjsSupport.get(this.uri, 'application/xml');
   },

   getJson : function() {
      return rjsSupport.get(this.uri, 'application/json');
   },

   putXml : function(content) {
      return rjsSupport.put(this.uri, 'application/xml', content);
   },

   putXml : function(content) {
      return rjsSupport.put(this.uri, 'application/xml', content);
   },

   putJson : function(content) {
      return rjsSupport.put(this.uri, 'application/json', content);
   },

   delete_ : function() {
      return rjsSupport.delete_(this.uri);
   },

   getClienteResource : function(cliente) {
      var link = new Cliente(this.uri+'/'+cliente)()
      return link;
   }

}
