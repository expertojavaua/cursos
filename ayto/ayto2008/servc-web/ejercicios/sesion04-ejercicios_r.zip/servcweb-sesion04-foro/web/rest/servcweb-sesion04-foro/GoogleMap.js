/*
* Support js for GoogleMap
*/

function GoogleMap(uri_) {
    this.uri = uri_;
}

GoogleMap.prototype = {

   getUri : function() {
      return this.uri;
   },
   
   getRemote : function() {
      return new GoogleMapRemote(this.uri);
   }
}

function GoogleMapRemote(uri_) {
    this.uri = uri_;
}

GoogleMapRemote.prototype = {

   getHtmlXml : function() {
      return rjsSupport.get(this.uri, 'application/xml');
   },

   getHtmlHtml : function() {
      return rjsSupport.get(this.uri, 'text/html');
   }

}
