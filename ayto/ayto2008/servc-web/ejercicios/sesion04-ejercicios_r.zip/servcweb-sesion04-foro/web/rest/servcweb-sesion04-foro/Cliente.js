/*
* Support js for Cliente
*/

function Cliente(uri_) {
    this.Cliente(uri_, false);
}

function Cliente(uri_, initialized_) {
    this.uri = uri_;
    this.id = '';
    this.nombre = '';
    this.email = '';
    this.direccion = '';
    this.mensajes = new Array();
    this.googleMapRef = '';

    this.initialized = initialized_;
}

Cliente.prototype = {

   getUri : function() {
      return this.uri;
   },

   getId : function() {
      if(!this.initialized)
         this.init();
      return this.id;
   },

   setId : function(id_) {
      this.id = id_;
   },

   getNombre : function() {
      if(!this.initialized)
         this.init();
      return this.nombre;
   },

   setNombre : function(nombre_) {
      this.nombre = nombre_;
   },

   getEmail : function() {
      if(!this.initialized)
         this.init();
      return this.email;
   },

   setEmail : function(email_) {
      this.email = email_;
   },

   getDireccion : function() {
      if(!this.initialized)
         this.init();
      return this.direccion;
   },

   setDireccion : function(direccion_) {
      this.direccion = direccion_;
   },

   getMensajes : function() {
      if(!this.initialized)
         this.init();
      return this.mensajes;
   },

   setMensajes : function(mensajes_) {
      this.mensajes = mensajes_;
   },

   getGoogleMapRef : function() {
      if(!this.initialized)
         this.init();
      return this.googleMapRef;
   },

   setGoogleMapRef : function(googleMapRef_) {
      this.googleMapRef = googleMapRef_;
   },



   init : function() {
      var remote = new ClienteRemote(this.uri);
      var c = remote.getJson();
      if(c != -1) {
         var myObj = eval('(' +c+')');
         var cliente = myObj.cliente;
         this.uri = cliente['@uri'];
         this.id = this.findValue(this.id, cliente['id']);
         this.nombre = this.findValue(this.nombre, cliente['nombre']);
         this.email = this.findValue(this.email, cliente['email']);
         this.direccion = this.findValue(this.direccion, cliente['direccion']);
         this.mensajes = new Mensajes(cliente['mensajes']['@uri']);
         this.googleMapRef = new GoogleMap(cliente['googleMapRef']['@uri']);

         this.initialized = true;
      }
   },

   findValue : function(field, value) {
      if(value == undefined)
          return field;
      else
         return value;
   },

   flush : function() {
      var remote = new ClienteRemote(this.uri);
      return remote.putJson('{'+this.toString()+'}');
   },

   delete_ : function() {
      var remote = new ClienteRemote(this.uri);
      return remote.delete_();
   },

   toString : function() {
      if(!this.initialized)
         this.init();
      var myObj = 
         '"cliente":'+
         '{'+
         '"@uri":"'+this.uri+'",'+
                  '"id":"'+this.id+'",'+
         '"nombre":"'+this.nombre+'",'+
         '"email":"'+this.email+'",'+
         '"direccion":"'+this.direccion+'",'+
         this.mensajes.toString()+','+
         '"googleMapRef":{"@uri":"'+this.googleMapRef.getUri()+'"}'+

         '}';
      return myObj;
   },

   getFields : function() {
      var fields = [];
         fields.push('id');
         fields.push('nombre');
         fields.push('email');
         fields.push('direccion');

      return fields;
   }

}

function ClienteRemote(uri_) {
    this.uri = uri_;
}

ClienteRemote.prototype = {

/* Default getJson() method used by Container/Containee init() methods. Do not remove. */
   getJson : function() {
      return rjsSupport.get(this.uri, 'application/json');
   },

   getXml : function() {
      return rjsSupport.get(this.uri, 'application/xml');
   },

   getXml : function() {
      return rjsSupport.get(this.uri, 'application/xml');
   },

   getJson : function() {
      return rjsSupport.get(this.uri, 'application/json');
   },

   putXml : function(content) {
      return rjsSupport.put(this.uri, 'application/xml', content);
   },

   putXml : function(content) {
      return rjsSupport.put(this.uri, 'application/xml', content);
   },

   putJson : function(content) {
      return rjsSupport.put(this.uri, 'application/json', content);
   },

   delete_ : function() {
      return rjsSupport.delete_(this.uri);
   },

   getMensajesResource : function(mensajes) {
      var link = new Mensajes(this.uri+'/'+mensajes)()
      return link;
   },

   getGoogleMap : function(googleMap) {
      var link = new GoogleMap(this.uri+'/'+googleMap)()
      return link;
   }

}
