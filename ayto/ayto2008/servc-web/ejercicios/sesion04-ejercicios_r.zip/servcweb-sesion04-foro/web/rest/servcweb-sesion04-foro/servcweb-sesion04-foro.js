/*
* servcweb-sesion04-foro stub
*/

function servcwebsesion04foro() {}

servcwebsesion04foro.prototype = {

   uri : 'http://localhost:8080/servcweb-sesion04-foro/resources',

   resources : new Array(),
   
   initialized : false,

   getUri : function() {
      return this.uri;
   },

   getResources : function() {
      if(!this.initialized)
          this.init();
      return this.resources;
   },

   init : function() {
      this.resources[0] = new Clientes(this.uri+'/clientes/');
      this.resources[1] = new Mensajes(this.uri+'/mensajes/');

      this.initialized = true;
   },

   flush : function(resources_) {
      for(j=0;j<resources_.length;j++) {
        var r = resources_[j];
        r.flush();
      }
   },

   toString : function() {
      var s = '';
      for(j=0;j<this.resources.length;j++) {
        var c = this.resources[j];
        if(j<this.resources.length-1)
            s = s + '{"@uri":"'+c.getUri()+'"},';
        else
            s = s + '{"@uri":"'+c.getUri()+'"}';
      }
      var myObj = 
         '{"resources":'+
         '{'+
         s+
         '}'+
      '}';
      return myObj;
   }

}
