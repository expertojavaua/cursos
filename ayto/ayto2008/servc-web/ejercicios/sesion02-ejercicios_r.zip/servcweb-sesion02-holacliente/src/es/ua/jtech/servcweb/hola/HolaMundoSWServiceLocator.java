/**
 * HolaMundoSWServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package es.ua.jtech.servcweb.hola;

public class HolaMundoSWServiceLocator extends org.apache.axis.client.Service implements es.ua.jtech.servcweb.hola.HolaMundoSWService {

    public HolaMundoSWServiceLocator() {
    }


    public HolaMundoSWServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public HolaMundoSWServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for HolaMundoSW
    private java.lang.String HolaMundoSW_address = "http://localhost:8080/servcweb-sesion02-hola/services/HolaMundoSW";

    public java.lang.String getHolaMundoSWAddress() {
        return HolaMundoSW_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String HolaMundoSWWSDDServiceName = "HolaMundoSW";

    public java.lang.String getHolaMundoSWWSDDServiceName() {
        return HolaMundoSWWSDDServiceName;
    }

    public void setHolaMundoSWWSDDServiceName(java.lang.String name) {
        HolaMundoSWWSDDServiceName = name;
    }

    public es.ua.jtech.servcweb.hola.HolaMundoSW getHolaMundoSW() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(HolaMundoSW_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getHolaMundoSW(endpoint);
    }

    public es.ua.jtech.servcweb.hola.HolaMundoSW getHolaMundoSW(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            es.ua.jtech.servcweb.hola.HolaMundoSWSoapBindingStub _stub = new es.ua.jtech.servcweb.hola.HolaMundoSWSoapBindingStub(portAddress, this);
            _stub.setPortName(getHolaMundoSWWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setHolaMundoSWEndpointAddress(java.lang.String address) {
        HolaMundoSW_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (es.ua.jtech.servcweb.hola.HolaMundoSW.class.isAssignableFrom(serviceEndpointInterface)) {
                es.ua.jtech.servcweb.hola.HolaMundoSWSoapBindingStub _stub = new es.ua.jtech.servcweb.hola.HolaMundoSWSoapBindingStub(new java.net.URL(HolaMundoSW_address), this);
                _stub.setPortName(getHolaMundoSWWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("HolaMundoSW".equals(inputPortName)) {
            return getHolaMundoSW();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://hola.servcweb.jtech.ua.es", "HolaMundoSWService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://hola.servcweb.jtech.ua.es", "HolaMundoSW"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("HolaMundoSW".equals(portName)) {
            setHolaMundoSWEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
