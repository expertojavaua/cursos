package es.ua.jtech.servcweb.tienda.cliente;

import java.rmi.RemoteException;

import es.ua.jtech.servcweb.tienda.PeliculaTO;
import es.ua.jtech.servcweb.tienda.TiendaDvdSW;
import es.ua.jtech.servcweb.tienda.TiendaDvdSWProxy;

public class ClienteTienda {

	public static void main(String[] args) throws RemoteException {
		TiendaDvdSW servicio = new TiendaDvdSWProxy();
		PeliculaTO [] peliculas = servicio.buscaDirector("Kubrick");
		for(PeliculaTO pelicula: peliculas) {
			System.out.println(pelicula.getTitulo() + ", " + pelicula.getDirector() + ", " + pelicula.getPrecio());
		}
	}

}
