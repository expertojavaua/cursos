package es.ua.jtech.servcweb.tienda;

public class TiendaDvdSWProxy implements es.ua.jtech.servcweb.tienda.TiendaDvdSW {
  private String _endpoint = null;
  private es.ua.jtech.servcweb.tienda.TiendaDvdSW tiendaDvdSW = null;
  
  public TiendaDvdSWProxy() {
    _initTiendaDvdSWProxy();
  }
  
  public TiendaDvdSWProxy(String endpoint) {
    _endpoint = endpoint;
    _initTiendaDvdSWProxy();
  }
  
  private void _initTiendaDvdSWProxy() {
    try {
      tiendaDvdSW = (new es.ua.jtech.servcweb.tienda.TiendaDvdSWServiceLocator()).getTiendaDvdSW();
      if (tiendaDvdSW != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)tiendaDvdSW)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)tiendaDvdSW)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (tiendaDvdSW != null)
      ((javax.xml.rpc.Stub)tiendaDvdSW)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public es.ua.jtech.servcweb.tienda.TiendaDvdSW getTiendaDvdSW() {
    if (tiendaDvdSW == null)
      _initTiendaDvdSWProxy();
    return tiendaDvdSW;
  }
  
  public es.ua.jtech.servcweb.tienda.PeliculaTO[] buscaDirector(java.lang.String director) throws java.rmi.RemoteException{
    if (tiendaDvdSW == null)
      _initTiendaDvdSWProxy();
    return tiendaDvdSW.buscaDirector(director);
  }
  
  
}