/**
 * TiendaDvdSWService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package es.ua.jtech.servcweb.tienda;

public interface TiendaDvdSWService extends javax.xml.rpc.Service {
    public java.lang.String getTiendaDvdSWAddress();

    public es.ua.jtech.servcweb.tienda.TiendaDvdSW getTiendaDvdSW() throws javax.xml.rpc.ServiceException;

    public es.ua.jtech.servcweb.tienda.TiendaDvdSW getTiendaDvdSW(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
