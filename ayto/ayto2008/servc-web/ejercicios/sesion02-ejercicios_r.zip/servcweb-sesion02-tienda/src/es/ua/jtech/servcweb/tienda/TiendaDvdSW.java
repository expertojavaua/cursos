package es.ua.jtech.servcweb.tienda;

import java.util.ArrayList;

public class TiendaDvdSW {
	
	final static PeliculaTO[] peliculas = {
	    new PeliculaTO("Mulholland Drive", "David Lynch", 26.96f),
	    new PeliculaTO("Carretera perdida", "David Lynch", 18.95f),
	    new PeliculaTO("Twin Peaks", "David Lynch", 46.95f),
	    new PeliculaTO("Telefono rojo", "Stanley Kubrick", 15.95f),
	    new PeliculaTO("Barry Lyndon", "Stanley Kubrick", 24.95f),
	    new PeliculaTO("La naranja mec�nica", "Stanley Kubrick", 22.95f) 
	};
	
	public PeliculaTO [] buscaDirector(String director) {
		director = director.toLowerCase();
		   
		ArrayList<PeliculaTO> list = new ArrayList<PeliculaTO>();
		   
		for (PeliculaTO pelicula : peliculas) {
		  if (pelicula.getDirector().toLowerCase().indexOf(director) != -1) {
		    list.add(pelicula);
		  }
		}
		
		PeliculaTO [] result = new PeliculaTO[list.size()];
		list.toArray(result);
		      
		return result;
	}
}
