package es.ua.jtech.servcweb.hola;

public class HolaMundoSW {
	public String saluda(String nombre) {
		return "Hola " + nombre;
	}
}
