package es.ua.jtech.servcweb.dni;

public class ValidaDniSWProxy implements es.ua.jtech.servcweb.dni.ValidaDniSW {
  private String _endpoint = null;
  private es.ua.jtech.servcweb.dni.ValidaDniSW validaDniSW = null;
  
  public ValidaDniSWProxy() {
    _initValidaDniSWProxy();
  }
  
  public ValidaDniSWProxy(String endpoint) {
    _endpoint = endpoint;
    _initValidaDniSWProxy();
  }
  
  private void _initValidaDniSWProxy() {
    try {
      validaDniSW = (new es.ua.jtech.servcweb.dni.ValidaDniSWServiceLocator()).getValidaDniSW();
      if (validaDniSW != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)validaDniSW)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)validaDniSW)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (validaDniSW != null)
      ((javax.xml.rpc.Stub)validaDniSW)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public es.ua.jtech.servcweb.dni.ValidaDniSW getValidaDniSW() {
    if (validaDniSW == null)
      _initValidaDniSWProxy();
    return validaDniSW;
  }
  
  public boolean validarDni(java.lang.String dni) throws java.rmi.RemoteException{
    if (validaDniSW == null)
      _initValidaDniSWProxy();
    return validaDniSW.validarDni(dni);
  }
  
  public int obtenerLetra(java.lang.String dni) throws java.rmi.RemoteException{
    if (validaDniSW == null)
      _initValidaDniSWProxy();
    return validaDniSW.obtenerLetra(dni);
  }
  
  public boolean validarNif(java.lang.String nif) throws java.rmi.RemoteException{
    if (validaDniSW == null)
      _initValidaDniSWProxy();
    return validaDniSW.validarNif(nif);
  }
  
  
}