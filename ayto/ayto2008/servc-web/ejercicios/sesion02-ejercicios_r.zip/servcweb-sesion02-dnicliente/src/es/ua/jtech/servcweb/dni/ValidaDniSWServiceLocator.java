/**
 * ValidaDniSWServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package es.ua.jtech.servcweb.dni;

public class ValidaDniSWServiceLocator extends org.apache.axis.client.Service implements es.ua.jtech.servcweb.dni.ValidaDniSWService {

    public ValidaDniSWServiceLocator() {
    }


    public ValidaDniSWServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public ValidaDniSWServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for ValidaDniSW
    private java.lang.String ValidaDniSW_address = "http://localhost:8080/servcweb-sesion02-dni/services/ValidaDniSW";

    public java.lang.String getValidaDniSWAddress() {
        return ValidaDniSW_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String ValidaDniSWWSDDServiceName = "ValidaDniSW";

    public java.lang.String getValidaDniSWWSDDServiceName() {
        return ValidaDniSWWSDDServiceName;
    }

    public void setValidaDniSWWSDDServiceName(java.lang.String name) {
        ValidaDniSWWSDDServiceName = name;
    }

    public es.ua.jtech.servcweb.dni.ValidaDniSW getValidaDniSW() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(ValidaDniSW_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getValidaDniSW(endpoint);
    }

    public es.ua.jtech.servcweb.dni.ValidaDniSW getValidaDniSW(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            es.ua.jtech.servcweb.dni.ValidaDniSWSoapBindingStub _stub = new es.ua.jtech.servcweb.dni.ValidaDniSWSoapBindingStub(portAddress, this);
            _stub.setPortName(getValidaDniSWWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setValidaDniSWEndpointAddress(java.lang.String address) {
        ValidaDniSW_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (es.ua.jtech.servcweb.dni.ValidaDniSW.class.isAssignableFrom(serviceEndpointInterface)) {
                es.ua.jtech.servcweb.dni.ValidaDniSWSoapBindingStub _stub = new es.ua.jtech.servcweb.dni.ValidaDniSWSoapBindingStub(new java.net.URL(ValidaDniSW_address), this);
                _stub.setPortName(getValidaDniSWWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("ValidaDniSW".equals(inputPortName)) {
            return getValidaDniSW();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://dni.servcweb.jtech.ua.es", "ValidaDniSWService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://dni.servcweb.jtech.ua.es", "ValidaDniSW"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("ValidaDniSW".equals(portName)) {
            setValidaDniSWEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
