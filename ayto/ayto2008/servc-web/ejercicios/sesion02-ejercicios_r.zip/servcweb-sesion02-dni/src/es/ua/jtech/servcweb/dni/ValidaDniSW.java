package es.ua.jtech.servcweb.dni;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidaDniSW {

	public boolean validarDni(String dni) {
		Pattern pattern =  Pattern.compile("[0-9]{8,8}");
		Matcher matcher = pattern.matcher(dni);
		return matcher.matches();
	}
	
	public int obtenerLetra(String dni) {
		String caracteres = "TRWAGMYFPDXBNJZSQVHLCKE";
		long lDni = Long.parseLong(dni);
		int indice = (int)(lDni % 23);
		return caracteres.charAt(indice);
	}
	
	public boolean validarNif(String nif) {
		if(nif.length()!=9) {
			return false;
		} else {
			String dni = nif.substring(0,8);
			char letra = nif.charAt(8);
			return validarDni(dni) && letra==obtenerLetra(dni);
		}
	}
}
