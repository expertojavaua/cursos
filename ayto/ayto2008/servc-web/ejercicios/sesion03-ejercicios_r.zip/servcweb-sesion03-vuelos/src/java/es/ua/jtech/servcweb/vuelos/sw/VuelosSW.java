/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package es.ua.jtech.servcweb.vuelos.sw;

import es.ua.jtech.servcweb.vuelos.dao.VuelosDAO;
import es.ua.jtech.servcweb.vuelos.jpa.Vuelo;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

/**
 *
 * @author Miguel Angel
 */
@WebService()
public class VuelosSW {

/**
     * Web service operation
     */
    @WebMethod(operationName = "getDisponibilidad")
    public int getDisponibilidad(@WebParam(name = "id")
    int id) {
        VuelosDAO vuelos = new VuelosDAO();
        Vuelo v = vuelos.getVuelo(id);
        if(v==null) {
            return -1;
        } else {
            return v.getDisponibles();            
        }
    }

/**
     * Web service operation
     */
    @WebMethod(operationName = "realizaReserva")
    public boolean realizaReserva(@WebParam(name = "vuelo")
    int vuelo, @WebParam(name = "nif")
    String nif, @WebParam(name = "nombre")
    String nombre) {
        VuelosDAO vuelos = new VuelosDAO();
        return vuelos.realizaReserva(vuelo, nif, nombre);
    }

}
