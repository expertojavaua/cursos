/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package es.ua.jtech.servcweb.carrito.sw;

import com.sun.xml.ws.developer.Stateful;
import com.sun.xml.ws.developer.StatefulWebServiceManager;
import es.ua.jtech.servcweb.carrito.to.LineaVentaTO;
import java.util.ArrayList;
import java.util.List;
import javax.jws.Oneway;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import javax.xml.ws.soap.Addressing;

/**
 *
 * @author Miguel Angel
 */
@Stateful
@WebService
@Addressing
public class CarritoSW {

    public static StatefulWebServiceManager<CarritoSW> manager;

    List<LineaVentaTO> productos;
    
    public CarritoSW() {
        productos = new ArrayList<LineaVentaTO>();
    }
    
    /**
     * Web service operation
     */
    @WebMethod(operationName = "addProducto")
    @Oneway
    public void addProducto(@WebParam(name = "nombre")
    String nombre, @WebParam(name = "cantidad")
    int cantidad, @WebParam(name = "precio")
    float precio) {
        productos.add(new LineaVentaTO(nombre, cantidad, precio));
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "getImporteTotal")
    public float getImporteTotal() {
        float total = 0.0f;
        for(LineaVentaTO linea: productos) {
            total += linea.getCantidad()*linea.getPrecio();
        }
        return total;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "finalizarCompra")
    @Oneway
    public void finalizarCompra() {
        manager.unexport(this);
    }

}
