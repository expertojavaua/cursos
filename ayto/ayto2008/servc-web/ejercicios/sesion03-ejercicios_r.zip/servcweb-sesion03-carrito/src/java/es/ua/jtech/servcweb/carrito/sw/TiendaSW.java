/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package es.ua.jtech.servcweb.carrito.sw;

import javax.jws.WebMethod;
import javax.jws.WebService;
import javax.xml.ws.wsaddressing.W3CEndpointReference;

/**
 *
 * @author Miguel Angel
 */
@WebService()
public class TiendaSW {

/**
     * Web service operation
     */
    @WebMethod(operationName = "creaCarrito")
    public W3CEndpointReference creaCarrito() {
        CarritoSW c = new CarritoSW();
        W3CEndpointReference endpoint = CarritoSW.manager.export(c);
        return endpoint;
    }

}
