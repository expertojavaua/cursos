/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package es.ua.jtech.servcweb.binario.sw;

import java.awt.Image;
import java.awt.image.BufferedImage;
import javax.jws.WebMethod;
import javax.jws.WebService;

/**
 *
 * @author Miguel Angel
 */
@WebService()
public class BinarioSW {

/**
     * Web service operation
     */
    @WebMethod(operationName = "getData")
    public byte [] getData() {
        //TODO write your implementation code here:
        return new byte[5];
    }

/**
     * Web service operation
     */
    @WebMethod(operationName = "getImage")
    public Image getImage() {
        //TODO write your implementation code here:
        return new BufferedImage(1024, 768, BufferedImage.TYPE_4BYTE_ABGR);
    }

}
