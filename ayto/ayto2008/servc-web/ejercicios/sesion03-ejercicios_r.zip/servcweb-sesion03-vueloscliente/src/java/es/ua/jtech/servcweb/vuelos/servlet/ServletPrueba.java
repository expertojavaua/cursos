/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package es.ua.jtech.servcweb.vuelos.servlet;

import es.ua.jtech.servcweb.vuelos.stub.VuelosSW;
import es.ua.jtech.servcweb.vuelos.stub.VuelosSWService;
import java.io.*;
import java.net.*;

import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;
import javax.xml.ws.WebServiceRef;

/**
 *
 * @author Miguel Angel
 */
public class ServletPrueba extends HttpServlet {
    @WebServiceRef(wsdlLocation = "http://localhost:8080/servcweb-sesion03-vuelos/VuelosSWService?WSDL")
    private VuelosSWService service;
   
    @Resource UserTransaction ut;
    
    /** 
    * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
    * @param request servlet request
    * @param response servlet response
    */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try {
            
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Reservas</title>");  
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Resultados de las reservas</h1>");
            
            
            try { 
                
                VuelosSW port = service.getVuelosSWPort();
                int vuelo = 1623;
                
                ut.begin();

                boolean reservado1 = port.realizaReserva(vuelo, "12345678X", "Miguel Lopez");
                out.println("<p>Reservado 1 = "+reservado1 + "</p>");
                boolean reservado2 = port.realizaReserva(vuelo, "64332423B", "Alberto Zamora");
                out.println("<p>Reservado 2 = "+reservado2 + "</p>");
                boolean reservado3 = port.realizaReserva(vuelo, "68372847A", "Ana Martinez");
                out.println("<p>Reservado 3 = "+reservado3 + "</p>");
                boolean reservado4 = port.realizaReserva(vuelo, "23287877T", "Manuel Gomez");
                out.println("<p>Reservado 4 = "+reservado4 + "</p>");
                boolean reservado5 = port.realizaReserva(vuelo, "94723535Q", "Laura Perez");
                out.println("<p>Reservado 5 = "+reservado5 + "</p>");

                if(reservado1 && reservado2 && reservado3 && reservado4 && reservado5) {
                    ut.commit();
                    out.println("<p>Operacion efectuada</p>");
                } else {
                    ut.rollback();
                    out.println("<p>Operacion cancelada</p>");
                }
                
            } catch (Exception ex) {
                ex.printStackTrace();
                out.println("<p>Operacion cancelada debido a un error: " + ex.getMessage() + "</p>");
                try {
                    ut.rollback();
                } catch (Exception ex1) {
                    ex1.printStackTrace();
                }
            }

            
            out.println("</body>");
            out.println("</html>");
            
        } finally { 
            out.close();
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
    * Handles the HTTP <code>GET</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
    * Handles the HTTP <code>POST</code> method.
    * @param request servlet request
    * @param response servlet response
    */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
    * Returns a short description of the servlet.
    */
    public String getServletInfo() {
        return "Short description";
    }
    // </editor-fold>
}
