/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package es.ua.jtech.servcweb.carrito;

import es.ua.jtech.servcweb.carrito.stub.carrito.CarritoSW;
import es.ua.jtech.servcweb.carrito.stub.carrito.CarritoSWService;
import es.ua.jtech.servcweb.carrito.stub.tienda.TiendaSW;
import es.ua.jtech.servcweb.carrito.stub.tienda.TiendaSWService;
import javax.xml.ws.wsaddressing.W3CEndpointReference;

/**
 *
 * @author Miguel Angel
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        try { 
            TiendaSWService tservice = new TiendaSWService();
            TiendaSW tport = tservice.getTiendaSWPort();
            
            W3CEndpointReference result = tport.creaCarrito();

            CarritoSWService cservice = new CarritoSWService();
            CarritoSW carrito = cservice.getPort(result, CarritoSW.class);

            carrito.addProducto("Tambor 25 DVD grabable", 2, 13.95f);
            carrito.addProducto("Pendrive 4GB", 1, 19.95f);
            System.out.println("Importe actual: " + carrito.getImporteTotal());
            carrito.addProducto("Monitor TFT 19inch", 1, 179.90f);
            System.out.println("Importe final: " + carrito.getImporteTotal());
            carrito.finalizarCompra();

        } catch (Exception ex) {
            ex.printStackTrace();
        }


    }
}
