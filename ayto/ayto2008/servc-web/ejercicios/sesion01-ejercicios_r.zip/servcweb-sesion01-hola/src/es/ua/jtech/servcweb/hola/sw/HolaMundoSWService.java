/**
 * HolaMundoSWService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package es.ua.jtech.servcweb.hola.sw;

public interface HolaMundoSWService extends javax.xml.rpc.Service {
    public java.lang.String getHolaMundoSWAddress();

    public es.ua.jtech.servcweb.hola.sw.HolaMundoSW getHolaMundoSW() throws javax.xml.rpc.ServiceException;

    public es.ua.jtech.servcweb.hola.sw.HolaMundoSW getHolaMundoSW(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
