package es.ua.jtech.servcweb.hola;

import java.rmi.RemoteException;

import es.ua.jtech.servcweb.hola.sw.HolaMundoSW;
import es.ua.jtech.servcweb.hola.sw.HolaMundoSWProxy;

public class ClienteHolaMundo {

	public static void main(String[] args) throws RemoteException {
		HolaMundoSW servicio = new HolaMundoSWProxy();
		System.out.println("Resultado: " + servicio.saluda("Miguel"));
	}

}
