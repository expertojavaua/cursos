package es.ua.jtech.servcweb.hola.sw;

public class HolaMundoSWProxy implements es.ua.jtech.servcweb.hola.sw.HolaMundoSW {
  private String _endpoint = null;
  private es.ua.jtech.servcweb.hola.sw.HolaMundoSW holaMundoSW = null;
  
  public HolaMundoSWProxy() {
    _initHolaMundoSWProxy();
  }
  
  public HolaMundoSWProxy(String endpoint) {
    _endpoint = endpoint;
    _initHolaMundoSWProxy();
  }
  
  private void _initHolaMundoSWProxy() {
    try {
      holaMundoSW = (new es.ua.jtech.servcweb.hola.sw.HolaMundoSWServiceLocator()).getHolaMundoSW();
      if (holaMundoSW != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)holaMundoSW)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)holaMundoSW)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (holaMundoSW != null)
      ((javax.xml.rpc.Stub)holaMundoSW)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public es.ua.jtech.servcweb.hola.sw.HolaMundoSW getHolaMundoSW() {
    if (holaMundoSW == null)
      _initHolaMundoSWProxy();
    return holaMundoSW;
  }
  
  public java.lang.String saluda(java.lang.String nombre) throws java.rmi.RemoteException{
    if (holaMundoSW == null)
      _initHolaMundoSWProxy();
    return holaMundoSW.saluda(nombre);
  }
  
  
}