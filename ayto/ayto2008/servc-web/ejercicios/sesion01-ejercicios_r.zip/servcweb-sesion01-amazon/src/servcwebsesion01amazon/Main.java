/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package servcwebsesion01amazon;

import com.amazon.webservices.awsecommerceservice._2008_10_06.Item;
import com.amazon.webservices.awsecommerceservice._2008_10_06.ItemAttributes;
import com.amazon.webservices.awsecommerceservice._2008_10_06.ItemSearchRequest;
import com.amazon.webservices.awsecommerceservice._2008_10_06.Items;
import com.amazon.webservices.awsecommerceservice._2008_10_06.OperationRequest;
import java.util.List;
import javax.xml.ws.Holder;

/**
 *
 * @author Miguel Angel
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {


        try { // Call Web Service Operation

            com.amazon.webservices.awsecommerceservice._2008_10_06.AWSECommerceService service = new com.amazon.webservices.awsecommerceservice._2008_10_06.AWSECommerceService();
            com.amazon.webservices.awsecommerceservice._2008_10_06.AWSECommerceServicePortType port = service.getAWSECommerceServicePort();

            String marketplaceDomain = null;
            String awsAccessKeyId = "15JCR9XWMPTGV91JC1R2";
            String subscriptionId = null;
            String associateTag = null;
            String xmlEscaping = null;
            String validate = null;
            ItemSearchRequest shared = null;
            List<ItemSearchRequest> request = null;
            Holder<OperationRequest> operationRequest = null;
            Holder<List<Items>> items = new Holder<List<Items>>();

            shared = new ItemSearchRequest();
            shared.setSearchIndex("DVD");
            shared.setDirector("Kubrick");
            shared.getResponseGroup().add("Offers");
            shared.getResponseGroup().add("Medium");

            port.itemSearch(marketplaceDomain, awsAccessKeyId,
                    subscriptionId, associateTag, xmlEscaping,
                    validate, shared, request, operationRequest, items);

            List<Items> listaResultados = items.value;
            for (Items resultado : listaResultados) {
                List<Item> listaArticulos = resultado.getItem();
                for (Item articulo : listaArticulos) {
                    ItemAttributes atributos = articulo.getItemAttributes();
                    System.out.println("Titulo: " + atributos.getTitle());

                    List<String> directores = atributos.getDirector();
                    for (String director : directores) {
                        System.out.print(director + "; ");
                    }

                    System.out.println("Precio: " +
                            (atributos.getListPrice() != null ? atributos.getListPrice().getFormattedPrice() : "no disponible"));
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }


    }
}
