/**
 * WSPortType.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package UASI.WS_wsdl;

public interface WSPortType extends java.rmi.Remote {
    public montgo.WS_xsd.Montgo_WsListAgrupaciones wsagrupaciones(java.lang.String plengua, java.lang.String pcurso, java.lang.String pcodcen, java.lang.String pcodest) throws java.rmi.RemoteException;
    public montgo.WS_xsd.Montgo_WsListProyectosInv wsproyectosgrupoinv(java.lang.String plengua, java.lang.String pcodgrp, java.lang.String ppublico, java.lang.String pfechaini, java.lang.String pfechafin) throws java.rmi.RemoteException;
    public montgo.WS_xsd.Montgo_WsListProyectosInv wsproyectosinst(java.lang.String plengua, java.lang.String pcodinst, java.lang.String ppublico, java.lang.String pfechaini, java.lang.String pfechafin) throws java.rmi.RemoteException;
    public montgo.WS_xsd.Montgo_WsListHorarioAgrup wshorarioagrp(java.lang.String plengua, java.lang.String pcurso, java.lang.String pagrupa) throws java.rmi.RemoteException;
    public montgo.WS_xsd.Montgo_WsListHorarios wshorarios(java.lang.String plengua, java.lang.String pcurso, java.lang.String pcodasi, java.lang.String porden) throws java.rmi.RemoteException;
    public montgo.WS_xsd.Montgo_WsListProyectosInv wsproyectosdepto(java.lang.String plengua, java.lang.String pcoddep, java.lang.String ppublico, java.lang.String pfechaini, java.lang.String pfechafin) throws java.rmi.RemoteException;
    public montgo.WS_xsd.Montgo_WsListFechaexa wsfechaexamenesasi(java.lang.String plengua, java.lang.String pcodest, java.lang.String pcurso, java.lang.String pcodasi, java.lang.String pcodconvoc, java.lang.String porden) throws java.rmi.RemoteException;
    public montgo.WS_xsd.Montgo_WsListAsignaturas wsasidepto(java.lang.String plengua, java.lang.String pcurso, java.lang.String pcoddep, java.lang.String pcodest) throws java.rmi.RemoteException;
    public montgo.WS_xsd.Montgo_WsListBibliografia wsbibliografia(java.lang.String plengua, java.lang.String pcurso, java.lang.String pcodasi, java.lang.String porden) throws java.rmi.RemoteException;
}
