package UASI.WS_wsdl;

public class WSPortTypeProxy implements UASI.WS_wsdl.WSPortType {
  private String _endpoint = null;
  private UASI.WS_wsdl.WSPortType wSPortType = null;
  
  public WSPortTypeProxy() {
    _initWSPortTypeProxy();
  }
  
  public WSPortTypeProxy(String endpoint) {
    _endpoint = endpoint;
    _initWSPortTypeProxy();
  }
  
  private void _initWSPortTypeProxy() {
    try {
      wSPortType = (new UASI.WS_wsdl.WSLocator()).getWSPort();
      if (wSPortType != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)wSPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)wSPortType)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (wSPortType != null)
      ((javax.xml.rpc.Stub)wSPortType)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public UASI.WS_wsdl.WSPortType getWSPortType() {
    if (wSPortType == null)
      _initWSPortTypeProxy();
    return wSPortType;
  }
  
  public montgo.WS_xsd.Montgo_WsListAgrupaciones wsagrupaciones(java.lang.String plengua, java.lang.String pcurso, java.lang.String pcodcen, java.lang.String pcodest) throws java.rmi.RemoteException{
    if (wSPortType == null)
      _initWSPortTypeProxy();
    return wSPortType.wsagrupaciones(plengua, pcurso, pcodcen, pcodest);
  }
  
  public montgo.WS_xsd.Montgo_WsListProyectosInv wsproyectosgrupoinv(java.lang.String plengua, java.lang.String pcodgrp, java.lang.String ppublico, java.lang.String pfechaini, java.lang.String pfechafin) throws java.rmi.RemoteException{
    if (wSPortType == null)
      _initWSPortTypeProxy();
    return wSPortType.wsproyectosgrupoinv(plengua, pcodgrp, ppublico, pfechaini, pfechafin);
  }
  
  public montgo.WS_xsd.Montgo_WsListProyectosInv wsproyectosinst(java.lang.String plengua, java.lang.String pcodinst, java.lang.String ppublico, java.lang.String pfechaini, java.lang.String pfechafin) throws java.rmi.RemoteException{
    if (wSPortType == null)
      _initWSPortTypeProxy();
    return wSPortType.wsproyectosinst(plengua, pcodinst, ppublico, pfechaini, pfechafin);
  }
  
  public montgo.WS_xsd.Montgo_WsListHorarioAgrup wshorarioagrp(java.lang.String plengua, java.lang.String pcurso, java.lang.String pagrupa) throws java.rmi.RemoteException{
    if (wSPortType == null)
      _initWSPortTypeProxy();
    return wSPortType.wshorarioagrp(plengua, pcurso, pagrupa);
  }
  
  public montgo.WS_xsd.Montgo_WsListHorarios wshorarios(java.lang.String plengua, java.lang.String pcurso, java.lang.String pcodasi, java.lang.String porden) throws java.rmi.RemoteException{
    if (wSPortType == null)
      _initWSPortTypeProxy();
    return wSPortType.wshorarios(plengua, pcurso, pcodasi, porden);
  }
  
  public montgo.WS_xsd.Montgo_WsListProyectosInv wsproyectosdepto(java.lang.String plengua, java.lang.String pcoddep, java.lang.String ppublico, java.lang.String pfechaini, java.lang.String pfechafin) throws java.rmi.RemoteException{
    if (wSPortType == null)
      _initWSPortTypeProxy();
    return wSPortType.wsproyectosdepto(plengua, pcoddep, ppublico, pfechaini, pfechafin);
  }
  
  public montgo.WS_xsd.Montgo_WsListFechaexa wsfechaexamenesasi(java.lang.String plengua, java.lang.String pcodest, java.lang.String pcurso, java.lang.String pcodasi, java.lang.String pcodconvoc, java.lang.String porden) throws java.rmi.RemoteException{
    if (wSPortType == null)
      _initWSPortTypeProxy();
    return wSPortType.wsfechaexamenesasi(plengua, pcodest, pcurso, pcodasi, pcodconvoc, porden);
  }
  
  public montgo.WS_xsd.Montgo_WsListAsignaturas wsasidepto(java.lang.String plengua, java.lang.String pcurso, java.lang.String pcoddep, java.lang.String pcodest) throws java.rmi.RemoteException{
    if (wSPortType == null)
      _initWSPortTypeProxy();
    return wSPortType.wsasidepto(plengua, pcurso, pcoddep, pcodest);
  }
  
  public montgo.WS_xsd.Montgo_WsListBibliografia wsbibliografia(java.lang.String plengua, java.lang.String pcurso, java.lang.String pcodasi, java.lang.String porden) throws java.rmi.RemoteException{
    if (wSPortType == null)
      _initWSPortTypeProxy();
    return wSPortType.wsbibliografia(plengua, pcurso, pcodasi, porden);
  }
  
  
}