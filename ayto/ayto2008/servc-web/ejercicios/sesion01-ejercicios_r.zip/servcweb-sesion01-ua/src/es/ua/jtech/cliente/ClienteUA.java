package es.ua.jtech.cliente;

import java.rmi.RemoteException;

import montgo.WS_xsd.Montgo_WsListHorarios;
import montgo.WS_xsd.Montgo_WsObjHorariosUser;
import UASI.WS_wsdl.WSPortType;
import UASI.WS_wsdl.WSPortTypeProxy;

public class ClienteUA {


	public static void main(String[] args) throws RemoteException {
		WSPortType servicio = new WSPortTypeProxy();
		
		Montgo_WsListHorarios listaHorarios = servicio.wshorarios("C", "2008-09", "9181", "T");
		Montgo_WsObjHorariosUser [] horarios = listaHorarios.getArray();
		for(Montgo_WsObjHorariosUser horario: horarios) {
			System.out.println(horario.getDiasemana() + " " + horario.getHoraini() + "-" + horario.getHorafin() + " " + horario.getTeopra());
		}
	}

}
