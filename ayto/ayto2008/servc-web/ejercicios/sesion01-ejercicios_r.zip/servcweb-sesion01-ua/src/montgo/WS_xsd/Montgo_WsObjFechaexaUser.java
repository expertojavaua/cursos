/**
 * Montgo_WsObjFechaexaUser.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package montgo.WS_xsd;

public class Montgo_WsObjFechaexaUser  implements java.io.Serializable {
    private java.lang.String fecha;

    private java.lang.String codasi;

    private java.lang.String nomasi;

    private java.lang.String codgrp;

    private java.lang.String codconv;

    private java.lang.String conv;

    private java.lang.String observaciones;

    private java.lang.String aulas;

    public Montgo_WsObjFechaexaUser() {
    }

    public Montgo_WsObjFechaexaUser(
           java.lang.String fecha,
           java.lang.String codasi,
           java.lang.String nomasi,
           java.lang.String codgrp,
           java.lang.String codconv,
           java.lang.String conv,
           java.lang.String observaciones,
           java.lang.String aulas) {
           this.fecha = fecha;
           this.codasi = codasi;
           this.nomasi = nomasi;
           this.codgrp = codgrp;
           this.codconv = codconv;
           this.conv = conv;
           this.observaciones = observaciones;
           this.aulas = aulas;
    }


    /**
     * Gets the fecha value for this Montgo_WsObjFechaexaUser.
     * 
     * @return fecha
     */
    public java.lang.String getFecha() {
        return fecha;
    }


    /**
     * Sets the fecha value for this Montgo_WsObjFechaexaUser.
     * 
     * @param fecha
     */
    public void setFecha(java.lang.String fecha) {
        this.fecha = fecha;
    }


    /**
     * Gets the codasi value for this Montgo_WsObjFechaexaUser.
     * 
     * @return codasi
     */
    public java.lang.String getCodasi() {
        return codasi;
    }


    /**
     * Sets the codasi value for this Montgo_WsObjFechaexaUser.
     * 
     * @param codasi
     */
    public void setCodasi(java.lang.String codasi) {
        this.codasi = codasi;
    }


    /**
     * Gets the nomasi value for this Montgo_WsObjFechaexaUser.
     * 
     * @return nomasi
     */
    public java.lang.String getNomasi() {
        return nomasi;
    }


    /**
     * Sets the nomasi value for this Montgo_WsObjFechaexaUser.
     * 
     * @param nomasi
     */
    public void setNomasi(java.lang.String nomasi) {
        this.nomasi = nomasi;
    }


    /**
     * Gets the codgrp value for this Montgo_WsObjFechaexaUser.
     * 
     * @return codgrp
     */
    public java.lang.String getCodgrp() {
        return codgrp;
    }


    /**
     * Sets the codgrp value for this Montgo_WsObjFechaexaUser.
     * 
     * @param codgrp
     */
    public void setCodgrp(java.lang.String codgrp) {
        this.codgrp = codgrp;
    }


    /**
     * Gets the codconv value for this Montgo_WsObjFechaexaUser.
     * 
     * @return codconv
     */
    public java.lang.String getCodconv() {
        return codconv;
    }


    /**
     * Sets the codconv value for this Montgo_WsObjFechaexaUser.
     * 
     * @param codconv
     */
    public void setCodconv(java.lang.String codconv) {
        this.codconv = codconv;
    }


    /**
     * Gets the conv value for this Montgo_WsObjFechaexaUser.
     * 
     * @return conv
     */
    public java.lang.String getConv() {
        return conv;
    }


    /**
     * Sets the conv value for this Montgo_WsObjFechaexaUser.
     * 
     * @param conv
     */
    public void setConv(java.lang.String conv) {
        this.conv = conv;
    }


    /**
     * Gets the observaciones value for this Montgo_WsObjFechaexaUser.
     * 
     * @return observaciones
     */
    public java.lang.String getObservaciones() {
        return observaciones;
    }


    /**
     * Sets the observaciones value for this Montgo_WsObjFechaexaUser.
     * 
     * @param observaciones
     */
    public void setObservaciones(java.lang.String observaciones) {
        this.observaciones = observaciones;
    }


    /**
     * Gets the aulas value for this Montgo_WsObjFechaexaUser.
     * 
     * @return aulas
     */
    public java.lang.String getAulas() {
        return aulas;
    }


    /**
     * Sets the aulas value for this Montgo_WsObjFechaexaUser.
     * 
     * @param aulas
     */
    public void setAulas(java.lang.String aulas) {
        this.aulas = aulas;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Montgo_WsObjFechaexaUser)) return false;
        Montgo_WsObjFechaexaUser other = (Montgo_WsObjFechaexaUser) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.fecha==null && other.getFecha()==null) || 
             (this.fecha!=null &&
              this.fecha.equals(other.getFecha()))) &&
            ((this.codasi==null && other.getCodasi()==null) || 
             (this.codasi!=null &&
              this.codasi.equals(other.getCodasi()))) &&
            ((this.nomasi==null && other.getNomasi()==null) || 
             (this.nomasi!=null &&
              this.nomasi.equals(other.getNomasi()))) &&
            ((this.codgrp==null && other.getCodgrp()==null) || 
             (this.codgrp!=null &&
              this.codgrp.equals(other.getCodgrp()))) &&
            ((this.codconv==null && other.getCodconv()==null) || 
             (this.codconv!=null &&
              this.codconv.equals(other.getCodconv()))) &&
            ((this.conv==null && other.getConv()==null) || 
             (this.conv!=null &&
              this.conv.equals(other.getConv()))) &&
            ((this.observaciones==null && other.getObservaciones()==null) || 
             (this.observaciones!=null &&
              this.observaciones.equals(other.getObservaciones()))) &&
            ((this.aulas==null && other.getAulas()==null) || 
             (this.aulas!=null &&
              this.aulas.equals(other.getAulas())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getFecha() != null) {
            _hashCode += getFecha().hashCode();
        }
        if (getCodasi() != null) {
            _hashCode += getCodasi().hashCode();
        }
        if (getNomasi() != null) {
            _hashCode += getNomasi().hashCode();
        }
        if (getCodgrp() != null) {
            _hashCode += getCodgrp().hashCode();
        }
        if (getCodconv() != null) {
            _hashCode += getCodconv().hashCode();
        }
        if (getConv() != null) {
            _hashCode += getConv().hashCode();
        }
        if (getObservaciones() != null) {
            _hashCode += getObservaciones().hashCode();
        }
        if (getAulas() != null) {
            _hashCode += getAulas().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Montgo_WsObjFechaexaUser.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://montgo/WS.xsd", "montgo_WsObjFechaexaUser"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fecha");
        elemField.setXmlName(new javax.xml.namespace.QName("", "fecha"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codasi");
        elemField.setXmlName(new javax.xml.namespace.QName("", "codasi"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomasi");
        elemField.setXmlName(new javax.xml.namespace.QName("", "nomasi"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codgrp");
        elemField.setXmlName(new javax.xml.namespace.QName("", "codgrp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codconv");
        elemField.setXmlName(new javax.xml.namespace.QName("", "codconv"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("conv");
        elemField.setXmlName(new javax.xml.namespace.QName("", "conv"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("observaciones");
        elemField.setXmlName(new javax.xml.namespace.QName("", "observaciones"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("aulas");
        elemField.setXmlName(new javax.xml.namespace.QName("", "aulas"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
