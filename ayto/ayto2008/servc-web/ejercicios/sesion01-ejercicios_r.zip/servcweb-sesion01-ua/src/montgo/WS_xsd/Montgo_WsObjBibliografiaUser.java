/**
 * Montgo_WsObjBibliografiaUser.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package montgo.WS_xsd;

public class Montgo_WsObjBibliografiaUser  implements java.io.Serializable {
    private java.lang.String codusu;

    private java.lang.String desusuario;

    private java.lang.String codbiblio;

    private java.lang.String nivel;

    private java.lang.String categoria;

    private java.lang.String escomun;

    private java.lang.String observaciones;

    private java.lang.String titulo;

    private java.lang.String autores;

    private java.lang.String editorial;

    private java.lang.String lugaredicion;

    private java.lang.String anyo;

    private java.lang.String edicion;

    private java.lang.String localizacion;

    private java.lang.String urlprofesor;

    private java.lang.String isbn;

    private java.lang.String validadosibyd;

    private java.lang.String biblioteca;

    private java.lang.String parametrocgi;

    private java.lang.String parametrocgi2;

    public Montgo_WsObjBibliografiaUser() {
    }

    public Montgo_WsObjBibliografiaUser(
           java.lang.String codusu,
           java.lang.String desusuario,
           java.lang.String codbiblio,
           java.lang.String nivel,
           java.lang.String categoria,
           java.lang.String escomun,
           java.lang.String observaciones,
           java.lang.String titulo,
           java.lang.String autores,
           java.lang.String editorial,
           java.lang.String lugaredicion,
           java.lang.String anyo,
           java.lang.String edicion,
           java.lang.String localizacion,
           java.lang.String urlprofesor,
           java.lang.String isbn,
           java.lang.String validadosibyd,
           java.lang.String biblioteca,
           java.lang.String parametrocgi,
           java.lang.String parametrocgi2) {
           this.codusu = codusu;
           this.desusuario = desusuario;
           this.codbiblio = codbiblio;
           this.nivel = nivel;
           this.categoria = categoria;
           this.escomun = escomun;
           this.observaciones = observaciones;
           this.titulo = titulo;
           this.autores = autores;
           this.editorial = editorial;
           this.lugaredicion = lugaredicion;
           this.anyo = anyo;
           this.edicion = edicion;
           this.localizacion = localizacion;
           this.urlprofesor = urlprofesor;
           this.isbn = isbn;
           this.validadosibyd = validadosibyd;
           this.biblioteca = biblioteca;
           this.parametrocgi = parametrocgi;
           this.parametrocgi2 = parametrocgi2;
    }


    /**
     * Gets the codusu value for this Montgo_WsObjBibliografiaUser.
     * 
     * @return codusu
     */
    public java.lang.String getCodusu() {
        return codusu;
    }


    /**
     * Sets the codusu value for this Montgo_WsObjBibliografiaUser.
     * 
     * @param codusu
     */
    public void setCodusu(java.lang.String codusu) {
        this.codusu = codusu;
    }


    /**
     * Gets the desusuario value for this Montgo_WsObjBibliografiaUser.
     * 
     * @return desusuario
     */
    public java.lang.String getDesusuario() {
        return desusuario;
    }


    /**
     * Sets the desusuario value for this Montgo_WsObjBibliografiaUser.
     * 
     * @param desusuario
     */
    public void setDesusuario(java.lang.String desusuario) {
        this.desusuario = desusuario;
    }


    /**
     * Gets the codbiblio value for this Montgo_WsObjBibliografiaUser.
     * 
     * @return codbiblio
     */
    public java.lang.String getCodbiblio() {
        return codbiblio;
    }


    /**
     * Sets the codbiblio value for this Montgo_WsObjBibliografiaUser.
     * 
     * @param codbiblio
     */
    public void setCodbiblio(java.lang.String codbiblio) {
        this.codbiblio = codbiblio;
    }


    /**
     * Gets the nivel value for this Montgo_WsObjBibliografiaUser.
     * 
     * @return nivel
     */
    public java.lang.String getNivel() {
        return nivel;
    }


    /**
     * Sets the nivel value for this Montgo_WsObjBibliografiaUser.
     * 
     * @param nivel
     */
    public void setNivel(java.lang.String nivel) {
        this.nivel = nivel;
    }


    /**
     * Gets the categoria value for this Montgo_WsObjBibliografiaUser.
     * 
     * @return categoria
     */
    public java.lang.String getCategoria() {
        return categoria;
    }


    /**
     * Sets the categoria value for this Montgo_WsObjBibliografiaUser.
     * 
     * @param categoria
     */
    public void setCategoria(java.lang.String categoria) {
        this.categoria = categoria;
    }


    /**
     * Gets the escomun value for this Montgo_WsObjBibliografiaUser.
     * 
     * @return escomun
     */
    public java.lang.String getEscomun() {
        return escomun;
    }


    /**
     * Sets the escomun value for this Montgo_WsObjBibliografiaUser.
     * 
     * @param escomun
     */
    public void setEscomun(java.lang.String escomun) {
        this.escomun = escomun;
    }


    /**
     * Gets the observaciones value for this Montgo_WsObjBibliografiaUser.
     * 
     * @return observaciones
     */
    public java.lang.String getObservaciones() {
        return observaciones;
    }


    /**
     * Sets the observaciones value for this Montgo_WsObjBibliografiaUser.
     * 
     * @param observaciones
     */
    public void setObservaciones(java.lang.String observaciones) {
        this.observaciones = observaciones;
    }


    /**
     * Gets the titulo value for this Montgo_WsObjBibliografiaUser.
     * 
     * @return titulo
     */
    public java.lang.String getTitulo() {
        return titulo;
    }


    /**
     * Sets the titulo value for this Montgo_WsObjBibliografiaUser.
     * 
     * @param titulo
     */
    public void setTitulo(java.lang.String titulo) {
        this.titulo = titulo;
    }


    /**
     * Gets the autores value for this Montgo_WsObjBibliografiaUser.
     * 
     * @return autores
     */
    public java.lang.String getAutores() {
        return autores;
    }


    /**
     * Sets the autores value for this Montgo_WsObjBibliografiaUser.
     * 
     * @param autores
     */
    public void setAutores(java.lang.String autores) {
        this.autores = autores;
    }


    /**
     * Gets the editorial value for this Montgo_WsObjBibliografiaUser.
     * 
     * @return editorial
     */
    public java.lang.String getEditorial() {
        return editorial;
    }


    /**
     * Sets the editorial value for this Montgo_WsObjBibliografiaUser.
     * 
     * @param editorial
     */
    public void setEditorial(java.lang.String editorial) {
        this.editorial = editorial;
    }


    /**
     * Gets the lugaredicion value for this Montgo_WsObjBibliografiaUser.
     * 
     * @return lugaredicion
     */
    public java.lang.String getLugaredicion() {
        return lugaredicion;
    }


    /**
     * Sets the lugaredicion value for this Montgo_WsObjBibliografiaUser.
     * 
     * @param lugaredicion
     */
    public void setLugaredicion(java.lang.String lugaredicion) {
        this.lugaredicion = lugaredicion;
    }


    /**
     * Gets the anyo value for this Montgo_WsObjBibliografiaUser.
     * 
     * @return anyo
     */
    public java.lang.String getAnyo() {
        return anyo;
    }


    /**
     * Sets the anyo value for this Montgo_WsObjBibliografiaUser.
     * 
     * @param anyo
     */
    public void setAnyo(java.lang.String anyo) {
        this.anyo = anyo;
    }


    /**
     * Gets the edicion value for this Montgo_WsObjBibliografiaUser.
     * 
     * @return edicion
     */
    public java.lang.String getEdicion() {
        return edicion;
    }


    /**
     * Sets the edicion value for this Montgo_WsObjBibliografiaUser.
     * 
     * @param edicion
     */
    public void setEdicion(java.lang.String edicion) {
        this.edicion = edicion;
    }


    /**
     * Gets the localizacion value for this Montgo_WsObjBibliografiaUser.
     * 
     * @return localizacion
     */
    public java.lang.String getLocalizacion() {
        return localizacion;
    }


    /**
     * Sets the localizacion value for this Montgo_WsObjBibliografiaUser.
     * 
     * @param localizacion
     */
    public void setLocalizacion(java.lang.String localizacion) {
        this.localizacion = localizacion;
    }


    /**
     * Gets the urlprofesor value for this Montgo_WsObjBibliografiaUser.
     * 
     * @return urlprofesor
     */
    public java.lang.String getUrlprofesor() {
        return urlprofesor;
    }


    /**
     * Sets the urlprofesor value for this Montgo_WsObjBibliografiaUser.
     * 
     * @param urlprofesor
     */
    public void setUrlprofesor(java.lang.String urlprofesor) {
        this.urlprofesor = urlprofesor;
    }


    /**
     * Gets the isbn value for this Montgo_WsObjBibliografiaUser.
     * 
     * @return isbn
     */
    public java.lang.String getIsbn() {
        return isbn;
    }


    /**
     * Sets the isbn value for this Montgo_WsObjBibliografiaUser.
     * 
     * @param isbn
     */
    public void setIsbn(java.lang.String isbn) {
        this.isbn = isbn;
    }


    /**
     * Gets the validadosibyd value for this Montgo_WsObjBibliografiaUser.
     * 
     * @return validadosibyd
     */
    public java.lang.String getValidadosibyd() {
        return validadosibyd;
    }


    /**
     * Sets the validadosibyd value for this Montgo_WsObjBibliografiaUser.
     * 
     * @param validadosibyd
     */
    public void setValidadosibyd(java.lang.String validadosibyd) {
        this.validadosibyd = validadosibyd;
    }


    /**
     * Gets the biblioteca value for this Montgo_WsObjBibliografiaUser.
     * 
     * @return biblioteca
     */
    public java.lang.String getBiblioteca() {
        return biblioteca;
    }


    /**
     * Sets the biblioteca value for this Montgo_WsObjBibliografiaUser.
     * 
     * @param biblioteca
     */
    public void setBiblioteca(java.lang.String biblioteca) {
        this.biblioteca = biblioteca;
    }


    /**
     * Gets the parametrocgi value for this Montgo_WsObjBibliografiaUser.
     * 
     * @return parametrocgi
     */
    public java.lang.String getParametrocgi() {
        return parametrocgi;
    }


    /**
     * Sets the parametrocgi value for this Montgo_WsObjBibliografiaUser.
     * 
     * @param parametrocgi
     */
    public void setParametrocgi(java.lang.String parametrocgi) {
        this.parametrocgi = parametrocgi;
    }


    /**
     * Gets the parametrocgi2 value for this Montgo_WsObjBibliografiaUser.
     * 
     * @return parametrocgi2
     */
    public java.lang.String getParametrocgi2() {
        return parametrocgi2;
    }


    /**
     * Sets the parametrocgi2 value for this Montgo_WsObjBibliografiaUser.
     * 
     * @param parametrocgi2
     */
    public void setParametrocgi2(java.lang.String parametrocgi2) {
        this.parametrocgi2 = parametrocgi2;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Montgo_WsObjBibliografiaUser)) return false;
        Montgo_WsObjBibliografiaUser other = (Montgo_WsObjBibliografiaUser) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codusu==null && other.getCodusu()==null) || 
             (this.codusu!=null &&
              this.codusu.equals(other.getCodusu()))) &&
            ((this.desusuario==null && other.getDesusuario()==null) || 
             (this.desusuario!=null &&
              this.desusuario.equals(other.getDesusuario()))) &&
            ((this.codbiblio==null && other.getCodbiblio()==null) || 
             (this.codbiblio!=null &&
              this.codbiblio.equals(other.getCodbiblio()))) &&
            ((this.nivel==null && other.getNivel()==null) || 
             (this.nivel!=null &&
              this.nivel.equals(other.getNivel()))) &&
            ((this.categoria==null && other.getCategoria()==null) || 
             (this.categoria!=null &&
              this.categoria.equals(other.getCategoria()))) &&
            ((this.escomun==null && other.getEscomun()==null) || 
             (this.escomun!=null &&
              this.escomun.equals(other.getEscomun()))) &&
            ((this.observaciones==null && other.getObservaciones()==null) || 
             (this.observaciones!=null &&
              this.observaciones.equals(other.getObservaciones()))) &&
            ((this.titulo==null && other.getTitulo()==null) || 
             (this.titulo!=null &&
              this.titulo.equals(other.getTitulo()))) &&
            ((this.autores==null && other.getAutores()==null) || 
             (this.autores!=null &&
              this.autores.equals(other.getAutores()))) &&
            ((this.editorial==null && other.getEditorial()==null) || 
             (this.editorial!=null &&
              this.editorial.equals(other.getEditorial()))) &&
            ((this.lugaredicion==null && other.getLugaredicion()==null) || 
             (this.lugaredicion!=null &&
              this.lugaredicion.equals(other.getLugaredicion()))) &&
            ((this.anyo==null && other.getAnyo()==null) || 
             (this.anyo!=null &&
              this.anyo.equals(other.getAnyo()))) &&
            ((this.edicion==null && other.getEdicion()==null) || 
             (this.edicion!=null &&
              this.edicion.equals(other.getEdicion()))) &&
            ((this.localizacion==null && other.getLocalizacion()==null) || 
             (this.localizacion!=null &&
              this.localizacion.equals(other.getLocalizacion()))) &&
            ((this.urlprofesor==null && other.getUrlprofesor()==null) || 
             (this.urlprofesor!=null &&
              this.urlprofesor.equals(other.getUrlprofesor()))) &&
            ((this.isbn==null && other.getIsbn()==null) || 
             (this.isbn!=null &&
              this.isbn.equals(other.getIsbn()))) &&
            ((this.validadosibyd==null && other.getValidadosibyd()==null) || 
             (this.validadosibyd!=null &&
              this.validadosibyd.equals(other.getValidadosibyd()))) &&
            ((this.biblioteca==null && other.getBiblioteca()==null) || 
             (this.biblioteca!=null &&
              this.biblioteca.equals(other.getBiblioteca()))) &&
            ((this.parametrocgi==null && other.getParametrocgi()==null) || 
             (this.parametrocgi!=null &&
              this.parametrocgi.equals(other.getParametrocgi()))) &&
            ((this.parametrocgi2==null && other.getParametrocgi2()==null) || 
             (this.parametrocgi2!=null &&
              this.parametrocgi2.equals(other.getParametrocgi2())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodusu() != null) {
            _hashCode += getCodusu().hashCode();
        }
        if (getDesusuario() != null) {
            _hashCode += getDesusuario().hashCode();
        }
        if (getCodbiblio() != null) {
            _hashCode += getCodbiblio().hashCode();
        }
        if (getNivel() != null) {
            _hashCode += getNivel().hashCode();
        }
        if (getCategoria() != null) {
            _hashCode += getCategoria().hashCode();
        }
        if (getEscomun() != null) {
            _hashCode += getEscomun().hashCode();
        }
        if (getObservaciones() != null) {
            _hashCode += getObservaciones().hashCode();
        }
        if (getTitulo() != null) {
            _hashCode += getTitulo().hashCode();
        }
        if (getAutores() != null) {
            _hashCode += getAutores().hashCode();
        }
        if (getEditorial() != null) {
            _hashCode += getEditorial().hashCode();
        }
        if (getLugaredicion() != null) {
            _hashCode += getLugaredicion().hashCode();
        }
        if (getAnyo() != null) {
            _hashCode += getAnyo().hashCode();
        }
        if (getEdicion() != null) {
            _hashCode += getEdicion().hashCode();
        }
        if (getLocalizacion() != null) {
            _hashCode += getLocalizacion().hashCode();
        }
        if (getUrlprofesor() != null) {
            _hashCode += getUrlprofesor().hashCode();
        }
        if (getIsbn() != null) {
            _hashCode += getIsbn().hashCode();
        }
        if (getValidadosibyd() != null) {
            _hashCode += getValidadosibyd().hashCode();
        }
        if (getBiblioteca() != null) {
            _hashCode += getBiblioteca().hashCode();
        }
        if (getParametrocgi() != null) {
            _hashCode += getParametrocgi().hashCode();
        }
        if (getParametrocgi2() != null) {
            _hashCode += getParametrocgi2().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Montgo_WsObjBibliografiaUser.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://montgo/WS.xsd", "montgo_WsObjBibliografiaUser"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codusu");
        elemField.setXmlName(new javax.xml.namespace.QName("", "codusu"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desusuario");
        elemField.setXmlName(new javax.xml.namespace.QName("", "desusuario"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codbiblio");
        elemField.setXmlName(new javax.xml.namespace.QName("", "codbiblio"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nivel");
        elemField.setXmlName(new javax.xml.namespace.QName("", "nivel"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("categoria");
        elemField.setXmlName(new javax.xml.namespace.QName("", "categoria"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("escomun");
        elemField.setXmlName(new javax.xml.namespace.QName("", "escomun"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("observaciones");
        elemField.setXmlName(new javax.xml.namespace.QName("", "observaciones"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("titulo");
        elemField.setXmlName(new javax.xml.namespace.QName("", "titulo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("autores");
        elemField.setXmlName(new javax.xml.namespace.QName("", "autores"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("editorial");
        elemField.setXmlName(new javax.xml.namespace.QName("", "editorial"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("lugaredicion");
        elemField.setXmlName(new javax.xml.namespace.QName("", "lugaredicion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("anyo");
        elemField.setXmlName(new javax.xml.namespace.QName("", "anyo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("edicion");
        elemField.setXmlName(new javax.xml.namespace.QName("", "edicion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("localizacion");
        elemField.setXmlName(new javax.xml.namespace.QName("", "localizacion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("urlprofesor");
        elemField.setXmlName(new javax.xml.namespace.QName("", "urlprofesor"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("isbn");
        elemField.setXmlName(new javax.xml.namespace.QName("", "isbn"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("validadosibyd");
        elemField.setXmlName(new javax.xml.namespace.QName("", "validadosibyd"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("biblioteca");
        elemField.setXmlName(new javax.xml.namespace.QName("", "biblioteca"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("parametrocgi");
        elemField.setXmlName(new javax.xml.namespace.QName("", "parametrocgi"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("parametrocgi2");
        elemField.setXmlName(new javax.xml.namespace.QName("", "parametrocgi2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
