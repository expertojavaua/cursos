/**
 * Montgo_WsObjHorarioAgrupUser.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package montgo.WS_xsd;

public class Montgo_WsObjHorarioAgrupUser  implements java.io.Serializable {
    private java.lang.String idagrupa;

    private java.lang.String descagr;

    private java.lang.String codgrp;

    private java.lang.String nomgrp;

    private java.lang.String aula;

    private java.lang.String descaula;

    private java.lang.String dni;

    private java.lang.String nombre;

    private java.lang.String apellido1;

    private java.lang.String apellido2;

    private java.lang.String idplaza;

    private java.lang.String nomplaz;

    private java.lang.String fechainicio;

    private java.lang.String fechafin;

    private java.lang.String horaini;

    private java.lang.String horafin;

    private java.lang.String idactiv;

    private java.lang.String nomact;

    private java.lang.String teopra;

    private java.lang.String codasi;

    private java.lang.String nomasi;

    private java.lang.String dia;

    private java.lang.String diasem;

    private java.lang.String edificio;

    private java.lang.String aulasig;

    public Montgo_WsObjHorarioAgrupUser() {
    }

    public Montgo_WsObjHorarioAgrupUser(
           java.lang.String idagrupa,
           java.lang.String descagr,
           java.lang.String codgrp,
           java.lang.String nomgrp,
           java.lang.String aula,
           java.lang.String descaula,
           java.lang.String dni,
           java.lang.String nombre,
           java.lang.String apellido1,
           java.lang.String apellido2,
           java.lang.String idplaza,
           java.lang.String nomplaz,
           java.lang.String fechainicio,
           java.lang.String fechafin,
           java.lang.String horaini,
           java.lang.String horafin,
           java.lang.String idactiv,
           java.lang.String nomact,
           java.lang.String teopra,
           java.lang.String codasi,
           java.lang.String nomasi,
           java.lang.String dia,
           java.lang.String diasem,
           java.lang.String edificio,
           java.lang.String aulasig) {
           this.idagrupa = idagrupa;
           this.descagr = descagr;
           this.codgrp = codgrp;
           this.nomgrp = nomgrp;
           this.aula = aula;
           this.descaula = descaula;
           this.dni = dni;
           this.nombre = nombre;
           this.apellido1 = apellido1;
           this.apellido2 = apellido2;
           this.idplaza = idplaza;
           this.nomplaz = nomplaz;
           this.fechainicio = fechainicio;
           this.fechafin = fechafin;
           this.horaini = horaini;
           this.horafin = horafin;
           this.idactiv = idactiv;
           this.nomact = nomact;
           this.teopra = teopra;
           this.codasi = codasi;
           this.nomasi = nomasi;
           this.dia = dia;
           this.diasem = diasem;
           this.edificio = edificio;
           this.aulasig = aulasig;
    }


    /**
     * Gets the idagrupa value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @return idagrupa
     */
    public java.lang.String getIdagrupa() {
        return idagrupa;
    }


    /**
     * Sets the idagrupa value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @param idagrupa
     */
    public void setIdagrupa(java.lang.String idagrupa) {
        this.idagrupa = idagrupa;
    }


    /**
     * Gets the descagr value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @return descagr
     */
    public java.lang.String getDescagr() {
        return descagr;
    }


    /**
     * Sets the descagr value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @param descagr
     */
    public void setDescagr(java.lang.String descagr) {
        this.descagr = descagr;
    }


    /**
     * Gets the codgrp value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @return codgrp
     */
    public java.lang.String getCodgrp() {
        return codgrp;
    }


    /**
     * Sets the codgrp value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @param codgrp
     */
    public void setCodgrp(java.lang.String codgrp) {
        this.codgrp = codgrp;
    }


    /**
     * Gets the nomgrp value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @return nomgrp
     */
    public java.lang.String getNomgrp() {
        return nomgrp;
    }


    /**
     * Sets the nomgrp value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @param nomgrp
     */
    public void setNomgrp(java.lang.String nomgrp) {
        this.nomgrp = nomgrp;
    }


    /**
     * Gets the aula value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @return aula
     */
    public java.lang.String getAula() {
        return aula;
    }


    /**
     * Sets the aula value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @param aula
     */
    public void setAula(java.lang.String aula) {
        this.aula = aula;
    }


    /**
     * Gets the descaula value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @return descaula
     */
    public java.lang.String getDescaula() {
        return descaula;
    }


    /**
     * Sets the descaula value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @param descaula
     */
    public void setDescaula(java.lang.String descaula) {
        this.descaula = descaula;
    }


    /**
     * Gets the dni value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @return dni
     */
    public java.lang.String getDni() {
        return dni;
    }


    /**
     * Sets the dni value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @param dni
     */
    public void setDni(java.lang.String dni) {
        this.dni = dni;
    }


    /**
     * Gets the nombre value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @return nombre
     */
    public java.lang.String getNombre() {
        return nombre;
    }


    /**
     * Sets the nombre value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @param nombre
     */
    public void setNombre(java.lang.String nombre) {
        this.nombre = nombre;
    }


    /**
     * Gets the apellido1 value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @return apellido1
     */
    public java.lang.String getApellido1() {
        return apellido1;
    }


    /**
     * Sets the apellido1 value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @param apellido1
     */
    public void setApellido1(java.lang.String apellido1) {
        this.apellido1 = apellido1;
    }


    /**
     * Gets the apellido2 value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @return apellido2
     */
    public java.lang.String getApellido2() {
        return apellido2;
    }


    /**
     * Sets the apellido2 value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @param apellido2
     */
    public void setApellido2(java.lang.String apellido2) {
        this.apellido2 = apellido2;
    }


    /**
     * Gets the idplaza value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @return idplaza
     */
    public java.lang.String getIdplaza() {
        return idplaza;
    }


    /**
     * Sets the idplaza value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @param idplaza
     */
    public void setIdplaza(java.lang.String idplaza) {
        this.idplaza = idplaza;
    }


    /**
     * Gets the nomplaz value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @return nomplaz
     */
    public java.lang.String getNomplaz() {
        return nomplaz;
    }


    /**
     * Sets the nomplaz value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @param nomplaz
     */
    public void setNomplaz(java.lang.String nomplaz) {
        this.nomplaz = nomplaz;
    }


    /**
     * Gets the fechainicio value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @return fechainicio
     */
    public java.lang.String getFechainicio() {
        return fechainicio;
    }


    /**
     * Sets the fechainicio value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @param fechainicio
     */
    public void setFechainicio(java.lang.String fechainicio) {
        this.fechainicio = fechainicio;
    }


    /**
     * Gets the fechafin value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @return fechafin
     */
    public java.lang.String getFechafin() {
        return fechafin;
    }


    /**
     * Sets the fechafin value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @param fechafin
     */
    public void setFechafin(java.lang.String fechafin) {
        this.fechafin = fechafin;
    }


    /**
     * Gets the horaini value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @return horaini
     */
    public java.lang.String getHoraini() {
        return horaini;
    }


    /**
     * Sets the horaini value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @param horaini
     */
    public void setHoraini(java.lang.String horaini) {
        this.horaini = horaini;
    }


    /**
     * Gets the horafin value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @return horafin
     */
    public java.lang.String getHorafin() {
        return horafin;
    }


    /**
     * Sets the horafin value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @param horafin
     */
    public void setHorafin(java.lang.String horafin) {
        this.horafin = horafin;
    }


    /**
     * Gets the idactiv value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @return idactiv
     */
    public java.lang.String getIdactiv() {
        return idactiv;
    }


    /**
     * Sets the idactiv value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @param idactiv
     */
    public void setIdactiv(java.lang.String idactiv) {
        this.idactiv = idactiv;
    }


    /**
     * Gets the nomact value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @return nomact
     */
    public java.lang.String getNomact() {
        return nomact;
    }


    /**
     * Sets the nomact value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @param nomact
     */
    public void setNomact(java.lang.String nomact) {
        this.nomact = nomact;
    }


    /**
     * Gets the teopra value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @return teopra
     */
    public java.lang.String getTeopra() {
        return teopra;
    }


    /**
     * Sets the teopra value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @param teopra
     */
    public void setTeopra(java.lang.String teopra) {
        this.teopra = teopra;
    }


    /**
     * Gets the codasi value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @return codasi
     */
    public java.lang.String getCodasi() {
        return codasi;
    }


    /**
     * Sets the codasi value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @param codasi
     */
    public void setCodasi(java.lang.String codasi) {
        this.codasi = codasi;
    }


    /**
     * Gets the nomasi value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @return nomasi
     */
    public java.lang.String getNomasi() {
        return nomasi;
    }


    /**
     * Sets the nomasi value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @param nomasi
     */
    public void setNomasi(java.lang.String nomasi) {
        this.nomasi = nomasi;
    }


    /**
     * Gets the dia value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @return dia
     */
    public java.lang.String getDia() {
        return dia;
    }


    /**
     * Sets the dia value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @param dia
     */
    public void setDia(java.lang.String dia) {
        this.dia = dia;
    }


    /**
     * Gets the diasem value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @return diasem
     */
    public java.lang.String getDiasem() {
        return diasem;
    }


    /**
     * Sets the diasem value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @param diasem
     */
    public void setDiasem(java.lang.String diasem) {
        this.diasem = diasem;
    }


    /**
     * Gets the edificio value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @return edificio
     */
    public java.lang.String getEdificio() {
        return edificio;
    }


    /**
     * Sets the edificio value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @param edificio
     */
    public void setEdificio(java.lang.String edificio) {
        this.edificio = edificio;
    }


    /**
     * Gets the aulasig value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @return aulasig
     */
    public java.lang.String getAulasig() {
        return aulasig;
    }


    /**
     * Sets the aulasig value for this Montgo_WsObjHorarioAgrupUser.
     * 
     * @param aulasig
     */
    public void setAulasig(java.lang.String aulasig) {
        this.aulasig = aulasig;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Montgo_WsObjHorarioAgrupUser)) return false;
        Montgo_WsObjHorarioAgrupUser other = (Montgo_WsObjHorarioAgrupUser) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.idagrupa==null && other.getIdagrupa()==null) || 
             (this.idagrupa!=null &&
              this.idagrupa.equals(other.getIdagrupa()))) &&
            ((this.descagr==null && other.getDescagr()==null) || 
             (this.descagr!=null &&
              this.descagr.equals(other.getDescagr()))) &&
            ((this.codgrp==null && other.getCodgrp()==null) || 
             (this.codgrp!=null &&
              this.codgrp.equals(other.getCodgrp()))) &&
            ((this.nomgrp==null && other.getNomgrp()==null) || 
             (this.nomgrp!=null &&
              this.nomgrp.equals(other.getNomgrp()))) &&
            ((this.aula==null && other.getAula()==null) || 
             (this.aula!=null &&
              this.aula.equals(other.getAula()))) &&
            ((this.descaula==null && other.getDescaula()==null) || 
             (this.descaula!=null &&
              this.descaula.equals(other.getDescaula()))) &&
            ((this.dni==null && other.getDni()==null) || 
             (this.dni!=null &&
              this.dni.equals(other.getDni()))) &&
            ((this.nombre==null && other.getNombre()==null) || 
             (this.nombre!=null &&
              this.nombre.equals(other.getNombre()))) &&
            ((this.apellido1==null && other.getApellido1()==null) || 
             (this.apellido1!=null &&
              this.apellido1.equals(other.getApellido1()))) &&
            ((this.apellido2==null && other.getApellido2()==null) || 
             (this.apellido2!=null &&
              this.apellido2.equals(other.getApellido2()))) &&
            ((this.idplaza==null && other.getIdplaza()==null) || 
             (this.idplaza!=null &&
              this.idplaza.equals(other.getIdplaza()))) &&
            ((this.nomplaz==null && other.getNomplaz()==null) || 
             (this.nomplaz!=null &&
              this.nomplaz.equals(other.getNomplaz()))) &&
            ((this.fechainicio==null && other.getFechainicio()==null) || 
             (this.fechainicio!=null &&
              this.fechainicio.equals(other.getFechainicio()))) &&
            ((this.fechafin==null && other.getFechafin()==null) || 
             (this.fechafin!=null &&
              this.fechafin.equals(other.getFechafin()))) &&
            ((this.horaini==null && other.getHoraini()==null) || 
             (this.horaini!=null &&
              this.horaini.equals(other.getHoraini()))) &&
            ((this.horafin==null && other.getHorafin()==null) || 
             (this.horafin!=null &&
              this.horafin.equals(other.getHorafin()))) &&
            ((this.idactiv==null && other.getIdactiv()==null) || 
             (this.idactiv!=null &&
              this.idactiv.equals(other.getIdactiv()))) &&
            ((this.nomact==null && other.getNomact()==null) || 
             (this.nomact!=null &&
              this.nomact.equals(other.getNomact()))) &&
            ((this.teopra==null && other.getTeopra()==null) || 
             (this.teopra!=null &&
              this.teopra.equals(other.getTeopra()))) &&
            ((this.codasi==null && other.getCodasi()==null) || 
             (this.codasi!=null &&
              this.codasi.equals(other.getCodasi()))) &&
            ((this.nomasi==null && other.getNomasi()==null) || 
             (this.nomasi!=null &&
              this.nomasi.equals(other.getNomasi()))) &&
            ((this.dia==null && other.getDia()==null) || 
             (this.dia!=null &&
              this.dia.equals(other.getDia()))) &&
            ((this.diasem==null && other.getDiasem()==null) || 
             (this.diasem!=null &&
              this.diasem.equals(other.getDiasem()))) &&
            ((this.edificio==null && other.getEdificio()==null) || 
             (this.edificio!=null &&
              this.edificio.equals(other.getEdificio()))) &&
            ((this.aulasig==null && other.getAulasig()==null) || 
             (this.aulasig!=null &&
              this.aulasig.equals(other.getAulasig())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getIdagrupa() != null) {
            _hashCode += getIdagrupa().hashCode();
        }
        if (getDescagr() != null) {
            _hashCode += getDescagr().hashCode();
        }
        if (getCodgrp() != null) {
            _hashCode += getCodgrp().hashCode();
        }
        if (getNomgrp() != null) {
            _hashCode += getNomgrp().hashCode();
        }
        if (getAula() != null) {
            _hashCode += getAula().hashCode();
        }
        if (getDescaula() != null) {
            _hashCode += getDescaula().hashCode();
        }
        if (getDni() != null) {
            _hashCode += getDni().hashCode();
        }
        if (getNombre() != null) {
            _hashCode += getNombre().hashCode();
        }
        if (getApellido1() != null) {
            _hashCode += getApellido1().hashCode();
        }
        if (getApellido2() != null) {
            _hashCode += getApellido2().hashCode();
        }
        if (getIdplaza() != null) {
            _hashCode += getIdplaza().hashCode();
        }
        if (getNomplaz() != null) {
            _hashCode += getNomplaz().hashCode();
        }
        if (getFechainicio() != null) {
            _hashCode += getFechainicio().hashCode();
        }
        if (getFechafin() != null) {
            _hashCode += getFechafin().hashCode();
        }
        if (getHoraini() != null) {
            _hashCode += getHoraini().hashCode();
        }
        if (getHorafin() != null) {
            _hashCode += getHorafin().hashCode();
        }
        if (getIdactiv() != null) {
            _hashCode += getIdactiv().hashCode();
        }
        if (getNomact() != null) {
            _hashCode += getNomact().hashCode();
        }
        if (getTeopra() != null) {
            _hashCode += getTeopra().hashCode();
        }
        if (getCodasi() != null) {
            _hashCode += getCodasi().hashCode();
        }
        if (getNomasi() != null) {
            _hashCode += getNomasi().hashCode();
        }
        if (getDia() != null) {
            _hashCode += getDia().hashCode();
        }
        if (getDiasem() != null) {
            _hashCode += getDiasem().hashCode();
        }
        if (getEdificio() != null) {
            _hashCode += getEdificio().hashCode();
        }
        if (getAulasig() != null) {
            _hashCode += getAulasig().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Montgo_WsObjHorarioAgrupUser.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://montgo/WS.xsd", "montgo_WsObjHorarioAgrupUser"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idagrupa");
        elemField.setXmlName(new javax.xml.namespace.QName("", "idagrupa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descagr");
        elemField.setXmlName(new javax.xml.namespace.QName("", "descagr"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codgrp");
        elemField.setXmlName(new javax.xml.namespace.QName("", "codgrp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomgrp");
        elemField.setXmlName(new javax.xml.namespace.QName("", "nomgrp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("aula");
        elemField.setXmlName(new javax.xml.namespace.QName("", "aula"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descaula");
        elemField.setXmlName(new javax.xml.namespace.QName("", "descaula"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dni");
        elemField.setXmlName(new javax.xml.namespace.QName("", "dni"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nombre");
        elemField.setXmlName(new javax.xml.namespace.QName("", "nombre"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("apellido1");
        elemField.setXmlName(new javax.xml.namespace.QName("", "apellido1"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("apellido2");
        elemField.setXmlName(new javax.xml.namespace.QName("", "apellido2"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idplaza");
        elemField.setXmlName(new javax.xml.namespace.QName("", "idplaza"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomplaz");
        elemField.setXmlName(new javax.xml.namespace.QName("", "nomplaz"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fechainicio");
        elemField.setXmlName(new javax.xml.namespace.QName("", "fechainicio"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fechafin");
        elemField.setXmlName(new javax.xml.namespace.QName("", "fechafin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("horaini");
        elemField.setXmlName(new javax.xml.namespace.QName("", "horaini"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("horafin");
        elemField.setXmlName(new javax.xml.namespace.QName("", "horafin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idactiv");
        elemField.setXmlName(new javax.xml.namespace.QName("", "idactiv"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomact");
        elemField.setXmlName(new javax.xml.namespace.QName("", "nomact"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("teopra");
        elemField.setXmlName(new javax.xml.namespace.QName("", "teopra"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codasi");
        elemField.setXmlName(new javax.xml.namespace.QName("", "codasi"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomasi");
        elemField.setXmlName(new javax.xml.namespace.QName("", "nomasi"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dia");
        elemField.setXmlName(new javax.xml.namespace.QName("", "dia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("diasem");
        elemField.setXmlName(new javax.xml.namespace.QName("", "diasem"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("edificio");
        elemField.setXmlName(new javax.xml.namespace.QName("", "edificio"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("aulasig");
        elemField.setXmlName(new javax.xml.namespace.QName("", "aulasig"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
