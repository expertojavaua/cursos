/**
 * Montgo_WsObjAgrupacionesUser.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package montgo.WS_xsd;

public class Montgo_WsObjAgrupacionesUser  implements java.io.Serializable {
    private java.lang.String idagrupa;

    private java.lang.String descagr;

    private java.lang.String enlaceagrp;

    private java.lang.String codcen;

    private java.lang.String desccen;

    private java.lang.String codest;

    private java.lang.String nomest;

    private java.lang.String numcurso;

    private java.lang.String nomturno;

    public Montgo_WsObjAgrupacionesUser() {
    }

    public Montgo_WsObjAgrupacionesUser(
           java.lang.String idagrupa,
           java.lang.String descagr,
           java.lang.String enlaceagrp,
           java.lang.String codcen,
           java.lang.String desccen,
           java.lang.String codest,
           java.lang.String nomest,
           java.lang.String numcurso,
           java.lang.String nomturno) {
           this.idagrupa = idagrupa;
           this.descagr = descagr;
           this.enlaceagrp = enlaceagrp;
           this.codcen = codcen;
           this.desccen = desccen;
           this.codest = codest;
           this.nomest = nomest;
           this.numcurso = numcurso;
           this.nomturno = nomturno;
    }


    /**
     * Gets the idagrupa value for this Montgo_WsObjAgrupacionesUser.
     * 
     * @return idagrupa
     */
    public java.lang.String getIdagrupa() {
        return idagrupa;
    }


    /**
     * Sets the idagrupa value for this Montgo_WsObjAgrupacionesUser.
     * 
     * @param idagrupa
     */
    public void setIdagrupa(java.lang.String idagrupa) {
        this.idagrupa = idagrupa;
    }


    /**
     * Gets the descagr value for this Montgo_WsObjAgrupacionesUser.
     * 
     * @return descagr
     */
    public java.lang.String getDescagr() {
        return descagr;
    }


    /**
     * Sets the descagr value for this Montgo_WsObjAgrupacionesUser.
     * 
     * @param descagr
     */
    public void setDescagr(java.lang.String descagr) {
        this.descagr = descagr;
    }


    /**
     * Gets the enlaceagrp value for this Montgo_WsObjAgrupacionesUser.
     * 
     * @return enlaceagrp
     */
    public java.lang.String getEnlaceagrp() {
        return enlaceagrp;
    }


    /**
     * Sets the enlaceagrp value for this Montgo_WsObjAgrupacionesUser.
     * 
     * @param enlaceagrp
     */
    public void setEnlaceagrp(java.lang.String enlaceagrp) {
        this.enlaceagrp = enlaceagrp;
    }


    /**
     * Gets the codcen value for this Montgo_WsObjAgrupacionesUser.
     * 
     * @return codcen
     */
    public java.lang.String getCodcen() {
        return codcen;
    }


    /**
     * Sets the codcen value for this Montgo_WsObjAgrupacionesUser.
     * 
     * @param codcen
     */
    public void setCodcen(java.lang.String codcen) {
        this.codcen = codcen;
    }


    /**
     * Gets the desccen value for this Montgo_WsObjAgrupacionesUser.
     * 
     * @return desccen
     */
    public java.lang.String getDesccen() {
        return desccen;
    }


    /**
     * Sets the desccen value for this Montgo_WsObjAgrupacionesUser.
     * 
     * @param desccen
     */
    public void setDesccen(java.lang.String desccen) {
        this.desccen = desccen;
    }


    /**
     * Gets the codest value for this Montgo_WsObjAgrupacionesUser.
     * 
     * @return codest
     */
    public java.lang.String getCodest() {
        return codest;
    }


    /**
     * Sets the codest value for this Montgo_WsObjAgrupacionesUser.
     * 
     * @param codest
     */
    public void setCodest(java.lang.String codest) {
        this.codest = codest;
    }


    /**
     * Gets the nomest value for this Montgo_WsObjAgrupacionesUser.
     * 
     * @return nomest
     */
    public java.lang.String getNomest() {
        return nomest;
    }


    /**
     * Sets the nomest value for this Montgo_WsObjAgrupacionesUser.
     * 
     * @param nomest
     */
    public void setNomest(java.lang.String nomest) {
        this.nomest = nomest;
    }


    /**
     * Gets the numcurso value for this Montgo_WsObjAgrupacionesUser.
     * 
     * @return numcurso
     */
    public java.lang.String getNumcurso() {
        return numcurso;
    }


    /**
     * Sets the numcurso value for this Montgo_WsObjAgrupacionesUser.
     * 
     * @param numcurso
     */
    public void setNumcurso(java.lang.String numcurso) {
        this.numcurso = numcurso;
    }


    /**
     * Gets the nomturno value for this Montgo_WsObjAgrupacionesUser.
     * 
     * @return nomturno
     */
    public java.lang.String getNomturno() {
        return nomturno;
    }


    /**
     * Sets the nomturno value for this Montgo_WsObjAgrupacionesUser.
     * 
     * @param nomturno
     */
    public void setNomturno(java.lang.String nomturno) {
        this.nomturno = nomturno;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Montgo_WsObjAgrupacionesUser)) return false;
        Montgo_WsObjAgrupacionesUser other = (Montgo_WsObjAgrupacionesUser) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.idagrupa==null && other.getIdagrupa()==null) || 
             (this.idagrupa!=null &&
              this.idagrupa.equals(other.getIdagrupa()))) &&
            ((this.descagr==null && other.getDescagr()==null) || 
             (this.descagr!=null &&
              this.descagr.equals(other.getDescagr()))) &&
            ((this.enlaceagrp==null && other.getEnlaceagrp()==null) || 
             (this.enlaceagrp!=null &&
              this.enlaceagrp.equals(other.getEnlaceagrp()))) &&
            ((this.codcen==null && other.getCodcen()==null) || 
             (this.codcen!=null &&
              this.codcen.equals(other.getCodcen()))) &&
            ((this.desccen==null && other.getDesccen()==null) || 
             (this.desccen!=null &&
              this.desccen.equals(other.getDesccen()))) &&
            ((this.codest==null && other.getCodest()==null) || 
             (this.codest!=null &&
              this.codest.equals(other.getCodest()))) &&
            ((this.nomest==null && other.getNomest()==null) || 
             (this.nomest!=null &&
              this.nomest.equals(other.getNomest()))) &&
            ((this.numcurso==null && other.getNumcurso()==null) || 
             (this.numcurso!=null &&
              this.numcurso.equals(other.getNumcurso()))) &&
            ((this.nomturno==null && other.getNomturno()==null) || 
             (this.nomturno!=null &&
              this.nomturno.equals(other.getNomturno())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getIdagrupa() != null) {
            _hashCode += getIdagrupa().hashCode();
        }
        if (getDescagr() != null) {
            _hashCode += getDescagr().hashCode();
        }
        if (getEnlaceagrp() != null) {
            _hashCode += getEnlaceagrp().hashCode();
        }
        if (getCodcen() != null) {
            _hashCode += getCodcen().hashCode();
        }
        if (getDesccen() != null) {
            _hashCode += getDesccen().hashCode();
        }
        if (getCodest() != null) {
            _hashCode += getCodest().hashCode();
        }
        if (getNomest() != null) {
            _hashCode += getNomest().hashCode();
        }
        if (getNumcurso() != null) {
            _hashCode += getNumcurso().hashCode();
        }
        if (getNomturno() != null) {
            _hashCode += getNomturno().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Montgo_WsObjAgrupacionesUser.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://montgo/WS.xsd", "montgo_WsObjAgrupacionesUser"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("idagrupa");
        elemField.setXmlName(new javax.xml.namespace.QName("", "idagrupa"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descagr");
        elemField.setXmlName(new javax.xml.namespace.QName("", "descagr"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("enlaceagrp");
        elemField.setXmlName(new javax.xml.namespace.QName("", "enlaceagrp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codcen");
        elemField.setXmlName(new javax.xml.namespace.QName("", "codcen"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("desccen");
        elemField.setXmlName(new javax.xml.namespace.QName("", "desccen"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codest");
        elemField.setXmlName(new javax.xml.namespace.QName("", "codest"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomest");
        elemField.setXmlName(new javax.xml.namespace.QName("", "nomest"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("numcurso");
        elemField.setXmlName(new javax.xml.namespace.QName("", "numcurso"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomturno");
        elemField.setXmlName(new javax.xml.namespace.QName("", "nomturno"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
