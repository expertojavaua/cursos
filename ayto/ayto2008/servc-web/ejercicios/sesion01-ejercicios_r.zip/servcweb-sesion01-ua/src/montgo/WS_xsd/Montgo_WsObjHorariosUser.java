/**
 * Montgo_WsObjHorariosUser.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package montgo.WS_xsd;

public class Montgo_WsObjHorariosUser  implements java.io.Serializable {
    private java.lang.String teopra;

    private java.lang.String codgrp;

    private java.lang.String fechainicio;

    private java.lang.String fechafin;

    private java.lang.String dia;

    private java.lang.String diasemana;

    private java.lang.String horaini;

    private java.lang.String horafin;

    private java.lang.String aula;

    private java.lang.String descaula;

    private java.lang.String aulasig;

    public Montgo_WsObjHorariosUser() {
    }

    public Montgo_WsObjHorariosUser(
           java.lang.String teopra,
           java.lang.String codgrp,
           java.lang.String fechainicio,
           java.lang.String fechafin,
           java.lang.String dia,
           java.lang.String diasemana,
           java.lang.String horaini,
           java.lang.String horafin,
           java.lang.String aula,
           java.lang.String descaula,
           java.lang.String aulasig) {
           this.teopra = teopra;
           this.codgrp = codgrp;
           this.fechainicio = fechainicio;
           this.fechafin = fechafin;
           this.dia = dia;
           this.diasemana = diasemana;
           this.horaini = horaini;
           this.horafin = horafin;
           this.aula = aula;
           this.descaula = descaula;
           this.aulasig = aulasig;
    }


    /**
     * Gets the teopra value for this Montgo_WsObjHorariosUser.
     * 
     * @return teopra
     */
    public java.lang.String getTeopra() {
        return teopra;
    }


    /**
     * Sets the teopra value for this Montgo_WsObjHorariosUser.
     * 
     * @param teopra
     */
    public void setTeopra(java.lang.String teopra) {
        this.teopra = teopra;
    }


    /**
     * Gets the codgrp value for this Montgo_WsObjHorariosUser.
     * 
     * @return codgrp
     */
    public java.lang.String getCodgrp() {
        return codgrp;
    }


    /**
     * Sets the codgrp value for this Montgo_WsObjHorariosUser.
     * 
     * @param codgrp
     */
    public void setCodgrp(java.lang.String codgrp) {
        this.codgrp = codgrp;
    }


    /**
     * Gets the fechainicio value for this Montgo_WsObjHorariosUser.
     * 
     * @return fechainicio
     */
    public java.lang.String getFechainicio() {
        return fechainicio;
    }


    /**
     * Sets the fechainicio value for this Montgo_WsObjHorariosUser.
     * 
     * @param fechainicio
     */
    public void setFechainicio(java.lang.String fechainicio) {
        this.fechainicio = fechainicio;
    }


    /**
     * Gets the fechafin value for this Montgo_WsObjHorariosUser.
     * 
     * @return fechafin
     */
    public java.lang.String getFechafin() {
        return fechafin;
    }


    /**
     * Sets the fechafin value for this Montgo_WsObjHorariosUser.
     * 
     * @param fechafin
     */
    public void setFechafin(java.lang.String fechafin) {
        this.fechafin = fechafin;
    }


    /**
     * Gets the dia value for this Montgo_WsObjHorariosUser.
     * 
     * @return dia
     */
    public java.lang.String getDia() {
        return dia;
    }


    /**
     * Sets the dia value for this Montgo_WsObjHorariosUser.
     * 
     * @param dia
     */
    public void setDia(java.lang.String dia) {
        this.dia = dia;
    }


    /**
     * Gets the diasemana value for this Montgo_WsObjHorariosUser.
     * 
     * @return diasemana
     */
    public java.lang.String getDiasemana() {
        return diasemana;
    }


    /**
     * Sets the diasemana value for this Montgo_WsObjHorariosUser.
     * 
     * @param diasemana
     */
    public void setDiasemana(java.lang.String diasemana) {
        this.diasemana = diasemana;
    }


    /**
     * Gets the horaini value for this Montgo_WsObjHorariosUser.
     * 
     * @return horaini
     */
    public java.lang.String getHoraini() {
        return horaini;
    }


    /**
     * Sets the horaini value for this Montgo_WsObjHorariosUser.
     * 
     * @param horaini
     */
    public void setHoraini(java.lang.String horaini) {
        this.horaini = horaini;
    }


    /**
     * Gets the horafin value for this Montgo_WsObjHorariosUser.
     * 
     * @return horafin
     */
    public java.lang.String getHorafin() {
        return horafin;
    }


    /**
     * Sets the horafin value for this Montgo_WsObjHorariosUser.
     * 
     * @param horafin
     */
    public void setHorafin(java.lang.String horafin) {
        this.horafin = horafin;
    }


    /**
     * Gets the aula value for this Montgo_WsObjHorariosUser.
     * 
     * @return aula
     */
    public java.lang.String getAula() {
        return aula;
    }


    /**
     * Sets the aula value for this Montgo_WsObjHorariosUser.
     * 
     * @param aula
     */
    public void setAula(java.lang.String aula) {
        this.aula = aula;
    }


    /**
     * Gets the descaula value for this Montgo_WsObjHorariosUser.
     * 
     * @return descaula
     */
    public java.lang.String getDescaula() {
        return descaula;
    }


    /**
     * Sets the descaula value for this Montgo_WsObjHorariosUser.
     * 
     * @param descaula
     */
    public void setDescaula(java.lang.String descaula) {
        this.descaula = descaula;
    }


    /**
     * Gets the aulasig value for this Montgo_WsObjHorariosUser.
     * 
     * @return aulasig
     */
    public java.lang.String getAulasig() {
        return aulasig;
    }


    /**
     * Sets the aulasig value for this Montgo_WsObjHorariosUser.
     * 
     * @param aulasig
     */
    public void setAulasig(java.lang.String aulasig) {
        this.aulasig = aulasig;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Montgo_WsObjHorariosUser)) return false;
        Montgo_WsObjHorariosUser other = (Montgo_WsObjHorariosUser) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.teopra==null && other.getTeopra()==null) || 
             (this.teopra!=null &&
              this.teopra.equals(other.getTeopra()))) &&
            ((this.codgrp==null && other.getCodgrp()==null) || 
             (this.codgrp!=null &&
              this.codgrp.equals(other.getCodgrp()))) &&
            ((this.fechainicio==null && other.getFechainicio()==null) || 
             (this.fechainicio!=null &&
              this.fechainicio.equals(other.getFechainicio()))) &&
            ((this.fechafin==null && other.getFechafin()==null) || 
             (this.fechafin!=null &&
              this.fechafin.equals(other.getFechafin()))) &&
            ((this.dia==null && other.getDia()==null) || 
             (this.dia!=null &&
              this.dia.equals(other.getDia()))) &&
            ((this.diasemana==null && other.getDiasemana()==null) || 
             (this.diasemana!=null &&
              this.diasemana.equals(other.getDiasemana()))) &&
            ((this.horaini==null && other.getHoraini()==null) || 
             (this.horaini!=null &&
              this.horaini.equals(other.getHoraini()))) &&
            ((this.horafin==null && other.getHorafin()==null) || 
             (this.horafin!=null &&
              this.horafin.equals(other.getHorafin()))) &&
            ((this.aula==null && other.getAula()==null) || 
             (this.aula!=null &&
              this.aula.equals(other.getAula()))) &&
            ((this.descaula==null && other.getDescaula()==null) || 
             (this.descaula!=null &&
              this.descaula.equals(other.getDescaula()))) &&
            ((this.aulasig==null && other.getAulasig()==null) || 
             (this.aulasig!=null &&
              this.aulasig.equals(other.getAulasig())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getTeopra() != null) {
            _hashCode += getTeopra().hashCode();
        }
        if (getCodgrp() != null) {
            _hashCode += getCodgrp().hashCode();
        }
        if (getFechainicio() != null) {
            _hashCode += getFechainicio().hashCode();
        }
        if (getFechafin() != null) {
            _hashCode += getFechafin().hashCode();
        }
        if (getDia() != null) {
            _hashCode += getDia().hashCode();
        }
        if (getDiasemana() != null) {
            _hashCode += getDiasemana().hashCode();
        }
        if (getHoraini() != null) {
            _hashCode += getHoraini().hashCode();
        }
        if (getHorafin() != null) {
            _hashCode += getHorafin().hashCode();
        }
        if (getAula() != null) {
            _hashCode += getAula().hashCode();
        }
        if (getDescaula() != null) {
            _hashCode += getDescaula().hashCode();
        }
        if (getAulasig() != null) {
            _hashCode += getAulasig().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Montgo_WsObjHorariosUser.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://montgo/WS.xsd", "montgo_WsObjHorariosUser"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("teopra");
        elemField.setXmlName(new javax.xml.namespace.QName("", "teopra"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codgrp");
        elemField.setXmlName(new javax.xml.namespace.QName("", "codgrp"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fechainicio");
        elemField.setXmlName(new javax.xml.namespace.QName("", "fechainicio"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fechafin");
        elemField.setXmlName(new javax.xml.namespace.QName("", "fechafin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("dia");
        elemField.setXmlName(new javax.xml.namespace.QName("", "dia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("diasemana");
        elemField.setXmlName(new javax.xml.namespace.QName("", "diasemana"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("horaini");
        elemField.setXmlName(new javax.xml.namespace.QName("", "horaini"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("horafin");
        elemField.setXmlName(new javax.xml.namespace.QName("", "horafin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("aula");
        elemField.setXmlName(new javax.xml.namespace.QName("", "aula"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("descaula");
        elemField.setXmlName(new javax.xml.namespace.QName("", "descaula"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("aulasig");
        elemField.setXmlName(new javax.xml.namespace.QName("", "aulasig"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
