/**
 * Montgo_WsObjAsignaturasUser.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package montgo.WS_xsd;

public class Montgo_WsObjAsignaturasUser  implements java.io.Serializable {
    private java.lang.String codasi;

    private java.lang.String nomasi;

    private java.lang.String enlaceasi;

    private java.lang.String codest;

    private java.lang.String nomest;

    public Montgo_WsObjAsignaturasUser() {
    }

    public Montgo_WsObjAsignaturasUser(
           java.lang.String codasi,
           java.lang.String nomasi,
           java.lang.String enlaceasi,
           java.lang.String codest,
           java.lang.String nomest) {
           this.codasi = codasi;
           this.nomasi = nomasi;
           this.enlaceasi = enlaceasi;
           this.codest = codest;
           this.nomest = nomest;
    }


    /**
     * Gets the codasi value for this Montgo_WsObjAsignaturasUser.
     * 
     * @return codasi
     */
    public java.lang.String getCodasi() {
        return codasi;
    }


    /**
     * Sets the codasi value for this Montgo_WsObjAsignaturasUser.
     * 
     * @param codasi
     */
    public void setCodasi(java.lang.String codasi) {
        this.codasi = codasi;
    }


    /**
     * Gets the nomasi value for this Montgo_WsObjAsignaturasUser.
     * 
     * @return nomasi
     */
    public java.lang.String getNomasi() {
        return nomasi;
    }


    /**
     * Sets the nomasi value for this Montgo_WsObjAsignaturasUser.
     * 
     * @param nomasi
     */
    public void setNomasi(java.lang.String nomasi) {
        this.nomasi = nomasi;
    }


    /**
     * Gets the enlaceasi value for this Montgo_WsObjAsignaturasUser.
     * 
     * @return enlaceasi
     */
    public java.lang.String getEnlaceasi() {
        return enlaceasi;
    }


    /**
     * Sets the enlaceasi value for this Montgo_WsObjAsignaturasUser.
     * 
     * @param enlaceasi
     */
    public void setEnlaceasi(java.lang.String enlaceasi) {
        this.enlaceasi = enlaceasi;
    }


    /**
     * Gets the codest value for this Montgo_WsObjAsignaturasUser.
     * 
     * @return codest
     */
    public java.lang.String getCodest() {
        return codest;
    }


    /**
     * Sets the codest value for this Montgo_WsObjAsignaturasUser.
     * 
     * @param codest
     */
    public void setCodest(java.lang.String codest) {
        this.codest = codest;
    }


    /**
     * Gets the nomest value for this Montgo_WsObjAsignaturasUser.
     * 
     * @return nomest
     */
    public java.lang.String getNomest() {
        return nomest;
    }


    /**
     * Sets the nomest value for this Montgo_WsObjAsignaturasUser.
     * 
     * @param nomest
     */
    public void setNomest(java.lang.String nomest) {
        this.nomest = nomest;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Montgo_WsObjAsignaturasUser)) return false;
        Montgo_WsObjAsignaturasUser other = (Montgo_WsObjAsignaturasUser) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codasi==null && other.getCodasi()==null) || 
             (this.codasi!=null &&
              this.codasi.equals(other.getCodasi()))) &&
            ((this.nomasi==null && other.getNomasi()==null) || 
             (this.nomasi!=null &&
              this.nomasi.equals(other.getNomasi()))) &&
            ((this.enlaceasi==null && other.getEnlaceasi()==null) || 
             (this.enlaceasi!=null &&
              this.enlaceasi.equals(other.getEnlaceasi()))) &&
            ((this.codest==null && other.getCodest()==null) || 
             (this.codest!=null &&
              this.codest.equals(other.getCodest()))) &&
            ((this.nomest==null && other.getNomest()==null) || 
             (this.nomest!=null &&
              this.nomest.equals(other.getNomest())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodasi() != null) {
            _hashCode += getCodasi().hashCode();
        }
        if (getNomasi() != null) {
            _hashCode += getNomasi().hashCode();
        }
        if (getEnlaceasi() != null) {
            _hashCode += getEnlaceasi().hashCode();
        }
        if (getCodest() != null) {
            _hashCode += getCodest().hashCode();
        }
        if (getNomest() != null) {
            _hashCode += getNomest().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Montgo_WsObjAsignaturasUser.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://montgo/WS.xsd", "montgo_WsObjAsignaturasUser"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codasi");
        elemField.setXmlName(new javax.xml.namespace.QName("", "codasi"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomasi");
        elemField.setXmlName(new javax.xml.namespace.QName("", "nomasi"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("enlaceasi");
        elemField.setXmlName(new javax.xml.namespace.QName("", "enlaceasi"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codest");
        elemField.setXmlName(new javax.xml.namespace.QName("", "codest"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomest");
        elemField.setXmlName(new javax.xml.namespace.QName("", "nomest"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
