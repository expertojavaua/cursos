/**
 * Montgo_WsObjProyectosInvUser.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package montgo.WS_xsd;

public class Montgo_WsObjProyectosInvUser  implements java.io.Serializable {
    private java.lang.String codproy;

    private java.lang.String espublico;

    private java.lang.String titulo;

    private java.lang.String referencia;

    private java.lang.String fechainicio;

    private java.lang.String fechafin;

    private java.lang.String duracion;

    private java.lang.String importe;

    private java.lang.String iva;

    private java.lang.String nomentidad;

    private java.lang.String director;

    public Montgo_WsObjProyectosInvUser() {
    }

    public Montgo_WsObjProyectosInvUser(
           java.lang.String codproy,
           java.lang.String espublico,
           java.lang.String titulo,
           java.lang.String referencia,
           java.lang.String fechainicio,
           java.lang.String fechafin,
           java.lang.String duracion,
           java.lang.String importe,
           java.lang.String iva,
           java.lang.String nomentidad,
           java.lang.String director) {
           this.codproy = codproy;
           this.espublico = espublico;
           this.titulo = titulo;
           this.referencia = referencia;
           this.fechainicio = fechainicio;
           this.fechafin = fechafin;
           this.duracion = duracion;
           this.importe = importe;
           this.iva = iva;
           this.nomentidad = nomentidad;
           this.director = director;
    }


    /**
     * Gets the codproy value for this Montgo_WsObjProyectosInvUser.
     * 
     * @return codproy
     */
    public java.lang.String getCodproy() {
        return codproy;
    }


    /**
     * Sets the codproy value for this Montgo_WsObjProyectosInvUser.
     * 
     * @param codproy
     */
    public void setCodproy(java.lang.String codproy) {
        this.codproy = codproy;
    }


    /**
     * Gets the espublico value for this Montgo_WsObjProyectosInvUser.
     * 
     * @return espublico
     */
    public java.lang.String getEspublico() {
        return espublico;
    }


    /**
     * Sets the espublico value for this Montgo_WsObjProyectosInvUser.
     * 
     * @param espublico
     */
    public void setEspublico(java.lang.String espublico) {
        this.espublico = espublico;
    }


    /**
     * Gets the titulo value for this Montgo_WsObjProyectosInvUser.
     * 
     * @return titulo
     */
    public java.lang.String getTitulo() {
        return titulo;
    }


    /**
     * Sets the titulo value for this Montgo_WsObjProyectosInvUser.
     * 
     * @param titulo
     */
    public void setTitulo(java.lang.String titulo) {
        this.titulo = titulo;
    }


    /**
     * Gets the referencia value for this Montgo_WsObjProyectosInvUser.
     * 
     * @return referencia
     */
    public java.lang.String getReferencia() {
        return referencia;
    }


    /**
     * Sets the referencia value for this Montgo_WsObjProyectosInvUser.
     * 
     * @param referencia
     */
    public void setReferencia(java.lang.String referencia) {
        this.referencia = referencia;
    }


    /**
     * Gets the fechainicio value for this Montgo_WsObjProyectosInvUser.
     * 
     * @return fechainicio
     */
    public java.lang.String getFechainicio() {
        return fechainicio;
    }


    /**
     * Sets the fechainicio value for this Montgo_WsObjProyectosInvUser.
     * 
     * @param fechainicio
     */
    public void setFechainicio(java.lang.String fechainicio) {
        this.fechainicio = fechainicio;
    }


    /**
     * Gets the fechafin value for this Montgo_WsObjProyectosInvUser.
     * 
     * @return fechafin
     */
    public java.lang.String getFechafin() {
        return fechafin;
    }


    /**
     * Sets the fechafin value for this Montgo_WsObjProyectosInvUser.
     * 
     * @param fechafin
     */
    public void setFechafin(java.lang.String fechafin) {
        this.fechafin = fechafin;
    }


    /**
     * Gets the duracion value for this Montgo_WsObjProyectosInvUser.
     * 
     * @return duracion
     */
    public java.lang.String getDuracion() {
        return duracion;
    }


    /**
     * Sets the duracion value for this Montgo_WsObjProyectosInvUser.
     * 
     * @param duracion
     */
    public void setDuracion(java.lang.String duracion) {
        this.duracion = duracion;
    }


    /**
     * Gets the importe value for this Montgo_WsObjProyectosInvUser.
     * 
     * @return importe
     */
    public java.lang.String getImporte() {
        return importe;
    }


    /**
     * Sets the importe value for this Montgo_WsObjProyectosInvUser.
     * 
     * @param importe
     */
    public void setImporte(java.lang.String importe) {
        this.importe = importe;
    }


    /**
     * Gets the iva value for this Montgo_WsObjProyectosInvUser.
     * 
     * @return iva
     */
    public java.lang.String getIva() {
        return iva;
    }


    /**
     * Sets the iva value for this Montgo_WsObjProyectosInvUser.
     * 
     * @param iva
     */
    public void setIva(java.lang.String iva) {
        this.iva = iva;
    }


    /**
     * Gets the nomentidad value for this Montgo_WsObjProyectosInvUser.
     * 
     * @return nomentidad
     */
    public java.lang.String getNomentidad() {
        return nomentidad;
    }


    /**
     * Sets the nomentidad value for this Montgo_WsObjProyectosInvUser.
     * 
     * @param nomentidad
     */
    public void setNomentidad(java.lang.String nomentidad) {
        this.nomentidad = nomentidad;
    }


    /**
     * Gets the director value for this Montgo_WsObjProyectosInvUser.
     * 
     * @return director
     */
    public java.lang.String getDirector() {
        return director;
    }


    /**
     * Sets the director value for this Montgo_WsObjProyectosInvUser.
     * 
     * @param director
     */
    public void setDirector(java.lang.String director) {
        this.director = director;
    }

    private java.lang.Object __equalsCalc = null;
    public synchronized boolean equals(java.lang.Object obj) {
        if (!(obj instanceof Montgo_WsObjProyectosInvUser)) return false;
        Montgo_WsObjProyectosInvUser other = (Montgo_WsObjProyectosInvUser) obj;
        if (obj == null) return false;
        if (this == obj) return true;
        if (__equalsCalc != null) {
            return (__equalsCalc == obj);
        }
        __equalsCalc = obj;
        boolean _equals;
        _equals = true && 
            ((this.codproy==null && other.getCodproy()==null) || 
             (this.codproy!=null &&
              this.codproy.equals(other.getCodproy()))) &&
            ((this.espublico==null && other.getEspublico()==null) || 
             (this.espublico!=null &&
              this.espublico.equals(other.getEspublico()))) &&
            ((this.titulo==null && other.getTitulo()==null) || 
             (this.titulo!=null &&
              this.titulo.equals(other.getTitulo()))) &&
            ((this.referencia==null && other.getReferencia()==null) || 
             (this.referencia!=null &&
              this.referencia.equals(other.getReferencia()))) &&
            ((this.fechainicio==null && other.getFechainicio()==null) || 
             (this.fechainicio!=null &&
              this.fechainicio.equals(other.getFechainicio()))) &&
            ((this.fechafin==null && other.getFechafin()==null) || 
             (this.fechafin!=null &&
              this.fechafin.equals(other.getFechafin()))) &&
            ((this.duracion==null && other.getDuracion()==null) || 
             (this.duracion!=null &&
              this.duracion.equals(other.getDuracion()))) &&
            ((this.importe==null && other.getImporte()==null) || 
             (this.importe!=null &&
              this.importe.equals(other.getImporte()))) &&
            ((this.iva==null && other.getIva()==null) || 
             (this.iva!=null &&
              this.iva.equals(other.getIva()))) &&
            ((this.nomentidad==null && other.getNomentidad()==null) || 
             (this.nomentidad!=null &&
              this.nomentidad.equals(other.getNomentidad()))) &&
            ((this.director==null && other.getDirector()==null) || 
             (this.director!=null &&
              this.director.equals(other.getDirector())));
        __equalsCalc = null;
        return _equals;
    }

    private boolean __hashCodeCalc = false;
    public synchronized int hashCode() {
        if (__hashCodeCalc) {
            return 0;
        }
        __hashCodeCalc = true;
        int _hashCode = 1;
        if (getCodproy() != null) {
            _hashCode += getCodproy().hashCode();
        }
        if (getEspublico() != null) {
            _hashCode += getEspublico().hashCode();
        }
        if (getTitulo() != null) {
            _hashCode += getTitulo().hashCode();
        }
        if (getReferencia() != null) {
            _hashCode += getReferencia().hashCode();
        }
        if (getFechainicio() != null) {
            _hashCode += getFechainicio().hashCode();
        }
        if (getFechafin() != null) {
            _hashCode += getFechafin().hashCode();
        }
        if (getDuracion() != null) {
            _hashCode += getDuracion().hashCode();
        }
        if (getImporte() != null) {
            _hashCode += getImporte().hashCode();
        }
        if (getIva() != null) {
            _hashCode += getIva().hashCode();
        }
        if (getNomentidad() != null) {
            _hashCode += getNomentidad().hashCode();
        }
        if (getDirector() != null) {
            _hashCode += getDirector().hashCode();
        }
        __hashCodeCalc = false;
        return _hashCode;
    }

    // Type metadata
    private static org.apache.axis.description.TypeDesc typeDesc =
        new org.apache.axis.description.TypeDesc(Montgo_WsObjProyectosInvUser.class, true);

    static {
        typeDesc.setXmlType(new javax.xml.namespace.QName("http://montgo/WS.xsd", "montgo_WsObjProyectosInvUser"));
        org.apache.axis.description.ElementDesc elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("codproy");
        elemField.setXmlName(new javax.xml.namespace.QName("", "codproy"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("espublico");
        elemField.setXmlName(new javax.xml.namespace.QName("", "espublico"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("titulo");
        elemField.setXmlName(new javax.xml.namespace.QName("", "titulo"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("referencia");
        elemField.setXmlName(new javax.xml.namespace.QName("", "referencia"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fechainicio");
        elemField.setXmlName(new javax.xml.namespace.QName("", "fechainicio"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("fechafin");
        elemField.setXmlName(new javax.xml.namespace.QName("", "fechafin"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("duracion");
        elemField.setXmlName(new javax.xml.namespace.QName("", "duracion"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("importe");
        elemField.setXmlName(new javax.xml.namespace.QName("", "importe"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("iva");
        elemField.setXmlName(new javax.xml.namespace.QName("", "iva"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("nomentidad");
        elemField.setXmlName(new javax.xml.namespace.QName("", "nomentidad"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
        elemField = new org.apache.axis.description.ElementDesc();
        elemField.setFieldName("director");
        elemField.setXmlName(new javax.xml.namespace.QName("", "director"));
        elemField.setXmlType(new javax.xml.namespace.QName("http://www.w3.org/2001/XMLSchema", "string"));
        elemField.setNillable(false);
        typeDesc.addFieldDesc(elemField);
    }

    /**
     * Return type metadata object
     */
    public static org.apache.axis.description.TypeDesc getTypeDesc() {
        return typeDesc;
    }

    /**
     * Get Custom Serializer
     */
    public static org.apache.axis.encoding.Serializer getSerializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanSerializer(
            _javaType, _xmlType, typeDesc);
    }

    /**
     * Get Custom Deserializer
     */
    public static org.apache.axis.encoding.Deserializer getDeserializer(
           java.lang.String mechType, 
           java.lang.Class _javaType,  
           javax.xml.namespace.QName _xmlType) {
        return 
          new  org.apache.axis.encoding.ser.BeanDeserializer(
            _javaType, _xmlType, typeDesc);
    }

}
