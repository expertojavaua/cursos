Recopilado de http://www.hibernate.org/6.html

Contiene las librerias necesarias para JPA en Java SE, obtenidas de las distribuciones:

- Hibernate Core 3.2.5.ga (31.07.2007)
- Hibernate Annotations 3.3.0 GA (20.03.2007)
- Hibernate EntityManager 3.3.1 GA (29.03.2007)