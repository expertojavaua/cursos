package ayto;

import javax.persistence.*;

@Entity
public class Empleado {
   @Id
   private int id;
   private String nombre;
   private long sueldo;

   public Empleado() {}
   public Empleado(int id) { this.id = id; }

   public int getId() { return id; }
   public void setId(int id) { this.id = id; }
   public String getNombre() { return nombre; }
   public void setNombre(String nombre) { this.nombre = nombre; }
   public long getSueldo() { return sueldo; }
   public void setSueldo(long sueldo) { this.sueldo = sueldo; }
}