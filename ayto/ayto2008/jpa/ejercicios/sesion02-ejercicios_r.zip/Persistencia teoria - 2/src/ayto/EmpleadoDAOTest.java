package ayto;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Collection;

public class EmpleadoDAOTest {

   public static void main(String[] args) {
      int numEmpleado=0;
      String nombre=null;

      EmpleadoDAO empDAO = new EmpleadoDAO();

      try {
         BufferedReader in = new BufferedReader(
               new InputStreamReader(System.in));
         System.out.print("Id: ");
         numEmpleado = Integer.parseInt(in.readLine());
         System.out.print("Nombre: ");
         nombre = in.readLine();
      } catch (IOException e) {
         System.exit(-1);
      }
      
      // crear y hacer persistente el empleado
      Empleado emp = empDAO.createEmpleado(numEmpleado,nombre, 50000);
      System.out.println("Empleado" + emp + "hecho persistente");

      // busca un empleado
      emp = empDAO.findEmpleado(numEmpleado);
      System.out.println("Encontrado empleado" + emp);

      // lista empleados
      Collection<Empleado> empleados = empDAO.findEmpleadosSueldoMayorQue(30000);
      System.out.println("Hay " + empleados.size() + " ejecutivos");
   }
}