package ayto;

import javax.persistence.*;
import java.util.List;

public class EmpleadoDAO {
   
   protected EntityManagerFactory emf;

   public EmpleadoDAO() {
      emf = Persistence.createEntityManagerFactory("simplejpa");
   }

   public Empleado createEmpleado(int id, String nombre, long sueldo)  {
      EntityManager em = emf.createEntityManager();
      em.getTransaction().begin();
      Empleado emp = em.find(Empleado.class, id);
      if (emp == null) {
         emp = new Empleado(id);
      }
      emp.setNombre(nombre);
      emp.setSueldo(sueldo);
      em.persist(emp);
      em.getTransaction().commit();
      em.close();
      return emp;
   }

   public void removeEmpleado(int id) {
      EntityManager em = emf.createEntityManager();
      em.getTransaction().begin();
      Empleado emp = em.find(Empleado.class, id);
      if (emp != null) {
         em.remove(emp);
      }
      em.getTransaction().commit();
      em.close();
   }

   public void subeSueldoEmpleado(int id, long aumento) {
      EntityManager em = emf.createEntityManager();
      em.getTransaction().begin();
      Empleado emp = em.find(Empleado.class, id);
      if (emp != null) {
         emp.setSueldo(emp.getSueldo() + aumento);
      }
      em.getTransaction().commit();
      em.close();
   }
   
   public void cambiaNombreEmpleado(int id, String nuevoNombre) {
      EntityManager em = emf.createEntityManager();
      em.getTransaction().begin();
      Empleado emp = em.find(Empleado.class, id);
      if (emp != null) {
         emp.setNombre(nuevoNombre);
      }
      em.getTransaction().commit();
      em.close();
   }

   public Empleado findEmpleado(int id) {
      EntityManager em = emf.createEntityManager();
      em.getTransaction().begin();
      Empleado emp= em.find(Empleado.class, id);
      em.getTransaction().commit();
      em.close();
      return emp;
   }

   public List<Empleado> findEmpleadosSueldoMayorQue(long sueldo) {
      EntityManager em = emf.createEntityManager();
      em.getTransaction().begin();
      Query query = em.createQuery("SELECT e FROM Empleado e " + 
                                "WHERE e.sueldo > :sueldo");
      query.setParameter("sueldo", sueldo);
      List<Empleado> list = (List<Empleado>) query.getResultList();
      em.getTransaction().commit();
      em.close();
      return list;
   }
}
