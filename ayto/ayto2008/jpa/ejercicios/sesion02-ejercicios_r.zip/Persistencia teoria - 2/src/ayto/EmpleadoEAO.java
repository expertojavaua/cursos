package ayto;

import javax.persistence.*;
import java.util.List;

public class EmpleadoEAO {
   protected EntityManager em;

   public EmpleadoEAO(EntityManager em) {
      this.em = em;
   }

   public Empleado createEmpleado(int id, String nombre, long sueldo) {
      Empleado emp = new Empleado(id);
      emp.setNombre(nombre);
      emp.setSueldo(sueldo);
      em.persist(emp);
      return emp;
   }
   
   public void removeEmpleado(Empleado emp) {
      em.remove(emp);
   }

   public void subeSueldoEmpleado(Empleado emp, long aumento) {
      emp.setSueldo(emp.getSueldo() + aumento);
   }

   public void cambiaNombreEmpleado(Empleado emp, String nuevoNombre) {
      emp.setNombre(nuevoNombre);
   }

   public Empleado findEmpleado(int id) {
      return em.find(Empleado.class, id);
   }

   public List<Empleado> findEmpleadosSueldo(long sueldo) {
      Query query = em.createQuery("SELECT e FROM Empleado e "
            + "WHERE e.sueldo > :sueldo");
      query.setParameter("sueldo", 20000);
      return (List<Empleado>) query.getResultList();
   }
}
