package ayto;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Collection;

import javax.persistence.*;

public class EmpleadoTest {

   public static void main(String[] args) {
      int numEmpleado=0;
      String nombre=null;

      EntityManagerFactory emf = Persistence.createEntityManagerFactory("simplejpa");
      EntityManager em = emf.createEntityManager();

      try {
         BufferedReader in = new BufferedReader(
               new InputStreamReader(System.in));
         System.out.print("Id: ");
         numEmpleado = Integer.parseInt(in.readLine());
         System.out.print("Nombre: ");
         nombre = in.readLine();
      } catch (IOException e) {
         System.exit(-1);
      }

      EmpleadoEAO empEAO = new EmpleadoEAO(em);

      // crear y hacer persistente el empleado
      em.getTransaction().begin();
      Empleado emp = empEAO.createEmpleado(numEmpleado,nombre, 50000);
      em.getTransaction().commit();
      System.out.println("Empleado" + emp + "hecho persistente");

      // busca un empleado
      emp = empEAO.findEmpleado(numEmpleado);
      System.out.println("Encontrado empleado" + emp);

      // lista empleados
      em.getTransaction().begin();
      Collection<Empleado> empleados = empEAO.findEmpleadosSueldo(3000);
      em.getTransaction().commit();
      System.out.println("Hay " + empleados.size() + " ejecutivos");
      em.close();
   }
}