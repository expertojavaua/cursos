package ayto;

import java.io.*;
import java.util.Collection;

import javax.persistence.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class DoAction extends HttpServlet {
   private static final long serialVersionUID = 1L;

   public void doGet(HttpServletRequest request, HttpServletResponse response)
         throws ServletException, IOException {

      String accion = request.getParameter("accion");

      if (accion.equals("add")) {
         doAdd(request, response);
      } else if (accion.equals("lista")) {
         doLista(request, response);
      } else if (accion.equals("cuenta")) {
         doCuenta(request, response);
      } else {
         PrintWriter out = response.getWriter();
         out.println("<html>");
         out.println("Error. La acci�n " + accion + " no est� implementada");
         out.println("</html>");
      }
   }

   private void doCuenta(HttpServletRequest request,
         HttpServletResponse response) throws ServletException, IOException {
      Autor autor;     
      String autorStr = request.getParameter("autor");
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("simplejpa");

      EntityManager em = emf.createEntityManager();
      System.out.println(em.getFlushMode());
      em.getTransaction().begin();
      autor = em.find(Autor.class, autorStr);
      Collection<Mensaje> mensajes = autor.getMensajes();
      em.getTransaction().commit();
      
      request.setAttribute("autor", autor);
      int mens = mensajes.size();
      request.setAttribute("numMensajes", mens);
      getServletContext().getRequestDispatcher("/numeroMensajes.jsp")
            .forward(request, response);
      em.close();
      emf.close();
   }

   private void doLista(HttpServletRequest request, 
                        HttpServletResponse response)
         throws ServletException, IOException {
      Autor autor;
      String autorStr = request.getParameter("autor");

      // Se deber�a sustituir por un singleton
      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("simplejpa");

      EntityManager em = emf.createEntityManager();

      //em.getTransaction().begin();
      autor = em.find(Autor.class, autorStr);
      Collection<Mensaje> mensajes = autor.getMensajes();
      //em.getTransaction().commit();

      request.setAttribute("autor", autor);
      request.setAttribute("mensajes", mensajes);
      getServletContext().getRequestDispatcher("/listaMensajes.jsp")
                         .forward(request, response);
      em.close();
      emf.close();
   }

   private void doAdd(HttpServletRequest request, 
                      HttpServletResponse response)
         throws ServletException, IOException {

      String mensStr = request.getParameter("mensaje");
      String autorStr = request.getParameter("autor");

      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("simplejpa");

      EntityManager em = emf.createEntityManager();

      em.getTransaction().begin();
      Autor autor = em.find(Autor.class, autorStr);
      if (autor == null) {
         autor = new Autor(autorStr, autorStr + "@ua.es");
         em.persist(autor);
      }
      Mensaje mensaje = new Mensaje(mensStr);
      em.persist(mensaje);
      mensaje.setAutor(autor);
      autor.addMensaje(mensaje);
      Collection<Mensaje> mensajes = autor.getMensajes();
      em.getTransaction().commit();
      //autor.getMensajes().size();
      em.close();
      emf.close();
      request.setAttribute("autor", autor);
      request.setAttribute("mensajes", mensajes);

      getServletContext().getRequestDispatcher("/listaMensajes.jsp")
                         .forward(request, response);
   }
}