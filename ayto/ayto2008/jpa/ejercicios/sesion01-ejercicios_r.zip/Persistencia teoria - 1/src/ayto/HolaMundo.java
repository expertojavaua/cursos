package ayto;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;
import javax.persistence.*;

public class HolaMundo {

   public static void main(String[] args) {
      String mensStr;
      String autorStr;

      EntityManagerFactory emf = Persistence
            .createEntityManagerFactory("simplejpa");

      EntityManager em = emf.createEntityManager();

      try {
         BufferedReader in = new BufferedReader(
               new InputStreamReader(System.in));
         System.out.print("Nombre: ");
         autorStr = in.readLine();
         System.out.print("Mensaje: ");
         mensStr = in.readLine();
      } catch (IOException e) {
         autorStr = "Error";
         mensStr = "Error";
      }

      em.getTransaction().begin();

      Autor autor = em.find(Autor.class, autorStr);
      
      if (autor == null) {
         autor = new Autor();
         autor.setNombre(autorStr);
         autor.setCorreo(autorStr + "@ua.es");
         em.persist(autor);
      }

      Mensaje mensaje = new Mensaje();
      mensaje.setTexto(mensStr);
      mensaje.setFecha(new Date());
      em.persist(mensaje);

      mensaje.setAutor(autor);
      Set<Mensaje> mensajes = autor.getMensajes();
      mensajes.add(mensaje);

      em.getTransaction().commit();

      System.out.println(autor.getNombre() + " ha enviado " + mensajes.size()
            + " mensaje(s):");
      Iterator<Mensaje> it = mensajes.iterator();
      while (it.hasNext()) {
         Mensaje mens = it.next();
         System.out.println(mens.getTexto() + " - "
               + mens.getFecha().toString());
      }
      em.close();
      emf.close();
   }
}