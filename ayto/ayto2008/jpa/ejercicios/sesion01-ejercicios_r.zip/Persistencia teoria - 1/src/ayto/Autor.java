package ayto;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.*;

@Entity
public class Autor {
   @Id
   private String nombre;
   private String correo;
   @OneToMany(mappedBy = "autor", cascade=CascadeType.ALL)
   private Set<Mensaje> mensajes = new HashSet<Mensaje>();

   public Autor() { }
   public String getNombre() { return nombre; }
   public void setNombre(String nombre) { this.nombre = nombre; }
   public String getCorreo() { return correo; }
   public void setCorreo(String correo) { this.correo = correo; }
   public Set<Mensaje> getMensajes() { return mensajes; }
   public void setMensajes(Set<Mensaje> mensajes) { this.mensajes = mensajes; }
}