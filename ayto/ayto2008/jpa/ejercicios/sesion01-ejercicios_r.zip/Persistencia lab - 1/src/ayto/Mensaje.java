package ayto;

import javax.persistence.*;

@Entity
public class Mensaje {
   @Id
   @GeneratedValue
   private long id;
   private String texto;
   @ManyToOne
   private Autor autor;

   public Mensaje() {
   }

   public Mensaje(String texto, Autor autor) {
      this.texto = texto;
      this.autor = autor;
   }

   public long getId() {
      return id;
   }
   
   public void setId(long id) {
      this.id = id;
   }

   public String getTexto() {
      return texto;
   }

   public void setTexto(String texto) {
      this.texto = texto;
   }

   public Autor getAutor() {
      return autor;
   }

   public void setAutor(Autor autor) {
      this.autor = autor;
   }
}
