package ayto;

import java.io.*;
import java.util.Collection;

import javax.persistence.*;
import javax.servlet.*;
import javax.servlet.http.*;


public class AddMensaje extends HttpServlet {
   private static final long serialVersionUID = 1L;

   public void doGet(HttpServletRequest request, 
         HttpServletResponse response) 
   throws ServletException, IOException   {

      String mensStr =
         request.getParameter("mensaje");
      String autorStr =
         request.getParameter("autor");
      EntityManagerFactory emf = Persistence
                            .createEntityManagerFactory("simplejpa");

      EntityManager em = emf.createEntityManager();
      
      em.getTransaction().begin();

      Autor autor = em.find(Autor.class, autorStr);
      if (autor == null) {
         autor = new Autor();
         autor.setNombre(autorStr);
         autor.setCorreo(autorStr+"@ua.es");
         em.persist(autor);
      }
      
      Mensaje mensaje = new Mensaje(mensStr, autor);
      em.persist(mensaje);
      
      autor.addMensaje(mensaje);
      
      Collection<Mensaje> mensajes = autor.getMensajes();
      em.getTransaction().commit();

      request.setAttribute("autor", autor);
      request.setAttribute("mensajes", mensajes);

      getServletContext().getRequestDispatcher("/listaMensajes.jsp")
                         .forward(request, response);
      em.close();      
      emf.close();
   }
}