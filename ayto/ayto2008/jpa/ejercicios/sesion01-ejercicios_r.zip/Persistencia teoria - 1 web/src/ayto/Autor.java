package ayto;

import java.util.Collection;
import java.util.HashSet;

import javax.persistence.*;

@Entity
public class Autor {
   @Id
   private String nombre;
   private String correo;
   @OneToMany(mappedBy = "autor")
   private Collection<Mensaje> mensajes = new HashSet<Mensaje>();

   public Autor() {
   }
   
   public void setMensajes(Collection<Mensaje> mensajes) {
      this.mensajes = mensajes;
   }

   public String getNombre() {
      return nombre;
   }

   public void setNombre(String nombre) {
      this.nombre = nombre;
   }

   public String getCorreo() {
      return correo;
   }

   public void setCorreo(String correo) {
      this.correo = correo;
   }

   public Collection<Mensaje> getMensajes() {
      return mensajes;
   }
   
   public void addMensaje(Mensaje mensaje) {
      this.mensajes.add(mensaje);
   }
}
