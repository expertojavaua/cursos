package main;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import entity.Autor;
import entity.Mensaje;

public class HolaMundo {

	public static void main(String[] args) {
		Autor autor;
		Mensaje mensaje;
		String autorStr, mensStr;

        SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
        Session session = sessionFactory.getCurrentSession();
        
        // Leo el mensaje y el autor
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(
					System.in));
			System.out.print("Nombre: ");
			autorStr = in.readLine();
			System.out.print("Mensaje: ");
			mensStr = in.readLine();
		} catch (IOException e) {
			autorStr = "Error";
			mensStr = "Error";
		}
		
        session.beginTransaction();
        
        // Busco el autor y lo creo si no existe
        autor = (Autor) session.get(Autor.class, autorStr);
		if (autor == null) {
			autor = new Autor();
			autor.setNombre(autorStr);
			autor.setCorreo(autorStr + "@ua.es");
			session.persist(autor);
		}
		
		// Creo el mensaje
		// A�ado el autor al mensaje
		mensaje = new Mensaje();
		mensaje.getAutores().add(autor);
		mensaje.setTexto(mensStr);
		mensaje.setCreado(new Date());
		session.persist(mensaje);

		// A�ado el mensaje al autor y cierro la sesion
		autor.getMensajes().add(mensaje);
		session.getTransaction().commit();
        
        // El estado de las entidades queda en memoria
		// Imprimimos todos los mensajes del autor
        Set<Mensaje> mensajes = autor.getMensajes();
		System.out.println(autor.getNombre() + " ha escrito " + mensajes.size() + " mensajes:");
		Iterator<Mensaje> it = mensajes.iterator();
		while (it.hasNext()) {
			Mensaje mens = it.next();
			System.out.print(mens.getTexto());
			if (mens.getCreado() != null)
			   System.out.print (" - " + mens.getCreado().toString());
			System.out.println();
		}
	}
}
