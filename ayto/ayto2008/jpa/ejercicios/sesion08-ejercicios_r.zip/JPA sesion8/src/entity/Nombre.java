package entity;

public class Nombre { 
    String nombre; 
    String primerApellido; 
    String segundoApellido; 
    
    public String getPrimerApellido() { 
        return primerApellido; 
    } 
    void setPrimerApellido(String apellido) { 
        this.primerApellido = apellido; 
    } 
    public String getSegundoApellido() { 
        return segundoApellido; 
    } 
    void setLast(String segundoApellido) { 
        this.segundoApellido = segundoApellido; 
    } 
    public String getNombre() { 
        return nombre; 
    } 
    void setInitial(String nombre) { 
        this.nombre = nombre; 
    } 
}