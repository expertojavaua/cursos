package entity;

public class Persona {
    private String key; 
    private java.util.Date cumpleanyos; 
    private Nombre name; 

    public Persona() {}
    
    private void setKey(String key) { 
        this.key=key; 
    } 

    public String getKey() { 
        return key; 
    } 
    
    public java.util.Date getCumpleanyos() { 
        return cumpleanyos; 
    } 
    public void setCumpleanyosy(java.util.Date cumpleanyos) { 
        this.cumpleanyos = cumpleanyos; 
    } 
    public Nombre getName() { 
        return name; 
    } 
    public void setName(Nombre name) { 
        this.name = name; 
    } 
}
