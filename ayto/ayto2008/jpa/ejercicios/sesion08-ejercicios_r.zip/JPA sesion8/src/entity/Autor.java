package entity;

import java.util.HashSet;
import java.util.Set;

public class Autor {
	private Long id; //identificador
	private String nombre;
	private String correo;
	private Set<Mensaje> mensajes = new HashSet<Mensaje>();

	public Autor() {}

	public void setId(Long id) {
		this.id = id;
	}
	
	public Long getId() {
		return id;
	}
	
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public Set<Mensaje> getMensajes() {
		return mensajes;
	}

	public void setMensajes(Set<Mensaje> mensajes) {
		this.mensajes = mensajes;
	}
}
