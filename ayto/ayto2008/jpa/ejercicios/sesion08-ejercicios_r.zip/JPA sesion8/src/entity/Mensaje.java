package entity;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class Mensaje {
	private long id;
	private String texto;
	private Date creado;
	private Set<Autor> autores =  new HashSet<Autor>();

	public Mensaje() {}

	public long getId() {return id;}
	public void setId(long id) {this.id = id;}
	public String getTexto() {return texto;}
	public void setTexto(String texto) {this.texto = texto;}
	public Set<Autor> getAutores() {return autores;}
	public void setAutores(Set<Autor> autores) {this.autores = autores;}
	public Date getCreado() {return creado;}
	public void setCreado(Date creado) {this.creado = creado;}
}
