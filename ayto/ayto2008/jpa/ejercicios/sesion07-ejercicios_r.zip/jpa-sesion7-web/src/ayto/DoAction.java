package ayto;

import java.io.*;
import java.util.Collection;
import java.util.Iterator;

import javax.persistence.*;
import javax.servlet.*;
import javax.servlet.http.*;



public class DoAction extends HttpServlet {
   private static final long serialVersionUID = 1L;

   public void doGet(HttpServletRequest request, HttpServletResponse response)
         throws ServletException, IOException {

      String accion = request.getParameter("accion");

      if (accion.equals("add")) {
         doAdd(request, response);
      } else if (accion.equals("lista")) {
         doLista(request, response);
      } else if (accion.equals("cuenta")) {
         doCuenta(request, response);
      } else if (accion.equals("tag")) {
          addTag();
      } else if (accion.equals("html")) {
    	  addPaginaHtml();
      } else if (accion.equals("autorPagina")) {
    	  addAutorPagina(request, response);
      } else if (accion.equals("tagPagina")) {
    	  addTagPagina(request, response);
      } else if (accion.equals("listarPaginaHtml")) {
    	  doListaTagPagina(request, response);
      } else if (accion.equals("tagsAutor")) {
    	  doTagsAutor(request, response);
      } else if (accion.equals("mensajeAutorTag")) {
    	  doMensajeAutorTag(request, response);
      } else {
         PrintWriter out = response.getWriter();
         out.println("Error. La acci�n " + accion + " no est� implementada");
      }
   }
   
   private void doMensajeAutorTag(HttpServletRequest request, HttpServletResponse response)
   					throws ServletException, IOException {

	   EntityManagerFactory emf = Persistence.createEntityManagerFactory("simplejpa");
	   EntityManager em = emf.createEntityManager();
	   
	   String nombre = request.getParameter("autor");
	   String cadena = request.getParameter("tag");

	   AutorDAO aDAO = new AutorDAO(em);
	   Collection<Mensaje> mensajes = aDAO.findMensajeAutorTag(aDAO.findAutor(nombre), cadena);

	   Iterator<Mensaje> it = mensajes.iterator();
	   while(it.hasNext()){
		   System.out.println(it.next().getTexto());
	   }

	   em.close();
	   emf.close();
   }
   
   
   private void doTagsAutor(HttpServletRequest request, HttpServletResponse response)
   								throws ServletException, IOException {
	   
	   EntityManagerFactory emf = Persistence.createEntityManagerFactory("simplejpa");
	   EntityManager em = emf.createEntityManager();

	   String nombre = request.getParameter("autor");

	   AutorDAO aDAO = new AutorDAO(em);
	   Collection<Tag> tags = aDAO.findTagsAutor(aDAO.findAutor(nombre));
	   
	   Iterator<Tag> it = tags.iterator();
	   while(it.hasNext()){
		   System.out.println(it.next().getCadena());
	   }

	   em.close();
	   emf.close();
   }
   
   private void doListaTagPagina(HttpServletRequest request, HttpServletResponse response)
	   				throws ServletException, IOException {
	   EntityManagerFactory emf = Persistence.createEntityManagerFactory("simplejpa");
	   EntityManager em = emf.createEntityManager();
	   	   
	   String paginaStr = request.getParameter("pagina");
	   
	   PaginaHtmlDAO pagDAO = new PaginaHtmlDAO(em);
	   Collection<Tag> tags = pagDAO.listarTags(paginaStr);
	   	   
	   request.setAttribute("pagina",paginaStr);
	   request.setAttribute("tags", tags);
	   
	   getServletContext().getRequestDispatcher("/listaTagsPagina.jsp").forward(request, response);
	   
	   em.close();
	   emf.close();
   }
	
   private void addTagPagina(HttpServletRequest request, HttpServletResponse response)
	   				throws ServletException, IOException {
	   
	   EntityManagerFactory emf = Persistence.createEntityManagerFactory("simplejpa");
	   EntityManager em = emf.createEntityManager();
	   	   	   
	   String tagStr = request.getParameter("tag");
	   String paginaStr = request.getParameter("pagina");
	   
	   TagDAO tagDAO = new TagDAO(em);
	   PaginaHtmlDAO pagDAO = new PaginaHtmlDAO(em);
	   
	   em.getTransaction().begin();
	   try{
		 //Buscamos una etiqueta con el texto introducido para pasar el id
		   Iterator<Tag> it = tagDAO.listaTags().iterator();
		   Tag tagAux = null;
		   Tag tag = null;
		   while(it.hasNext()){
			   tagAux = (Tag)it.next();
			   if (tagStr.equals(tagAux.getCadena())){
				   tag = tagAux;
			   }
		   }	   
		   
		   pagDAO.setTagPaginaHtml(paginaStr, tag.getId());
		   em.getTransaction().commit();
		   
		   request.setAttribute("tag", tagStr);
		   request.setAttribute("pagina", paginaStr);

		   getServletContext().getRequestDispatcher("/addTagPagina.jsp").forward(request, response);
	   }
	   catch(RuntimeException ex){
		   System.out.println("Se ha producido una excepci�n");
		   em.getTransaction().rollback();
	   }
	   finally{
		   em.close();
		   emf.close();
	   }	   
   }

   private void addAutorPagina(HttpServletRequest request, HttpServletResponse response){
	   
	   EntityManagerFactory emf = Persistence.createEntityManagerFactory("simplejpa");
	   EntityManager em = emf.createEntityManager();
	   	   	   	   
	   String autorStr = request.getParameter("autor");
	   String paginaStr = request.getParameter("pagina");
	   
	   PaginaHtmlDAO pagDAO = new PaginaHtmlDAO(em);
	   pagDAO.setAutorPaginaHtml(paginaStr, autorStr);
	   	   
	   em.close();
	   emf.close();
   }
   
   private void addPaginaHtml(){
	   
	   EntityManagerFactory emf = Persistence.createEntityManagerFactory("simplejpa");
	   EntityManager em = emf.createEntityManager();
	   	   
	   PaginaHtml pHtml = new PaginaHtml("fichero");
	   em.persist(pHtml);	   
	   	   
	   em.close();
	   emf.close();
   }
   
   private void addTag() {
	   
	   EntityManagerFactory emf = Persistence.createEntityManagerFactory("simplejpa");
	   EntityManager em = emf.createEntityManager();
	   
	   Tag t = new Tag();
	   em.persist(t);
	   t.setCadena("prueba");
	  	   
	   em.close();
	   emf.close();
   }
   
   private void doCuenta(HttpServletRequest request,
         HttpServletResponse response) throws ServletException, IOException {

	   // Cuenta los mensajes de un autor
	   	   
	   String autorStr = request.getParameter("autor");
	   EntityManagerFactory emf = Persistence.createEntityManagerFactory("simplejpa");

	   EntityManager em = emf.createEntityManager();
   
	   AutorDAO aDAO = new AutorDAO(em);
	   
	   em.getTransaction().begin();
	   try{
		   Autor autor = aDAO.findAutor(autorStr);
		   if (autor == null) {
		   	   autor = aDAO.createAutor(autorStr, autorStr + "@ua.es");
		   }
	   	   
	   	   Collection<Mensaje> mensajes = aDAO.findMensajes(autorStr);
	   	   em.getTransaction().commit();

	   	   request.setAttribute("autor", autor);
	   	   request.setAttribute("mensajes", mensajes.size());

	   	   getServletContext().getRequestDispatcher("/cuentaMensajes.jsp").forward(request, response);
	   }
	   catch(RuntimeException ex){
		   System.out.println("Se ha producido una excepci�n");
		   em.getTransaction().rollback();
	   }
	   finally{
		   em.close();
		   emf.close();
	   }
   }

   private void doLista(HttpServletRequest request, 
                        HttpServletResponse response)
         throws ServletException, IOException {
      
      // Lista los mensajes de un autor
	   	   
	   String autorStr = request.getParameter("autor");
	   EntityManagerFactory emf = Persistence.createEntityManagerFactory("simplejpa");

	   EntityManager em = emf.createEntityManager();
	   
	   AutorDAO aDAO = new AutorDAO(em); 
	   
	   em.getTransaction().begin();
	   
	   try{
		   Autor autor = aDAO.findAutor(autorStr);
		   if (autor == null) {
		   	   autor = aDAO.createAutor(autorStr, autorStr + "@ua.es");
		   }
	   
		   Collection<Mensaje> mensajes = aDAO.findMensajes(autorStr);
		   em.getTransaction().commit();

		   request.setAttribute("autor", autor);
		   request.setAttribute("mensajes", mensajes);

		   getServletContext().getRequestDispatcher("/listaMensajes.jsp").forward(request, response);
	   }
	   catch(RuntimeException ex){
		   System.out.println("Se ha producido una excepci�n");
		   em.getTransaction().rollback();
	   }
	   finally{
		   em.close();
		   emf.close();
	   }
   }

   private void doAdd(HttpServletRequest request, 
                      HttpServletResponse response)
         throws ServletException, IOException {

	   String mensStr = request.getParameter("mensaje");
	   String autorStr = request.getParameter("autor");
	   EntityManagerFactory emf = Persistence.createEntityManagerFactory("simplejpa");

	   EntityManager em = emf.createEntityManager();
	   
	   AutorDAO aDAO = new AutorDAO(em); 
	   MensajeDAO mDAO = new MensajeDAO(em);
	   
	   em.getTransaction().begin();
	   try{
		   Autor autor = aDAO.findAutor(autorStr);
		   if (autor == null) {
			   autor = aDAO.createAutor(autorStr, autorStr + "@ua.es");
		   }
	   
		   Mensaje mensaje = mDAO.createMensaje(mensStr);
	   
		   mDAO.estableceAutor(mensaje.getId(), autor);

		   aDAO.insertaMensaje(autorStr,mensaje);
	   
		   em.getTransaction().commit();

		   request.setAttribute("autor", autor);
		   request.setAttribute("mensaje", mensaje);

		   getServletContext().getRequestDispatcher("/addMensaje.jsp").forward(request, response);
	   }
	   catch(RuntimeException ex){
		   System.out.println("Se ha producido una excepci�n");
		   em.getTransaction().rollback();
	   }
	   finally{
		   em.close();
		   emf.close();
	   }	   
   }
}