package ayto;

import java.util.Collection;

import javax.persistence.*;





public class AutorDAO {
   protected EntityManager em;
   private boolean transaccionActiva = false;
   
   public AutorDAO(EntityManager em) {
      this.em = em;
   }

   public Autor createAutor(String nombre, String correo)  {
	  
	  compruebaComienzoTx();
	  Autor aut = new Autor(nombre,correo);
	  em.persist(aut);
	  compruebaFinTx();
      return aut;
   }

   public void removeAutor(String nombre) {
	  
	  compruebaComienzoTx();
	  Autor aut = em.find(Autor.class, nombre);
      if (aut != null) {
         em.remove(aut);
      }
      compruebaFinTx();
   }

   public Autor findAutor(String nombre) {
      return em.find(Autor.class, nombre);
   }
   
   public void insertaMensaje(String nombre, Mensaje mensaje) {
		
	   compruebaComienzoTx();
	   Autor aut = em.find(Autor.class, nombre);
	   if (aut != null) {
		   aut.addMensaje(mensaje);
	   }
	   compruebaFinTx();
   }
   
   public Collection<Mensaje> findMensajes(String nombre) {
	   
	   Collection<Mensaje> mensajes = null;
	   
	   Autor aut = em.find(Autor.class, nombre);
	   
	   if (aut != null) {
		   mensajes = aut.getMensajes();
	   }
	   return mensajes;
   }
   
   
   public Collection<Tag> findTagsAutor(Autor autor){
	   
	   Collection<Tag> tags = null;
	   
	   Query query = em.createQuery("SELECT DISTINCT t FROM PaginaHtml p JOIN p.tags t " +
	   								" WHERE p.autor LIKE ?1");

	   query.setParameter(1, autor);
	   
	   tags = (Collection<Tag>) query.getResultList();
	   
	   return tags;
   }
   
   public Collection<Mensaje> findMensajeAutorTag(Autor autor, String cadena){
	   
	   Collection<Mensaje> mensajes = null;
	   
	   Query query = em.createQuery("SELECT m FROM Autor a JOIN a.mensajes m " +
									" WHERE a LIKE ?1" +
									" AND a IN(SELECT DISTINCT p.autor FROM PaginaHtml p JOIN p.tags t" +
									"			WHERE t.cadena LIKE ?2)");
	   
	   query.setParameter(1, autor);
	   query.setParameter(2, cadena+"%");
	   
	   mensajes = (Collection<Mensaje>) query.getResultList();
	   
	   return mensajes;
   }
   
   private void compruebaComienzoTx() {
	   transaccionActiva = false;
	   if (!em.getTransaction().isActive()) {
		   em.getTransaction().begin();
		   transaccionActiva = true;
	   }
   }

   private void compruebaFinTx() {
	   if (transaccionActiva) em.getTransaction().commit();
   }
   
}