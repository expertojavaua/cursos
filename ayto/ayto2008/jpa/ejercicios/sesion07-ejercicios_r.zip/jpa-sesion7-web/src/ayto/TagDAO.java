package ayto;

import java.util.Collection;
import java.util.List;

import javax.persistence.*;

public class TagDAO {
   protected EntityManager em;
   private boolean transaccionActiva = false;

   public TagDAO(EntityManager em) {

      this.em = em;
   }

   public Tag createTag(String cadena) {

      compruebaComienzoTx();
      Tag tag = new Tag();
      em.persist(tag);
      tag.setCadena(cadena);
      tag.setFechaCreacion(new java.util.Date());
      tag.setOcurrencias(0);
      compruebaFinTx();
      return tag;
   }

   public Tag cambiaCadena(Tag tag, String cadena) {

      compruebaComienzoTx();
      Tag t = em.find(Tag.class, tag.getId());
      if (t != null) {
         t.setCadena(cadena);
      }
      compruebaFinTx();
      return t;
   }

   @SuppressWarnings("unchecked")
   public List<Tag> listaTags() {
      Query query = em.createQuery("SELECT t FROM Tag t");
      return (List<Tag>) query.getResultList();
   }

   @SuppressWarnings("unchecked")
   public Collection<Tag> findTagsComienzanPor(String cadena) {
      Collection<Tag> tags = null;
      Query query = em
            .createQuery("");
      query.setParameter(1, cadena + "%");
      tags = (Collection<Tag>) query.getResultList();
      return tags;
   }

   public Tag findTagMasUsada() {
      Query query = em
            .createQuery("");
      query.setMaxResults(1);
      return (Tag) query.getSingleResult();
   }

   @SuppressWarnings("unchecked")
   public List<Tag> findTagsUsadasMasDe(int veces) {
      List<Tag> tags = null;
      Query query = em
            .createQuery("");
      query.setParameter(1, veces);
      tags = (List<Tag>) query.getResultList();
      return tags;
   }

   private void compruebaComienzoTx() {
      transaccionActiva = false;
      if (!em.getTransaction().isActive()) {
         em.getTransaction().begin();
         transaccionActiva = true;
      }
   }

   private void compruebaFinTx() {
      if (transaccionActiva)
         em.getTransaction().commit();
   }

}