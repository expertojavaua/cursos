package ayto;

import java.io.*;
import java.util.Collection;
import java.util.Iterator;

import javax.persistence.*;
import javax.servlet.*;
import javax.servlet.http.*;

import ayto.DatosFichero.Encoding;



public class DoActionPaginaHtml extends HttpServlet {
   private static final long serialVersionUID = 1L;

   public void doGet(HttpServletRequest request, HttpServletResponse response)
         throws ServletException, IOException {

      String accion = request.getParameter("accion");

      if (accion.equals("add")) {
         doAddPaginaHtml(request, response);
      } else if (accion.equals("buscar")) {
         doBuscarPaginaHtml(request, response);      
      } else if (accion.equals("listarPaginas")) {
         doListarPaginasHtml(request, response);
      } else if (accion.equals("listarPaginasTag")) {
         doListarPaginasHtmlTag(request, response);
      } else if (accion.equals("listarPaginasTagStrict")) {
          doListarPaginasHtmlTagStrict(request, response);
      } else if (accion.equals("listarPaginasConMasTags")) {
          doListarPaginasHtmlConMasTagsDe(request, response);
      } else {
         PrintWriter out = response.getWriter();
         out.println("Error. La acci�n " + accion + " no est� implementada");
      }
   }
   
   private void doListarPaginasHtmlConMasTagsDe(HttpServletRequest request,
		   HttpServletResponse response) {

	   int veces = Integer.parseInt(request.getParameter("veces"));

	   EntityManagerFactory emf = Persistence.createEntityManagerFactory("simplejpa");
	   EntityManager em = emf.createEntityManager();
	  
	   PaginaHtmlDAO phDAO = new PaginaHtmlDAO(em); 
	   Collection<PaginaHtml> paginas = phDAO.findPaginasHtmlConMasTagsDe(veces);	   
	  
	   Iterator<PaginaHtml> it = paginas.iterator();
	   while(it.hasNext()){
		   System.out.println(it.next().getNombreFichero());
	   }

	   em.close();
	   emf.close();
   }
   
   private void doListarPaginasHtmlTagStrict(HttpServletRequest request,
		   HttpServletResponse response) {

	   String cadena = request.getParameter("cadena");

	   EntityManagerFactory emf = Persistence.createEntityManagerFactory("simplejpa");
	   EntityManager em = emf.createEntityManager();

	   PaginaHtmlDAO phDAO = new PaginaHtmlDAO(em); 
	   Collection<PaginaHtml> paginas = phDAO.findPaginasHtmlTagStrict(cadena);	   

	   Iterator<PaginaHtml> it = paginas.iterator();
	   while(it.hasNext()){
		   System.out.println(it.next().getNombreFichero());
	   }

	   em.close();
	   emf.close();
   }
   
   private void doListarPaginasHtmlTag(HttpServletRequest request,
			HttpServletResponse response) {

	   	String cadena = request.getParameter("cadena");
	   
	   	EntityManagerFactory emf = Persistence.createEntityManagerFactory("simplejpa");
	   	EntityManager em = emf.createEntityManager();

	   	PaginaHtmlDAO phDAO = new PaginaHtmlDAO(em); 
	   	Collection<PaginaHtml> paginas = phDAO.findPaginasHtmlTag(cadena);	   

	   	Iterator<PaginaHtml> it = paginas.iterator();
	   	while(it.hasNext()){
	   		System.out.println(it.next().getNombreFichero());
	   	}

	   	em.close();
	   	emf.close();
   }
   
   private void doListarPaginasHtml(HttpServletRequest request,
	         						HttpServletResponse response) {
		   		   
	   EntityManagerFactory emf = Persistence.createEntityManagerFactory("simplejpa");
	   EntityManager em = emf.createEntityManager();

	   PaginaHtmlDAO phDAO = new PaginaHtmlDAO(em); 
	   Collection<PaginaHtml> paginas = phDAO.findAllPaginasHtml();	   

	   Iterator<PaginaHtml> it = paginas.iterator();
	   while(it.hasNext()){
		   System.out.println(it.next().getNombreFichero());
	   }

	   em.close();
	   emf.close();
   }   
   
   private void doBuscarPaginaHtml(HttpServletRequest request,
         HttpServletResponse response) throws ServletException, IOException {

	   String nombre = request.getParameter("nombre");
	   
	   EntityManagerFactory emf = Persistence.createEntityManagerFactory("simplejpa");
	   EntityManager em = emf.createEntityManager();
	   
	   PaginaHtmlDAO phDAO = new PaginaHtmlDAO(em); 
	   PaginaHtml ph = phDAO.findPaginaHtml(nombre);	   
		   	   
	   request.setAttribute("PaginaHtml", ph);
	   
	   getServletContext().getRequestDispatcher("/buscaPaginaHtml.jsp").forward(request, response);

	   em.close();
	   emf.close();
   }

   

   private void doAddPaginaHtml(HttpServletRequest request, 
                      HttpServletResponse response)
         throws ServletException, IOException {

	   String nombre = request.getParameter("nombre");
	   String codigo = request.getParameter("codigo");
	   Encoding encoding = Encoding.valueOf(request.getParameter("encoding"));
	   
	   EntityManagerFactory emf = Persistence.createEntityManagerFactory("simplejpa");
	   EntityManager em = emf.createEntityManager();
	   
	   PaginaHtmlDAO phDAO = new PaginaHtmlDAO(em); 
	   PaginaHtml ph = phDAO.createPaginaHtml(nombre, codigo, encoding);
	   	   
	   request.setAttribute("nombre", ph.getNombreFichero());
	   
	   getServletContext().getRequestDispatcher("/addPaginaHtml.jsp").forward(request, response);

	   em.close();
	   emf.close();
   }
}