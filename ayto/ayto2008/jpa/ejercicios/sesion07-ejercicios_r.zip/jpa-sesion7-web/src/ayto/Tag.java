package ayto;

import java.util.Collection;
import java.util.Date;
import java.util.HashSet;

import javax.persistence.*;

@Entity
public class Tag{
	
	@Id @GeneratedValue private int id;
	private String cadena;
	private Date fechaCreacion;
	private int ocurrencias;
	@ManyToMany(mappedBy="tags")
	private Collection<PaginaHtml> paginas = new HashSet<PaginaHtml>();
	
	
	public Tag() {
	
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCadena() {
		return cadena;
	}

	public void setCadena(String cadena) {
		this.cadena = cadena;
	}

	public Date getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public int getOcurrencias() {
		return ocurrencias;
	}

	public void setOcurrencias(int ocurrencias) {
		this.ocurrencias = ocurrencias;
	}
	
	public Collection<PaginaHtml> getPaginas() {
		
	   return paginas;
	}

	public void addPagina(PaginaHtml pagina) {
		   
	   this.paginas.add(pagina);
	}
	
}