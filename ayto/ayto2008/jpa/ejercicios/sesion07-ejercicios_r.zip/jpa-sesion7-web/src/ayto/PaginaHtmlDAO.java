package ayto;

import java.util.Collection;

import javax.persistence.*;

import ayto.DatosFichero.Encoding;

public class PaginaHtmlDAO {
   protected EntityManager em;
   private boolean transaccionActiva = false;

   public PaginaHtmlDAO(EntityManager em) {
      this.em = em;
   }

   public PaginaHtml createPaginaHtml(String nombre, String html,
         Encoding encoding) {

      compruebaComienzoTx();
      PaginaHtml pHtml = new PaginaHtml(nombre);
      em.persist(pHtml);
      pHtml.setHtml(html);
      DatosFichero df = new DatosFichero();
      df.setEncoding(encoding);
      df.setEstilo(DatosFichero.EstiloHtml.HTML_4_01_TRANSITIONAL);
      df.setExtension(".html");
      pHtml.setDatos(df);
      pHtml.setCreacion(new java.util.Date());
      compruebaFinTx();
      return pHtml;
   }

   public PaginaHtml findPaginaHtml(String nombre) {

      return em.find(PaginaHtml.class, nombre);
   }

   public PaginaHtml cambiaEncondingPaginaHtml(PaginaHtml pagina,
         Encoding nuevoEncoding) {

      compruebaComienzoTx();
      PaginaHtml pHtml = em.find(PaginaHtml.class, pagina.getNombreFichero());
      if (pHtml != null) {
         pHtml.getDatos().setEncoding(nuevoEncoding);
      }
      compruebaFinTx();
      return pHtml;
   }

   public PaginaHtml cambiaNombrePaginaHtml(PaginaHtml pagina,
         String nuevoNombre) {

      compruebaComienzoTx();
      PaginaHtml pHtml = em.find(PaginaHtml.class, pagina.getNombreFichero());
      if (pHtml != null) {
         pHtml.setNombreFichero(nuevoNombre);
      }
      compruebaFinTx();
      return pHtml;
   }

   public PaginaHtml setAutorPaginaHtml(String pagina, String autor) {

      compruebaComienzoTx();
      PaginaHtml pHtml = em.find(PaginaHtml.class, pagina);
      Autor aut = em.find(Autor.class, autor);
      if (pHtml != null && aut != null) {
         pHtml.setAutor(aut);
         aut.addPagina(pHtml);
      }
      compruebaFinTx();
      return pHtml;
   }

   public PaginaHtml setTagPaginaHtml(String pagina, int id) {

      compruebaComienzoTx();
      PaginaHtml pHtml = em.find(PaginaHtml.class, pagina);
      Tag tag = em.find(Tag.class, id);
      if (pHtml != null) {
         pHtml.addTag(tag);
         tag.addPagina(pHtml);
         tag.setOcurrencias(tag.getOcurrencias() + 1);
      }
      compruebaFinTx();
      return pHtml;
   }

   public Collection<Tag> listarTags(String nombre) {

      Collection<Tag> tags = null;

      PaginaHtml pagHtml = em.find(PaginaHtml.class, nombre);

      if (pagHtml != null) {
         tags = pagHtml.getTags();
      }
      return tags;
   }

   @SuppressWarnings("unchecked")
   public Collection<PaginaHtml> findAllPaginasHtml() {
      Collection<PaginaHtml> paginas = null;
      Query query = em.createQuery("");
      paginas = (Collection<PaginaHtml>) query.getResultList();
      return paginas;
   }

   @SuppressWarnings("unchecked")
   public Collection<PaginaHtml> findPaginasHtmlTag(String cadena) {
      Collection<PaginaHtml> paginas = null;
      Query query = em.createQuery("");
      query.setParameter(1, cadena + "%");
      paginas = (Collection<PaginaHtml>) query.getResultList();
      return paginas;
   }

   @SuppressWarnings("unchecked")
   public Collection<PaginaHtml> findPaginasHtmlTagStrict(String cadena) {
      Collection<PaginaHtml> paginas = null;
      Query query = em.createQuery("");
      query.setParameter(1, cadena);
      paginas = (Collection<PaginaHtml>) query.getResultList();
      return paginas;
   }

   @SuppressWarnings("unchecked")
   public Collection<PaginaHtml> findPaginasHtmlConMasTagsDe(int veces) {
      Collection<PaginaHtml> paginas = null;
      Query query = em.createQuery("");
      query.setParameter(1, (long) veces);
      paginas = (Collection<PaginaHtml>) query.getResultList();
      return paginas;
   }

   private void compruebaComienzoTx() {
      transaccionActiva = false;
      if (!em.getTransaction().isActive()) {
         em.getTransaction().begin();
         transaccionActiva = true;
      }
   }

   private void compruebaFinTx() {
      if (transaccionActiva)
         em.getTransaction().commit();
   }

}