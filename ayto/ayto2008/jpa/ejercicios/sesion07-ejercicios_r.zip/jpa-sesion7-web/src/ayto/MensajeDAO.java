package ayto;

import javax.persistence.*;




public class MensajeDAO {
   protected EntityManager em;
   private boolean transaccionActiva = false;
   
   public MensajeDAO(EntityManager em) {
      this.em = em;
   }

   public Mensaje createMensaje(String texto, Autor autor)  {
	   
	   compruebaComienzoTx();
	   Mensaje men = new Mensaje(texto,autor);
	   em.persist(men);
	   compruebaFinTx();
	   return men;	   
   }
   
   public Mensaje createMensaje(String texto)  {
	   
	   compruebaComienzoTx();
	   Mensaje men = new Mensaje(texto);
	   em.persist(men);
	   compruebaFinTx();
	   return men;
   }

   public void removeMensaje(long id) {
	   
	   compruebaComienzoTx();
	   Mensaje men = em.find(Mensaje.class, id);
	   if (men != null) {
		   em.remove(men);
	   }
	   compruebaFinTx();
   }

   public Mensaje findMensaje(long id) {
      return em.find(Mensaje.class, id);
   }
   
   public void estableceAutor(long id, Autor autor) {
	
	   compruebaComienzoTx();
	   Mensaje men = em.find(Mensaje.class, id);
	   if (men != null) {
		   men.setAutor(autor);
	   }
	   compruebaFinTx();
   }
   
   private void compruebaComienzoTx() {
	   transaccionActiva = false;
	   if (!em.getTransaction().isActive()) {
		   em.getTransaction().begin();
		   transaccionActiva = true;
	   }
   }

   private void compruebaFinTx() {
	   if (transaccionActiva) em.getTransaction().commit();
   }
   
}