package ayto;

import java.io.*;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import javax.persistence.*;
import javax.servlet.*;
import javax.servlet.http.*;




public class DoActionTag extends HttpServlet {
   private static final long serialVersionUID = 1L;

   public void doGet(HttpServletRequest request, HttpServletResponse response)
         throws ServletException, IOException {

      String accion = request.getParameter("accion");

      if (accion.equals("add")) {
         doAddTag(request, response);
      } else if (accion.equals("listar")) {
         doListarTag(request, response);
      } else if (accion.equals("buscar")) {
         doBuscarTag(request, response);
      } else if (accion.equals("tagsComienzan")) {
          doTagsComienzanPor(request, response);
      } else if (accion.equals("tagMasUsada")) {
    	  doTagMasUsada(request, response);
      } else if (accion.equals("tagsUsadasMas")) {
    	  doTagsUsadasMasDe(request, response);      
      } else {
         PrintWriter out = response.getWriter();
         out.println("Error. La acci�n " + accion + " no est� implementada");
      }
   }   
   
   private void doTagsUsadasMasDe(HttpServletRequest request,
		   HttpServletResponse response) {

	   int veces = Integer.parseInt(request.getParameter("veces"));
	   
	   EntityManagerFactory emf = Persistence.createEntityManagerFactory("simplejpa");
	   EntityManager em = emf.createEntityManager();
	 
	   TagDAO tDAO = new TagDAO(em); 
	   List<Tag> tags = tDAO.findTagsUsadasMasDe(veces);
	 	 
	   Iterator<Tag> it = tags.iterator();
	   while(it.hasNext()){
		   System.out.println(it.next().getCadena());
	   }
	   
	   em.close();
	   emf.close();
   }
   
   private void doTagMasUsada(HttpServletRequest request,
		   HttpServletResponse response) {

	   EntityManagerFactory emf = Persistence.createEntityManagerFactory("simplejpa");
	   EntityManager em = emf.createEntityManager();
	 
	   TagDAO tDAO = new TagDAO(em); 
	   Tag tag = tDAO.findTagMasUsada();	   
	 
	   System.out.println(tag.getCadena());
	   
	   em.close();
	   emf.close();
   }
   
   private void doTagsComienzanPor(HttpServletRequest request,
		   HttpServletResponse response) {

	   String cadena = request.getParameter("cadena");

	   EntityManagerFactory emf = Persistence.createEntityManagerFactory("simplejpa");
	   EntityManager em = emf.createEntityManager();

	   TagDAO tDAO = new TagDAO(em); 
	   Collection<Tag> tags = tDAO.findTagsComienzanPor(cadena);	   

	   Iterator<Tag> it = tags.iterator();
	   while(it.hasNext()){
		   System.out.println(it.next().getCadena());
	   }

	   em.close();
	   emf.close();
   }
   
   private void doBuscarTag(HttpServletRequest request,
         HttpServletResponse response) throws ServletException, IOException {

	   String cadena = request.getParameter("cadena");
	   
	   EntityManagerFactory emf = Persistence.createEntityManagerFactory("simplejpa");
	   EntityManager em = emf.createEntityManager();
	   
	   TagDAO tDAO = new TagDAO(em);
	   List<Tag> tags = tDAO.listaTags();
	   
	   Iterator<Tag> it = tags.iterator();
	   
	   Tag t = null;
	   Tag aux = null;
	   while (it.hasNext()){
		   
		   aux = it.next();
		   if(aux.getCadena().equals(cadena)){
			   t = aux;			   
		   }		   
	   }

	   request.setAttribute("tag", t);
	   
	   getServletContext().getRequestDispatcher("/buscaTag.jsp").forward(request, response);

	   em.close();
	   emf.close();
   }

   private void doListarTag(HttpServletRequest request, 
                        HttpServletResponse response)
         throws ServletException, IOException {
      
      EntityManagerFactory emf = Persistence.createEntityManagerFactory("simplejpa");
      EntityManager em = emf.createEntityManager();
	   
      TagDAO tDAO = new TagDAO(em);
      List<Tag> tags = tDAO.listaTags(); 

	  request.setAttribute("tags", tags);

	  getServletContext().getRequestDispatcher("/listaTags.jsp").forward(request, response);

	  em.close();
	  emf.close();

   }

   private void doAddTag(HttpServletRequest request, 
                      HttpServletResponse response)
         throws ServletException, IOException {

	   String cadena = request.getParameter("cadena");
	   
	   EntityManagerFactory emf = Persistence.createEntityManagerFactory("simplejpa");
	   EntityManager em = emf.createEntityManager();
	   
	   TagDAO tDAO = new TagDAO(em); 
	   Tag tag = tDAO.createTag(cadena);

	   request.setAttribute("cadena", tag.getCadena());
	   
	   getServletContext().getRequestDispatcher("/addTag.jsp").forward(request, response);

	   em.close();
	   emf.close();
   }
}