package ayto;

import java.util.Collection;
import java.util.Date;
import java.util.HashSet;

import javax.persistence.*;

@Entity
public class PaginaHtml{
	
	@Id private String nombreFichero;
	@Embedded private DatosFichero datos;
	private Date creacion;
	@Lob private String html;
	@ManyToOne
	private Autor autor;
	@ManyToMany
	private Collection<Tag> tags = new HashSet<Tag>();
	
	
	protected PaginaHtml() {
	
	}
	
	public PaginaHtml(String nombre) {
		this.nombreFichero = nombre;
	}

	public String getNombreFichero() {
		return nombreFichero;
	}

	public void setNombreFichero(String nombreFichero) {
		this.nombreFichero = nombreFichero;
	}

	public DatosFichero getDatos() {
		return datos;
	}

	public void setDatos(DatosFichero datos) {
		this.datos = datos;
	}

	public Date getCreacion() {
		return creacion;
	}

	public void setCreacion(Date creacion) {
		this.creacion = creacion;
	}

	public String getHtml() {
		return html;
	}

	public void setHtml(String html) {
		this.html = html;
	}
	
	public Autor getAutor() {
		return autor;
	}

	public void setAutor(Autor autor) {
		this.autor = autor;
	}
	
	public Collection<Tag> getTags() {
		
	   return tags;
	}

	public void addTag(Tag tag) {
		   
	   this.tags.add(tag);
	}
	
	
}