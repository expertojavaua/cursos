package ayto;

import javax.persistence.*;

@Embeddable
public class DatosFichero {
	
	@Enumerated(EnumType.STRING) private Encoding encoding;
	@Enumerated(EnumType.STRING) private EstiloHtml estilo;
	private String extension;
	
	public enum Encoding {WINDOWS_LATIN_1,UNIX_LATIN_1,MAC_ROMAN,UTF_8};
	
	public enum EstiloHtml {HTML_4_01_STRICT, HTML_4_01_TRANSITIONAL, XHTML_1_0_STRICT, XHTML_1_0_TRANSATIONAL}

	public Encoding getEncoding() {
		return encoding;
	}

	public void setEncoding(Encoding encoding) {
		this.encoding = encoding;
	}

	public EstiloHtml getEstilo() {
		return estilo;
	}

	public void setEstilo(EstiloHtml estilo) {
		this.estilo = estilo;
	}

	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	};	
	
	
}