package cliente;

import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import es.ua.jtech.amigosSpring.AmigosSpringException;
import es.ua.jtech.amigosSpring.modelo.Sexo;
import es.ua.jtech.amigosSpring.modelo.UsuarioTO;
import es.ua.jtech.amigosSpring.negocio.IGestorUsuariosRemoto;

public class Cliente {

	/**
	 * @param args
	 * @throws AmigosSpringException 
	 */
	public static void main(String[] args) throws AmigosSpringException {
		// Cargar la configuraci�n	
		ClassPathXmlApplicationContext contexto = 
			new ClassPathXmlApplicationContext("cliente.xml");
		//Pedir el bean
		IGestorUsuariosRemoto gur = (IGestorUsuariosRemoto) contexto.getBean("httpProxy");
		
		List<UsuarioTO> lista = gur.buscar("", 0, 100, Sexo.indiferente);
		for(UsuarioTO u : lista) {
			System.out.println(u.getLogin());
		}
	}

}
