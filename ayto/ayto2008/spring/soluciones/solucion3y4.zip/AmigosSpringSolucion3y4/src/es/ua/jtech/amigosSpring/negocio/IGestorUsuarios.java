package es.ua.jtech.amigosSpring.negocio;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import es.ua.jtech.amigosSpring.AmigosSpringException;
import es.ua.jtech.amigosSpring.SinPermisoException;
import es.ua.jtech.amigosSpring.datos.IUsuarioDAO;
import es.ua.jtech.amigosSpring.modelo.Sexo;
import es.ua.jtech.amigosSpring.modelo.UsuarioTO;

public interface IGestorUsuarios {

	@Autowired
	public void setVisitas(Visitas visitas);

	public Visitas getVisitas();

	public void setUsuarioDAO(IUsuarioDAO udao);

	public List<UsuarioTO> buscar(String localidad, int edadMin, int edadMax,
			Sexo sexo) throws AmigosSpringException;

	public void cobrar(UsuarioTO u, int cantidad) throws SinPermisoException,
			AmigosSpringException;

	public UsuarioTO login(String login, String password)
			throws AmigosSpringException;

	public UsuarioTO getUsuario(String login) throws AmigosSpringException;

}