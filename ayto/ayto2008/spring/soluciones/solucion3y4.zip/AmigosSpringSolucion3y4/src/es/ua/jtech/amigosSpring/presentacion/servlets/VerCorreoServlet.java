package es.ua.jtech.amigosSpring.presentacion.servlets;

import es.ua.jtech.amigosSpring.AmigosSpringException;
import es.ua.jtech.amigosSpring.SinPermisoException;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.ua.jtech.amigosSpring.modelo.MensajeTO;
import es.ua.jtech.amigosSpring.modelo.UsuarioTO;
import es.ua.jtech.amigosSpring.negocio.GestorMensajes;
import javax.servlet.ServletContext;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

public class VerCorreoServlet extends AmigosServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = -402880766206042024L;

	public VerCorreoServlet() {
		super();
	}

	@Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //sacar el usuario actual de la sesion HTTP   	
        UsuarioTO usuario = (UsuarioTO) request.getSession().getAttribute("usuario");
        //si no est�, no hay permiso de acceso
        if (usuario == null) {
            doForward(request, response, "/index.jsp");
        }
        //Obtenemos la factoría de beans (el WebApplicationContext)
        ServletContext sc = getServletContext();
        WebApplicationContext wac = WebApplicationContextUtils.getWebApplicationContext(sc);
        //Pedimos el bean por nombre
        GestorMensajes gm = (GestorMensajes) wac.getBean("gestorMensajes");

        //Empieza la "accion"
        try {
            List<MensajeTO> recibidos = gm.getRecibidos(usuario);
            request.getSession().setAttribute("recibidos", recibidos);
            doForward(request, response, "/correo.jsp");
        } catch (SinPermisoException spe) {
            request.getSession().setAttribute("error", spe.getMessage());
            doForward(request, response, "/personal.jsp");
        } catch (AmigosSpringException ase) {
            request.getSession().setAttribute("exception", ase);
            doForward(request, response, "/error.jsp");
        }

    }
	
}
