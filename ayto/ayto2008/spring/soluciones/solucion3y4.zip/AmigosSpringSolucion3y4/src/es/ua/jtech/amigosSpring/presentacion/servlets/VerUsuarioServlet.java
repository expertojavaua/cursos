package es.ua.jtech.amigosSpring.presentacion.servlets;

import es.ua.jtech.amigosSpring.AmigosSpringException;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.ua.jtech.amigosSpring.modelo.UsuarioTO;
import es.ua.jtech.amigosSpring.negocio.IGestorUsuarios;

import javax.servlet.ServletContext;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

public class VerUsuarioServlet extends AmigosServlet {

    /**
     * 
     */
    private static final long serialVersionUID = 1101984568591985632L;

    public VerUsuarioServlet() {
        super();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //sacar el usuario actual de la sesion HTTP   	
        UsuarioTO usuario = (UsuarioTO) request.getSession().getAttribute("usuario");
        //si no est�, no hay permiso de acceso
        if (usuario == null) {
            doForward(request, response, "/index.jsp");
        }
        //Obtenemos la factoría de beans (el WebApplicationContext)
        ServletContext sc = getServletContext();
        WebApplicationContext wac = WebApplicationContextUtils.getWebApplicationContext(sc);
        //Pedimos el bean por nombre
        IGestorUsuarios gu = (IGestorUsuarios) wac.getBean("gestorUsuarios");
        try {
            UsuarioTO amigo = gu.getUsuario(request.getParameter("usuario"));
            if (amigo != null) {
                request.setAttribute("amigo", amigo);
                doForward(request, response, "/usuario.jsp");
            } else {
                request.setAttribute("error", "el usuario no existe");
                doForward(request, response, "/personal.jsp");
            }
        }
        catch(AmigosSpringException ase) {
            request.setAttribute("error", ase);
            doForward(request, response, "/error.jsp");            
        }
    }
}
