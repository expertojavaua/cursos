package es.ua.jtech.amigosSpring.mvc;

import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import es.ua.jtech.amigosSpring.SinPermisoException;
import es.ua.jtech.amigosSpring.modelo.MensajeTO;
import es.ua.jtech.amigosSpring.modelo.UsuarioTO;
import es.ua.jtech.amigosSpring.negocio.GestorMensajes;

@Controller
public class LeerMensajeController {
	@Autowired
	GestorMensajes gm;

	@RequestMapping("/leerMensaje.do")
	public String procesar(@RequestParam("id") String id, ModelMap modelo,
			HttpSession sesion) {
		// Comprobar que estamos autentificados
		UsuarioTO u = (UsuarioTO) sesion.getAttribute("usuario");
		if (u == null) {
			return ("index");
		}
		try {
			// Empieza la "accion"
			MensajeTO m = gm.leerMensaje(u, id);
			modelo.addAttribute("mensaje", m);
			return ("mensaje");
		} catch (SinPermisoException spe) {
			modelo.addAttribute("error", spe.getMessage());
			return ("correo");
		}
	}

}
