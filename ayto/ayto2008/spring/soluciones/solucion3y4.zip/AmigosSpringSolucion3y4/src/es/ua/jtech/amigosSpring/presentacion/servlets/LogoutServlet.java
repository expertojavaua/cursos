package es.ua.jtech.amigosSpring.presentacion.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LogoutServlet extends AmigosServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = -3390056458372008461L;

	public LogoutServlet() {
		super();
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            //borrar la sesion HTTP
            request.getSession().invalidate();
            //saltar a la pagina principal
            doForward(request, response, "/index.jsp");
	}
	
	

}
