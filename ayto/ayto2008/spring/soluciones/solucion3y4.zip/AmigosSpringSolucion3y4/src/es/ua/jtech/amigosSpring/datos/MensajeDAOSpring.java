package es.ua.jtech.amigosSpring.datos;

import java.sql.*;
import java.util.*;

import es.ua.jtech.amigosSpring.modelo.*;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.simple.ParameterizedRowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.stereotype.Repository;

/**
 * Implementa las operaciones de acceso a datos relativas a mensajes
 */
@Repository
public class MensajeDAOSpring implements IMensajeDAO {
	private String GETRECIBIDOS_SQL = "select * from recibidos where destinatario=? order by fecha desc";
	private String GETMENSAJE_SQL = "select * from recibidos where id_mensaje=?";
	private String ENVIAR_SQL = "insert into recibidos values(null,null,?,?,?,?)";

	private DataSource ds;

	private SimpleJdbcTemplate template;

	@Autowired
	public void setDatasource(DataSource ds) {
		System.out.println("Instanciando datasource en MensajeDAOSpring " + new java.util.Date());
		this.template = new SimpleJdbcTemplate(ds);
		this.ds = ds;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * es.ua.jtech.amigosSpring.datos.IUsuarioDAO#getMensaje(java.lang.String)
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * es.ua.jtech.amigosSpring.datos.IMensajeDAO#getMensaje(java.lang.String)
	 */
	public MensajeTO getMensaje(String id) throws DAOException {
		MensajeTOMapper miMapper = new MensajeTOMapper();
		
		return this.template.queryForObject(GETMENSAJE_SQL,miMapper,id);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * es.ua.jtech.amigosSpring.datos.IUsuarioDAO#enviar(es.ua.jtech.amigosSpring
	 * .modelo.MensajeTO)
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * es.ua.jtech.amigosSpring.datos.IMensajeDAO#enviar(es.ua.jtech.amigosSpring
	 * .modelo.MensajeTO)
	 */
	public void enviar(MensajeTO mensaje) throws DAOException {
		PreparedStatement ps;
		Connection con = null;

		try {
			// para poder hacer rollback
			con = DataSourceUtils.getConnection(ds);
			// insertar copia en la tabla de mensajes recibidos
			ps = con.prepareStatement(ENVIAR_SQL);
			ps.setString(1, mensaje.getRemitente());
			ps.setString(2, mensaje.getDestinatario());
			ps.setString(3, mensaje.getAsunto());
			ps.setString(4, mensaje.getTexto());
			ps.executeUpdate();
		} catch (SQLException e) {
			throw new DAOException("Error al intentar enviar mensaje", e);
		}
		// cerrar la conexi�n si es que est� abierta
		finally {
			if (con != null)
				// para poder hacer rollback
				DataSourceUtils.releaseConnection(con, ds);
			}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @seees.ua.jtech.amigosSpring.datos.IUsuarioDAO#getRecibidos(es.ua.jtech.
	 * amigosSpring.modelo.UsuarioTO)
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @seees.ua.jtech.amigosSpring.datos.IMensajeDAO#getRecibidos(es.ua.jtech.
	 * amigosSpring.modelo.UsuarioTO)
	 */
	public List<MensajeTO> getRecibidos(UsuarioTO destinatario)
			throws DAOException {
		ArrayList<MensajeTO> lista;
		PreparedStatement ps;
		ResultSet datos;
		Connection con = null;

		lista = new ArrayList<MensajeTO>();
		try {
			con = ds.getConnection();
			ps = con.prepareStatement(GETRECIBIDOS_SQL);
			ps.setString(1, destinatario.getLogin());
			datos = ps.executeQuery();
			while (datos.next()) {
				lista.add(crearMensaje(datos));
			}
			return lista;
		} catch (SQLException sqle) {
			throw new DAOException(
					"Error al intentar obtener la lista de mensajes", sqle);
		}
		// cerrar la conexi�n si es que est� abierta
		finally {
			try {
				if (con != null)
					con.close();
			} catch (SQLException sqle) {
				throw new DAOException(sqle);
			}
		}
	}

	private MensajeTO crearMensaje(ResultSet datos) throws SQLException {
		MensajeTO mensaje;

		mensaje = new MensajeTO();
		mensaje.setId(datos.getString("id_mensaje"));
		mensaje.setFecha(datos.getTimestamp("fecha"));
		mensaje.setAsunto(datos.getString("asunto"));
		mensaje.setTexto(datos.getString("texto"));
		mensaje.setDestinatario(datos.getString("destinatario"));
		mensaje.setRemitente(datos.getString("remitente"));
		return mensaje;
	}

	private class MensajeTOMapper implements ParameterizedRowMapper<MensajeTO> {

		@Override
		public MensajeTO mapRow(ResultSet datos, int numFila) throws SQLException {
			MensajeTO mensaje = new MensajeTO();
			mensaje.setId(datos.getString("id_mensaje"));
			mensaje.setFecha(datos.getTimestamp("fecha"));
			mensaje.setAsunto(datos.getString("asunto"));
			mensaje.setTexto(datos.getString("texto"));
			mensaje.setDestinatario(datos.getString("destinatario"));
			mensaje.setRemitente(datos.getString("remitente"));
			return mensaje;
		}

	}
}
