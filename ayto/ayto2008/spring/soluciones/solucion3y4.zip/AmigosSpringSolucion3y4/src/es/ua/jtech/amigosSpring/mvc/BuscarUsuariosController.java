package es.ua.jtech.amigosSpring.mvc;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import es.ua.jtech.amigosSpring.AmigosSpringException;
import es.ua.jtech.amigosSpring.modelo.UsuarioTO;
import es.ua.jtech.amigosSpring.negocio.IGestorUsuarios;

@Controller
@RequestMapping("/busqueda.do")
public class BuscarUsuariosController {
	@Autowired
	IGestorUsuarios gu;
	
	@RequestMapping(method=RequestMethod.GET)
	public String preparaForm(ModelMap modelo) {
		CriteriosBusqueda cb = new CriteriosBusqueda();
		cb.setEdadMin(18);
		cb.setEdadMax(80);
		modelo.addAttribute("cb", cb);
		return "busqueda";
	}
	
	@RequestMapping(method=RequestMethod.POST)	
	public String procesaForm(@ModelAttribute("cb") CriteriosBusqueda cb,
			BindingResult br, ModelMap modelo) {
		//comprobar errores de conversi�n
		if (br.hasErrors())
			return "busqueda";
		//Validar mi l�gica
		if (cb.getEdadMin()<18) {
			br.rejectValue("edadMin","error.menorDeEdad");
			return "busqueda";
		}
		try {
			//L�gica de negocio
			List<UsuarioTO> lista = gu.buscar(cb.getLocalidad(), cb.getEdadMin(),
					cb.getEdadMax(), cb.getSexo());
			//Guardar el resultado para que lo muestre la vista
			modelo.addAttribute("encontrados", lista);
		} catch (AmigosSpringException e) {
			e.printStackTrace();
			return "error";
		}
		return "encontrados";
	}
}
