package es.ua.jtech.amigosSpring;

/**
 * Error de la aplicacion AmigosJ2EE
 */
public class AmigosSpringException extends Exception {
   /**
	 * 
	 */
	private static final long serialVersionUID = -7169055199986790037L;

/**
    * Envuelve una excepci�n en un objeto de la clase AMigosJ2EEException, para
    * ocultar su naturaleza a las capas superiores.
    * @param e la excepci�n "envuelta".
    */
   public AmigosSpringException(Exception e) {
   	  super(e);
   }
   
   
   /**
    * Construye una excepci�n con el mensaje especificado.
    * @param mensaje mensaje de error asociado a la excepci�n.
    */
   public AmigosSpringException(String mensaje) {
   	  super(mensaje);
   }
}
