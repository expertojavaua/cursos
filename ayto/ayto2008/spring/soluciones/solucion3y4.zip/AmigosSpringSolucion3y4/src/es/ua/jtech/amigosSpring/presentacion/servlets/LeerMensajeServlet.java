package es.ua.jtech.amigosSpring.presentacion.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.ua.jtech.amigosSpring.SinPermisoException;
import es.ua.jtech.amigosSpring.modelo.MensajeTO;
import es.ua.jtech.amigosSpring.modelo.UsuarioTO;
import es.ua.jtech.amigosSpring.negocio.GestorMensajes;
import javax.servlet.ServletContext;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

public class LeerMensajeServlet extends AmigosServlet {

    /**
     * 
     */
    private static final long serialVersionUID = -545933837532786675L;

    public LeerMensajeServlet() {
        super();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Comprobar que estamos autentificados
        UsuarioTO u = (UsuarioTO) request.getSession().getAttribute("usuario");
        if (u == null) {
            doForward(request, response, "/index.jsp");
        }
        //Obtenemos la factoría de beans (el WebApplicationContext)
        ServletContext sc = getServletContext();
        WebApplicationContext wac = WebApplicationContextUtils.getWebApplicationContext(sc);
        //Pedimos el bean por nombre
        GestorMensajes gm = (GestorMensajes) wac.getBean("gestorMensajes");
        try {
            //Empieza la "accion"
            MensajeTO m = gm.leerMensaje(u, request.getParameter("id"));
            request.setAttribute("mensaje", m);
            doForward(request, response, "/mensaje.jsp");
        } catch (SinPermisoException spe) {
            request.setAttribute("error", spe.getMessage());
            doForward(request, response, "/correo.jsp");
        }
    }
}
