package es.ua.jtech.amigosSpring.modelo;

import java.io.Serializable;

public enum Sexo implements Serializable {
	hombre,
	mujer,
	indiferente
}
