package es.ua.jtech.amigosSpring;

/**
 * Indica que un usuario ha intentado realizar una operacion:
 * <ul>
 * <li>Para la que no tiene permiso, como
 * leer un mensaje de correo que no es suyo</li>
 * <li>Para la que no tiene credito suficiente en su cuenta.</li>
 * </ul>
 */
public class SinPermisoException extends Exception {
   /**
	 * 
	 */
	private static final long serialVersionUID = -5767211547412713485L;

/**
    * Envuelve una excepci�n en un objeto de la clase AMigosJ2EEException, para
    * ocultar su naturaleza a las capas superiores.
    * @param e la excepci�n "envuelta".
    */
   public SinPermisoException(Exception e) {
   	  super(e);
   }
   
   /**
    * Construye una excepci�n con el mensaje especificado.
    * @param mensaje mensaje de error asociado a la excepci�n.
    */
   public SinPermisoException(String mensaje) {
   	  super(mensaje);
   }
}
