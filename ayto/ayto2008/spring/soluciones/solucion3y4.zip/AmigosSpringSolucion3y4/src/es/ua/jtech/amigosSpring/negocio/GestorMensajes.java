package es.ua.jtech.amigosSpring.negocio;

import es.ua.jtech.amigosSpring.AmigosSpringException;
import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import es.ua.jtech.amigosSpring.SinPermisoException;
import es.ua.jtech.amigosSpring.datos.DAOException;
import es.ua.jtech.amigosSpring.datos.IMensajeDAO;
import es.ua.jtech.amigosSpring.modelo.MensajeTO;
import es.ua.jtech.amigosSpring.modelo.UsuarioTO;

//Comentado por el ejercicio 3, sesi�n 1
//@Service
public class GestorMensajes {
	// Comentado por el ejercicio 3, sesi�n 1
	// @Autowired
	private IMensajeDAO mdao;
	// Comentado por el ejercicio 3, sesi�n 1
	// @Autowired
	private IGestorUsuarios gu;

	private static int COSTE_MENSAJE;

	public int getCOSTE_MENSAJE() {
		return COSTE_MENSAJE;
	}

	public void setCOSTE_MENSAJE(int coste_mensaje) {
		COSTE_MENSAJE = coste_mensaje;
	}

	public void setMensajeDAO(IMensajeDAO mdao) {
		this.mdao = mdao;
	}

	public void setGestorUsuarios(IGestorUsuarios gu) {
		this.gu = gu;
	}

	@Transactional(rollbackFor=SinPermisoException.class)
	public void enviar(UsuarioTO u, MensajeTO mensaje)
			throws SinPermisoException, AmigosSpringException {
		try {
			mdao.enviar(mensaje);
		} catch (DAOException daoe) {
			throw new AmigosSpringException(
					"Hay problemas con el correo. Vuelve a intentarlo");
		}
		gu.cobrar(u, COSTE_MENSAJE);
	}

	public List<MensajeTO> getRecibidos(UsuarioTO destinatario)
			throws SinPermisoException, AmigosSpringException {
		// si el usuario no tiene crédito, no puede ver el buzón
		if (destinatario.getCredito() <= 0)
			throw new SinPermisoException(
					"Debes tener credito para ver el buzón");
		try {
			return mdao.getRecibidos(destinatario);
		} catch (DAOException daoe) {
			throw new AmigosSpringException("Hay problemas con tu buzón");
		}
	}

	public MensajeTO leerMensaje(UsuarioTO usuario, String id)
			throws SinPermisoException {

		// No se cobra por leer mensajes, pero el usuario debe tener credito > 0
		if (usuario.getCredito() <= 0)
			throw new SinPermisoException(
					"Debes tener credito para poder leer mensajes");
		try {
			return mdao.getMensaje(id);
		} catch (DAOException daoe) {
			throw new SinPermisoException("El mensaje no existe");
		}
	}

}
