package es.ua.jtech.amigosSpring.datos;

import java.util.List;

import javax.sql.DataSource;

import es.ua.jtech.amigosSpring.modelo.Sexo;
import es.ua.jtech.amigosSpring.modelo.UsuarioTO;

public interface IUsuarioDAO {

	public void setDataSource(DataSource ds);

	/**
	 * Devuelve un usuario sabiendo su login, <tt>null</tt> en caso contrario
	 * @param login login del usuario a buscar.
	 * @return un usuario, <tt>null</tt> si no existe.
	 * @throws DAOException si se produce una excepci�n de acceso a datos.
	 */
	public UsuarioTO getUsuario(String login) throws DAOException;

	/**
	 * Obtiene una lista de usuarios que cumplen los criterios especificados.
	 * @param localidad localidad de procedencia
	 * @param edadMin edad minima
	 * @param edadMax edad maxima
	 * @param sexo sexo
	 * @return la lista de usuarios que cumplen todas las condiciones, vac�a en caso
	 * de que no haya ninguno.
	 */
	public List<UsuarioTO> buscar(String localidad, int edadMin, int edadMax,
			Sexo sexo) throws DAOException;

	/**
	 * Modificar los datos de un usuario
	 * @param usuario nuevos datos
	 */
	public void actualizarCredito(UsuarioTO uto, int nuevoCredito)
			throws DAOException;

}