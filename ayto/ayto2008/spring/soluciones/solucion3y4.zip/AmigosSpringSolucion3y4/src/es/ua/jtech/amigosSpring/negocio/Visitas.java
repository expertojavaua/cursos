package es.ua.jtech.amigosSpring.negocio;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

@Service
@Scope("session")
public class Visitas {
    private List<String> logins;
    
    public Visitas() {
        logins = new ArrayList<String>();
    }
    
    public List<String> getLogins() {
        return logins;
    }
    
    public void addVisita(String login) {
        if (!logins.contains(login))
            logins.add(login);
    }
}
