package es.ua.jtech.amigosSpring.negocio;

import java.util.List;

import es.ua.jtech.amigosSpring.AmigosSpringException;
import es.ua.jtech.amigosSpring.modelo.Sexo;
import es.ua.jtech.amigosSpring.modelo.UsuarioTO;

public interface IGestorUsuariosRemoto {
	public List<UsuarioTO> buscar(String localidad, int edadMin, int edadMax,
			Sexo sexo) throws AmigosSpringException;
	public UsuarioTO login(String login, String password) throws AmigosSpringException;
}
