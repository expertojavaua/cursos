package es.ua.jtech.amigosSpring.mvc;

import es.ua.jtech.amigosSpring.modelo.Sexo;

public class CriteriosBusqueda {
	private Sexo sexo;
	private int edadMin;
	private int edadMax;
	private String localidad;
	
	public Sexo getSexo() {
		return sexo;
	}
	public void setSexo(Sexo sexo) {
		this.sexo = sexo;
	}
	public int getEdadMin() {
		return edadMin;
	}
	public void setEdadMin(int edadMin) {
		this.edadMin = edadMin;
	}
	public int getEdadMax() {
		return edadMax;
	}
	public void setEdadMax(int edadMax) {
		this.edadMax = edadMax;
	}
	public String getLocalidad() {
		return localidad;
	}
	public void setLocalidad(String localidad) {
		this.localidad = localidad;
	}
	
	
	
	
	
}
