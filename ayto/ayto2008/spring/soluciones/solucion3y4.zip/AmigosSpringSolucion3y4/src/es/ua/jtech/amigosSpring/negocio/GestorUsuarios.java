package es.ua.jtech.amigosSpring.negocio;

import es.ua.jtech.amigosSpring.AmigosSpringException;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.ua.jtech.amigosSpring.SinPermisoException;
import es.ua.jtech.amigosSpring.datos.DAOException;
import es.ua.jtech.amigosSpring.datos.IUsuarioDAO;
import es.ua.jtech.amigosSpring.modelo.Sexo;
import es.ua.jtech.amigosSpring.modelo.UsuarioTO;

@Service
public class GestorUsuarios implements IGestorUsuarios, IGestorUsuariosRemoto {
	@Resource(name="usuarioDAO")
    private IUsuarioDAO udao;
	
	private Visitas visitas;
	
	/* (non-Javadoc)
	 * @see es.ua.jtech.amigosSpring.negocio.IGestorUsuarios#setVisitas(es.ua.jtech.amigosSpring.negocio.Visitas)
	 */
	@Autowired
	public void setVisitas(Visitas visitas) {
		this.visitas = visitas;
	}
	
	/* (non-Javadoc)
	 * @see es.ua.jtech.amigosSpring.negocio.IGestorUsuarios#getVisitas()
	 */
	public Visitas getVisitas() {
		return this.visitas;
	}

    /* (non-Javadoc)
	 * @see es.ua.jtech.amigosSpring.negocio.IGestorUsuarios#setUsuarioDAO(es.ua.jtech.amigosSpring.datos.IUsuarioDAO)
	 */
    public void setUsuarioDAO(IUsuarioDAO udao) {
        this.udao = udao;
    }

    /* (non-Javadoc)
	 * @see es.ua.jtech.amigosSpring.negocio.IGestorUsuarios#buscar(java.lang.String, int, int, es.ua.jtech.amigosSpring.modelo.Sexo)
	 */
    public List<UsuarioTO> buscar(String localidad, int edadMin, int edadMax,
            Sexo sexo) throws AmigosSpringException {
        try {
            return udao.buscar(localidad, edadMin, edadMax, sexo);
        } catch (DAOException daoe) {
            throw new AmigosSpringException(daoe);
        }
    }

    /* (non-Javadoc)
	 * @see es.ua.jtech.amigosSpring.negocio.IGestorUsuarios#cobrar(es.ua.jtech.amigosSpring.modelo.UsuarioTO, int)
	 */
    public void cobrar(UsuarioTO u, int cantidad) throws SinPermisoException, AmigosSpringException {
        int credActual = u.getCredito() - cantidad;
        if (credActual < 0) {
            throw new SinPermisoException("No tienes credito suficiente para realizar esta operación");
        } else {
            u.setCredito(credActual);
            try {
                udao.actualizarCredito(u, credActual);
            } catch (DAOException daoe) {
                throw new AmigosSpringException(daoe);
            }
        }
    }

    /* (non-Javadoc)
	 * @see es.ua.jtech.amigosSpring.negocio.IGestorUsuarios#login(java.lang.String, java.lang.String)
	 */
    public UsuarioTO login(String login, String password) throws AmigosSpringException {
        UsuarioTO u = null;

        try {
            u = udao.getUsuario(login);
            if (u == null || (!u.getPassword().equals(password))) {
                throw new AmigosSpringException("login y/o password erróneos");
            } else {
                return u;
            }
        } catch (DAOException daoe) {
            throw new AmigosSpringException(daoe);
        }
    }

    /* (non-Javadoc)
	 * @see es.ua.jtech.amigosSpring.negocio.IGestorUsuarios#getUsuario(java.lang.String)
	 */
    public UsuarioTO getUsuario(String login) throws AmigosSpringException {
    	visitas.addVisita(login);
        try {
            UsuarioTO uto = udao.getUsuario(login);
            return uto;
        } catch (DAOException daoe) {
            throw new AmigosSpringException(daoe);
        }
    }
}
