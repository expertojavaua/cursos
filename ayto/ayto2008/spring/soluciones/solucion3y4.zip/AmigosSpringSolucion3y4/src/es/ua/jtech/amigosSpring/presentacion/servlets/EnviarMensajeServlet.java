package es.ua.jtech.amigosSpring.presentacion.servlets;

import es.ua.jtech.amigosSpring.AmigosSpringException;
import es.ua.jtech.amigosSpring.SinPermisoException;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.ua.jtech.amigosSpring.modelo.MensajeTO;
import es.ua.jtech.amigosSpring.modelo.UsuarioTO;
import es.ua.jtech.amigosSpring.negocio.GestorMensajes;
import javax.servlet.ServletContext;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

public class EnviarMensajeServlet extends AmigosServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 8998957071573304455L;

	public EnviarMensajeServlet() {
		super();
	}

	@Override
        protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            //Obtenemos el usuario de la sesión (remitente)
            UsuarioTO u = (UsuarioTO) request.getSession().getAttribute("usuario");
            if (u == null) {
                doForward(request, response, "/index.jsp");
            }
            //Construimos el mensaje a partir de los parametros HTTP
            MensajeTO m = new MensajeTO();
            m.setAsunto(request.getParameter("asunto"));
            m.setDestinatario(request.getParameter("destinatario"));
            m.setRemitente(u.getLogin());
            m.setTexto(request.getParameter("texto"));
            //Obtenemos la factoría de beans (el WebApplicationContext)
            ServletContext sc = getServletContext();
            WebApplicationContext wac = WebApplicationContextUtils.getWebApplicationContext(sc);
            //Pedimos el bean por nombre
            GestorMensajes gm = (GestorMensajes) wac.getBean("gestorMensajes");
                //Empieza la "accion"
		try {
                    gm.enviar(u, m);
		    doForward(request, response, "/personal.jsp");
                } catch(SinPermisoException spe) {
                    request.setAttribute("error", spe.getMessage());
		    doForward(request, response, "/personal.jsp");                    
		} catch (AmigosSpringException ase) {
                    request.setAttribute("exception", ase);
		    doForward(request, response, "/error.jsp");
                }
	}
	

}
