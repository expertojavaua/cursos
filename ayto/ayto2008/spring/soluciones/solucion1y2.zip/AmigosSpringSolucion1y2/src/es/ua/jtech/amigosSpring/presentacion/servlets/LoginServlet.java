package es.ua.jtech.amigosSpring.presentacion.servlets;

import es.ua.jtech.amigosSpring.AmigosSpringException;
import es.ua.jtech.amigosSpring.modelo.UsuarioTO;

import es.ua.jtech.amigosSpring.negocio.GestorUsuarios;
import java.io.IOException;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

public class LoginServlet extends AmigosServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5048956930130368789L;

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
            
            //Obtenemos la factoría de beans (el WebApplicationContext)
            ServletContext sc = getServletContext();
            WebApplicationContext wac = WebApplicationContextUtils.getWebApplicationContext(sc);
            //Pedimos el bean por nombre
            GestorUsuarios gu = (GestorUsuarios) wac.getBean("gestorUsuarios");
	    //Ahora comienza la "accion"
            try {
                UsuarioTO u = gu.login(request.getParameter("login"), request.getParameter("password"));
                request.getSession().setAttribute("usuario", u);
                doForward(request, response, "/personal.jsp");
            }
            catch(AmigosSpringException ase) {
		request.setAttribute("error", ase.getMessage());
   		doForward(request, response, "/index.jsp");			                
            }
	}

	

}
