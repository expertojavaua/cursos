DROP DATABASE IF EXISTS amigos;
CREATE DATABASE amigos;
USE amigos;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `login` varchar(20) NOT NULL default '',
  `password` varchar(20) NOT NULL default '',
  `varon` tinyint(1) unsigned NOT NULL default '0',
  `fechaNac` date NOT NULL default '0000-00-00',
  `localidad` varchar(30) NOT NULL default '',
  `descripcion` mediumtext NOT NULL,
  `credito` int(5) unsigned default '0',
  PRIMARY KEY  (`login`),
  UNIQUE KEY `login` (`login`),
  KEY `login_2` (`login`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES ('j2ee','j2ee',1,'1979-01-01','Alicante','En realidad yo ni quiero conocer a nadie ni nada, esto solamente es una prueba para el curso de Java Enterprise. ',7),('jsf','jsf',0,'1987-10-02','Alcoy','Basicamente busco gente que le guste el tema de JSF para discutir sobre ello, crear algunos componentes GUI juntos, y quien sabe...',1),('maria','maria',0,'1980-09-07','San Vicente del Raspeig','Hola a todos, me aburria soberanamente y por eso he decidido darme de alta en AmigosSpring. A ver que os contais!!',10),('pepe','pepe',1,'1980-09-09','Alicante','Hola, soy un programador de .NET despistado que me he metido en esto de AmigosSpring a ver que pasa, espero conocer mucha gente.',3),('spring','spring',0,'1975-01-01','springFrameworkLandia','Me encanta Spring!!! Odio los EJBs!! sobre todo la versi�n 2.x. �Vosotros qu� opin�is?',0),('triqui','triqui',1,'1965-01-07','Sesame Street','MMMM!!! galletas!!!!',10);
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;


DROP TABLE IF EXISTS `recibidos`;
CREATE TABLE `recibidos` (
  `id_mensaje` int(5) unsigned NOT NULL auto_increment,
  `fecha` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `remitente` varchar(20) NOT NULL default '',
  `destinatario` varchar(20) NOT NULL default '',
  `asunto` varchar(100) default NULL,
  `texto` mediumtext,
  PRIMARY KEY  (`id_mensaje`),
  UNIQUE KEY `id_mensaje` (`id_mensaje`),
  KEY `id_mensaje_2` (`id_mensaje`),
  KEY `destinatario_existe` (`destinatario`),
  KEY `remitente_existe` (`remitente`),
  CONSTRAINT `destinatario_existe` FOREIGN KEY (`destinatario`) REFERENCES `usuarios` (`login`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `remitente_existe` FOREIGN KEY (`remitente`) REFERENCES `usuarios` (`login`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `recibidos`
--

LOCK TABLES `recibidos` WRITE;
/*!40000 ALTER TABLE `recibidos` DISABLE KEYS */;
INSERT INTO `recibidos` VALUES (7,'2007-02-10 09:35:31','jsf','j2ee','hola!!','Pues nada, que he visto tu pagina y he pensado en mandarte un mensajito de saludo...a ver si te animas a decirme algo!!');
/*!40000 ALTER TABLE `recibidos` ENABLE KEYS */;
UNLOCK TABLES;


-- Dump completed on 2008-05-02 13:26:11
