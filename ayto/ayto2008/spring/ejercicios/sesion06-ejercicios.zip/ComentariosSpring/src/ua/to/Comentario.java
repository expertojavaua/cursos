package ua.to;
import java.text.SimpleDateFormat;
import java.util.*;

public class Comentario {
	private String autor;
	private Date fecha;
	private String texto;
	private static SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

	public Comentario() {
		
	}
	
	public Comentario(String autor, String texto) {
		this.autor = autor;
		this.texto = texto;
		this.fecha = new Date();
	}
	
	
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}
	public Date getFecha() {
		return fecha;
	}
	public String getFechaCadena() {
		return sdf.format(fecha);
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	public String getTexto() {
		return texto;
	}
	public void setTexto(String texto) {
		this.texto = texto;
	}
	
	
	
}
