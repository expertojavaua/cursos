package ua.dao;

import java.util.List;

import ua.to.Comentario;

public interface IComentarioDAO {

	public void addComentario(String autor, String texto);

	public List<Comentario> listarComentarios();

}