package ua.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import ua.to.Comentario;

@Repository
public class ComentarioDAO implements IComentarioDAO {
	@Autowired
	DataSource ds;

	/* (non-Javadoc)
	 * @see ua.dao.IComentarioDAO#addComentario(java.lang.String, java.lang.String)
	 */
	public void addComentario(String autor, String texto) {
		try {
			Connection con = ds.getConnection();
			PreparedStatement sql = con
					.prepareStatement("INSERT INTO comentarios VALUES (NULL,NULL,?,?)");
			sql.setString(1, autor);
			sql.setString(2, texto);
			sql.executeUpdate();
			con.close();
		} catch (SQLException sqle) {
			sqle.printStackTrace();
		}
	}
	
	/* (non-Javadoc)
	 * @see ua.dao.IComentarioDAO#listarComentarios()
	 */
	public List<Comentario> listarComentarios() {
		List<Comentario> lista;
		lista = new ArrayList<Comentario>();
		try {
			Connection con = ds.getConnection();
			Statement sql = con.createStatement();
			ResultSet rs = sql.executeQuery("SELECT * FROM comentarios");
			while (rs.next()) {
				Comentario c = new Comentario(rs.getString("autor"),
						rs.getString("texto"));
				c.setFecha(rs.getDate("fecha"));
				lista.add(c);
			}
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return lista;
	}
}
