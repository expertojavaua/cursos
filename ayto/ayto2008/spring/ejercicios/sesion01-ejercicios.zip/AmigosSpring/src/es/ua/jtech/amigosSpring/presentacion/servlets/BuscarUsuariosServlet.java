package es.ua.jtech.amigosSpring.presentacion.servlets;

import es.ua.jtech.amigosSpring.AmigosSpringException;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.ua.jtech.amigosSpring.modelo.Sexo;
import es.ua.jtech.amigosSpring.modelo.UsuarioTO;
import es.ua.jtech.amigosSpring.negocio.GestorUsuarios;

public class BuscarUsuariosServlet extends AmigosServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5896401475183826831L;

	public BuscarUsuariosServlet() {
		super();
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//Leemos los parámetros de HTTP
                int edadMin = Integer.parseInt(request.getParameter("edadMin"));
		int edadMax = Integer.parseInt(request.getParameter("edadMax"));
		Sexo sexo = Sexo.valueOf(request.getParameter("sexo"));
                
                //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                //TODO: CAMBIAR ESTO. HAY QUE PEDIRLE A SPRING EL BEAN
                //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                GestorUsuarios gu = null;
                if (gu==null)
                    throw new UnsupportedOperationException("FALTA OBTENER EL BEAN GESTORUSUARIOS (EJERCICIO 1 SESION 1)");
                
                
                //Empieza la "accion"
                try {
                    List<UsuarioTO> encontrados = gu.buscar(request.getParameter("localidad"), edadMin, edadMax, sexo);
                    request.setAttribute("encontrados", encontrados);
                    doForward(request, response, "/encontrados.jsp");
                }
                catch(AmigosSpringException ase) {
                    request.setAttribute("exception", ase);
                    doForward(request, response, "/error.jsp");
                }
	}
	
	

}
