package es.ua.jtech.amigosSpring.datos;

import java.util.List;

import es.ua.jtech.amigosSpring.modelo.MensajeTO;
import es.ua.jtech.amigosSpring.modelo.UsuarioTO;

public interface IMensajeDAO {

	/* (non-Javadoc)
	 * @see es.ua.jtech.amigosSpring.datos.IUsuarioDAO#getMensaje(java.lang.String)
	 */
	public MensajeTO getMensaje(String id) throws DAOException;

	/* (non-Javadoc)
	 * @see es.ua.jtech.amigosSpring.datos.IUsuarioDAO#enviar(es.ua.jtech.amigosSpring.modelo.MensajeTO)
	 */
	public void enviar(MensajeTO mensaje) throws DAOException;

	/* (non-Javadoc)
	 * @see es.ua.jtech.amigosSpring.datos.IUsuarioDAO#getRecibidos(es.ua.jtech.amigosSpring.modelo.UsuarioTO)
	 */
	public List<MensajeTO> getRecibidos(UsuarioTO destinatario)
			throws DAOException;

}