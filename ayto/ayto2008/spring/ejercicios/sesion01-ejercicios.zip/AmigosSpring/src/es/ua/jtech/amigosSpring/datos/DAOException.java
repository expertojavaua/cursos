package es.ua.jtech.amigosSpring.datos;

public class DAOException extends Exception {
   /**
	 * 
	 */
	private static final long serialVersionUID = 5231998154053029176L;

/**
    * Envuelve una excepci�n en un objeto de la clase BDException, para
    * ocultar su naturaleza a las capas superiores.
    * @param e la excepci�n "envuelta".
    */
   public DAOException(Exception e) {
   	  super(e);
   }
   
   /**
    * Construye una excepci�n con el mensaje especificado.
    * @param mensaje mensaje de error asociado a la excepci�n.
    */
   public DAOException(String mensaje) {
   	  super(mensaje);
   }
   
   public DAOException(String mensaje, Exception e) {
   	  super(mensaje, e);
   }
}
