package es.ua.jtech.amigosSpring.modelo;

public enum Sexo {
	hombre,
	mujer,
	indiferente
}
