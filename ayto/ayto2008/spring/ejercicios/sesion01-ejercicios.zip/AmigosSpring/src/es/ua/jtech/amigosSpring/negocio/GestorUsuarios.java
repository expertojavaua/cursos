package es.ua.jtech.amigosSpring.negocio;

import es.ua.jtech.amigosSpring.AmigosSpringException;
import java.util.List;
import es.ua.jtech.amigosSpring.SinPermisoException;
import es.ua.jtech.amigosSpring.datos.DAOException;
import es.ua.jtech.amigosSpring.datos.IUsuarioDAO;
import es.ua.jtech.amigosSpring.modelo.Sexo;
import es.ua.jtech.amigosSpring.modelo.UsuarioTO;

public class GestorUsuarios {
    private IUsuarioDAO udao;

    public void setUsuarioDAO(IUsuarioDAO udao) {
        this.udao = udao;
    }

    public List<UsuarioTO> buscar(String localidad, int edadMin, int edadMax,
            Sexo sexo) throws AmigosSpringException {
        try {
            return udao.buscar(localidad, edadMin, edadMax, sexo);
        } catch (DAOException daoe) {
            throw new AmigosSpringException(daoe);
        }
    }

    public void cobrar(UsuarioTO u, int cantidad) throws SinPermisoException, AmigosSpringException {
        int credActual = u.getCredito() - cantidad;
        if (credActual < 0) {
            throw new SinPermisoException("No tienes credito suficiente para realizar esta operación");
        } else {
            u.setCredito(credActual);
            try {
                udao.actualizarCredito(u, credActual);
            } catch (DAOException daoe) {
                throw new AmigosSpringException(daoe);
            }
        }
    }

    public UsuarioTO login(String login, String password) throws AmigosSpringException {
        UsuarioTO u = null;

        try {
            u = udao.getUsuario(login);
            if (u == null || (!u.getPassword().equals(password))) {
                throw new AmigosSpringException("login y/o password erróneos");
            } else {
                return u;
            }
        } catch (DAOException daoe) {
            throw new AmigosSpringException(daoe);
        }
    }

    public UsuarioTO getUsuario(String login) throws AmigosSpringException {
        try {
            UsuarioTO uto = udao.getUsuario(login);
            return uto;
        } catch (DAOException daoe) {
            throw new AmigosSpringException(daoe);
        }
    }
}
