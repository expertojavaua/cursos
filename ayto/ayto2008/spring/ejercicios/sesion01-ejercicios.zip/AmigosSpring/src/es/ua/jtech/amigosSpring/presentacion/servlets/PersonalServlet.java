package es.ua.jtech.amigosSpring.presentacion.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import es.ua.jtech.amigosSpring.modelo.UsuarioTO;
import es.ua.jtech.amigosSpring.negocio.GestorUsuarios;
import javax.servlet.ServletContext;

import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

public class PersonalServlet extends AmigosServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7820985432601898692L;

	public PersonalServlet() {
		super();
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
              //obtener el usuario actual de la sesion HTTP
              UsuarioTO usuario = (UsuarioTO) request.getSession().getAttribute("usuario");
              //si no lo hay, el usuario no se ha autentificado. Echarlo
              if (usuario==null) 
                     doForward(request, response, "/index.jsp");
              else {
                  //Obtenemos la factoría de beans (el WebApplicationContext)
                  ServletContext sc = getServletContext();
                  WebApplicationContext wac = WebApplicationContextUtils.getWebApplicationContext(sc);
                  //Pedimos el bean por nombre
                  GestorUsuarios gu = (GestorUsuarios) wac.getBean("gestorUsuarios");
                  //EN REALIDAD AQUI EL BEAN SOLO NOS SIRVE PARA EL EJERCICIO 2 DE LA SESION 1
                  doForward(request, response, "/personal.jsp");
              }       
	}
	
	

}
