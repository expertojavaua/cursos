package es.ua.jtech.amigosSpring.negocio;

import es.ua.jtech.amigosSpring.AmigosSpringException;
import java.util.List;


import es.ua.jtech.amigosSpring.SinPermisoException;
import es.ua.jtech.amigosSpring.datos.DAOException;
import es.ua.jtech.amigosSpring.datos.IMensajeDAO;
import es.ua.jtech.amigosSpring.modelo.MensajeTO;
import es.ua.jtech.amigosSpring.modelo.UsuarioTO;

public class GestorMensajes  {
        private IMensajeDAO mdao;
        private GestorUsuarios gu;
        
        private static final int COSTE_MENSAJE = 2;
        
        public void setMensajeDAO(IMensajeDAO mdao) {
            this.mdao = mdao;
        }
        
        public void setGestorUsuarios(GestorUsuarios gu) {
            this.gu = gu;
        }

	public void enviar(UsuarioTO u, MensajeTO mensaje) throws SinPermisoException, AmigosSpringException {
                try {
                    mdao.enviar(mensaje);
                }
                catch(DAOException daoe) {
                    throw new AmigosSpringException("Hay problemas con el correo. Vuelve a intentarlo");
                }
               gu.cobrar(u, COSTE_MENSAJE);
 	}

	public List<MensajeTO> getRecibidos(UsuarioTO destinatario) throws SinPermisoException, AmigosSpringException {
                //si el usuario no tiene crédito, no puede ver el buzón
                if (destinatario.getCredito()<=0)
                    throw new SinPermisoException("Debes tener credito para ver el buzón");
                try {
                    return mdao.getRecibidos(destinatario);
                }
                catch(DAOException daoe) {
                    throw new AmigosSpringException("Hay problemas con tu buzón");
                }
	}

	public MensajeTO leerMensaje(UsuarioTO usuario, String id)
			throws SinPermisoException {
		
		//No se cobra por leer mensajes, pero el usuario debe tener credito > 0
		if (usuario.getCredito()<=0)
			throw new SinPermisoException("Debes tener credito para poder leer mensajes");
		try {
			return mdao.getMensaje(id);
		}
		catch(DAOException daoe) {
			throw new SinPermisoException("El mensaje no existe");
		}
	}


}
