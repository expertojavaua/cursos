package es.ua.jtech.amigosSpring.presentacion.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class AmigosServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = -5528634184567776754L;

	public AmigosServlet() {
		super();
	}
	
	
	
	@Override
	protected void doGet(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException {
		doPost(arg0, arg1);
	}



	protected void doForward(HttpServletRequest request, HttpServletResponse response, String path) throws ServletException, IOException {
		ServletContext sc = this.getServletContext();
		RequestDispatcher rd = sc.getRequestDispatcher(path);
		rd.forward(request, response);
	}
	

}
