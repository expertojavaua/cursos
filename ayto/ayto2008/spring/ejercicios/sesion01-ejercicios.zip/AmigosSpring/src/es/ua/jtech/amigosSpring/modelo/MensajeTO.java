package es.ua.jtech.amigosSpring.modelo;

import java.util.*;
import java.text.*;

/**
 * Representa un mensaje de correo que un usuario le envia a otro.
 */
public class MensajeTO {
   private String id;	
   private java.util.Date fecha;	
   private String remitente;
   private String destinatario;
   private String asunto;
   private String texto;
     	   
   	/**
   	 * Obtiene el identificador del mensaje.
   	 */
	public String getId() {
		return id;
	}
	
	/**
	 * Asigna un identificador al mensaje. 
	 * @param id el nuevo identificador.
	 */
	public void setId(String id) {
		this.id = id;
	}
	/**
	 * Obtiene la fecha y hora en que fue enviado el mensaje.
	 */
	public java.util.Date getFecha() {
		return fecha;
	}
	/**
	 * Asigna fecha y hora de envio al mensaje.
	 * @param fecha la nueva fecha y hora.
	 */
	public void setFecha(java.util.Date fecha) {
		this.fecha = fecha;
	}
	/**
	 * Obtiene la fecha y hora de envio del mensaje como una cadena en el formato
	 * dd/mm/aaaaa hh:mm si la fecha no es de hoy, y solo hh:mm si lo es.
	 * @return fecha y hora de envio del mensaje en el formato especificado.
	 */
	public String getFechaCadena() {
	   SimpleDateFormat formato;	
	   GregorianCalendar gc = new GregorianCalendar();
	   gc.setTime(fecha);
	   GregorianCalendar gcAhora = new GregorianCalendar();
	   //si es el mismo dia, solo nos interesa la hora, si no, toda la fecha
	   if (gcAhora.get(Calendar.DAY_OF_YEAR)==gc.get(Calendar.DAY_OF_YEAR) && 
	   		gcAhora.get(Calendar.YEAR)==gc.get(Calendar.YEAR)) {
	   	    formato = new SimpleDateFormat("HH:mm");
	   }
	   else {
	   		formato = new SimpleDateFormat("dd/MM/yyyy HH:mm");
	   }
  	   return formato.format(fecha);
	}
	/**
	 * Obtiene el asunto <i>(subject)</i> del mensaje.
	 */
	public String getAsunto() {
		return asunto;
	}
	/**
	 * Permite cambiar el asunto del mensaje.
	 * @param asunto el nuevo asunto.
	 */
	public void setAsunto(String asunto) {
		this.asunto = asunto;
	}
	/**
	 * Obtiene el login del usuario que debe recibir el mensaje.
	 */
	public String getDestinatario() {
		return destinatario;
	}
	/**
	 * Permite especificar el login del usuario que debe recibir el mensaje.
	 * @param destinatario
	 */
	public void setDestinatario(String destinatario) {
		this.destinatario = destinatario;
	}
	/**
	 * Obtiene el login del usuario que envia el mensaje.
	 */
	public String getRemitente() {
		return remitente;
	}
	/**
	 * Permite especificar el login del usuario que envia el mensaje.
	 * @param remitente el login del remitente.
	 */
	public void setRemitente(String remitente) {
		this.remitente = remitente;
	}
	/**
	 * Obtiene el texto del mensaje.
	 */
	public String getTexto() {
		return texto;
	}
	/**
	 * Permite especificar el texto del mensaje.
	 * @param texto el nuevo texto.
	 */
	public void setTexto(String texto) {
		this.texto = texto;
	}
}