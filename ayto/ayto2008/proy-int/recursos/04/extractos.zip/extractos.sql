CREATE TABLE extractos
(
  texto character varying(80),
  entidad character varying(10),
  id serial NOT NULL,
  abr character varying(4),
  idlibro integer,
  CONSTRAINT pk PRIMARY KEY (id)
)
WITH (OIDS=FALSE);
ALTER TABLE extractos OWNER TO postgres;