package ieci.tecdoc.sgm.rpadmin.struts.acciones.extractos;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import ieci.tecdoc.sgm.core.services.LocalizadorServicios;
import ieci.tecdoc.sgm.core.services.rpadmin.ExtractoBean;
import ieci.tecdoc.sgm.core.services.rpadmin.OptionsBean;
import ieci.tecdoc.sgm.core.services.rpadmin.ServicioRPAdmin;
import ieci.tecdoc.sgm.rpadmin.ServicioRPAdminAdapter;
import ieci.tecdoc.sgm.rpadmin.struts.acciones.RPAdminWebAction;
import ieci.tecdoc.sgm.rpadmin.struts.util.SesionHelper;

public class GuardarExtractoAction extends RPAdminWebAction {

	public ActionForward executeAction(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		ExtractoBean extracto = new ExtractoBean();
		extracto.setTexto(request.getParameter("textoExtracto"));
		extracto.setAbreviatura(request.getParameter("abrExtracto"));
		extracto.setIdLibro(Integer.parseInt(request.getParameter("id")));
		
		ServicioRPAdminAdapter oServicio = (ServicioRPAdminAdapter) LocalizadorServicios.getServicioRPAdmin();
		oServicio.guardarExtracto(extracto, SesionHelper.obtenerEntidad(request));
		return mapping.findForward("success");
	}
	

}
