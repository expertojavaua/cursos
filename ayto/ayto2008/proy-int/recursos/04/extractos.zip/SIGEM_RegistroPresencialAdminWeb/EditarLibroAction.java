package ieci.tecdoc.sgm.rpadmin.struts.acciones.libros;

import java.util.ResourceBundle;

import ieci.tecdoc.sgm.core.services.LocalizadorServicios;
import ieci.tecdoc.sgm.core.services.rpadmin.Libro;
import ieci.tecdoc.sgm.core.services.rpadmin.LibroBean;
import ieci.tecdoc.sgm.core.services.rpadmin.OptionBean;
import ieci.tecdoc.sgm.core.services.rpadmin.OptionsBean;
import ieci.tecdoc.sgm.core.services.rpadmin.ServicioRPAdmin;
import ieci.tecdoc.sgm.rpadmin.ServicioRPAdminAdapter;
import ieci.tecdoc.sgm.rpadmin.struts.acciones.RPAdminWebAction;
import ieci.tecdoc.sgm.rpadmin.struts.forms.LibroForm;
import ieci.tecdoc.sgm.rpadmin.struts.util.SesionHelper;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

public class EditarLibroAction extends RPAdminWebAction {

	private static final Logger logger = Logger.getLogger(EditarLibroAction.class);
	public ActionForward executeAction(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		

		ServicioRPAdmin oServicio = LocalizadorServicios.getServicioRPAdmin();
		
		String idBook = (String)request.getParameter("idLibro");
		String idEstado = (String)request.getParameter("idEstado");
		String nombre = (String)request.getParameter("nombre");
		if(idBook == null || idBook.equals("")) {
			idBook = (String)request.getSession(false).getAttribute("idLibro");
		}
		
		if( idBook != null && !idBook.equals("")) {
			
            // Mostramos la p�gina de editarLibro.jsp
			LibroForm libroForm = (LibroForm)form;
			
			if(libroForm.getId() == null) {
				LibroBean libro = oServicio.obtenerLibroBean(Integer.parseInt(idBook), SesionHelper.obtenerEntidad(request));
				BeanUtils.copyProperties(libroForm, libro);
			}

			request.setAttribute("tipoLibro", loadOptionsTipo(request));
			request.setAttribute("numeracionLibro", loadOptionsNumeracion(request));
			request.setAttribute("estado", idEstado);
			request.setAttribute("nombre", nombre);
			request.getSession(false).setAttribute("idLibro", String.valueOf(libroForm.getId()));
			
			//Otto
			int idLibro = Integer.parseInt(libroForm.getId());
			ServicioRPAdminAdapter serv = (ServicioRPAdminAdapter) oServicio;
			request.setAttribute("extractos", serv.listarExtractos(idLibro, 
					SesionHelper.obtenerEntidad(request)));
		}
		
		return mapping.findForward("success");
	}
	
	private OptionsBean loadOptionsTipo(HttpServletRequest request) {
		
        //	Cargamos los combos Tipo de Libro
		ResourceBundle rb = ResourceBundle.getBundle("ApplicationResource", getLocale(request));	
		
		OptionsBean optionsTipo = new OptionsBean();
		
		OptionBean optionTipoSeleccione = new OptionBean();
		optionTipoSeleccione.setCodigo("");
		optionTipoSeleccione.setDescripcion(rb.getString("ieci.tecdoc.sgm.rpadmin.libros.tipo.seleccione"));
		optionsTipo.add(optionTipoSeleccione);
		
		OptionBean optionTipoEntrada = new OptionBean();
		optionTipoEntrada.setCodigo(String.valueOf(Libro.LIBRO_ENTRADA));
		optionTipoEntrada.setDescripcion(rb.getString("ieci.tecdoc.sgm.rpadmin.libros.tipo.libro.entrada"));
		optionsTipo.add(optionTipoEntrada);
		
		OptionBean optionTipoSalida = new OptionBean();
		optionTipoSalida.setCodigo(String.valueOf(Libro.LIBRO_SALIDA));
		optionTipoSalida.setDescripcion(rb.getString("ieci.tecdoc.sgm.rpadmin.libros.tipo.libro.salida"));
		optionsTipo.add(optionTipoSalida);
		
		return optionsTipo;
		
		
	}
	
	private OptionsBean loadOptionsNumeracion(HttpServletRequest request) {
		
        // Cargamos los combos Numeraci�n de Libro
		ResourceBundle rb = ResourceBundle.getBundle("ApplicationResource", getLocale(request));	
		
		OptionsBean optionsNumeracion = new OptionsBean();
		
		OptionBean optionNumSeleccione = new OptionBean();
		optionNumSeleccione.setCodigo("");
		optionNumSeleccione.setDescripcion(rb.getString("ieci.tecdoc.sgm.rpadmin.libros.numeracion.seleccione"));
		optionsNumeracion.add(optionNumSeleccione);
		
		OptionBean optionNumCentral = new OptionBean();
		optionNumCentral.setCodigo(String.valueOf(LibroBean.NUMERACION_CENTRAL));
		optionNumCentral.setDescripcion(rb.getString("ieci.tecdoc.sgm.rpadmin.libros.numeracion.central"));
		optionsNumeracion.add(optionNumCentral);
		
		OptionBean optionNumOficina = new OptionBean();
		optionNumOficina.setCodigo(String.valueOf(LibroBean.NUMERACION_POR_OFICINA));
		optionNumOficina.setDescripcion(rb.getString("ieci.tecdoc.sgm.rpadmin.libros.numeracion.oficina"));
		optionsNumeracion.add(optionNumOficina);
		
		return optionsNumeracion;
	}
}
