package ieci.tecdoc.sgm.rpadmin.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import ieci.tecdoc.sgm.core.services.rpadmin.ExtractoBean;


//Otto
public class ExtractoDAO {
	private DataSource ds;
	private String SQL_INSERT="insert into extractos(abr,texto,idLibro,entidad) values(?,?,?,?)";
	private String SQL_SELECT="select * from extractos where idLibro=? and entidad=? order by texto";
	
	public ExtractoDAO() {
		try {
			Context ctx = new InitialContext();
			ds = (DataSource) ctx.lookup("java:comp/env/jdbc/registroDS_000");	
		}
		catch(NamingException ne) {
			System.out.println("ERROR" +  ne);			
		}
		
	}
	public void guardarExtracto(ExtractoBean extracto, String entidad) {
		try {
			Connection con = ds.getConnection();
			PreparedStatement ps = con.prepareStatement(SQL_INSERT);
			ps.setString(1, extracto.getAbreviatura());
			ps.setString(2, extracto.getTexto());
			ps.setInt(3, extracto.getIdLibro());
			ps.setString(4, entidad);
			ps.executeUpdate();
			con.close();
		}
		catch(Exception e) {
			System.out.println("ERROR" +  e);			
		}
	}
	
	public List listarExtractos(int idLibro, String entidad) {
		try {
			Connection con = ds.getConnection();
			PreparedStatement sentencia = con.prepareStatement(SQL_SELECT);
			sentencia.setInt(1, idLibro);
			sentencia.setString(2, entidad);
			ResultSet rs = sentencia.executeQuery();
			List res = new ArrayList();
			while(rs.next()) {
				ExtractoBean extracto = new ExtractoBean();
				extracto.setAbreviatura(rs.getString("abr"));
				extracto.setTexto(rs.getString("texto"));
				extracto.setCod(rs.getInt("id"));
				extracto.setIdLibro(rs.getInt("idlibro"));
				res.add(extracto);
			}
			con.close();
			return res;
		}
		catch(Exception e) {
			System.out.println("ERROR" +  e);
			return null;
		}		
		
	}
}

