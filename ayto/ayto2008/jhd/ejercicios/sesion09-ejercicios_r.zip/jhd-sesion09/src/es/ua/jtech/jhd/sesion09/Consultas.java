package es.ua.jtech.jhd.sesion09;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Time;

public class Consultas {
	// Declarar la conexion
	Connection con;
	
	public Consultas() throws SQLException, ClassNotFoundException {
		// Crear la conexion
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection("jdbc:mysql://localhost/viajes", "root", "root");
	}
	
	public void listaVuelos () throws SQLException {
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("SELECT * from vuelos");
		while(rs.next()) {
			int id = rs.getInt("id");
			String aeroInic = rs.getString("aeroInic");
			String aeroFin = rs.getString("aeroFin");
			Date diaSal = rs.getDate("diaSal");
			Date diaLleg = rs.getDate("diaLleg");
			Time horaSal = rs.getTime("horaSal");
			Time horaLleg = rs.getTime("horaLleg");
			String avion = rs.getString("avion");
			int plazasDisp = rs.getInt("plazasDisp");
			System.out.println("* [" + id + "] " + aeroInic + "(" + diaSal + ", " + horaSal + 
					") --> " + aeroFin + " (" + diaLleg + ", " + horaLleg + " ) " + avion + 
					"(" + plazasDisp + ")");
		}
	}
	
	
	public void consultaHoteles () throws SQLException {
		Integer auxInt;
		int opc=10;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		// Crear la sentencia y realizar la consulta
		Statement stmt = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
		ResultSet rs = stmt.executeQuery("SELECT * FROM hoteles");
		
		try {
			if (!rs.next()) {
				System.out.println("No existen datos!.\nPulse una tecla para continuar.");
				br.readLine();
				return;
			}
			while (opc!=0) {
				System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"+
							"Id\tNombre\t\tDireccion\t\tanyCrea\tplazasDisp\tprecios");
								
				// Imprimir los datos del resulset
				int id = rs.getInt("id");
				String nombre = rs.getString("nombre");
				String direccion = rs.getString("direccion");
				int anyoCrea = rs.getInt("anyoCrea");
				int plazasDisp = rs.getInt("plazasDisp");
				double precio = rs.getDouble("precio");
				System.out.println(id + "\t" + nombre + "\t" + direccion + "\t" + anyoCrea + "\t" + plazasDisp + "\t" + precio);
				System.out.println(); 

				System.out.print(
							"\t1.- Registro siguiente.\n"+
							"\t2.- Registro anterior.\n"+
							"\t3.- Ultimo registro.\n"+
							"\t4.- Primer registro.\n"+
							"\t5.- Restar plaza disponible.\n"+
							"\t0.- Salir.\n"+
							"\t\tElija una opcion:");
				auxInt = new Integer(br.readLine());
				opc = auxInt.intValue();
				switch (opc) {
					case (1): if (rs.isLast()) { // Se debe comprobar si es el ultimo
								System.out.println("Se encuentra en el ultimo registro!.\nPulse una tecla para continuar.");
								br.readLine();
				  			  }
				  			  else 
				  				  rs.next(); 
				  			  break;
					case (2): if (rs.isFirst()) {// Se debe comprobar si es el primero
								System.out.println("Se encuentra en el primer registro!.\nPulse una tecla para continuar.");
								br.readLine();
							  }
							  else 
								  rs.previous(); // Ir hacia atras
							  break;
					case (3): ; // Ir al ultimo
							  rs.last();
							  break;
					case (4): ; // Ir al primero
					 	      rs.first();
					  		  break;
					case (5): // Restar plaza disponible
							  rs.updateInt("plazasDisp", rs.getInt("plazasDisp")-1);
							  rs.updateRow();
					  		  break;
				}
			}
		}
		catch (Exception e) {System.out.println(e);}
	}
		
	public void close () throws SQLException { // Cerrar la conexion
		con.close();
	}

	
	public static void main(String [] args) {
		Consultas cons=null;
		
		try {
			cons=new Consultas();
			cons.listaVuelos();
			cons.consultaHoteles();
			cons.close();
		}
		catch (SQLException e) {
			System.out.println(e);
		} catch (ClassNotFoundException e) {
			System.out.println("Driver no encontrado: " + e.getMessage());
		}		
	}
}
