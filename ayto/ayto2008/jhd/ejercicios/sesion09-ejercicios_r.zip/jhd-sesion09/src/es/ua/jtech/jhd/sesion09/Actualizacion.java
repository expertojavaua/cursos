package es.ua.jtech.jhd.sesion09;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Actualizacion {
	// Declarar la conexion
	Connection con;
	
	public Actualizacion() throws SQLException, ClassNotFoundException {
		// Crear la conexion
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection("jdbc:mysql://localhost/viajes", "root", "root");
	}
	
	public int actualizaEuros () throws SQLException{
		// Realizar la actualizacion
		Statement stmt = con.createStatement();
		stmt.executeUpdate("alter table hoteles change precio precio double(10,3)");
		return stmt.executeUpdate("update hoteles set precio = precio/166.386");
	}
	
	public void close () throws SQLException { // Cerrar la conexion
		con.close();
	}

	
	public static void main(String [] args) {
		Actualizacion cons=null;
		
		try {
			cons=new Actualizacion();
			System.out.println("Registros actualizados="+cons.actualizaEuros());
			cons.close();
		}
		catch (SQLException e) {
			System.out.println(e);
		} catch (ClassNotFoundException e) {
			System.out.println("Driver no encontrado: " + e.getMessage());
		}
	}
}
