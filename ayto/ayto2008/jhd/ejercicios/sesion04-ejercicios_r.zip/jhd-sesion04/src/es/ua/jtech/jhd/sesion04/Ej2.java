package es.ua.jtech.jhd.sesion04;

public class Ej2 {

	// TODO: Declarar que el m�todo logaritmo puede lanzar excepciones

	public static double logaritmo(String entrada)
			throws WrongParameterException {
		double num = 0;

		try {
			num = Double.parseDouble(entrada);
		} catch (NumberFormatException e) {
			throw new WrongParameterException("Formato de numero erroneo",e);
		}

		if (num <= 0) {
			throw new WrongParameterException("El parametro debe ser positivo");
		}

		return Math.log(num);
	}

	public static void main(String[] args) {

		try {
			System.out.println("Logaritmo = " + logaritmo(args[0]));
		} catch (WrongParameterException e) {
			e.printStackTrace();
		}
	}
}