package es.ua.jtech.jhd.sesion04;

public class WrongParameterException extends Exception {
	public WrongParameterException(String msg) {
		super(msg);
	}
	public WrongParameterException(String msg, Exception causa) {
		super(msg,causa);
	}
}
