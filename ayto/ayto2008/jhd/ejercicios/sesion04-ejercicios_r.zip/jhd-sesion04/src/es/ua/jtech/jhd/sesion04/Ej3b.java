package es.ua.jtech.jhd.sesion04;

import java.util.Timer;
import java.util.TimerTask;

public class Ej3b {
	// Hilo actual

	public Ej3b() {

		// Crea primer hilo

		Timer t = new Timer();
		t.schedule(new MiTarea(),0,100);

		// Duerme durante 5 segundos

		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
		}

		// Crea segundo hilo

		t.cancel();
		t = new Timer();
		t.schedule(new MiTarea(), 0, 100);

		// Duerme durante 5 segundos

		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
		}

		// Destruye hilo

		t.cancel();
	}

	class MiTarea extends TimerTask {

		long ini;
		
		public MiTarea() {
			ini = System.currentTimeMillis();			
		}
		
		public void run() {
			System.out.print("Ejecutando (" + ini + ") ");			
		}
		
	}

	public static void main(String[] args) {
		new Ej3b();
	}
}