package es.ua.jtech.jhd.sesion04;

public class Ej1 {
	public static double logaritmo(double num) {
		return Math.log(num);
	}

	public static void main(String[] args) {
		try {
			double num = Double.parseDouble(args[0]);
			System.out.println("Logaritmo = " + logaritmo(num));
		} catch (ArrayIndexOutOfBoundsException ex1) {
			System.err.println("Debe especificarse al menos un parametro");
		} catch (NumberFormatException ex2) {
			System.err.println("El parametro debe ser un numero");
		}
	}
}