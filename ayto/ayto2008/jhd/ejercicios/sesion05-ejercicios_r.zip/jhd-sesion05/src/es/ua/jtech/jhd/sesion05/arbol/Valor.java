package es.ua.jtech.jhd.sesion05.arbol;

public class Valor {
	private String valor;

	public Valor(String valor) {
		super();
		this.valor = valor;
	}

	public String getValor() {
		return valor;
	}

	public void setValor(String valor) {
		this.valor = valor;
	}
}
