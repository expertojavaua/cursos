package es.ua.jtech.jhd.sesion05.arbol;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class Arbol {
	private Collection<Nodo> nodos;
	
	public Arbol() {
		nodos = new ArrayList<Nodo>();
	}
	
	public void addNodo(Nodo nodo) {
		nodos.add(nodo);
	}
	
	public List<Nodo> getNodos() {
		List<Nodo> lista = new ArrayList<Nodo>();
		lista.addAll(nodos);
		
		Collections.sort(lista);
		return lista;
	}
}
