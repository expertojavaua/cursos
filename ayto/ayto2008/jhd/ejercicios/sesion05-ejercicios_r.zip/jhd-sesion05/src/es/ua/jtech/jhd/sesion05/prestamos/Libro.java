package es.ua.jtech.jhd.sesion05.prestamos;

public class Libro extends MaterialPrestamo {
	private int numPaginas;

	public int getNumPaginas() {
		return numPaginas;
	}

	public void setNumPaginas(int numPaginas) {
		this.numPaginas = numPaginas;
	}

	public Libro(String autor, int codigo, String titulo, int numPaginas) {
		super(autor, codigo, titulo);
		this.numPaginas = numPaginas;
	}

	public Libro() {
		super();
	}
	
	
}
