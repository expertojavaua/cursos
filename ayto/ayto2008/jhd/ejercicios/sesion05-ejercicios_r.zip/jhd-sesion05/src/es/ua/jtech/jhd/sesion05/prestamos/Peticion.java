package es.ua.jtech.jhd.sesion05.prestamos;

import java.util.Date;

public class Peticion {
	private Date fechaInicio;
	private Date fechaFin;
	private MaterialPrestamo material;
	public Date getFechaInicio() {
		return fechaInicio;
	}
	public void setFechaInicio(Date fechaInicio) {
		this.fechaInicio = fechaInicio;
	}
	public Date getFechaFin() {
		return fechaFin;
	}
	public void setFechaFin(Date fechaFin) {
		this.fechaFin = fechaFin;
	}
	public MaterialPrestamo getMaterial() {
		return material;
	}
	public void setMaterial(MaterialPrestamo material) {
		this.material = material;
	}
	public Peticion(Date fechaFin, Date fechaInicio, MaterialPrestamo material) {
		super();
		this.fechaFin = fechaFin;
		this.fechaInicio = fechaInicio;
		this.material = material;
	}
	public Peticion() {
		super();
	}
	
	
}
