package es.ua.jtech.jhd.sesion05;

import java.util.Date;
import java.util.List;

import es.ua.jtech.jhd.sesion05.prestamos.Cliente;
import es.ua.jtech.jhd.sesion05.prestamos.Disco;
import es.ua.jtech.jhd.sesion05.prestamos.Libro;
import es.ua.jtech.jhd.sesion05.prestamos.Peticion;

public class Ej2 {

	public static void main(String[] args) {
		Cliente c = new Cliente("12345678A", "Pepe");
		c.addPeticion(new Peticion(new Date(), new Date(), new Disco("MGMT", 1,
				"Oracular Spectacular", "Sony BMG")));
		c.addPeticion(new Peticion(new Date(), new Date(), new Libro(
				"Chuck Palahniuk", 2, "Asfixia", 256)));
		c.addPeticion(new Peticion(new Date(), new Date(), new Disco(
				"Pink Floyd", 3, "Wish you were here", "EMI")));

		List<Peticion> peticiones = c.getPeticiones();
		for (Peticion p : peticiones) {
			System.out.println(p.getMaterial().getTitulo() + " ("
					+ p.getMaterial().getAutor() + ")");
		}
	}

}
