package es.ua.jtech.jhd.sesion05.arbol;

public class Persona extends Clave {
	private String fechas;

	Persona() {
		super();
	}

	public String getFechas() {
		return fechas;
	}

	public void setFechas(String fechas) {
		this.fechas = fechas;
	}

	public String getTipo() {
		return "persona";
	}
}
