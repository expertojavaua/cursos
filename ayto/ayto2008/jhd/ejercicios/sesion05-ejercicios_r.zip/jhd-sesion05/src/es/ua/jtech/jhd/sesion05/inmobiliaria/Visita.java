package es.ua.jtech.jhd.sesion05.inmobiliaria;

import java.sql.Date;
/**
 * @author administrador
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class Visita {

	private Piso piso;

	private Cliente cliente;

	private Date fechaHoraVisita;

	private String impresion;

	public Piso getPiso() {
		return piso;
	}

	public void setPiso(Piso piso) {
		this.piso = piso;
	}

	public String getImpresion() {
		return impresion;
	}

	public void setImpresion(String impresion) {
		this.impresion = impresion;
	}

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public Date getFechaHoraVisita() {
		return fechaHoraVisita;
	}

	public void setFechaHoraVisita(Date fechaHoraVisita) {
		this.fechaHoraVisita = fechaHoraVisita;
	}
	
	

}
