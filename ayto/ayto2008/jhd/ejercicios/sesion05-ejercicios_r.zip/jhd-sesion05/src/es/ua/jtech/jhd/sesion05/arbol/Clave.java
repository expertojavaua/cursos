package es.ua.jtech.jhd.sesion05.arbol;

public abstract class Clave {
	private String nombre;

	public abstract String getTipo();
	
	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	Clave(String nombre) {
		this.nombre = nombre;
	}

	Clave() {
	}
}
