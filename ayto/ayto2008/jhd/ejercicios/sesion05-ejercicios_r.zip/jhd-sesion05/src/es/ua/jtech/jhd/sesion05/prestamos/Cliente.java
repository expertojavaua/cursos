package es.ua.jtech.jhd.sesion05.prestamos;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Cliente {
	String dni;
	String nombre;
	List<Peticion> peticiones;
	
	public Cliente() {
		peticiones = new ArrayList<Peticion>();
	}
	
	public String getDni() {
		return dni;
	}
	public void setDni(String dni) {
		this.dni = dni;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public List<Peticion> getPeticiones() {
		return Collections.unmodifiableList(peticiones);
	}
	public void addPeticion(Peticion p) {
		peticiones.add(p);
	}

	public Cliente(String dni, String nombre) {
		this();
		this.dni = dni;
		this.nombre = nombre;
	}
	
	
}
