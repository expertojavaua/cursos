package es.ua.jtech.jhd.sesion05.prestamos;

public abstract class MaterialPrestamo {
	private int codigo;
	private String titulo;
	private String autor;
	
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}
	
	public MaterialPrestamo(String autor, int codigo, String titulo) {
		super();
		this.autor = autor;
		this.codigo = codigo;
		this.titulo = titulo;
	}
	
	public MaterialPrestamo() {
		super();
	}
	
	
}
