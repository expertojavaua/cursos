package es.ua.jtech.jhd.sesion05.inmobiliaria;

/**
 * @author administrador
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class VPO extends Piso {

}