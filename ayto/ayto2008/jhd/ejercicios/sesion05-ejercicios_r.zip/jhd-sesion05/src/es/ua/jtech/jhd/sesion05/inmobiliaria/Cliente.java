package es.ua.jtech.jhd.sesion05.inmobiliaria;

import java.util.Collection;
/**
 * @author administrador
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class Cliente {

	private Collection<Visita> visita;

	private Collection<Prestamo> prestamo;

	private String DNI;

	private String nombre;

	public Collection<Visita> getVisita() {
		return visita;
	}

	public void setVisita(Collection<Visita> visita) {
		this.visita = visita;
	}

	public Collection<Prestamo> getPrestamo() {
		return prestamo;
	}

	public void setPrestamo(Collection<Prestamo> prestamo) {
		this.prestamo = prestamo;
	}

	public String getDNI() {
		return DNI;
	}

	public void setDNI(String dni) {
		DNI = dni;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	
}
