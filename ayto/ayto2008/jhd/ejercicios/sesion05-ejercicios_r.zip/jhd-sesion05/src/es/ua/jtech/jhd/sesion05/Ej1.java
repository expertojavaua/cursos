package es.ua.jtech.jhd.sesion05;

import java.util.List;

import es.ua.jtech.jhd.sesion05.arbol.Arbol;
import es.ua.jtech.jhd.sesion05.arbol.FactoriaClave;
import es.ua.jtech.jhd.sesion05.arbol.Nodo;
import es.ua.jtech.jhd.sesion05.arbol.Valor;

public class Ej1 {

	public static void main(String[] args) {

		Arbol a = new Arbol();
		a.addNodo(new Nodo(FactoriaClave.crearClave("Pepe"), new Valor("v1")));
		a.addNodo(new Nodo(FactoriaClave.crearClave("mesa"), new Valor("v2")));
		a.addNodo(new Nodo(FactoriaClave.crearClave("Juan"), new Valor("v3")));

		List<Nodo> lista = a.getNodos();
		for (Nodo n : lista) {
			System.out.println(n.getClave().getNombre() + " ("
					+ n.getClave().getTipo() + "): " + n.getValor().getValor());
		}
	}

}
