package es.ua.jtech.jhd.sesion05.arbol;

public class Nodo implements Comparable<Nodo> {
	private Clave clave;
	private Valor valor;
	
	public Nodo(Clave clave, Valor valor) {
		super();
		this.clave = clave;
		this.valor = valor;
	}

	public Clave getClave() {
		return clave;
	}

	public void setClave(Clave clave) {
		this.clave = clave;
	}

	public Valor getValor() {
		return valor;
	}

	public void setValor(Valor valor) {
		this.valor = valor;
	}

	public int compareTo(Nodo o) {
		return this.clave.getNombre().compareToIgnoreCase(o.getClave().getNombre());
	}
}
