package es.ua.jtech.jhd.sesion05.arbol;

public class FactoriaClave {

	public static Clave crearClave(String nombre) {
		if(nombre!=null && nombre.length()>0) {
			if(nombre.charAt(0)>='A' && nombre.charAt(0)<='Z') {
				return new Cosa(nombre, "");
			} else {
				Persona p = new Persona();
				p.setNombre(nombre);
				return p;
			}
		} else {
			return null;
		}
	}
}
