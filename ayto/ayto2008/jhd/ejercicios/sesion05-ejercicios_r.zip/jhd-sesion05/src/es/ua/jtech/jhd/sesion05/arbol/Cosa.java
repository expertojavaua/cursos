package es.ua.jtech.jhd.sesion05.arbol;

public class Cosa extends Clave {
	private String descripcion;
	
	Cosa(String nombre, String descripcion) {
		super(nombre);
		this.descripcion = descripcion;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getTipo() {
		return "cosa";
	}


}
