package es.ua.jtech.jhd.sesion05.inmobiliaria;

/**
 * @author administrador
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class Prestamo {

	private Cliente cliente;

	private double interes;

	private boolean aval = false;

	private double cantidad;

	private int anyos;

	public Cliente getCliente() {
		return cliente;
	}

	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}

	public double getInteres() {
		return interes;
	}

	public void setInteres(double interes) {
		this.interes = interes;
	}

	public boolean isAval() {
		return aval;
	}

	public void setAval(boolean aval) {
		this.aval = aval;
	}

	public double getCantidad() {
		return cantidad;
	}

	public void setCantidad(double cantidad) {
		this.cantidad = cantidad;
	}

	public int getAnyos() {
		return anyos;
	}

	public void setAnyos(int anyos) {
		this.anyos = anyos;
	}
	
	

}
