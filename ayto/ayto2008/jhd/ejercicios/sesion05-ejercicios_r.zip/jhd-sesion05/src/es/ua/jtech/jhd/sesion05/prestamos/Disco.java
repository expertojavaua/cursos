package es.ua.jtech.jhd.sesion05.prestamos;

public class Disco extends MaterialPrestamo {
	String discografica;

	public String getDiscografica() {
		return discografica;
	}

	public void setDiscografica(String discografica) {
		this.discografica = discografica;
	}

	public Disco(String autor, int codigo, String titulo, String discografica) {
		super(autor, codigo, titulo);
		this.discografica = discografica;
	}

	public Disco() {
		super();
	}
	
	
}
