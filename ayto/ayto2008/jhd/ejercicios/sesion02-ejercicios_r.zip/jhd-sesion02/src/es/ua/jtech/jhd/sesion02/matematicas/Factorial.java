package es.ua.jtech.jhd.sesion02.matematicas;

/**
  * Esqueleto para el ejercicio del factorial
  */
public class Factorial
{	  
	/**
	  * Obtiene el factorial recursivo del numero que se le pasa
	  */
	public static int factorialRec (int num)
	{ 
		if(num<1) {
			return 1;
		} else {
			return num*factorialRec(num-1);
		}
	} 

	/**
	  * Obtiene el factorial iterativo del numero que se le pasa
	  */
	public static int factorialIter (int num)
	{ 
		int res = 1;
		for(int i=1;i<=num;i++) {
			res = res*i;
		}
		return res;
	} 

	/**
	  * Main
	  */
	public static void main(String[] args) 
	{ 
		int entradas [] = { 30, 5, 1, 0 };
		for(int n: entradas) {
			System.out.println ("Factorial de " + n + " = " + factorialRec(n) + ", " + factorialIter(n)); 			
		}
	} 
}
