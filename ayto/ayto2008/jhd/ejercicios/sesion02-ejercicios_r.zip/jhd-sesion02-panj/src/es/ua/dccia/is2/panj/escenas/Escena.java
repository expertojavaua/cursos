package es.ua.dccia.is2.panj.escenas;

import java.awt.Graphics;

import es.ua.dccia.is2.panj.contexto.GameContext;

// ------------------------------------------------------------------------------------
// 	Clase general para las escenas (escena de titulo, escena de juego, etc)
// ------------------------------------------------------------------------------------

public interface Escena
{

	public int update(GameContext gc);

	public void render(Graphics g);

}