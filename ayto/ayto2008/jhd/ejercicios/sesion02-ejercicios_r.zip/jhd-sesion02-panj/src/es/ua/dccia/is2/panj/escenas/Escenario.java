package es.ua.dccia.is2.panj.escenas;

import java.awt.*;

// ------------------------------------------------------------------------------------
// 	Escenario de las fases
// ------------------------------------------------------------------------------------

public class Escenario {

	Image img;

	public Escenario(Image img) {

		this.img = img;

	}

	public void render(Graphics g) {

		// Dibuja la imagen de fondo

		g.drawImage(img, 0, 0, null);

	}
}