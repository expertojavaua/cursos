package es.ua.jtech.jhd.sesion03.holamundo;

/**
 * La clase <code>Principal</code> es la clase principal de la 
 * aplicaci�n de prueba Hola Mundo.
 * @author Miguel Angel
 */
public class Principal {

	public static void main(String[] args) {
		System.out.println("Hola mundo");

/* DESCOMENTAR PARA EL EJERCICIO 2
		Ventana vent = new Ventana();
		vent.pack();
		vent.show();
*/
	}
}
