package es.ua.dccia.is2.panj.sprites;

import java.awt.*;
import java.net.URL;


// ------------------------------------------------------------------------------------
// 	Sprite de las bolas
// ------------------------------------------------------------------------------------

public class BallSprite extends Sprite 
{

	// Nombre de las imagenes del sprite
	public final static String FILE_NAME = "/bola";
	public final static String FILE_EXT = ".gif";

	// Tama�o m�ximo de las bolas
	public final static int MAX_SIZE = 3;

	// Imagen del sprite
	Image sprite;

	// Dimensiones reales (en pixels) para cada tama�o
	int [] dim = { 10, 25, 50, 75 };

	// Velocidad x e y del sprite
	public double vx, vy;

	// Descendientes del sprite (cuando la bola se parte en 2)
	public BallSprite desc1, desc2;

	public BallSprite(int tam, String color, double vx) {

		// Establece tama�o, velocidad e imagen del sprite
		setSize(dim[tam], dim[tam]);
		sprite = createSprite(tam, color);
		this.vx = vx;
		this.vy = 0.0;

		// Si no tiene el tama�o minimo crea dos descendientes de tama�o inferior

		if(tam > 0) {
			desc1 = new BallSprite(tam - 1, color, vx);
			desc2 = new BallSprite(tam - 1, color, -vx);
		} else {
			desc1 = desc2 = null;
		}
	}

	public Image createSprite(int tam, String color) {

		// Carga la imagen del sprite para el color adecuado
		
		Toolkit tk = Toolkit.getDefaultToolkit();

		String nombre = FILE_NAME + color + FILE_EXT;
		URL urlNombre = this.getClass().getResource(nombre);
		Image img = tk.getImage(urlNombre);

		return img;
	}

	public void render(Graphics g) {

		// Dibuja el sprite en su posicion
		
		g.drawImage(sprite, (int)bb.x, (int)bb.y, (int)bb.width, (int)bb.height, null);

	}

}