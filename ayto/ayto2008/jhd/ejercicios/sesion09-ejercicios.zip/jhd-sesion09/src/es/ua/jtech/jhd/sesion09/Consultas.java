package es.ua.jtech.jhd.sesion09;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Consultas {
	// TODO Declarar la conexion
	
	public Consultas() throws SQLException, ClassNotFoundException {
		// TODO Crear la conexion
	}
	
	public void listaVuelos () throws SQLException {
		// TODO Muestra listado de vuelos
	}
	
	
	public void consultaHoteles () throws SQLException {
		Integer auxInt;
		int opc=10;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		// TODO Crear la sentencia y realizar la consulta
		ResultSet rs = null;
		
		try {
			if (!rs.next()) {
				System.out.println("No existen datos!.\nPulse una tecla para continuar.");
				br.readLine();
				return;
			}
			while (opc!=0) {
				System.out.println("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n"+
							"Id\tNombre\t\tDireccion\t\tanyCrea\tplazasDisp\tprecios");
								
				// TODO Imprimir los datos del resulset
				System.out.println(); 

				System.out.print(
							"\t1.- Registro siguiente.\n"+
							"\t2.- Registro anterior.\n"+
							"\t3.- Ultimo registro.\n"+
							"\t4.- Primer registro.\n"+
							"\t5.- Restar plaza disponible.\n"+
							"\t0.- Salir.\n"+
							"\t\tElija una opcion:");
				auxInt = new Integer(br.readLine());
				opc = auxInt.intValue();
				switch (opc) {
					case (1): if (true) { // TODO Se debe comprobar si es el ultimo
								System.out.println("Se encuentra en el ultimo registro!.\nPulse una tecla para continuar.");
								br.readLine();
				  			  }
				  			  else 
				  				  ; // TODO Ir al siguiente
				  			  break;
					case (2): if (true) { // TODO Se debe comprobar si es el primero
								System.out.println("Se encuentra en el primer registro!.\nPulse una tecla para continuar.");
								br.readLine();
							  }
							  else 
								  ; // TODO Ir hacia atras
							  break;
					case (3): ; // TODO Ir al ultimo
							  break;
					case (4): ; // TODO Ir al primero
					  		  break;
					case (5): // TODO Restar plaza disponible
					  		  break;
				}
			}
		}
		catch (Exception e) {System.out.println(e);}
	}
		
	public void close () throws SQLException { // TODO Cerrar la conexion
	}

	
	public static void main(String [] args) {
		Consultas cons=null;
		
		try {
			cons=new Consultas();
			cons.listaVuelos();
			cons.consultaHoteles();
			cons.close();
		}
		catch (SQLException e) {
			System.out.println(e);
		} catch (ClassNotFoundException e) {
			System.out.println("Driver no encontrado: " + e.getMessage());
		}		
	}
}
