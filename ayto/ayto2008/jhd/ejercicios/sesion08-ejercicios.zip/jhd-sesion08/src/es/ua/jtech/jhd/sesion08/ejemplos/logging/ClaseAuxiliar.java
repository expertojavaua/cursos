package es.ua.jtech.jhd.sesion08.ejemplos.logging;

import org.apache.log4j.*;

public class ClaseAuxiliar 
{
	String mensaje = null;
	static Logger logger = Logger.getLogger(ClaseAuxiliar.class);
	
	public ClaseAuxiliar()
	{	
		logger.info("Clase auxiliar inicializada");
	}
	
	public String mensaje()
	{
		if (mensaje == null)
		{
			logger.warn("Atencion, el mensaje es null");
			return "";
		}
		return mensaje;
	}
}
