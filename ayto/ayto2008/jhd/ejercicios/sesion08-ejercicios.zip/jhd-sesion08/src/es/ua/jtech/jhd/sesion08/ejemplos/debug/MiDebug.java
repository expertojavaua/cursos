package es.ua.jtech.jhd.sesion08.ejemplos.debug;

public class MiDebug 
{	
	public static void main(String[] args)
	{
		int a = 2;
		for (int i = 1; i < 5; i++)
			a *= i;
		System.out.println("Hola Mundo: " + a);
	}
}
