package es.ua.jtech.jhd.sesion08.ejemplos.logging2;

import org.apache.commons.logging.*;

public class ClaseAuxiliar 
{
	String mensaje = null;
	static Log logger = LogFactory.getLog(LogBasico.class);
	
	public ClaseAuxiliar()
	{	
		logger.info("Clase auxiliar inicializada");
	}
	
	public String mensaje()
	{
		if (mensaje == null)
		{
			logger.warn("Atencion, el mensaje es null");
			return "";
		}
		return mensaje;
	}
}
