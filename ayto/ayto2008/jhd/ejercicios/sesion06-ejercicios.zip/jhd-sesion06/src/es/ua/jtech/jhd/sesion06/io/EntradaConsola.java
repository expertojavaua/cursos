package es.ua.jtech.jhd.sesion06.io;

import java.io.*;

public class EntradaConsola {

	BufferedReader in;

	public EntradaConsola() {
		in = new BufferedReader(new InputStreamReader(System.in));
	}

	// -----------------------------------------------------------------------------
	//  Pide datos al usuario (muestra un mensaje y lee una linea de la entrada)
	// -----------------------------------------------------------------------------

	public String promptLine(String message) {
		System.out.print(message);
		return readLine();
	}

	// -----------------------------------------------------------------------------
	//  Lee una linea de la entrada
	// -----------------------------------------------------------------------------

	public String readLine() {
		try {
			return in.readLine();
		} catch (IOException e) {
			return null;
		}
	}
}
