package es.ua.jtech.jhd.sesion06;
import es.ua.jtech.jhd.sesion06.io.EntradaConsola;

public class Ej4 {

	private final static String URL_LISTA =
		"http://jtech.ua.es/ejemplos-j2ee/jhd/foro/servlet/ServletLista";
	private final static String URL_ENVIAR =
		"http://jtech.ua.es/ejemplos-j2ee/jhd/foro/servlet/ServletEnviar";

	String nick;
	EntradaConsola ec;

	public Ej4() {
		ec = new EntradaConsola();

		menu();
	}

	public void menu() {
		nick = ec.promptLine("Nick: ");

		while (true) {
			System.out.println("(1) Ver mensajes");
			System.out.println("(2) Enviar mensaje");
			System.out.println("(0) Salir");

			String opcion = ec.promptLine("Opcion: ");

			if (opcion.trim().equals("1")) {
				leeMensajes();
			} else if (opcion.trim().equals("2")) {
				enviaMensaje();
			} else if (opcion.trim().equals("0")) {
				break;
			}
		}
	}

	private void leeMensajes() {

		// TODO: Lee y muestra mensajes de URL_LISTA

	}

	private void enviaMensaje() {
		String msg = ec.promptLine("Mensaje: ");

		// TODO: Envia nick y mensaje a URL_ENVIAR

	}

	public static void main(String[] args) {
		new Ej4();
	}
}
