package es.ua.jtech.jhd.sesion06.ejerc5;

import java.util.*;
import java.io.*;

public class GestionProductos {

	private final static String FICHERO_DATOS = "prod.dat";

	ArrayList productos;

	public GestionProductos() {
		try {
			productos = recuperar();
		} catch(IOException e) {
			productos = new ArrayList();
		}
	}

	public void nuevoProducto(Producto prod) {
		productos.add(prod);
	}

	public Producto[] leeProductos() {
		int tam = productos.size();
		Producto[] lista = new Producto[tam];

		productos.toArray(lista);
		return lista;
	}

	public void eliminaProducto(int indice) {
		productos.remove(indice);
	}

	public void guardar() throws IOException {
		almacenar(productos);
	}

	private static void almacenar(ArrayList productos) throws IOException {

		// TODO: Guardar los datos en el fichero FICHERO_DATOS

	}

	private static ArrayList recuperar() throws IOException {

		ArrayList productos = new ArrayList();

		// TODO: Leer los datos del fichero FICHERO_DATOS

		return productos;
	}

}
