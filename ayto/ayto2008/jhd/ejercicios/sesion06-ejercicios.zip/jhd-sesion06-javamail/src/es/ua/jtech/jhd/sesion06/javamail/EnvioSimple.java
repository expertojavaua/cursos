package es.ua.jtech.jhd.sesion06.javamail;

import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class EnvioSimple {

	public static void main(String[] args) {

		// Configura las propiedades
		Properties props = System.getProperties();
		props.put("mail.smtp.host", "mail.alu.ua.es");

		// Obtiene la sesion
		Session session = Session.getDefaultInstance(props, null);
		session.setDebug(true);

		try {
			// Compone el mensaje
			Message msg = new MimeMessage(session);
			msg.setFrom(new InternetAddress("noreply@jtech.ua.es"));
			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(
					"malozano@ua.es", false));
			msg.setSubject("Prueba Javamail");
			msg
					.setText("Hola,\n"
							+ "Este es un mensaje de prueba enviado desde Javamail.\n\n"
							+ "Saludos");
			msg.setSentDate(new Date());

			// Envia el mensaje
			Transport.send(msg);
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("Mensaje enviado");

	}

}
