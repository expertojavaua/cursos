/*
 * Created on 13-sep-2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package es.ua.jtech.jhd.sesion6.chat;

import java.util.*;
import java.io.*;

/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class ListaMensajes extends LinkedList<Mensaje> {

	private static final long serialVersionUID = 1L;
	int capacidad;

	public ListaMensajes(int capacidad) {
		this.capacidad = capacidad;
	}
	
	public synchronized void nuevoMensaje(String nick, String msg) {
		if(this.size() > capacidad) {
			this.removeFirst();
		}
		this.addLast(new Mensaje(nick, msg));

	}

	public synchronized Mensaje [] leeMensajes() {
		int tam = this.size();
		Mensaje [] msgs = new Mensaje[tam];
		this.toArray(msgs);
		
		return msgs;
	}
	
	public synchronized void serialize(OutputStream out) throws IOException {
		DataOutputStream dos = new DataOutputStream(out);

		int i=0;
		int tam = this.size();
		
		for(i=0;i<tam;i++) {
			Mensaje msg = (Mensaje)this.get(i); 
			dos.writeUTF(i + ". [" + msg.nick + "] " + msg.texto);
		}
		
	}

}
