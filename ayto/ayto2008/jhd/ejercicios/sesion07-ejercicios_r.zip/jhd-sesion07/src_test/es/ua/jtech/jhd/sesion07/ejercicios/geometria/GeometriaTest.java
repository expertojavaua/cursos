package es.ua.jtech.jhd.sesion07.ejercicios.geometria;

import junit.framework.Test;
import junit.framework.TestSuite;

public class GeometriaTest {

	public static Test suite() {
		TestSuite suite = new TestSuite(
				"Test for es.ua.jtech.jhd.sesion07.ejercicios.geometria");
		//$JUnit-BEGIN$
		suite.addTestSuite(MiVectorTest.class);
		suite.addTestSuite(CirculoTest.class);
		//$JUnit-END$
		return suite;
	}

}
