package es.ua.jtech.jhd.sesion07.ejercicios.geometria;

import junit.framework.TestCase;

public class CirculoTest extends TestCase {

	Circulo c = new Circulo(1,1,1);
	
	public void testArea() {
		assertEquals(Math.PI, c.area());
	}

	public void testLongitud() {
		assertEquals(2*Math.PI, c.longitud());
	}

}
