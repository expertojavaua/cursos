package es.ua.jtech.jhd.sesion07.ejemplos;

import es.ua.jtech.jhd.sesion07.ejemplos.MatrizSimple;
import junit.framework.*;

public class MatrizSimpleTest extends TestCase
{
	final static int[][] MatrizSimple =  {{1, 0, 0},
					{0, 1, 0},
					{0, 0, 1}};

	final static int[][] SUMA   =  {{2, 0, 0},
					{0, 2, 0},
					{0, 0, 2}};

	MatrizSimple m1, m2;

	public MatrizSimpleTest(String nombre)
	{
		super(nombre);
	}

	public void testSuma()
	{
		MatrizSimple m1 = new MatrizSimple(MatrizSimple);
		MatrizSimple m2 = new MatrizSimple(MatrizSimple);
		MatrizSimple msumaOK   = new MatrizSimple(SUMA);
		MatrizSimple msumaTest = m1.suma(m2);

		assertTrue(msumaOK.equals(msumaTest));
	}

	public static void main (String[] args)
	{
		junit.swingui.TestRunner.run(MatrizSimpleTest.class);
	}
}