package es.ua.jtech.jhd.sesion07.ejercicios.geometria;

import junit.framework.TestCase;

public class MiVectorTest extends TestCase {

	public void testMaximo() {
		MiVector v = new MiVector(new int[] {9, 3, 5, 7, 1});
		assertEquals(9, v.maximo());
	}
}
