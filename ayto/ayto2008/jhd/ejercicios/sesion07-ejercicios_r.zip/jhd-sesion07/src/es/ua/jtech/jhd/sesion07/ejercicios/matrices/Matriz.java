package es.ua.jtech.jhd.sesion07.ejercicios.matrices;

public class Matriz
{
	int[][] elem;

	public Matriz(int[][] elem)
	{
		this.elem = new int[elem.length][elem[0].length];

		for (int i = 0; i < elem.length; i++)
			for (int j = 0; j < elem[0].length; j++)
				this.elem[i][j] = elem[i][j];
	}

	public Matriz suma(Matriz m)
	{
		Matriz nueva = new Matriz(this.elem);

		for (int i = 0; i < elem.length; i++)
			for (int j = 0; j < elem[0].length; j++)
				nueva.elem[i][j] += m.elem[i][j];

		return nueva;
	}

	public Matriz resta(Matriz m)
	{
		Matriz nueva = new Matriz(this.elem);

		for (int i = 0; i < elem.length; i++)
			for (int j = 0; j < elem[0].length; j++)
				nueva.elem[i][j] -= m.elem[i][j];

		return nueva;
	}

	public Matriz resta2(Matriz m)
	{
		Matriz nueva = new Matriz(this.elem);

		for (int i = 0; i < elem.length; i++)
			for (int j = 0; j < elem[0].length; j++)
				nueva.elem[i][j] = m.elem[i][j] - this.elem[i][j];

		return nueva;
	}
	
	public Matriz multiplicar(Matriz m) {
		int dim = m.elem.length;
		Matriz nueva = new Matriz(new int[dim][dim]);
		
		for(int i=0;i<dim;i++) {
			for(int j=0;j<dim;j++) {
				for(int k=0;k<dim;k++) {
					nueva.elem[i][k] += this.elem[i][j]*m.elem[j][k];
				}
			}
		}
		
		return nueva;
	}

	public boolean equals(Matriz m)
	{
		for (int i = 0; i < elem.length; i++)
			for (int j = 0; j < elem[0].length; j++)
				if (elem[i][j] != m.elem[i][j])
					return false;
		return true;
	}
}
