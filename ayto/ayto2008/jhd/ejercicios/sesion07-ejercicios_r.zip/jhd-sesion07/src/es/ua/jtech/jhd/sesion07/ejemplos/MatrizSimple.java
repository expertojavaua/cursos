package es.ua.jtech.jhd.sesion07.ejemplos;

public class MatrizSimple
{
	int[][] elem;

	public MatrizSimple(int[][] elem)
	{
		this.elem = new int[elem.length][elem[0].length];

		for (int i = 0; i < elem.length; i++)
			for (int j = 0; j < elem[0].length; j++)
				this.elem[i][j] = elem[i][j];
	}

	public MatrizSimple suma(MatrizSimple m)
	{
		MatrizSimple nueva = new MatrizSimple(this.elem);

		for (int i = 0; i < elem.length; i++)
			for (int j = 0; j < elem[0].length; j++)
				nueva.elem[i][j] += m.elem[i][j];

		return nueva;
	}

	public boolean equals(MatrizSimple m)
	{
		for (int i = 0; i < elem.length; i++)
			for (int j = 0; j < elem[0].length; j++)
				if (elem[i][j] != m.elem[i][j])
					return false;
		return true;
	}
}
