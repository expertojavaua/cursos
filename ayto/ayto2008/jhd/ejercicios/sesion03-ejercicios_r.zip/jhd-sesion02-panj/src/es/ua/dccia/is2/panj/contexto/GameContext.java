package es.ua.dccia.is2.panj.contexto;

// ------------------------------------------------------------------------------------
// 	Contexto del juego (dispositivos de entrada)
// ------------------------------------------------------------------------------------

public class GameContext {

	public EntradaTeclado et;
	
}