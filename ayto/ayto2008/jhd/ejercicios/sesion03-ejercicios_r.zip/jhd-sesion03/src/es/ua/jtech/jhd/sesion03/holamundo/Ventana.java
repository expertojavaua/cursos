package es.ua.jtech.jhd.sesion03.holamundo;

import java.io.*;
import java.awt.*;
import javax.swing.*;

import es.ua.j2ee.componentes.Ticker;

/**
 * Ventana principal de la aplicaci�n
 * @author Miguel Angel
 */
public class Ventana extends JFrame {

	private static final long serialVersionUID = 1L;

	/**
	 * Constructor de la clase <code>Ventana</code>
	 */
	public Ventana() {
		Container panel = this.getContentPane();

		// Carga imagen
		
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		InputStream in = getClass().getResourceAsStream("/logo.gif");

		if(in != null) {
			try {
				int c;
				while( (c=in.read()) != -1 ) {
					baos.write(c);
				}
			} catch(IOException e) {
				System.err.println("Error al cargar imagen");
			}

			byte [] datos = baos.toByteArray();
			Icon icono = new ImageIcon(datos); 
			JLabel lbl = new JLabel(icono);
			panel.add(lbl, BorderLayout.CENTER);
		}

		// Crea ticker

		Ticker ticker = new Ticker("Hola mundo!");
		ticker.start();

		panel.add(ticker, BorderLayout.NORTH);
		
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
}
