package es.ua.jtech.jhd.sesion08.ejercicios.logging;

import java.io.*;

import org.apache.log4j.Logger;

public class LeeFichero
{
	static Logger logger = Logger.getLogger(LeeFichero.class);
	
	BufferedReader r = null;
	
	public LeeFichero(String fichero) throws FileNotFoundException
	{
		// Mensaje: inicializando clase
		logger.debug("Inicializando clase");
		
		r = new BufferedReader(new FileReader(fichero));
	}
	
	public String lee() throws IOException
	{
		String result = "";
		String linea = "";
		
		// Mensaje: leyendo 5 primeras lineas
		logger.debug("Leyendo 5 primeras lineas");
		for (int i = 0; i < 5; i++)
		{
			linea = r.readLine();
			if (linea == null)
				throw new IOException ("Error al leer el fichero");
			else
				result += linea;
		}
		
		// Mensaje: leyendo lineas restantes
		logger.debug("Leyendo lineas restantes");
		while ((linea = r.readLine()) != null)
		{
			result += linea;
		}
		
		// Mensaje: devolviendo el resultado
		logger.debug("Devolviendo el resultado");
		return result;
	}
}