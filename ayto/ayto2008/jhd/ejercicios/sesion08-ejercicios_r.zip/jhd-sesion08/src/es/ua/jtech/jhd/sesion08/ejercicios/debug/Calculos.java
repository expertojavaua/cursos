package es.ua.jtech.jhd.sesion08.ejercicios.debug;

public class Calculos
{
	public static void main(String[] args)
	{
		double[] x = {0.1, 0.25, 0.5, 0.75, 1, 3, 5, 7};
		double[] y = new double[x.length];
		
		// En la iteracion 4 el primer termino vale 0.54
		// La serie es decreciente por los elementos <1 (a partir del indice 5 se hace creciente)
		for (int i = 0; i < x.length; i++)
		{
			double valor = Math.sqrt(Math.abs(Math.log(x[i]))) + Math.pow(x[i], 4) - x[i];
			y[i] = valor;
		}
	}
}