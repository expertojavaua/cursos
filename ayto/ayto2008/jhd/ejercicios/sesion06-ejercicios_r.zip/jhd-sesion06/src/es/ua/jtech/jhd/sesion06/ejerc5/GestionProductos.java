package es.ua.jtech.jhd.sesion06.ejerc5;

import java.util.*;
import java.io.*;

public class GestionProductos {

	private final static String FICHERO_DATOS = "prod.dat";

	ArrayList productos;

	public GestionProductos() {
		try {
			productos = recuperar();
		} catch(Exception e) {
			productos = new ArrayList();
		}
	}

	public void nuevoProducto(Producto prod) {
		productos.add(prod);
	}

	public Producto[] leeProductos() {
		int tam = productos.size();
		Producto[] lista = new Producto[tam];

		productos.toArray(lista);
		return lista;
	}

	public void eliminaProducto(int indice) {
		productos.remove(indice);
	}

	public void guardar() throws IOException {
		almacenar(productos);
	}

	private static void almacenar(ArrayList productos) throws IOException {

		// Guardar los datos en el fichero FICHERO_DATOS
		/* DataOutputStream dos = new DataOutputStream(new FileOutputStream(FICHERO_DATOS));

		Iterator iter = productos.iterator();
		while(iter.hasNext()) {
			Producto p = (Producto)iter.next();
			dos.writeUTF(p.autor);
			dos.writeUTF(p.titulo);
			dos.writeFloat(p.precio);
			dos.writeBoolean(p.stock);
		}
		
		dos.close(); */
		
		ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(FICHERO_DATOS));

		Iterator iter = productos.iterator();
		while(iter.hasNext()) {
			Producto p = (Producto)iter.next();
			oos.writeObject(p);
		}
		
		oos.close();
	}

	private static ArrayList recuperar() throws IOException, ClassNotFoundException {

		ArrayList productos = new ArrayList();

		// Leer los datos del fichero FICHERO_DATOS
		/* DataInputStream dis = new DataInputStream(new FileInputStream(FICHERO_DATOS));

		try {
			while(true) {
				String autor = dis.readUTF();
				String titulo = dis.readUTF();
				float precio = dis.readFloat();
				boolean stock = dis.readBoolean();
				
				productos.add(new Producto(titulo, autor, precio, stock));
			}
		} catch(EOFException e) {} */
		
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream(FICHERO_DATOS));

		try {
			while(true) {
				Object p = ois.readObject();
				productos.add(p);
			}
		} catch(EOFException e) {}
		
		return productos;
	}

}
