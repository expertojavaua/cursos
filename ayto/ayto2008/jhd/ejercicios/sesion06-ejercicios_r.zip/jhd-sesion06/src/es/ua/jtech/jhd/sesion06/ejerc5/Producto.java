package es.ua.jtech.jhd.sesion06.ejerc5;

import java.io.Serializable;

public class Producto implements Serializable {

	private static final long serialVersionUID = -1872729612699160490L;
	
	String titulo;
	String autor;
	float precio;
	boolean stock;

	public Producto(String titulo, String autor, float precio, boolean stock) {
		this.titulo = titulo;
		this.autor = autor;
		this.precio = precio;
		this.stock = stock;
	}
	
	public String toString() {
		String s = "";
		s += "Titulo: \t" + titulo + "\n";
		s += "Autor: \t" + autor + "\n";
		s += "Precio: \t" + precio + "\n";
		s += stock?"En stock":"Agotado" + "\n";
		
		return s;
	}
}
