/*
 * Created on 13-sep-2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package es.ua.jtech.jhd.sesion6.chat;

/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class Mensaje {
	String nick;
	String texto;
	
	public Mensaje(String nick, String texto) {
		this.nick = nick;
		this.texto = texto;
	}

}
