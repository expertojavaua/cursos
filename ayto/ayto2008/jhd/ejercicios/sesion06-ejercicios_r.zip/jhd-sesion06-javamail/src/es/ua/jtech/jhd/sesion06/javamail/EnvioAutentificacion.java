package es.ua.jtech.jhd.sesion06.javamail;

import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class EnvioAutentificacion {

	public static void main(String[] args) {

		// Configura las propiedades
		Properties props = System.getProperties();
		props.put("mail.smtp.host", "smtp.gmail.com");
		props.put("mail.smtp.port", "25");
		props.put("mail.smtp.auth", "true");
	    props.put("mail.smtp.starttls.enable", "true"); 
	    
		// Obtiene la sesion
		Session session = Session.getDefaultInstance(props, new Autentificador());
		session.setDebug(true);

		try {
			// Compone el mensaje
			Message msg = new MimeMessage(session);
			msg.setFrom(new InternetAddress("noreply@jtech.ua.es"));
			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(
					"malozano@ua.es", false));
			msg.setSubject("Prueba Javamail con autentificacion");
			msg
					.setText("Hola,\n"
							+ "Este es un mensaje de prueba enviado desde Javamail con autentificacion.\n\n"
							+ "Saludos");
			msg.setSentDate(new Date());

			// Envia el mensaje
			Transport.send(msg);
			
			System.out.println("Mensaje enviado");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
