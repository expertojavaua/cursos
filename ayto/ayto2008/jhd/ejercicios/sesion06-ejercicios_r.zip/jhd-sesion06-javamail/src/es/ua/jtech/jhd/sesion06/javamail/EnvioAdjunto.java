package es.ua.jtech.jhd.sesion06.javamail;

import java.util.Date;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

public class EnvioAdjunto {

	public static void main(String[] args) {

		String filename = "banner-java.gif";
		
		// Configura las propiedades
		Properties props = System.getProperties();
		props.put("mail.smtp.host", "mail.alu.ua.es");

		// Obtiene la sesion
		Session session = Session.getDefaultInstance(props, null);
		session.setDebug(true);

		try {
			// Compone el mensaje
			Message msg = new MimeMessage(session);
			msg.setFrom(new InternetAddress("noreply@jtech.ua.es"));
			msg.setRecipients(Message.RecipientType.TO, InternetAddress.parse(
					"malozano@ua.es", false));
			msg.setSubject("Prueba con adjunto");
			msg.setSentDate(new Date());

			Multipart multipart = new MimeMultipart("related");

			BodyPart texto = new MimeBodyPart();
			String htmlText = "<H1>Hola</H1>" + 
		      "<img border=\"1\" src=\"cid:imagen.gif\"><br/>" + 
		      "Texto del mensaje";
			texto.setContent(htmlText, "text/html");
			
			multipart.addBodyPart(texto);
			
			BodyPart attachment = new MimeBodyPart();
			DataSource source = new FileDataSource(filename);
			attachment.setDataHandler(new DataHandler(source));
			attachment.setFileName(filename);
			attachment.setHeader("Content-ID","<imagen.gif>");
			multipart.addBodyPart(attachment);
			
			msg.setContent(multipart);
			
			// Envia el mensaje
			Transport.send(msg);
		} catch (Exception e) {
			e.printStackTrace();
		}

		System.out.println("Mensaje enviado");

	}

}
