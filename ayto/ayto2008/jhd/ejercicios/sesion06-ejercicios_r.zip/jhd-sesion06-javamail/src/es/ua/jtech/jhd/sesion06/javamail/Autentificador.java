package es.ua.jtech.jhd.sesion06.javamail;

import javax.mail.*;
import java.util.*;

public class Autentificador extends Authenticator {

  public PasswordAuthentication getPasswordAuthentication() {
    String username, password;

    Scanner scan = new Scanner(System.in);
    System.out.print("Usuario: ");
    username = scan.nextLine();
    System.out.print("Password: ");
    password = scan.nextLine();
    
    return new PasswordAuthentication(username, password);
  }

}
