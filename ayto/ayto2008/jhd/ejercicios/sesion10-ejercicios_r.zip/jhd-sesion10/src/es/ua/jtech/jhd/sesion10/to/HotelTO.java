package es.ua.jtech.jhd.sesion10.to;

public class HotelTO {
	private int id;
	private String nombre;
	private String direccion;
	private int anyoCrea;
	private int plazasDisp;
	private int precio;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public int getAnyoCrea() {
		return anyoCrea;
	}
	public void setAnyoCrea(int anyoCrea) {
		this.anyoCrea = anyoCrea;
	}
	public int getPlazasDisp() {
		return plazasDisp;
	}
	public void setPlazasDisp(int plazasDisp) {
		this.plazasDisp = plazasDisp;
	}
	public int getPrecio() {
		return precio;
	}
	public void setPrecio(int precio) {
		this.precio = precio;
	}
	
	public String toString() {
		return "[" + id + "] " + nombre + " (" + direccion + ")";
	}
}
