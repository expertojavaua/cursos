package es.ua.jtech.jhd.sesion10.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import es.ua.jtech.jhd.sesion10.to.HotelTO;

public class HotelDAO {

	public HotelDAO() {
	}

	public HotelTO selectHotel(int id) throws DAOException {
		Connection con=null;
		try { 
			con = FuenteDatosJDBC.getInstance().getConnection();
			
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM hoteles WHERE id="
					+ id);
			if (rs.next()) {
				return creaHotelTO(rs);
			} else {
				return null;
			}
		} catch (SQLException e) {
			throw new DAOException("Error al seleccionar hotel", e);
		} finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e) {}
			}
		}
	}

	public void updateHotel(HotelTO hotel) throws DAOException {
		Connection con=null;
		try { 
			con = FuenteDatosJDBC.getInstance().getConnection();
			
			Statement stmt = con.createStatement();
			stmt.executeUpdate("UPDATE hoteles SET nombre='" + hotel.getNombre() + "', direccion='" + hotel.getDireccion() + "', anyoCrea=" + hotel.getAnyoCrea() + ", plazasDisp=" + hotel.getPlazasDisp() + ", precio=" + hotel.getPrecio() + " WHERE id=" + hotel.getId());
		} catch (SQLException e) {
			throw new DAOException("Error al modificar hotel", e);
		} finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e) {}
			}
		}
	}

	public void addHotel(HotelTO hotel) throws DAOException {
		Connection con=null;
		try { 
			con = FuenteDatosJDBC.getInstance().getConnection();
			
			Statement stmt = con.createStatement();
			stmt.executeUpdate("INSERT INTO hoteles(nombre, direccion, anyoCrea, plazasDisp, precio) VALUES('" + hotel.getNombre() + "', '" + hotel.getDireccion() + "', " + hotel.getAnyoCrea() + ", " + hotel.getPlazasDisp() + ", " + hotel.getPrecio() + ")");
		} catch (SQLException e) {
			throw new DAOException("Error al agregar hotel", e);
		} finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e) {}
			}
		}
	}

	public void delHotel(HotelTO hotel) throws DAOException {
		Connection con=null;
		try { 
			con = FuenteDatosJDBC.getInstance().getConnection();
			
			Statement stmt = con.createStatement();
			stmt.executeUpdate("DELETE hoteles WHERE id=" + hotel.getId());
		} catch (SQLException e) {
			throw new DAOException("Error al eliminar hotel", e);
		} finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e) {}
			}
		}
	}

	public List<HotelTO> getAllHoteles() throws DAOException {
		Connection con = null;
		try {
			con = FuenteDatosJDBC.getInstance().getConnection();
			
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM hoteles");
			List<HotelTO> lista = new ArrayList<HotelTO>();
			while(rs.next()) {
				lista.add(creaHotelTO(rs));
			}
			return lista;
		} catch (SQLException e) {
			throw new DAOException("Error al obtener lista de hoteles", e);
		} finally {
			if(con!=null) {
				try {
					con.close();
				} catch (SQLException e) {}
			}
		}
	}

	private HotelTO creaHotelTO(ResultSet rs) throws SQLException {
		HotelTO hotel = new HotelTO();

		hotel.setId(rs.getInt("id"));
		hotel.setNombre(rs.getString("nombre"));
		hotel.setDireccion(rs.getString("direccion"));
		hotel.setAnyoCrea(rs.getInt("anyoCrea"));
		hotel.setPlazasDisp(rs.getInt("plazasDisp"));
		hotel.setPrecio(rs.getInt("precio"));

		return hotel;
	}
}
