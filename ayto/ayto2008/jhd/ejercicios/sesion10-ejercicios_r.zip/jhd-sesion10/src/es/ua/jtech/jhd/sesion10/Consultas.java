package es.ua.jtech.jhd.sesion10;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.*;

public class Consultas {
	private Connection con = null;

	public Consultas() throws SQLException, ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection("jdbc:mysql://localhost/viajes",
				"root", "root");
	}

	private void reservaViaje() {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int numHotel = 0, numUsu = 0, numVuelo = 0;

		try {
			System.out.print("Introduzca el numero del hotel: ");
			numHotel = Integer.parseInt(br.readLine());
			System.out.print("Introduzca el numero del usuario: ");
			numUsu = Integer.parseInt(br.readLine());
			System.out.print("Introduzca el numero del vuelo:");
			numVuelo = Integer.parseInt(br.readLine());
		} catch (IOException e) {
			System.out.println(e);
		}

		// Hacer la transaccion
		try {
			Statement stmt = con.createStatement();
			con.setAutoCommit(false);
			stmt.executeUpdate("UPDATE hoteles SET plazasDisp=plazasDisp-1 WHERE id=" + numHotel);
			stmt.executeUpdate("UPDATE vuelos SET plazasDisp=plazasDisp-1 WHERE id=" + numVuelo);
			stmt.executeUpdate("INSERT INTO reshotel(fk_usuario, fk_hotel) VALUES(" + numUsu + ", " + numHotel + ")");
			stmt.executeUpdate("INSERT INTO resvuelo(fk_usuario, fk_vuelo) VALUES(" + numUsu + ", " + numVuelo + ")");			
			con.commit();
			System.out.println("Transaccion efectuada");
		} catch(SQLException e) {
			try {
				con.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			System.out.println("Transaccion cancelada");
		}
	}

	public void consultaHoteles() throws SQLException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int precio=0, plazas=0;
		try {
			System.out.print("Introduzca el precio maximo:");
			precio = Integer.parseInt(br.readLine());
			System.out.print("Introduzca el numero de plazas: ");
			plazas = Integer.parseInt(br.readLine());
		} catch (IOException e) {
			System.out.println(e);
		}
		
		// Hacer la consulta
		PreparedStatement ps = con.prepareStatement("SELECT * FROM hoteles WHERE precio<=? AND plazasDisp>=?");
		ps.setInt(1, precio);
		ps.setInt(2, plazas);
		ResultSet rs = ps.executeQuery();
		while(rs.next()) {
			int id = rs.getInt("id");
			String nombre = rs.getString("nombre");
			
			System.out.println("[" + id + "] " + nombre);
		}
	}

	public void close() throws SQLException {
		con.close();
	}

	public static void main(String[] args) {
		Consultas cons = null;

		try {
			cons = new Consultas();
			cons.consultaHoteles();
			cons.reservaViaje();
			cons.close();
		} catch (SQLException e) {
			System.out.println(e);
		} catch (ClassNotFoundException e) {
			System.out.println("Driver no encontrado: " + e.getMessage());
		}
	}
}
