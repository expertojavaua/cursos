package es.ua.jtech.jhd.sesion10.dao;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import es.ua.jtech.jhd.sesion10.to.HotelTO;

public class HotelDAO {
	private Connection con=null;
	
	public HotelDAO () throws SQLException {
	}
	
	public HotelTO selectHotel(int id){
		return null;
	}
	
	public void updateHotel (HotelTO hotel) {
	}
	
	public void addHotel (HotelTO hotel) {
	}
	
	public void delHotel (HotelTO hotel) {
	}
	
	public List<HotelTO> getAllHoteles () {
		return null;
	}
}
