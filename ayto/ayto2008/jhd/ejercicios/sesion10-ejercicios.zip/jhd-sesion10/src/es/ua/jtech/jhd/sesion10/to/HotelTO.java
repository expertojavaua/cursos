package es.ua.jtech.jhd.sesion10.to;

public class HotelTO {
}
