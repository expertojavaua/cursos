package es.ua.jtech.jhd.sesion10;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.*;

public class Consultas {
	private Connection con = null;

	public Consultas() throws SQLException, ClassNotFoundException {
		Class.forName("com.mysql.jdbc.Driver");
		con = DriverManager.getConnection("jdbc:mysql://localhost/viajes",
				"root", "root");
	}

	private void reservaViaje() {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int numHotel = 0, numUsu = 0, numVuelo = 0;

		try {
			System.out.print("Introduzca el numero del hotel: ");
			numHotel = Integer.parseInt(br.readLine());
			System.out.print("Introduzca el numero del usuario: ");
			numUsu = Integer.parseInt(br.readLine());
			System.out.print("Introduzca el numero del vuelo:");
			numVuelo = Integer.parseInt(br.readLine());
		} catch (IOException e) {
			System.out.println(e);
		}

		// TODO Hacer la transaccion
	}

	public void consultaHoteles() throws SQLException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		int precio=0, plazas=0;
		try {
			System.out.print("Introduzca el precio maximo:");
			precio = Integer.parseInt(br.readLine());
			System.out.print("Introduzca el numero de plazas: ");
			plazas = Integer.parseInt(br.readLine());
		} catch (IOException e) {
			System.out.println(e);
		}
		// TODO Realizar la consulta
	}

	public void close() throws SQLException {
		con.close();
	}

	public static void main(String[] args) {
		Consultas cons = null;

		try {
			cons = new Consultas();
			cons.consultaHoteles();
			cons.reservaViaje();
			cons.close();
		} catch (SQLException e) {
			System.out.println(e);
		} catch (ClassNotFoundException e) {
			System.out.println("Driver no encontrado: " + e.getMessage());
		}
	}
}
