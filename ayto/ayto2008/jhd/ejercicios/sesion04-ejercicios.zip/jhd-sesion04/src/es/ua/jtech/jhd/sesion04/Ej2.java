package es.ua.jtech.jhd.sesion04;
public class Ej2 {

	// TODO: Declarar que el m�todo logaritmo puede lanzar excepciones

	public static double logaritmo(String entrada) {

		double num = Double.parseDouble(entrada);

		if (num <= 0) {
			// TODO: Lanzar excepcion con mensaje descriptivo

		}

		return Math.log(num);
	}

	public static void main(String[] args) {

		System.out.println("Logaritmo = " + logaritmo(args[0]));
	}
}