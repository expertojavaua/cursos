package es.ua.jtech.struts.acciones;

import javax.servlet.http.*;
import org.apache.struts.action.*;

public class LogoutAccion extends Action {
	   public ActionForward execute(
	            ActionMapping mapping,
	            ActionForm form,
	            HttpServletRequest request,
	            HttpServletResponse response)
	            throws Exception {
		   
		   request.getSession().setAttribute("usuario", null);
		   return mapping.findForward("OK");
	   }
}
