package es.ua.jtech.struts.dao;

import es.ua.jtech.struts.domain.*;

import java.util.*;
import java.sql.*;

public class TareaDAO {
	private static final String SQL_GET ="select * from tareas where id=?";
	private static final String SQL_LISTAR = "select * from tareas where login=? order by vencimiento";
	private static final String SQL_CREAR ="insert into tareas(descripcion, prioridad,vencimiento,login,comentario) values(?,?,?,?,?)";
	private static final String SQL_ELIMINAR ="delete from tareas where id=? and login=?";
	
	private static TareaDAO singleton = null;

	private TareaDAO() {

	}

	public static TareaDAO getInstance() {
		if (singleton == null)
			singleton = new TareaDAO();
		return singleton;
	}

	
	public Tarea getTarea(int id) throws DAOException {
		Connection con = null;
		PreparedStatement ps;
		ResultSet rs;
		
		try {
			con = FuenteDatos.getConnection();
			ps = con.prepareStatement(SQL_GET);
			ps.setInt(1, id);
			rs = ps.executeQuery();
			if (rs.next()) {
				return crearDesdeRegistro(rs);
			}
			else
				return null;
		}
		catch (Exception e) {
			System.out.println(e);
			throw new DAOException("error con la b.d.", e);
		}
		finally {
			try {
				if (con!=null)
					con.close();
			}
			catch(SQLException sqle) {
				throw new DAOException("error al cerrar la conexi�n", sqle);
			}
		}
	}
		
	
	public List<Tarea> listar(String login) throws DAOException {
		Connection con = null;
		PreparedStatement ps;
		ResultSet rs;
		List<Tarea> tareas = null;
		
		try {
			con = FuenteDatos.getConnection();
			ps = con.prepareStatement(SQL_LISTAR);
			ps.setString(1, login);
			rs = ps.executeQuery();
			tareas = new ArrayList<Tarea>();
			while (rs.next()) {
				tareas.add(crearDesdeRegistro(rs));
			}
		}
		catch (Exception e) {
			System.out.println(e);
			throw new DAOException("error con la b.d.", e);
		}
		finally {
			try {
				if (con!=null)
					con.close();
			}
			catch(SQLException sqle) {
				throw new DAOException("error al cerrar la conexi�n", sqle);
			}
		}
		return tareas;
	}

	public void crear(Tarea nueva, String login) throws DAOException {
		Connection con = null;
		PreparedStatement ps;
		
		try {
			con = FuenteDatos.getConnection();
			ps = con.prepareStatement(SQL_CREAR);
			ps.setString(1, nueva.getDescripcion());
			ps.setString(2, nueva.getPrioridad().toString());
			ps.setDate(3, new java.sql.Date(nueva.getVencimiento().getTime()));
			ps.setString(4, login);
			ps.setString(5, nueva.getComentario());
			ps.executeUpdate();
		}
		catch (Exception e) {
			System.out.println(e);
			throw new DAOException("error con la b.d.", e);
		}
		finally {
			try {
				if (con!=null)
					con.close();
			}
			catch(SQLException sqle) {
				throw new DAOException("error al cerrar la conexi�n", sqle);
			}
		}
	}

	public void eliminar(int id, String login) throws DAOException {
		Connection con = null;
		PreparedStatement ps;
		
		try {
			con = FuenteDatos.getConnection();
			ps = con.prepareStatement(SQL_ELIMINAR);
			ps.setInt(1, id);
			ps.setString(2, login);
			ps.executeUpdate();
		}
		catch (Exception e) {
			System.out.println(e);
			throw new DAOException("error con la b.d.", e);
		}
		finally {
			try {
				if (con!=null)
					con.close();
			}
			catch(SQLException sqle) {
				throw new DAOException("error al cerrar la conexi�n", sqle);
			}
		}

	}


	/**
	 * Crea un objeto tarea a partir de la informaci�n contenida en el registro
	 * actual de un ResultSet
	 * 
	 * @param rs
	 * @return
	 */
	private Tarea crearDesdeRegistro(ResultSet rs) throws SQLException {
		Tarea t;

		t = new Tarea();
		t.setId(rs.getInt("id"));
		t.setDescripcion(rs.getString("descripcion"));
		t.setPrioridad(Tarea.Prioridad.valueOf(rs.getString("prioridad")));
		t.setVencimiento(rs.getDate("vencimiento"));
		t.setComentario(rs.getString("comentario"));
		t.setAviso(rs.getInt("aviso"));

		return t;
	}

}
