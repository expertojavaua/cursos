package es.ua.jtech.struts.acciones;

import javax.servlet.http.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import org.apache.struts.action.*;
import es.ua.jtech.struts.dao.*;
import es.ua.jtech.struts.domain.*;

public class NuevaTareaAccion extends Action {
	   public ActionForward execute(
	            ActionMapping mapping,
	            ActionForm form,
	            HttpServletRequest request,
	            HttpServletResponse response)
	            throws Exception {
		   
		   //�Hay permiso de acceso?
		   Usuario u = (Usuario)request.getSession().getAttribute("usuario");
		   if (u==null)
			   return mapping.findForward("noAutorizado");
		   //copiar los datos del request en la tarea, aprovechando para validar ciertos parametros
		   Tarea t = validar(request);
		   //Guardar los datos en la B.D.
		   TareaDAO miDao = TareaDAO.getInstance();
		   try {
			   miDao.crear(t, u.getLogin());
		   }
		   catch(DAOException de) {
			   return mapping.findForward("error");
		   }
		   return mapping.findForward("OK");
	   }
	   
	   
	   private Tarea validar (HttpServletRequest request) {
			SimpleDateFormat sdf;
			java.util.Date vencimiento;
			Tarea.Prioridad prioridad;
			int dias;
			
			//validar y convertir la fecha
			sdf = new SimpleDateFormat("dd/MM/yyyy");
			try {
				vencimiento = sdf.parse(request.getParameter("vencimiento"));			
			} catch (ParseException pe) {
				pe.printStackTrace();
				return null;
			}
			//validar y convertir la prioridad
			try {
				prioridad = Tarea.Prioridad.valueOf(request.getParameter("prioridad"));
			}
			catch (Exception exc) {
				exc.printStackTrace();
				return null;
			}
			//Validar y convertir los d�as de aviso
			try {
				dias = Integer.parseInt(request.getParameter("aviso"));
			}
			catch(NumberFormatException nfe) {
				nfe.printStackTrace();
				return null;
			}
			//crear el objeto tarea y rellenar los campos
			Tarea t = new Tarea();
			t.setComentario(request.getParameter("comentario"));
			t.setDescripcion(request.getParameter("descripcion"));
			t.setPrioridad(prioridad);
			t.setVencimiento(vencimiento);
			t.setAviso(dias);
			return t;
		}
}

