package es.ua.jtech.struts.acciones;

import javax.servlet.http.*;
import org.apache.struts.action.*;
import es.ua.jtech.struts.dao.*;
import es.ua.jtech.struts.domain.Usuario;

public class LoginAccion extends Action {
	   public ActionForward execute(
	            ActionMapping mapping,
	            ActionForm form,
	            HttpServletRequest request,
	            HttpServletResponse response)
	            throws Exception {
		   
		   UsuarioDAO dao = UsuarioDAO.getInstance();
		   //si el m�todo login devuelve "null" entonces, el login y/o el password son incorrectos
		   Usuario u = dao.login(request.getParameter("login"), request.getParameter("password"));
		   if (u==null) {
			   //si hay error se debe volver al formulario de login
			   return mapping.findForward("error");			   
		   }
		   else {
			   request.getSession().setAttribute("usuario", u);
			   //si todo va bien, hay que mostrar la lista de tareas (URL: /listarTodas.do)
			   return mapping.findForward("OK");
		   }
	   }
}
