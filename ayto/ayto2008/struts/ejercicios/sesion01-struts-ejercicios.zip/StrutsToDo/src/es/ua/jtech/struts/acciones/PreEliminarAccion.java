package es.ua.jtech.struts.acciones;

import javax.servlet.http.*;
import org.apache.struts.action.*;
import es.ua.jtech.struts.dao.*;
import es.ua.jtech.struts.domain.*;

public class PreEliminarAccion extends Action {
	   public ActionForward execute(
	            ActionMapping mapping,
	            ActionForm form,
	            HttpServletRequest request,
	            HttpServletResponse response)
	            throws Exception {
		   
		   //�Hay permiso de acceso?
		   Usuario u = (Usuario)request.getSession().getAttribute("usuario");
		   if (u==null)
			   return mapping.findForward("noAutorizado");
		   //Recuperar los datos de la tarea a borrar
		   TareaDAO miDao = TareaDAO.getInstance();
		   try {
			   Tarea t = miDao.getTarea(Integer.parseInt(request.getParameter("id")));
			   request.setAttribute("tarea", t);
		   }
		   catch(DAOException de) {
			   return mapping.findForward("error");
		   }
		   return mapping.findForward("OK");
	   }
}
