package es.ua.jtech.struts.acciones;

import javax.servlet.http.*;
import org.apache.struts.action.*;

import es.ua.jtech.struts.dao.TareaDAO;
import es.ua.jtech.struts.domain.Usuario;

public class ListarTodasAccion extends Action {
	   public ActionForward execute(
	            ActionMapping mapping,
	            ActionForm form,
	            HttpServletRequest request,
	            HttpServletResponse response)
	            throws Exception {

		   
		   //Comprobar que se ha hecho login
		   Usuario u = (Usuario)request.getSession().getAttribute("usuario");
		   if (u==null)
			   return mapping.findForward("noAutorizado");
		   //sacar la lista de tareas y meterla en el request
		   TareaDAO dao = TareaDAO.getInstance();
		   request.setAttribute("tareas", dao.listar(u.getLogin()));
		   return mapping.findForward("OK");
	   }
}
