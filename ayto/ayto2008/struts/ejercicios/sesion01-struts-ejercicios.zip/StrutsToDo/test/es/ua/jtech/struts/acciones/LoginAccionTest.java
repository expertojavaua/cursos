package es.ua.jtech.struts.acciones;

import servletunit.struts.CactusStrutsTestCase;

public class LoginAccionTest extends CactusStrutsTestCase {
	public LoginAccionTest(String testName) {
		super(testName);
	}
	
	public void testLoginOK() {
		setRequestPathInfo("/login");
		addRequestParameter("login", "struts");
		addRequestParameter("password", "mola");
		actionPerform();
		verifyForward("OK");
		verifyNoActionErrors();
	}
	
	public void testLoginNOOK() {
		setRequestPathInfo("/login");
		addRequestParameter("login", "struts");
		addRequestParameter("password", "nomola");
		actionPerform();
		verifyForward("error");
		//Si no has hecho el optativo de la sesi�n 1, el error no se generar�. 
		//Si lo has hecho, descomenta esto y cambia "error.login" por el nombre que le hayas dado a tu error
		//verifyActionErrors(new String[] {"error.login"});
		
	}

}
