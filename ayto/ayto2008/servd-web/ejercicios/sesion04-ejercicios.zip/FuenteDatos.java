package ua;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class FuenteDatos {
	static private DataSource ds = null;
	
	static public DataSource getDS() throws Exception {
		if (ds==null) {
			try {
				Context initCtx = new InitialContext();
				//Obtener el recurso con su nombre l�gico (JNDI)
				ds = (DataSource) initCtx.lookup("java:/comentariosDS");
			}
			catch(NamingException ne) {
				throw new Exception(ne);
			}
		}
		return ds;
			
	}
}
