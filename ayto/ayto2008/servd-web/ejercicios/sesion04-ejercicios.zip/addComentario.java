package ua;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.*;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

/**
 * Servlet implementation class addComentario
 */
public class addComentario extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public addComentario() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			Connection con = FuenteDatos.getDS().getConnection();
			PreparedStatement sql = con.prepareStatement("INSERT INTO comentarios VALUES (NULL,NULL,?,?)");
			sql.setString(1, request.getParameter("autor"));
			sql.setString(2, request.getParameter("texto"));
			sql.executeUpdate();
		}
		catch(Exception e) {
			throw new ServletException(e.getCause());
		}
		response.sendRedirect("comentarioOK.html");
	}
	

}
