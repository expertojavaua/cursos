package es.ua.jtech.ctj.sesion12.notas;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class EdicionNota extends Form implements CommandListener {

	Command cmdAceptar;
	Command cmdCancelar;

	TextField txtNombre;
	TextField txtTexto;

	private Mensaje msg;
	private boolean nueva;

	MIDlet owner;
	AdaptadorRMS rms;

	public EdicionNota(MIDlet owner, AdaptadorRMS rms, Mensaje msg) {
		super("Edicion");
		this.owner = owner;

		this.rms = rms;
		this.nueva = false;
		this.msg = msg;

		init(msg.getAsunto(), msg.getTexto());
	}

	public EdicionNota(MIDlet owner, AdaptadorRMS rms) {
		super("Nueva nota");
		this.owner = owner;

		this.rms = rms;
		this.nueva = true;

		init("", "");
	}

	public void init(String nombre, String texto) {

		// A�adimos elementos al formulario		
		txtNombre = new TextField("Nombre", nombre, 8, TextField.ANY);
		txtTexto = new TextField("Texto", texto, 140, TextField.ANY);
		this.append(txtNombre);
		this.append(txtTexto);
		
		// Creamos comandos
		cmdAceptar = new Command("Aceptar", Command.OK, 1);
		cmdCancelar = new Command("Cancelar", Command.CANCEL, 1);
		this.addCommand(cmdAceptar);
		this.addCommand(cmdCancelar);
		this.setCommandListener(this);		
	}

	public String getNombre() {
		// Devuelve el nombre introducido
		return txtNombre.getString();
	}

	public String getTexto() {
		// Devuelve el texto introducido
		return txtTexto.getString();
	}

	public synchronized void commandAction(Command cmd, Displayable disp) {

		if(cmd == cmdAceptar) {

			// Acepta los cambios
			Display d = Display.getDisplay(owner);
			
			try {
				if(nueva) {
					msg = new Mensaje();
					msg.setAsunto(this.getNombre());
					msg.setTexto(this.getTexto());
					rms.addMensaje(msg);
				} else {
					msg.setAsunto(this.getNombre());
					msg.setTexto(this.getTexto());
					rms.updateMensaje(msg);
				}
			} catch(Exception e) {
				Alert a = new Alert("Error", "No se puede guardar", null, AlertType.ERROR);
				d.setCurrent(a, new ListaNotas(owner, rms));
				return;					
			}

			d.setCurrent(new ListaNotas(owner, rms));

		} else if (cmd == cmdCancelar) {

			// Cancela y vuelve a la pantalla anterior
			Display d = Display.getDisplay(owner);
			d.setCurrent(new ListaNotas(owner, rms));
		}
	}

}
