package es.ua.jtech.ctj.sesion10.ts;

import javax.microedition.lcdui.*;

public class AreaDibujo extends Canvas implements Runnable, CommandListener {

	Image offScreen; 

	int cursor_x;
	int cursor_y;

	int radio = 1;
	int color = 0x00000000;

	Thread t;

	boolean abajo = false;
	boolean arriba = false;
	boolean izq = false;
	boolean der = false;

	Command cmdRojo;
	Command cmdVerde;
	Command cmdAzul;
	Command cmdNegro;
	Command cmdFino;
	Command cmdGrueso;

	public AreaDibujo() {
		// Crea imagen offscreen para dibujar en ella y cursor en el centro
		offScreen = Image.createImage(this.getWidth(), this.getHeight());
		cursor_x = this.getWidth()/2;
		cursor_y = this.getHeight()/2;
		
		actualiza();
		
		// Crea comandos
		cmdRojo = new Command("Rojo", Command.SCREEN, 1);
		cmdVerde = new Command("Verde", Command.SCREEN, 1);
		cmdAzul = new Command("Azul", Command.SCREEN, 1);
		cmdNegro = new Command("Negro", Command.SCREEN, 1);
		cmdFino = new Command("Fino", Command.SCREEN, 1);
		cmdGrueso = new Command("Grueso", Command.SCREEN, 1);
		this.addCommand(cmdRojo);
		this.addCommand(cmdVerde);
		this.addCommand(cmdAzul);
		this.addCommand(cmdNegro);
		this.addCommand(cmdFino);
		this.addCommand(cmdGrueso);
		this.setCommandListener(this);
	}

	public void showNotify() {
		t = new Thread(this);
		t.start();
	}

	public void hideNotify() {
		t = null;
	}

	public void run() {
		// Mueve cursor segun teclas pulsadas
		while(t == Thread.currentThread()) {
			if(arriba)
				mueveCursor(0,-1);
			if(abajo)
				mueveCursor(0,1);
			if(izq)
				mueveCursor(-1,0);
			if(der)
				mueveCursor(1,0);
			
			try {
				Thread.sleep(100);
			} catch(InterruptedException e) {
			}
		}
	}

	protected void keyPressed(int keyCode) {
		switch(this.getGameAction(keyCode)) {
			case UP: 	arriba = true; break;
			case DOWN: 	abajo = true; break;
			case LEFT: 	izq = true; break;
			case RIGHT: der = true; break;
		}
	}

	protected void keyReleased(int keyCode) {
		switch(this.getGameAction(keyCode)) {
			case UP: 	arriba = false; break;
			case DOWN: 	abajo = false; break;
			case LEFT: 	izq = false; break;
			case RIGHT: der = false; break;
		}
	}

/*
	protected void keyPressed(int keyCode) {
		switch(this.getGameAction(keyCode)) {
			case UP: 	mueveCursor(0,-1); break;
			case DOWN: 	mueveCursor(0,1); break;
			case LEFT: 	mueveCursor(-1,0); break;
			case RIGHT: mueveCursor(1,0); break;
		}
	}

	protected void keyRepeated(int keyCode) {
		switch(this.getGameAction(keyCode)) {
			case UP: 	mueveCursor(0,-1); break;
			case DOWN: 	mueveCursor(0,1); break;
			case LEFT: 	mueveCursor(-1,0); break;
			case RIGHT: mueveCursor(1,0); break;
		}
	}
*/

	private void mueveCursor(int x, int y) {
		cursor_x += x;
		cursor_y += y;
		
		actualiza();
	}

	private void actualiza() {
		// Pinta los gr�ficos en offscreen
		Graphics offg = offScreen.getGraphics();
		offg.setColor(color);
		offg.fillRect(cursor_x - radio, cursor_y - radio, radio*2, radio*2);
		this.repaint();
	}

	protected void paint(Graphics g) {
		// Vuelca los graficos de offscreen a la pantalla
		g.drawImage(offScreen, 0, 0, Graphics.TOP | Graphics.LEFT);
	}

	public void commandAction(Command cmd, Displayable disp) {

		// Cambia color o grosor
		if(cmd == cmdRojo) {
			color = 0x00ff0000;
		} else if(cmd == cmdVerde) {
			color = 0x0000ff00;
		} else if(cmd == cmdAzul) {
			color = 0x000000ff;
		} else if(cmd == cmdNegro) {
			color = 0x00000000;
		} else if(cmd == cmdFino) {
			radio = 1;
		} else if(cmd == cmdGrueso) {
			radio = 5;
		}
	}
}
