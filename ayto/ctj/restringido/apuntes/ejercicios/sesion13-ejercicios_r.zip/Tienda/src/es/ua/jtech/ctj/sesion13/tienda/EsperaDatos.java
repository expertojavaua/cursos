package es.ua.jtech.ctj.sesion13.tienda;

import java.io.*;
import java.util.*;
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class EsperaDatos extends Form implements Runnable {

	MIDlet owner;
	Timer temp;
	Gauge itemProgreso;

	public EsperaDatos(MIDlet owner) {
		super("Espere");
		
		this.owner = owner;
		
		// Crea barra de progreso
		itemProgreso = new Gauge("Cargando datos, espere por favor ...", false, 10, 0);
		this.append(itemProgreso);
		
		// Crea temporizador para barra de progreso
		Progreso prog = new Progreso();
		temp = new Timer();
		temp.schedule(prog, 200, 200);
		
		// Inicia hilo de carga de datos
		Thread t = new Thread(this);
		t.start();
	}
	
	public void run() {
		Display d = Display.getDisplay(owner);

		try {
			// Crea la lista de productos
			ListaProductos lp = new ListaProductos(owner);
			d.setCurrent(lp);
		} catch(IOException e) {
			// Muestra mensaje de error
			Alert a = new Alert("Error", "Error en la conexion de red", null, AlertType.ERROR);
			d.setCurrent(a, this);
			temp.cancel();
			this.setTitle("Error");
			this.delete(0);
		}
	}
	
	private void actualizaProgreso() {

		// Incrementa ciclicamente la barra
		int max = itemProgreso.getMaxValue();
		int valor = itemProgreso.getValue();
		itemProgreso.setValue( (valor + 1) % max );
	}

	// Actualizacion de la barra de progreso
	
	class Progreso extends TimerTask {
		public void run() {
			actualizaProgreso();
		}
	}
}
