package es.ua.jtech.ctj.sesion14.bt;

import java.io.IOException;

public interface ConexionChat {

	public void envia(String texto) throws IOException;
	
	public String recibe() throws IOException;
}
