package es.ua.jtech.ctj.sesion14.bt;

import java.io.DataInputStream;
import java.io.DataOutputStream;

import javax.microedition.lcdui.Display;
import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

public class MIDletBT extends MIDlet {

	public final static String UUID = "000000000000010008000123456789ab";
	
	protected void destroyApp(boolean arg0) throws MIDletStateChangeException {
	}

	protected void pauseApp() {
	}

	protected void startApp() throws MIDletStateChangeException {
		mostrarLista();
	}
	
	public void salir() {
		
		try {
			destroyApp(true);
		} catch (MIDletStateChangeException e) {
		}

		notifyDestroyed();
	}
	
	public void mostrarChat(ConexionChat con) {
		Display d = Display.getDisplay(this);
		FormChat fc = new FormChat(con);
		d.setCurrent(fc);
	}
	
	public void mostrarLista() {
		Display d = Display.getDisplay(this);
		ListaTipo lt = new ListaTipo(this);
		d.setCurrent(lt);
	}
	
	public void mostrarServidor() {
		Display d = Display.getDisplay(this);
		FormMaestro fs = new FormMaestro(this);
		d.setCurrent(fs);		
	}
	
	public void mostrarCliente() {
		Display d = Display.getDisplay(this);
		FormEsclavo fc = new FormEsclavo(this);
		d.setCurrent(fc);		
	}
}
