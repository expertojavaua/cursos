package es.ua.jtech.ctj.sesion14.bt;

import java.io.DataInputStream;
import java.io.DataOutputStream;

import javax.bluetooth.BluetoothStateException;
import javax.bluetooth.DiscoveryAgent;
import javax.bluetooth.LocalDevice;
import javax.bluetooth.ServiceRecord;
import javax.microedition.io.Connector;
import javax.microedition.io.StreamConnection;
import javax.microedition.io.StreamConnectionNotifier;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.StringItem;

public class FormEsclavo extends Form implements CommandListener, Runnable {

	MIDletBT owner;

	public FormEsclavo(MIDletBT owner) {
		super("Datos del esclavo");

		this.owner = owner;

		this.setCommandListener(this);
		
		Thread bt = new Thread(this);
		bt.start();
	}

	public void commandAction(Command cmd, Displayable disp) {

	}

	public void run() {

		try {
			LocalDevice ld = LocalDevice.getLocalDevice();

			String bt_addr = ld.getBluetoothAddress();
			String bt_name = ld.getFriendlyName();

			this.append(new StringItem("Direcci�n BT:", bt_addr));
			this.append(new StringItem("Nombre BT:", bt_name));
			
			// set we are discoverable
			if (!ld.setDiscoverable(DiscoveryAgent.GIAC)) {
				throw new BluetoothStateException("No es descubrible");
			}

			// prepare a URL to create a notifier
			String url = "btspp://localhost:" + MIDletBT.UUID;

			StreamConnectionNotifier scn = (StreamConnectionNotifier)Connector.open(url);

			// and remember the service record for the later updates
			ServiceRecord sr = ld.getRecord(scn);
			
			while(true) {
		      StreamConnection sc = (StreamConnection)scn.acceptAndOpen();

		      this.append("Maestro conectado");
		      
		      DataInputStream dis = sc.openDataInputStream();
		      DataOutputStream dos = sc.openDataOutputStream();

		      ConexionChat con = new ConexionCliente(dis, dos);
		      owner.mostrarChat(con);
		      //dos.writeUTF("Hola mundo!");
		      //dos.flush();
		      //dos.close();
		      //sc.close();
			}
		} catch (Exception e) {
			this.append("Error: " + e.getMessage());
		}
	}
}