package es.ua.j2ee.sw.hola;

import java.rmi.RemoteException;

public class HolaMundoImpl implements HolaMundoIF {

	public String saluda(String nombre) throws RemoteException {
		return "Hola " + nombre;
	}


}
