package es.ua.jtech.ctj.sesion16.mensajes.modelo;

public class SyncItem {

	long timeStamp;

	Mensaje[] mensajes;


	public Mensaje[] getMensajes() {
		return mensajes;
	}

	public void setMensajes(Mensaje[] mensajes) {
		this.mensajes = mensajes;
	}
	
	public long getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(long timeStamp) {
		this.timeStamp = timeStamp;
	}
}