package es.ua.jtech.ctj.sesion16.agenda.modelo;

import java.io.IOException;

import javax.microedition.rms.RecordStoreException;

public class FachadaModelo {

	boolean online;

	ModeloLocal mLocal;

	ProxyRemoto mRemoto;

	public FachadaModelo(GestorAlarmas alarmas) throws RecordStoreException, IOException {
		mLocal = new ModeloLocal(alarmas);
		mRemoto = new ProxyRemoto();

		InfoLocal info = getConfig();
		online = info.isOnline();
	}

	/*
	 * Crea una nueva cita
	 */
	public void nuevaCita(Cita cita) throws IOException, RecordStoreException {
		mLocal.addCita(cita, true);
		if (online) {
			sincroniza();
		}
	}

	/*
	 * Obtiene la lista de todas las citas
	 */
	public Cita[] listaCitas() throws RecordStoreException, IOException {
		if (online) {
			sincroniza();
		}
		return mLocal.listaCitas();
	}

	/*
	 * Obtiene la lista de citas con alarmas pendientes
	 */
	public Cita[] listaAlarmasPendientes() throws RecordStoreException,
			IOException {
		if (online) {
			sincroniza();
		}
		IndiceCita[] indices = mLocal.listaAlarmasPendientes();
		return mLocal.listaCitas(indices);
	}

	/*
	 * Obtiene la configuracion local
	 */
	public InfoLocal getConfig() throws RecordStoreException, IOException {
		return mLocal.getInfoLocal();
	}

	/*
	 * Actualiza la configuracion local
	 */
	public void updateConfig(InfoLocal config) throws RecordStoreException,
			IOException {
		InfoLocal info = mLocal.getInfoLocal();
		info.setOnline(config.isOnline());
		this.online = config.isOnline();
		mLocal.setInfoLocal(info);
	}

	/*
	 * Sincroniza la lista de citas con el servidor
	 */
	public void sincroniza() throws RecordStoreException, IOException {

		// Obtiene datos del cliente
		
		InfoLocal info = mLocal.getInfoLocal();

		IndiceCita[] indices = mLocal.listaCitasPendientes();
		Cita[] citas = mLocal.listaCitas(indices);
		SyncItem datosCliente = new SyncItem();
		datosCliente.setCitas(citas);
		datosCliente.setTimeStamp(info.getTimeStamp());

		// Envia y recibe
		
		SyncItem datosServidor = mRemoto.sincroniza(datosCliente);

		mLocal.marcaEnviados(indices);

		// Agrega los datos recibidos del servidor

		Cita[] citasServidor = datosServidor.getCitas();
		if (citasServidor != null) {
			for (int i = 0; i < citasServidor.length; i++) {
				mLocal.addCita(citasServidor[i], false);
			}
		}

		info.setTimeStamp(datosServidor.getTimeStamp());
		mLocal.setInfoLocal(info);
	}

	public void destroy() throws RecordStoreException {
		mLocal.destroy();
	}

}