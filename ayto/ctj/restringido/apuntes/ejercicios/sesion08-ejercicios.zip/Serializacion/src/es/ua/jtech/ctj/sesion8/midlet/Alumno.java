/*
 * Created on 27/06/2004
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package es.ua.jtech.ctj.sesion8.midlet;

import java.io.DataInputStream;
import java.io.IOException;

/**
 * @author Miguel Angel
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class Alumno {

	public String dni;
	public String nombre;
	public String apellidos;
	public char sexo;
	public short edad;
	public String tlfno;
	public boolean casado;
	
	public String toString() {
		String s="";
		s+= "DNI: \t" + dni + "\n"; 
		s+= "Nombre: \t" + nombre + "\n"; 
		s+= "Apellidos: \t" + apellidos + "\n"; 
		s+= "Sexo: \t" + sexo + "\n"; 
		s+= "Edad: \t" + edad + "\n"; 
		s+= "Telefono: \t" + tlfno + "\n"; 
		s+= casado?"Casado":"Soltero";
		
		return s;
	}	
}
