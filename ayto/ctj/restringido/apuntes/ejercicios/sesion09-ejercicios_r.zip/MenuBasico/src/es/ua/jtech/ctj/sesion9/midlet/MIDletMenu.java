package es.ua.jtech.ctj.sesion9.midlet;

import javax.microedition.lcdui.Display;
import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;

public class MIDletMenu extends MIDlet {

	protected void startApp() throws MIDletStateChangeException {
		Display d = Display.getDisplay(this);
		Menu m = new Menu();
		d.setCurrent(m);
	}

	protected void pauseApp() {
	}

	protected void destroyApp(boolean arg0) throws MIDletStateChangeException {
	}

}
