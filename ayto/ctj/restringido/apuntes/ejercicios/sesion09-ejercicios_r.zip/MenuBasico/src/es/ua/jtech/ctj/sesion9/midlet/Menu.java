package es.ua.jtech.ctj.sesion9.midlet;

import javax.microedition.lcdui.ChoiceGroup;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.List;

public class Menu extends List {

	Command cmdOK;
	Command cmdExit;
	
	public Menu() {
		super("Menu", ChoiceGroup.IMPLICIT);
		
		this.append("Nuevo juego", null);
		this.append("Continuar partida", null);
		this.append("Hi-score", null);
		this.append("Salir", null);
		
		cmdOK = new Command("OK", Command.OK, 1);
		cmdExit = new Command("Salir", Command.EXIT, 1);
		this.addCommand(cmdOK);
		this.addCommand(cmdExit);
	}
}
