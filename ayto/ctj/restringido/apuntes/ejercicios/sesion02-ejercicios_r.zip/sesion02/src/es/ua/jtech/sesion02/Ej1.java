package es.ua.jtech.sesion02;

public class Ej1
{
	public static void main(String[] args)
	{
		double d = Double.parseDouble(args[0]);
		double d2 = Double.parseDouble(args[1]);
		
		System.out.println("Producto = " + (d*d2));
	}
}