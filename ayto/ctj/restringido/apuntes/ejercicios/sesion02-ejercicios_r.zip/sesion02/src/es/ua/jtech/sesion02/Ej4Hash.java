package es.ua.jtech.sesion02;

import java.util.*;

public class Ej4Hash
{
	public static void main(String[] args)
	{
		Hashtable ht = new Hashtable();
		
		// A�adir los elementos en la lista
		
		for (int i = 0; i < 10; i++)
		{
			ht.put("Clave" + i, "Valor" + i);
		}
		
		// Buscar el elemento que se pasa como parametro
		
		String valor = (String)(ht.get(args[0]));
		boolean encontrado = (valor != null);
		if (encontrado)
			System.out.println ("Finalizado. Encontrado elemento");
		else
			System.out.println ("Finalizado. No encontrado.");
		
		// Imprimir todos los elementos por pantalla, con su nombre y su valor
		
		Enumeration en = ht.keys();
		while (en.hasMoreElements())
		{
			String clave = (String)(en.nextElement());
			String v = (String)(ht.get(clave));
			System.out.println (clave + " = " + v);
		}
		
	}
}

