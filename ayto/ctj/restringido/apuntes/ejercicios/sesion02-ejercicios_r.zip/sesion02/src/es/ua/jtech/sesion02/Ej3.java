package es.ua.jtech.sesion02;

import java.util.*;

public class Ej3
{
	public static void main(String[] args)
	{
		// Creamos un Vector con 10 cadenas 
		Vector v = new Vector();
		for (int i = 0; i < 10; i++)
			v.addElement("Hola" + i);
		
		// Recorrido mediante Enumeration
		Enumeration en = v.elements();
		System.out.println("Enumeration");
		while (en.hasMoreElements())
		{
			String s = (String)(en.nextElement());
			System.out.println(s);
		}
		
		// Recorrido mediante Iterator
		Iterator it = v.iterator();
		System.out.println("Iterator");
		while (it.hasNext())
		{
			String s = (String)(it.next());
			System.out.println(s);
		}
		
		// Recorrido mediante un bucle for, accediendo a mano a cada posici�n del vector
		System.out.println("A mano");
		for (int i = 0; i < v.size(); i++)
		{
			String s = (String)(v.elementAt(i));
			System.out.println(s);
		}
	}
}