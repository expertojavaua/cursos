package es.ua.jtech.ctj.sesion12.notas;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class ListaNotas extends List implements CommandListener {

	MIDlet owner;

	Command cmdMem;
	Command cmdVer;
	Command cmdNueva;
	Command cmdEditar;
	Command cmdBorrar;
	
	AdaptadorRMS rms;

	Mensaje [] mensajes;
	
	public ListaNotas(MIDlet owner, AdaptadorRMS rms) {
		super("Notas", Choice.IMPLICIT);
		
		this.owner = owner;
		this.rms = rms;
		
		try {
			// Crea lista de notas
			mensajes = rms.listaMensajes();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		for(int i=0;i<mensajes.length;i++) {
			this.append(mensajes[i].getAsunto(), null);
		}
		
		// A�ade comandos
		cmdVer = new Command("Ver", Command.ITEM, 1);
		cmdNueva = new Command("Nueva", Command.SCREEN, 1);
		cmdMem = new Command("Memoria", Command.SCREEN, 1);
		cmdEditar = new Command("Editar", Command.ITEM, 1);
		cmdBorrar = new Command("Borrar", Command.ITEM, 1);
		this.addCommand(cmdVer);
		this.addCommand(cmdMem);
		this.addCommand(cmdNueva);
		this.addCommand(cmdEditar);
		this.addCommand(cmdBorrar);
		this.setCommandListener(this);
	}

	public void commandAction(Command cmd, Displayable disp) {
		if(cmd == List.SELECT_COMMAND || cmd == cmdVer) {
			
			// Elimina una nota
			int indice = this.getSelectedIndex();
			if(indice != -1) {
				VerNota vn = new VerNota(owner, this, mensajes[indice]);
				Display d = Display.getDisplay(owner);
				d.setCurrent(vn);
			} else {
				Alert a = new Alert("Error", "No hay ninguna nota seleccionada", null, AlertType.ERROR);
				Display d = Display.getDisplay(owner);
				d.setCurrent(a, d.getCurrent());
			}
			
		} else if(cmd == cmdMem) {

			// Muestra informacion sobre la memoria de RMS
			try {
				VerInfo vi = new VerInfo(owner, this, rms);
				Display d = Display.getDisplay(owner);
				d.setCurrent(vi);
			} catch(Exception e) {
				Alert a = new Alert("Error", "No se puede acceder a RMS", null, AlertType.ERROR);
				Display d = Display.getDisplay(owner);
				d.setCurrent(a, d.getCurrent());
			}
			
		} else if(cmd == cmdNueva) {

			// A�ade una nueva nota
			EdicionNota en = new EdicionNota(owner, rms);

			Display d = Display.getDisplay(owner);
			Displayable previo = d.getCurrent();
			d.setCurrent(en);


		} else if(cmd == cmdEditar) {

			// Edita una nota
			int indice = this.getSelectedIndex();
			if(indice != -1) {

				EdicionNota en = new EdicionNota(owner, rms, mensajes[indice]);

				Display d = Display.getDisplay(owner);
				Displayable previo = d.getCurrent();
				d.setCurrent(en);

			} else {
				Alert a = new Alert("Error", "No hay ninguna nota seleccionada", null, AlertType.ERROR);
				Display d = Display.getDisplay(owner);
				d.setCurrent(a, d.getCurrent());
			}
			
		} else if(cmd == cmdBorrar) {

			// Elimina una nota
			int indice = this.getSelectedIndex();
			if(indice != -1) {
				Thread t = new Thread(new EliminaNota(mensajes[indice]));
				t.start();
			} else {
				Alert a = new Alert("Error", "No hay ninguna nota seleccionada", null, AlertType.ERROR);
				Display d = Display.getDisplay(owner);
				d.setCurrent(a, d.getCurrent());
			}
		}
	}

	// Abre la pantalla de confirmacion para la eliminacion

	class EliminaNota implements Runnable {

		Mensaje msg;

		public EliminaNota(Mensaje msg) {
			this.msg = msg;
		}

		public void run() {
			Confirmacion c = new Confirmacion(owner, "Se va a eliminar la nota " + msg.getAsunto() + ", �esta seguro?");

			Display d = Display.getDisplay(owner);
			d.setCurrent(c);

			if(c.acepta()) {
				try {
					rms.removeMensaje(msg.getRmsID());
				} catch(Exception e) {
					Alert a = new Alert("Error", "No se puede eliminar", null, AlertType.ERROR);
					d.setCurrent(a, new ListaNotas(owner, rms));
					return;					
				}
				
			}

			d.setCurrent(new ListaNotas(owner, rms));
		}
	}

}
