package es.ua.jtech.ctj.sesion14.bt;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Vector;

import javax.bluetooth.DeviceClass;
import javax.bluetooth.DiscoveryAgent;
import javax.bluetooth.DiscoveryListener;
import javax.bluetooth.LocalDevice;
import javax.bluetooth.RemoteDevice;
import javax.bluetooth.ServiceRecord;
import javax.bluetooth.UUID;
import javax.microedition.io.Connector;
import javax.microedition.io.StreamConnection;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.StringItem;

public class FormMaestro extends Form implements CommandListener, DiscoveryListener, Runnable {

	MIDletBT owner;

	Vector remoteDevices = new Vector();
	Vector remoteServices = new Vector();
	
	Command cmdConecta;
	
	public FormMaestro(MIDletBT owner) {
		super("Buscar esclavos");

		this.owner = owner;

		this.setCommandListener(this);
		
		cmdConecta = new Command("Conectar", Command.SCREEN, 1);
		
		Thread ts = new Thread(this);
		ts.start();
	}

	public void commandAction(Command cmd, Displayable disp) {
		if(cmd==cmdConecta) {
			
			// Conecta con el primer servicio encontrado
			
			Thread t = new Thread() {
				public void run() {
					ServiceRecord rs = (ServiceRecord)remoteServices.elementAt(0);
					String url = rs.getConnectionURL(ServiceRecord.NOAUTHENTICATE_NOENCRYPT,true);

					try {
						StreamConnection sc = (StreamConnection)Connector.open(url);

						DataInputStream dis = sc.openDataInputStream();
						DataOutputStream dos = sc.openDataOutputStream();
						
						String cadena = dis.readUTF();
						append(new StringItem("Leido: ", cadena));
						sc.close();
					} catch (IOException e) {
						append("Error al conectar");
					}					
				}
			};
			t.start();
		}
	}

	public synchronized void run() {
		
		try {
			LocalDevice ld = LocalDevice.getLocalDevice();
			DiscoveryAgent da = ld.getDiscoveryAgent();
			da.startInquiry(DiscoveryAgent.GIAC, this);

			wait();

			for(int i=0;i<remoteDevices.size();i++) {
				this.append("Servicios de " + i);
				da.searchServices(null,new UUID[]{new UUID(MIDletBT.UUID,false)},(RemoteDevice)remoteDevices.elementAt(i),this);

				wait();
			}

			this.append("Completado");

			this.addCommand(cmdConecta);
			
		} catch(Exception e) {
			this.append("Error: " + e.getMessage());
		}
		
	}
	
	public void deviceDiscovered(RemoteDevice rd, DeviceClass dc) {
		String bt_addr = rd.getBluetoothAddress();
		this.append(new StringItem("Encontrado:", bt_addr));

		remoteDevices.addElement(rd);
	}

	public synchronized void inquiryCompleted(int arg0) {
		this.append("Busqueda de dispositivos completada");
		notify();
	}

	public void servicesDiscovered(int transID, ServiceRecord[] servicios) {
		for(int i=0;i<servicios.length;i++) {
			String url = servicios[i].getConnectionURL(ServiceRecord.NOAUTHENTICATE_NOENCRYPT, true);
			this.append(new StringItem("Servicio: ", url));

			remoteServices.addElement(servicios[i]);
		}
	}

	public synchronized void serviceSearchCompleted(int arg0, int arg1) {
		this.append("Busqueda de servicios completada");
		notify();
	}

}