package es.ua.jtech.sesion3;
public class Ej3 implements Runnable {
	// Hilo actual

	Thread t;

	public Ej3() {

		// Crea primer hilo

		t = new Thread(this);
		t.start();

		// Duerme durante 5 segundos

		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
		}

		// Crea segundo hilo

		t = new Thread(this);
		t.start();

		// Duerme durante 5 segundos

		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
		}

		// Destruye hilo

		t = null;
	}

	public void run() {

		// Toma el tiempo inicial (en ms)

		long ini = System.currentTimeMillis();

		while (t == Thread.currentThread()) {

			System.out.println("Ejecutando (" + ini + ") ");

			// Dormir el hilo 100ms

			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
			}
		}

		System.out.println("Finalizando hilo (" + ini + ")");
	}

	public static void main(String[] args) {
		new Ej3();
	}
}