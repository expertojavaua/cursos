package es.ua.jtech.ctj.sesion10.midlet;

import javax.microedition.lcdui.Canvas;
import javax.microedition.lcdui.Graphics;

public class CanvasDibujo extends Canvas {

	String texto = "Hola mundo!";
	int x = 80;
	int y = 80;
	
	protected void paint(Graphics g) {
		// Dibuja rectangulo blanco como fondo
		g.setColor(0xffffff);
		g.fillRect(0, 0, this.getWidth(), this.getHeight());
		
		// Dibuja rectangulo rojo
		g.setColor(0xff0000);
		g.fillRect(x,y,40,40);
		
		// Dibuja texto
		g.setColor(0x000000);
		g.drawString(texto, x, y, Graphics.LEFT | Graphics.BASELINE);
	}

}
