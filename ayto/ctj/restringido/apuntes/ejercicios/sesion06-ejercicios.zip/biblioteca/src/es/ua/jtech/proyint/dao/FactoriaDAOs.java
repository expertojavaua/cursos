package es.ua.jtech.proyint.dao;

import es.ua.jtech.proyint.dao.libro.ILibroDAO;
import es.ua.jtech.proyint.dao.libro.LibroJDBCDAO;
import es.ua.jtech.proyint.dao.operacion.IOperacionDAO;
import es.ua.jtech.proyint.dao.operacion.OperacionJDBCDAO;
import es.ua.jtech.proyint.dao.usuario.IUsuarioDAO;
import es.ua.jtech.proyint.dao.usuario.UsuarioJDBCDAO;

public class FactoriaDAOs {
	
	private static FactoriaDAOs me = new FactoriaDAOs();

	private FactoriaDAOs() {
	}

	public static FactoriaDAOs getInstance() {
		return me;
	}

	public IUsuarioDAO getUsuarioDAO() {
		return new UsuarioJDBCDAO();
	}

	public ILibroDAO getLibroDAO() {
		return new LibroJDBCDAO();
	}

	public IOperacionDAO getOperacionDAO() {
		return new OperacionJDBCDAO();
	}
}
