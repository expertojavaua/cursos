package es.ua.jtech.proyint.dao.operacion;

import java.sql.Connection;
import java.util.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;


import es.ua.jtech.proyint.dao.DAOException;
import es.ua.jtech.proyint.dao.FactoriaFuenteDatos;
import es.ua.jtech.proyint.to.EstadoUsuario;
import es.ua.jtech.proyint.to.LibroTO;
import es.ua.jtech.proyint.to.TipoOperacion;
import es.ua.jtech.proyint.to.UsuarioTO;

/**
 * Implementaci�n JDBC del DAO Operacion
 * @author Miguel
 */
public class OperacionJDBCDAO implements IOperacionDAO {
	
	public boolean realizaReserva (UsuarioTO usuario, LibroTO libro,
			Date finicio, Date ffin) throws DAOException {
		Connection conn = null;
		PreparedStatement st = null, stUsu=null;

		try {
			java.sql.Date date1=new java.sql.Date(finicio.getTime());
			java.sql.Date date2=new java.sql.Date(ffin.getTime());
			String insert = "insert into operacion(idoperacion, login, " +
					"isbn, tipoOperacion, finicio, ffin) values (null, ?, " +
					"?, ?, ?, ?)";
			String modUsuario = "update usuario set estadoUsuario=? where login=? ";
			
			conn = FactoriaFuenteDatos.getInstance().createConnection();
			st = conn.prepareStatement(insert);
			st.setString(1, usuario.getLogin());
			st.setString(2, libro.getIsbn());
			st.setString(3, TipoOperacion.reserva.toString());
			st.setString(4, date1.toString());
			st.setString(5, date2.toString());
			stUsu = conn.prepareStatement(modUsuario);
			stUsu.setString(1, EstadoUsuario.reserva.toString());
			stUsu.setString(2, usuario.getLogin());
			conn.setAutoCommit(false);
			st.executeUpdate();
			stUsu.executeUpdate();
			conn.commit();
		} catch (SQLException sqle) {
			try {
				conn.rollback();
			} catch (SQLException e) {
				throw new RuntimeException("Error haciendo rollback", e);
			}
			throw new DAOException("Error en el update de operacion", sqle);
		} finally {
			try {
				if (st != null) {
					st.close();
					st = null;
				}
				if (stUsu != null) {
					stUsu.close();
					stUsu = null;
				}
				if (conn != null) {
					conn.close();
					conn = null;
				}
			} catch (SQLException sqlError) {
				throw new RuntimeException("Error cerrando las conexiones", sqlError);
			}
		}
		return true;
	}
}

