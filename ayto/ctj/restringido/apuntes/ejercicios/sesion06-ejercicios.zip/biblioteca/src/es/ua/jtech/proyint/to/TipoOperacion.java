package es.ua.jtech.proyint.to;

/**
 * Enumeracion con los posibles tipos de operaciones
 * @author $Author$
 * @version $Revision$
 */
public enum TipoOperacion {
	reserva, prestamo, multa
}
