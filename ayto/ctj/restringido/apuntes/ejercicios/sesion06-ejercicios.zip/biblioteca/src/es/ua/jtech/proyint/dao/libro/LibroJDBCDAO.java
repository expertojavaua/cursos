package es.ua.jtech.proyint.dao.libro;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import es.ua.jtech.proyint.dao.DAOException;
import es.ua.jtech.proyint.dao.FactoriaFuenteDatos;
import es.ua.jtech.proyint.to.LibroTO;

/**
 * Implementaci�n JDBC del DAO Libro
 * @author Miguel
 *
 */
public class LibroJDBCDAO implements ILibroDAO {
	
	private static Log logger = LogFactory.getLog(LibroJDBCDAO.class.getName());

	/** 
	 * M�todo para seleccionar el libro cuyo Isbn se pasa por par�metro.
	 * @see es.ua.jtech.proyint.dao.libro.ILibroDAO#selectLibro(java.lang.String)
	 */
	public LibroTO selectLibro(String isbn) throws DAOException {
		LibroTO libro = null;

		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;

		try {
			String query = "select * from LIBRO where ISBN = ?";
			
			if (logger.isDebugEnabled()) {
				logger.debug(query + " [isbn=" + isbn + "]");
			}

			conn = FactoriaFuenteDatos.getInstance().createConnection();
			st = conn.prepareStatement(query);
			st.setString(1, isbn);
			rs=st.executeQuery();

			if (rs.next()) {
				libro = new LibroTO();
				libro.setIsbn(isbn);
				libro.setTitulo(rs.getString("titulo"));
				libro.setAutor(rs.getString("autor"));
				libro.setNumPaginas(rs.getInt("numPaginas"));
			}
		} catch (SQLException sqle) {
			throw new DAOException("Error en el select de libro", sqle);
		} finally {
			try {
				if (rs != null) {
					rs.close();
					rs = null;
				}
				if (st != null) {
					st.close();
					st = null;
				}
				if (conn != null) {
					conn.close();
					conn = null;
				}
			} catch (SQLException sqlError) {
				throw new RuntimeException("Error cerrando las conexiones", sqlError);
			}
		}

		return libro;
	}
	
	public void addLibro (LibroTO libro) throws DAOException {
		Connection conn = null;
		PreparedStatement st = null;

		try {
			String insert = "insert into libro(isbn, titulo, " +
					"autor, numPaginas) values (?, ?, ?, ?)";
			
			conn = FactoriaFuenteDatos.getInstance().createConnection();
			st = conn.prepareStatement(insert);
			st.setString(1, libro.getIsbn());
			st.setString(2, libro.getTitulo());
			st.setString(3, libro.getAutor());
			st.setInt(4, libro.getNumPaginas());
			st.executeUpdate();
		} catch (SQLException sqle) {
			throw new DAOException("Error en el update de libro", sqle);
		} finally {
			try {
				if (st != null) {
					st.close();
					st = null;
				}
				if (conn != null) {
					conn.close();
					conn = null;
				}
			} catch (SQLException sqlError) {
				throw new RuntimeException("Error cerrando las conexiones", sqlError);
			}
		}
	}
	
	public int delLibro (LibroTO libro) throws DAOException {
		Connection conn = null;
		PreparedStatement st = null;
		int numDel=0;
		
		try {			
			String delete = "delete from libro where isbn=?";
			
			conn = FactoriaFuenteDatos.getInstance().createConnection();
			st = conn.prepareStatement(delete);
			st.setString(1, libro.getIsbn());
			numDel=st.executeUpdate();
		} catch (SQLException sqle) {
			throw new DAOException("Error en el delete de libro", sqle);
		} finally {
			try {
				if (st != null) {
					st.close();
					st = null;
				}
				if (conn != null) {
					conn.close();
					conn = null;
				}
			} catch (SQLException sqlError) {
				throw new RuntimeException("Error cerrando las conexiones", sqlError);
			}
		}
		return numDel;
	}
	
	public List<LibroTO> getAllLibros () throws DAOException {
		Connection conn=null;
		Statement st=null;
		ResultSet rs=null;
		List<LibroTO> al=null;
		
		try {
			conn = FactoriaFuenteDatos.getInstance().createConnection();
			st = conn.createStatement();
			rs = st.executeQuery("select * from libro");
			al = new ArrayList<LibroTO>();
			LibroTO lib=null;
			while (rs.next()) {
				lib = new LibroTO(rs.getString("isbn"), 
						rs.getString("titulo"), rs.getString("autor"),
						rs.getInt("numPaginas"));
				al.add(lib);
			}
		} catch (SQLException sqle) {
			throw new DAOException("Error en el select de libro", sqle);
		} finally {
			try {
				if (rs != null) {
					rs.close();
					rs = null;
				}
				if (st != null) {
					st.close();
					st = null;
				}
				if (conn != null) {
					conn.close();
					conn = null;
				}
			} catch (SQLException sqlError) {
				throw new RuntimeException("Error cerrando las conexiones", sqlError);
			}
		}
		return al;
	}
}
