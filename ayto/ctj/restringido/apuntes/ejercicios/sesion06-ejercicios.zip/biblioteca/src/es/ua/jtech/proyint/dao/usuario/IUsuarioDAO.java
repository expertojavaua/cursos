package es.ua.jtech.proyint.dao.usuario;

import java.util.List;

import es.ua.jtech.proyint.dao.DAOException;
import es.ua.jtech.proyint.to.UsuarioTO;

/**
 * Interface para el DAO Usuario
 * @author Miguel
 */
public interface IUsuarioDAO {
	
	/**
	 * Selecciona un usuario, comprobando su contrase�a
	 * @param login Login del usuario a seleccionar
	 * @param password Contrase�a �dem
	 * @return El usuario seleccionado o null si no existe
	 * @throws DAOException
	 */
	UsuarioTO selectUsuario(String login, String password) throws DAOException;
	/**
	 * A�ade un usuario a la BD
	 * @param usuario Usuario a a�adir en la BD
	 * @throws DAOException
	 */
	void addUsuario(UsuarioTO usuario) throws DAOException;
	/**
	 * Borra el usuario de la BD
	 * @param usuario Usuario a eliminar
	 * @return N�mero de registros afectados en el borrado
	 * @throws DAOException
	 */
	int delUsuario(UsuarioTO usuario) throws DAOException;
	/**
	 * Devuelve una lista con todos los usuarios en la BD
	 * @return Lista con todos los usuarios
	 * @throws DAOException
	 */
	List<UsuarioTO> getAllUsuarios() throws DAOException;
}
