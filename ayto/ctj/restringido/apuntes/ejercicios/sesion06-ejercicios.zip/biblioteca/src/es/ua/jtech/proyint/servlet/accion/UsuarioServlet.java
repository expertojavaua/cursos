package es.ua.jtech.proyint.servlet.accion;

import java.io.*;
import java.util.List;

import javax.servlet.*;
import javax.servlet.http.*;

import org.apache.commons.logging.*;

import es.ua.jtech.proyint.dao.*;
import es.ua.jtech.proyint.dao.usuario.*;
import es.ua.jtech.proyint.to.*;

 public class UsuarioServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {

	private static final long serialVersionUID = 6158132279964132112L;
	private static Log logger = LogFactory.getLog(UsuarioServlet.class.getName());

	public UsuarioServlet() {
		super();
	}   	
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String parAccion = request.getParameter("accion");
		
		if ("listar".equals(parAccion)) {
			
			// Listado de usuarios
			if(!compruebaPermisos(request, TipoUsuario.administrador)) {
				request.setAttribute("error", "Se necesita ser administrador para obtener el listado de usuarios");
				doForward(request, response, "/jsp/error.jsp");
			} else { 
				listaUsuarios(request, response);			
			}

		} else if ("seleccionar".equals(parAccion)) {
			
			// Seleccion de un usuario
			if(!compruebaPermisos(request, TipoUsuario.administrador)) {
				request.setAttribute("error", "Se necesita ser administrador para ver los datos de un usuario");
				doForward(request, response, "/jsp/error.jsp");
			} else { 
				seleccionaUsuario(request, response);			
			}

		} else if ("insertar".equals(parAccion)) {
			
			// Insercion de un usuario
			if(!compruebaPermisos(request, TipoUsuario.administrador)) {
				request.setAttribute("error", "Se necesita ser administrador para dar de alta un usuario");
				doForward(request, response, "/jsp/error.jsp");
			} else { 
				insertaUsuario(request, response);			
			}

		} else if ("borrar".equals(parAccion)) {
			
			// Borrado de un usuario
			if(!compruebaPermisos(request, TipoUsuario.administrador)) {
				request.setAttribute("error", "Se necesita ser administrador para dar de baja un usuario");
				doForward(request, response, "/jsp/error.jsp");
			} else { 
				borraUsuario(request, response);			
			}
		} else {
			generaPagina("<h2>Comando no valido</h2>", response);
		}
	}  	
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request, response);
	}   

	/* Metodo privado para sacar el listado de usuarios */
	private void listaUsuarios(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		FactoriaDAOs fd = FactoriaDAOs.getInstance();
		IUsuarioDAO iu = fd.getUsuarioDAO();
		List<UsuarioTO> lista = null;
		try
		{
			lista = iu.getAllUsuarios();
			if (lista != null)
			{
				request.setAttribute("lista", lista);
				this.doForward(request, response, "/jsp/listadoUsuarios.jsp");
				logger.info("Usuarios - listar - Listado servido correctamente");
				return;
			} else {
				request.setAttribute("error", "No se encontraron resultados");
				this.doForward(request, response, "/jsp/error.jsp");
				logger.warn("Usuarios - listar - No se encontraron resultados");
			}
		} catch (Exception ex) {
			request.setAttribute("error", "Error recuperando listado");
			this.doForward(request, response, "/jsp/error.jsp");
			logger.error("Usuarios - listar - Error recuperando listado");
			return;
		}
		
	}

	/* Metodo privado para seleccionar un usuario dado su login y password en el request */
	private void seleccionaUsuario(HttpServletRequest request, HttpServletResponse response)
	{
		if (request.getParameter("login") == null || request.getParameter("password") == null)
		{
			generaPagina("<h2>Falta login y/o password</h2>", response);
			logger.error("Usuarios - seleccionar - Falta login y/o password");
			return;
		}
		String contenido = "";
		FactoriaDAOs fd = FactoriaDAOs.getInstance();
		IUsuarioDAO iu = fd.getUsuarioDAO();
		UsuarioTO usu = null;
		try
		{
			usu = iu.selectUsuario(request.getParameter("login"), request.getParameter("password"));
			if (usu != null)
			{
				contenido += "Datos del usuario: " + usu.getLogin() + "-" + usu.getPassword() + "-" + usu.getNombre() + "-" + usu.getApellido1() + " - " + usu.getApellido2() + " - " + usu.getTipo() + " - " + usu.getEstado();
				generaPagina(contenido, response);
				logger.info("Usuario - seleccionar - " + usu.getLogin() + " - Datos servidos correctamente");
				return;
			} else {
				generaPagina("<h2>No se encontraron resultados</h2>", response);
				logger.warn("Usuarios - seleccionar - " + request.getParameter("login") + " - No se encontraron resultados");
			}
		} catch (Exception ex) {
			generaPagina("<h2>Error recuperando usuario</h2>", response);
			logger.error("Usuarios - seleccionar - " + request.getParameter("login") + " - Error recuperando usuario");
			return;
		}
	}

	/* Metodo privado para insertar un usuario, dados sus datos en el request */
	private void insertaUsuario(HttpServletRequest request, HttpServletResponse response)
	{
		if (request.getParameter("login") == null || request.getParameter("password") == null)
		{
			generaPagina("<h2>Falta login y/o password</h2>", response);
			logger.error("Usuarios - insertar - Falta login y/o password");
			return;
		}
		String nombre = request.getParameter("nombre") != null?request.getParameter("nombre"):"";
		String apellido1 = request.getParameter("apellido1") != null?request.getParameter("apellido1"):"";
		String apellido2 = request.getParameter("apellido2") != null?request.getParameter("apellido2"):"";
		TipoUsuario tipo = null;
		String parTipo = request.getParameter("tipo");
		if ("administrador".equals(parTipo))
		{
			tipo = TipoUsuario.administrador;
		} else if ("bibliotecario".equals(parTipo)) {
			tipo = TipoUsuario.bibliotecario;
		} else if ("socio".equals(parTipo)) {
			tipo = TipoUsuario.socio;
		} else {
			tipo = TipoUsuario.profesor;
		}
		EstadoUsuario estado = null;
		String parEstado = request.getParameter("estado");
		if ("baja".equals(parEstado))
		{
			estado = EstadoUsuario.baja;
		} else if ("activo".equals(parEstado)) {
			estado = EstadoUsuario.activo;
		} else if ("reserva".equals(parEstado)) {
			estado = EstadoUsuario.reserva;
		} else if ("moroso".equals(parEstado)) {
			estado = EstadoUsuario.moroso;
		} else {
			estado = EstadoUsuario.prestamo;
		}
		
		FactoriaDAOs fd = FactoriaDAOs.getInstance();
		IUsuarioDAO iu = fd.getUsuarioDAO();
		UsuarioTO usu = new UsuarioTO(request.getParameter("login"), request.getParameter("password"), nombre, apellido1, apellido2, tipo, estado);
		try
		{
			iu.addUsuario(usu);
			generaPagina("<h2>Operacion realizada</h2>", response);
			logger.info("Usuarios - insertar - " + request.getParameter("login") + " - Insercion realizada");
		} catch (Exception ex) {
			generaPagina("<h2>Error insertando usuario</h2>", response);
			logger.error("Usuarios - insertar - " + request.getParameter("login") + " - Error en la insercion");
			return;
		}
	}
	
	/* Metodo privado para borrar un usuario, dados su login y password en el request */
	private void borraUsuario(HttpServletRequest request, HttpServletResponse response)
	{
		if (request.getParameter("login") == null || request.getParameter("password") == null)
		{
			generaPagina("<h2>Falta login y/o password</h2>", response);
			logger.error("Usuarios - borrar - Falta login y/o password");
			return;
		}
		FactoriaDAOs fd = FactoriaDAOs.getInstance();
		IUsuarioDAO iu = fd.getUsuarioDAO();
		UsuarioTO usu = null;
		try
		{
			usu = iu.selectUsuario(request.getParameter("login"), request.getParameter("password"));
		} catch (Exception ex) {
			logger.error("Usuarios - borrar - " + request.getParameter("login") + " - Error obteniendo usuario");
			generaPagina("<h2>Error obteniendo usuario</h2>", response);
			return;
		}
		if (usu == null)
		{
			logger.error("Usuarios - borrar - " + request.getParameter("login") + " - Error obteniendo usuario");
			generaPagina("<h2>Error obteniendo usuario</h2>", response);
			return;
		} else {
			try
			{
				iu.delUsuario(usu);
				logger.info("Usuarios - borrar - " + request.getParameter("login") + " - Borrado realizado");
				generaPagina("<h2>Operacion realizada</h2>", response);
			} catch (Exception ex) {
				logger.error("Usuarios - borrar - " + request.getParameter("login") + " - Error borrando usuario");
				generaPagina("<h2>Error borrando usuario</h2>", response);
				return;
			}
		}
	}
	
	private void doForward(HttpServletRequest request, HttpServletResponse response, String path) throws ServletException, IOException {
		ServletContext sc = this.getServletContext();
		RequestDispatcher rd = sc.getRequestDispatcher(path);
		rd.forward(request, response);
	}
	
	private boolean compruebaPermisos(HttpServletRequest request, TipoUsuario tipo) {
		HttpSession sesion = request.getSession();
		UsuarioTO usuario = (UsuarioTO)sesion.getAttribute("usuario");
		
		if(usuario==null) {
			return false;
		} else {
			return usuario.getTipo()==tipo;
		}
	}

	private void generaPagina(String mensaje, HttpServletResponse res)
	{
		try
		{
			PrintWriter writer = res.getWriter();
			writer.println("<html><body>"+mensaje+"</body></html>");
			writer.close();
		} catch (Exception ex) { 
			try
			{
				res.sendError(500, "Error generando la pagina"); 
			} catch (Exception ex2) {}
		}
	}
	
}