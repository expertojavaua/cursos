package es.ua.jtech.proyint.to;

/**
 * Enumeracion con los posibles estados de un usuario
 * @author $Author$
 * @version $Revision$
 */
public enum EstadoUsuario {
	baja, activo, reserva, prestamo, moroso
}
