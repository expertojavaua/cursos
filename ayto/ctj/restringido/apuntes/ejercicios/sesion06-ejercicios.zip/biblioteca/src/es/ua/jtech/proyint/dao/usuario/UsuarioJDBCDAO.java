package es.ua.jtech.proyint.dao.usuario;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import es.ua.jtech.proyint.dao.DAOException;
import es.ua.jtech.proyint.dao.FactoriaFuenteDatos;
import es.ua.jtech.proyint.to.EstadoUsuario;
import es.ua.jtech.proyint.to.TipoUsuario;
import es.ua.jtech.proyint.to.UsuarioTO;

/**
 * Implementaci�n JDBC del DAO Usuario
 * @author Miguel
 */
public class UsuarioJDBCDAO implements IUsuarioDAO {
	
	private static Log logger = LogFactory.getLog(UsuarioJDBCDAO.class.getName());

	public UsuarioTO selectUsuario(String login, String password) throws DAOException {
		UsuarioTO usuario = null;
		Connection conn = null;
		PreparedStatement st = null;
		ResultSet rs = null;

		try {
			String query = "select * from USUARIO where LOGIN = ? and PASSWORD = ?";
			
			if (logger.isDebugEnabled()) {
				logger.debug(query + " [login=" + login + ",password=" + password + "]");
			}

			conn = FactoriaFuenteDatos.getInstance().createConnection();

			st = conn.prepareStatement(query);
			st.setString(1, login);
			st.setString(2, password);
			rs = st.executeQuery();

			if (rs.next()) {
				usuario = new UsuarioTO();
				usuario.setLogin(login);
				usuario.setPassword(password);
				usuario.setNombre(rs.getString("nombre"));
				usuario.setApellido1(rs.getString("apellido1"));
				usuario.setApellido2(rs.getString("apellido2"));
				usuario.setEstado(Enum.valueOf(EstadoUsuario.class, rs.getString("estadoUsuario")));
				usuario.setTipo(Enum.valueOf(TipoUsuario.class, rs.getString("tipoUsuario")));
			}
		} catch (SQLException sqle) {
			throw new DAOException("Error en el select de usuario", sqle);
		} finally {
			try {
				if (rs != null) {
					rs.close();
					rs = null;
				}
				if (st != null) {
					st.close();
					st = null;
				}
				if (conn != null) {
					conn.close();
					conn = null;
				}
			} catch (SQLException sqlError) {
				throw new RuntimeException("Error cerrando las conexiones", sqlError);
			}
		}

		return usuario;
	}
	
	public void addUsuario (UsuarioTO usuario) throws DAOException {
		Connection conn = null;
		PreparedStatement st = null;

		try {
			String insert = "insert into usuario(login, password, " +
					"nombre, apellido1, apellido2, tipoUsuario, " +
					"estadoUsuario) values (?, ?, ?, ?, ?, ?, ?)";
			
			conn = FactoriaFuenteDatos.getInstance().createConnection();
			st = conn.prepareStatement(insert);
			st.setString(1, usuario.getLogin());
			st.setString(2, usuario.getPassword());
			st.setString(3, usuario.getNombre());
			st.setString(4, usuario.getApellido1());
			st.setString(5, usuario.getApellido2());
			st.setString(6, usuario.getTipo().toString());
			st.setString(7, usuario.getEstado().toString());
			st.executeUpdate();
		} catch (SQLException sqle) {
			throw new DAOException("Error en el update de usuario", sqle);
		} finally {
			try {
				if (st != null) {
					st.close();
					st = null;
				}
				if (conn != null) {
					conn.close();
					conn = null;
				}
			} catch (SQLException sqlError) {
				throw new RuntimeException("Error cerrando las conexiones", sqlError);
			}
		}
	}
	
	public int delUsuario (UsuarioTO usuario) throws DAOException {
		Connection conn = null;
		PreparedStatement st = null;
		int numDel=0;
		
		try {
			String delete = "delete from usuario where login=?";
			
			conn = FactoriaFuenteDatos.getInstance().createConnection();
			st = conn.prepareStatement(delete);
			st.setString(1, usuario.getLogin());
			numDel=st.executeUpdate();
		} catch (SQLException sqle) {
			throw new DAOException("Error en el delete de usuario", sqle);
		} finally {
			try {
				if (st != null) {
					st.close();
					st = null;
				}
				if (conn != null) {
					conn.close();
					conn = null;
				}
			} catch (SQLException sqlError) {
				throw new RuntimeException("Error cerrando las conexiones", sqlError);
			}
		}
		return numDel;
	}
	
	public List<UsuarioTO> getAllUsuarios () throws DAOException {
		Connection conn=null;
		Statement st=null;
		ResultSet rs=null;
		List<UsuarioTO> al=null;
		
		try {
			conn = FactoriaFuenteDatos.getInstance().createConnection();
			st = conn.createStatement();
			rs = st.executeQuery("select * from usuario");
			al = new ArrayList<UsuarioTO>();
			UsuarioTO usu=null;
			while (rs.next()) {
				usu = new UsuarioTO(rs.getString("login"), 
						rs.getString("password"), rs.getString("nombre"),
						rs.getString("apellido1"), rs.getString("apellido2"),
						Enum.valueOf(TipoUsuario.class, rs.getString("tipoUsuario")),
						Enum.valueOf(EstadoUsuario.class, rs.getString("estadoUsuario")));
				al.add(usu);
			}
		} catch (SQLException sqle) {
			throw new DAOException("Error en el select de usuario", sqle);
		} finally {
			try {
				if (rs != null) {
					rs.close();
					rs = null;
				}
				if (st != null) {
					st.close();
					st = null;
				}
				if (conn != null) {
					conn.close();
					conn = null;
				}
			} catch (SQLException sqlError) {
				throw new RuntimeException("Error cerrando las conexiones", sqlError);
			}
		}
		return al;
	}
}
