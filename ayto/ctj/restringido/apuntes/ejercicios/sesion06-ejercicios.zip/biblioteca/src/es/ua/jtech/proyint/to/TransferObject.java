package es.ua.jtech.proyint.to;

import java.io.Serializable;

import org.apache.commons.lang.builder.ToStringBuilder;

public abstract class TransferObject implements Serializable {
	
	// crea un nuevo TO a partir de los datos del objeto
	public abstract TransferObject getData();
	
	public String toString() {
		// libreria commons-lang de jakarta
		return ToStringBuilder.reflectionToString(this);
	}
	
}
