package es.ua.jtech.proyint.servlet.accion;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import es.ua.jtech.proyint.dao.FactoriaDAOs;
import es.ua.jtech.proyint.dao.usuario.IUsuarioDAO;
import es.ua.jtech.proyint.to.UsuarioTO;

/**
 * Servlet implementation class for Servlet: LoginServlet
 *
 */
 public class LoginServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {

	private static final long serialVersionUID = -1859584491132060195L;
	private static Log logger = LogFactory.getLog(LoginServlet.class.getName());

	public LoginServlet() {
		super();
	}   	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String login = request.getParameter("login");
		String password = request.getParameter("password");

		HttpSession sesion = request.getSession();
		
		FactoriaDAOs fd = FactoriaDAOs.getInstance();
		IUsuarioDAO iu = fd.getUsuarioDAO();
		try {
			UsuarioTO usuario = iu.selectUsuario(login, password);
			if(usuario!=null) {
				sesion.setAttribute("usuario", usuario);
				doForward(request, response, "/jsp/menu.jsp");
			} else {
				request.setAttribute("error", "El login y/o password no son correctos");
				doForward(request, response, "/index.jsp");				
			}
		} catch (Exception e) {
			logger.error("Login - " + request.getParameter("login") + " - Error haciendo login");
			request.setAttribute("error", "Error al hacer login");
			doForward(request, response, "/index.jsp");
		}
	}  	
	
	private void doForward(HttpServletRequest request, HttpServletResponse response, String path) throws ServletException, IOException {
		ServletContext sc = this.getServletContext();
		RequestDispatcher rd = sc.getRequestDispatcher(path);
		rd.forward(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doGet(request, response);
	}   	  	    
}