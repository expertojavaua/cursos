package es.ua.jtech.proyint.to;

/**
 * Clase que representa un libro. Destacar que la app no permite 2 ejemplares de
 * un mismo libro
 * 
 * @author $Author$
 * @version $Revision$
 */
public class LibroTO extends TransferObject {

	private static final long serialVersionUID = 5874144497759547336L;

	private String isbn;
	private String titulo;
	private String autor;
	private int numPaginas;

	public LibroTO() {
		super();
	}

	public LibroTO(String isbn, String titulo, String autor, int numPaginas) {
		super();
		this.init(isbn, titulo, autor, numPaginas);

	}

	public LibroTO(LibroTO libro) {
		super();
		this.init(libro.isbn, libro.titulo, libro.autor, libro.numPaginas);
	}

	private void init(String isbn, String titulo, String autor, int numPaginas) {
		this.isbn = isbn;
		this.titulo = titulo;
		this.autor = autor;
		this.numPaginas = numPaginas;
	}

	@Override
	public LibroTO getData() {
		return new LibroTO(this);
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public int getNumPaginas() {
		return numPaginas;
	}

	public void setNumPaginas(int numPaginas) {
		this.numPaginas = numPaginas;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

}
