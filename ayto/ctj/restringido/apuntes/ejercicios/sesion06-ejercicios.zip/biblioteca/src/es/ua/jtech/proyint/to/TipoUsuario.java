package es.ua.jtech.proyint.to;

/**
 * Enumeracion con los posibles tipos de usuarios
 * @author $Author$
 * @version $Revision$
 */
public enum TipoUsuario {
	administrador, bibliotecario, socio, profesor

}
