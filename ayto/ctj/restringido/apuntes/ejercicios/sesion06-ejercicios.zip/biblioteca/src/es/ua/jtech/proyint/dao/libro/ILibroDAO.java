package es.ua.jtech.proyint.dao.libro;

import java.util.List;

import es.ua.jtech.proyint.dao.DAOException;
import es.ua.jtech.proyint.to.LibroTO;

/**
 * Interface para el DAO Libro
 * @author Miguel
 *
 */
public interface ILibroDAO {

	/**
	 * Selecciona un libro de la BD
	 * @param isbn Isbn del libro a seleccionar
	 * @return Libro seleccionado
	 * @throws DAOException
	 */
	LibroTO selectLibro(String isbn) throws DAOException;

	/**
	 * A�ade un libro en la BD
	 * @param libro Libro a a�adir.
	 * @throws DAOException
	 */
	void addLibro(LibroTO libro) throws DAOException;

	/**
	 * El libro pasado por par�metro es borrado de la BD
	 * @param libro Libro a eliminar
	 * @return N�mero de registros afectados por el borrado
	 * @throws DAOException
	 */
	int delLibro(LibroTO libro) throws DAOException;

	/**
	 * Devuelve una lista con todos los libros en la BD
	 * @return Lista con todos los libros
	 * @throws DAOException
	 */
	List<LibroTO> getAllLibros() throws DAOException;
}