package es.ua.jtech.proyint.to;

/**
 * Clase que define un Usuario
 * 
 * @author $Author$
 * @version $Revision$
 */
public class UsuarioTO extends TransferObject {

	private static final long serialVersionUID = 2101518489212202517L;

	private String login;

	private String password;

	private String nombre;

	private String apellido1;

	private String apellido2;

	private String email;

	private TipoUsuario tipo;

	private EstadoUsuario estado;

	public UsuarioTO() {
		super();
	}

	public UsuarioTO(String login, String password, String nombre,
			String apellido1, String apellido2, TipoUsuario tipo,
			EstadoUsuario estado) {
		super();
		this.init(login, password, nombre, apellido1, apellido2,  tipo,
				estado);
	}

	public UsuarioTO(UsuarioTO usuario) {
		this.init(usuario.login, usuario.password, usuario.nombre,
				usuario.apellido1, usuario.apellido2, 
				usuario.tipo, usuario.estado);
	}

	private void init(String login, String password, String nombre,
			String apellido1, String apellido2, TipoUsuario tipo,
			EstadoUsuario estado) {
		this.login = login;
		this.password = password;
		this.nombre = nombre;
		this.apellido1 = apellido1;
		this.apellido2 = apellido2;
		this.tipo = tipo;
		this.estado = estado;
	}

	@Override
	public UsuarioTO getData() {
		return new UsuarioTO(this);
	}

	public String getApellido1() {
		return apellido1;
	}

	public void setApellido1(String apellido1) {
		this.apellido1 = apellido1;
	}

	public String getApellido2() {
		return apellido2;
	}

	public void setApellido2(String apellido2) {
		this.apellido2 = apellido2;
	}

	public EstadoUsuario getEstado() {
		return estado;
	}

	public void setEstado(EstadoUsuario estado) {
		this.estado = estado;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public TipoUsuario getTipo() {
		return tipo;
	}

	public void setTipo(TipoUsuario tipo) {
		this.tipo = tipo;
	}

	/**
	 * @return Returns the email.
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email The email to set.
	 */
	public void setEmail(String email) {
		this.email = email;
	}

}
