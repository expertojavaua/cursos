package es.ua.jtech.proyint.servlet.accion;

import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

import org.apache.commons.logging.*;

import es.ua.jtech.proyint.dao.*;
import es.ua.jtech.proyint.dao.libro.*;
import es.ua.jtech.proyint.to.*;

/**
 * Servlet implementation class for Servlet: UsuarioServlet
 *
 */
 public class LibroServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {

	private static final long serialVersionUID = 6158132279964132110L;
	private static Log logger = LogFactory.getLog(LibroServlet.class.getName());

	public LibroServlet() {
		super();
	}   	
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String parAccion = request.getParameter("accion");		
		
		if ("listar".equals(parAccion)) {
			
			// Listado de libros
			if(!compruebaPermisos(request, TipoUsuario.profesor) && !compruebaPermisos(request, TipoUsuario.socio) && !compruebaPermisos(request, TipoUsuario.bibliotecario)) {
				request.setAttribute("error", "Se necesita ser profesor, socio o bibliotecario para obtener el listado de libros");
				doForward(request, response, "/jsp/error.jsp");
			} else { 
				listaLibros(request, response);
			}

		} else if ("seleccionar".equals(parAccion)) {
			
			// Seleccion de un libro
			if(!compruebaPermisos(request, TipoUsuario.profesor) && !compruebaPermisos(request, TipoUsuario.socio) && !compruebaPermisos(request, TipoUsuario.bibliotecario)) {
				request.setAttribute("error", "Se necesita ser profesor, socio o bibliotecario para consultar los datos de un libro");
				doForward(request, response, "/jsp/error.jsp");
			} else {
				seleccionaLibro(request, response);
			}

		} else if ("insertar".equals(parAccion)) {
			
			// Insercion de un libro
			if(!compruebaPermisos(request, TipoUsuario.bibliotecario)) {
				request.setAttribute("error", "Se necesita ser bibliotecario para dar de alta nuevos libros");
				doForward(request, response, "/jsp/error.jsp");
			} else {
				insertaLibro(request, response);
			}

		} else if ("borrar".equals(parAccion)) {
			
			// Borrado de un libro
			if(!compruebaPermisos(request, TipoUsuario.bibliotecario)) {
				request.setAttribute("error", "Se necesita ser bibliotecario para dar de baja un libro");
				doForward(request, response, "/jsp/error.jsp");
			} else {
				borraLibro(request, response);
			}
		} else {
			generaPagina("<h2>Comando no valido</h2>", response);
		}
	} 
	
	/* Metodo privado para sacar el listado de libros */
	private void listaLibros(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		FactoriaDAOs fd = FactoriaDAOs.getInstance();
		ILibroDAO il = fd.getLibroDAO();
		List<LibroTO> lista = null;
		try
		{
			lista = il.getAllLibros();
			if (lista != null)
			{
				request.setAttribute("lista", lista);
				this.doForward(request, response, "/jsp/listadoLibros.jsp");
				logger.info("Libros - listar - Listado servido correctamente");
				return;
			} else {
				request.setAttribute("error", "No se encontraron resultados");
				this.doForward(request, response, "/jsp/error.jsp");
				logger.warn("Libros - listar - No se encontraron resultados");
			}
		} catch (Exception ex) {
			request.setAttribute("error", "Error recuperando listado");
			this.doForward(request, response, "/jsp/error.jsp");
			logger.error("Libros - listar - Error recuperando listado");
			return;
		}
		
	}

	/* Metodo privado para seleccionar un libro dado su isbn en el request */
	private void seleccionaLibro(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		if (request.getParameter("isbn") == null)
		{
			request.setAttribute("error", "Falta isbn");
			this.doForward(request, response, "/jsp/error.jsp");
			logger.error("Libros - seleccionar - Falta isbn");
			return;
		}
		FactoriaDAOs fd = FactoriaDAOs.getInstance();
		ILibroDAO il = fd.getLibroDAO();
		LibroTO libro = null;
		try
		{
			libro = il.selectLibro(request.getParameter("isbn"));
			if (libro != null)
			{
				request.setAttribute("libro", libro);
				this.doForward(request, response, "/jsp/datosLibro.jsp");
				logger.info("Libros - seleccionar - " + libro.getIsbn() + " - Datos servidos correctamente");
				return;
			} else {
				request.setAttribute("error", "No se encontraron resultados");
				this.doForward(request, response, "/jsp/error.jsp");
				logger.warn("Libros - seleccionar - " + request.getParameter("isbn") + " - No se encontraron resultados");
			}
		} catch (Exception ex) {
			request.setAttribute("error", "Error recuperando libro");
			this.doForward(request, response, "/jsp/error.jsp");
			logger.error("Libros - seleccionar - " + request.getParameter("isbn") + " - Error recuperando libro");
			return;
		}
	}

	/* Metodo privado para insertar un libro, dados sus datos en el request */
	private void insertaLibro(HttpServletRequest request, HttpServletResponse response)
	{
		if (request.getParameter("isbn") == null)
		{
			generaPagina("<h2>Falta isbn</h2>", response);
			logger.error("Libros - insertar - Falta isbn");
			return;
		}
		String titulo = request.getParameter("titulo") != null?request.getParameter("titulo"):"";
		String autor = request.getParameter("autor") != null?request.getParameter("autor"):"";
		int numPaginas = request.getParameter("paginas") != null?Integer.parseInt(request.getParameter("paginas")):0;
		
		FactoriaDAOs fd = FactoriaDAOs.getInstance();
		ILibroDAO il = fd.getLibroDAO();
		LibroTO libro = new LibroTO(request.getParameter("isbn"), titulo, autor, numPaginas);
		try
		{
			il.addLibro(libro);
			generaPagina("<h2>Operacion realizada</h2>", response);
			logger.info("Libros - insertar - " + request.getParameter("isbn") + " - Insercion realizada");
		} catch (Exception ex) {
			generaPagina("<h2>Error insertando libro</h2>", response);
			logger.error("Libros - insertar - " + request.getParameter("isbn") + " - Error en la insercion");
			return;
		}
	}
	
	/* Metodo privado para borrar un libro, dado su isbn en el request */
	private void borraLibro(HttpServletRequest request, HttpServletResponse response)
	{
		if (request.getParameter("isbn") == null)
		{
			generaPagina("<h2>Falta isbn</h2>", response);
			logger.error("Libros - borrar - Falta isbn");
			return;
		}
		FactoriaDAOs fd = FactoriaDAOs.getInstance();
		ILibroDAO il = fd.getLibroDAO();
		LibroTO libro = null;
		try
		{
			libro = il.selectLibro(request.getParameter("isbn"));
		} catch (Exception ex) {
			logger.error("Libros - borrar - " + request.getParameter("isbn") + " - Error obteniendo libro");
			generaPagina("<h2>Error obteniendo libro</h2>", response);
			return;
		}
		if (libro == null)
		{
			logger.error("Libros - borrar - " + request.getParameter("isbn") + " - Error obteniendo libro");
			generaPagina("<h2>Error obteniendo libro</h2>", response);
			return;
		} else {
			try
			{
				il.delLibro(libro);
				logger.info("Libros - borrar - " + request.getParameter("isbn") + " - Borrado realizado");
				generaPagina("<h2>Operacion realizada</h2>", response);
			} catch (Exception ex) {
				logger.error("Libros - borrar - " + request.getParameter("isbn") + " - Error borrando libro");
				generaPagina("<h2>Error borrando libro</h2>", response);
				return;
			}
		}
	}
	
	private void generaPagina(String mensaje, HttpServletResponse res)
	{
		try
		{
			PrintWriter writer = res.getWriter();
			writer.println("<html><body>"+mensaje+"</body></html>");
			writer.close();
		} catch (Exception ex) { 
			try
			{
				res.sendError(500, "Error generando la pagina"); 
			} catch (Exception ex2) {}
		}
	}
	
	private void doForward(HttpServletRequest request, HttpServletResponse response, String path) throws ServletException, IOException {
		ServletContext sc = this.getServletContext();
		RequestDispatcher rd = sc.getRequestDispatcher(path);
		rd.forward(request, response);
	}
	
	private boolean compruebaPermisos(HttpServletRequest request, TipoUsuario tipo) {
		HttpSession sesion = request.getSession();
		UsuarioTO usuario = (UsuarioTO)sesion.getAttribute("usuario");
		
		if(usuario==null) {
			return false;
		} else {
			return usuario.getTipo()==tipo;
		}
	}
 	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request, response);
	}   	  	    
}