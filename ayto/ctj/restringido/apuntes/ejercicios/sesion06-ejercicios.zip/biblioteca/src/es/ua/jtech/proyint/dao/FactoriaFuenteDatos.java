package es.ua.jtech.proyint.dao;

import java.sql.*;
import javax.naming.*;
import javax.sql.*;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class FactoriaFuenteDatos {

	private static FactoriaFuenteDatos me = new FactoriaFuenteDatos();
	private static Log logger = LogFactory.getLog(FactoriaFuenteDatos.class.getName());

	private FactoriaFuenteDatos() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException cnfe) {
			logger.fatal("No se encuentra el Driver de MySQL", cnfe);
		}
	}

	public static FactoriaFuenteDatos getInstance() {
		return me;
	}

	public Connection createConnection() {
		Connection conn = null;

		try {
			Context initCtx = new InitialContext();
			Context envCtx = (Context) initCtx.lookup("java:comp/env");
			DataSource ds = (DataSource)envCtx.lookup("jdbc/biblioteca");	
			conn = ds.getConnection();
		} catch (Exception e) {
			logger.fatal("No se ha podido crear la conexion", e);
		}
		
		return conn;
	}

}
