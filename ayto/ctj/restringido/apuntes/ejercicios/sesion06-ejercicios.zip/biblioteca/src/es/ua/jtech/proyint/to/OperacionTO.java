package es.ua.jtech.proyint.to;

import java.util.Date;

/**
 * Clase que representa una Operacion
 * 
 * @author $Author$
 * @version $Revision$
 */
public class OperacionTO extends TransferObject {

	private static final long serialVersionUID = -2530119910741277759L;

	private String idOperacion;
	private LibroTO libro;
	private UsuarioTO usuario;
	private TipoOperacion tipo;
	private Date fechaInicio;
	private Date fechaFin;

	public OperacionTO() {
		super();
	}

	public OperacionTO(String idOperacion, LibroTO libro, UsuarioTO usuario,
			TipoOperacion tipo, Date fechaInicio, Date fechaFin) {
		super();
		this.init(idOperacion, libro, usuario, tipo, fechaInicio, fechaFin);
	}

	public OperacionTO(OperacionTO operacion) {
		super();
		this.init(operacion.idOperacion, operacion.libro, operacion.usuario,
				operacion.tipo, operacion.fechaInicio, operacion.fechaFin);
	}

	private void init(String idOperacion, LibroTO libro, UsuarioTO usuario,
			TipoOperacion tipo, Date fechaInicio, Date fechaFin) {
		this.idOperacion = idOperacion;
		this.libro = libro;
		this.usuario = usuario;
		this.tipo = tipo;
		this.fechaInicio = fechaInicio;
		this.fechaFin = fechaFin;
	}

	@Override
	public OperacionTO getData() {
		return new OperacionTO(this);
	}

	public String getIdOperacion() {
		return idOperacion;
	}

	public void setIdOperacion(String idOperacion) {
		this.idOperacion = idOperacion;
	}

	public Date getFechaFin() {
		return fechaFin;
	}

	public void setFechaFin(Date fechaFin) {
		this.fechaFin = fechaFin;
	}

	public Date getFechaInicio() {
		return fechaInicio;
	}

	public void setFechaInicio(Date fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	public LibroTO getLibro() {
		return libro;
	}

	public void setLibro(LibroTO libro) {
		this.libro = libro;
	}

	public TipoOperacion getTipo() {
		return tipo;
	}

	public void setTipo(TipoOperacion tipo) {
		this.tipo = tipo;
	}

	public UsuarioTO getUsuario() {
		return usuario;
	}

	public void setUsuario(UsuarioTO usuario) {
		this.usuario = usuario;
	}

}
