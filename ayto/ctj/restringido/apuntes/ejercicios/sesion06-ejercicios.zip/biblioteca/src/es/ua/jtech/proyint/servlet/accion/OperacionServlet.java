package es.ua.jtech.proyint.servlet.accion;

import java.io.*;
import java.text.DateFormat;

import javax.servlet.*;
import javax.servlet.http.*;

import org.apache.commons.logging.*;

import es.ua.jtech.proyint.dao.*;
import es.ua.jtech.proyint.dao.usuario.*;
import es.ua.jtech.proyint.dao.libro.*;
import es.ua.jtech.proyint.dao.operacion.*;
import es.ua.jtech.proyint.to.*;

 public class OperacionServlet extends javax.servlet.http.HttpServlet implements javax.servlet.Servlet {

	private static final long serialVersionUID = 6158132279964132111L;
	private static Log logger = LogFactory.getLog(OperacionServlet.class.getName());

	public OperacionServlet() {
		super();
	}   	
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String parAccion = request.getParameter("accion");
		
		if ("reservar".equals(parAccion)) {
			
			// Reserva de un libro por un usuario
			if(!compruebaPermisos(request, TipoUsuario.profesor) && !compruebaPermisos(request, TipoUsuario.socio) && !compruebaPermisos(request, TipoUsuario.bibliotecario)) {
				request.setAttribute("error", "Se necesita ser profesor o socio para realizar una reserva");
				doForward(request, response, "/jsp/error.jsp");
			} else { 
				reserva(request, response);			
			}

		} else {
			generaPagina("<h2>Comando no valido</h2>", response);
		}
	}  	
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request, response);
	}

	/* Metodo privado para reservar un libro por un usuario */
	private void reserva(HttpServletRequest request, HttpServletResponse response)
	{
		if (request.getParameter("login") == null || request.getParameter("password") == null || request.getParameter("isbn") == null)
		{
			generaPagina("<h2>Falta login y/o password y/o isbn</h2>", response);
			logger.error("Operaciones - reservar - Falta login y/o password y/o isbn");
			return;
		}
		
		java.util.Date fechaIni, fechaFin;
		DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT);
		
		try
		{
			fechaIni = df.parse(request.getParameter("fechaini"));
			fechaFin = df.parse(request.getParameter("fechafin"));
		} catch (Exception ex) {
			logger.error("Operaciones - reservar -  Error convirtiendo las fechas");
			generaPagina("<h2>Error convirtiendo las fechas</h2>", response);
			return;			
		}
		
		FactoriaDAOs fd = FactoriaDAOs.getInstance();
		IUsuarioDAO iu = fd.getUsuarioDAO();
		ILibroDAO il = fd.getLibroDAO();
		IOperacionDAO io = fd.getOperacionDAO();
		UsuarioTO usu = null;
		LibroTO libro = null;
		
		try
		{
			usu = iu.selectUsuario(request.getParameter("login"), request.getParameter("password"));
			libro = il.selectLibro(request.getParameter("isbn"));
		} catch (Exception ex) {
			logger.error("Operaciones - reservar - " + request.getParameter("login") + " - Error obteniendo usuario y/o libro");
			generaPagina("<h2>Error obteniendo usuario y/o libro</h2>", response);
			return;
		}
		if (usu == null)
		{
			logger.error("Operaciones - reservar - " + request.getParameter("login") + " - Error obteniendo usuario");
			generaPagina("<h2>Error obteniendo usuario</h2>", response);
			return;
		} else if (libro == null) {
			logger.error("Operaciones - reservar - " + request.getParameter("isbn") + " - Error obteniendo libro");
			generaPagina("<h2>Error obteniendo libro</h2>", response);
			return;
		} else {
			try
			{
				io.realizaReserva(usu, libro, fechaIni, fechaFin);
				logger.info("Operaciones - reservar - " + request.getParameter("login") + " - " + request.getParameter("isbn") +  " - Borrado realizado");
				generaPagina("<h2>Operacion realizada</h2>", response);
			} catch (Exception ex) {
				logger.error("Operaciones - reservar - " + request.getParameter("login") + " - " + request.getParameter("isbn") +  " - Error realizando reserva");
				generaPagina("<h2>Error realizando reserva</h2>", response);
				return;
			}
		}
	}
	
	private void doForward(HttpServletRequest request, HttpServletResponse response, String path) throws ServletException, IOException {
		ServletContext sc = this.getServletContext();
		RequestDispatcher rd = sc.getRequestDispatcher(path);
		rd.forward(request, response);
	}
	
	private boolean compruebaPermisos(HttpServletRequest request, TipoUsuario tipo) {
		HttpSession sesion = request.getSession();
		UsuarioTO usuario = (UsuarioTO)sesion.getAttribute("usuario");
		
		if(usuario==null) {
			return false;
		} else {
			return usuario.getTipo()==tipo;
		}
	}

	private void generaPagina(String mensaje, HttpServletResponse res)
	{
		try
		{
			PrintWriter writer = res.getWriter();
			writer.println("<html><body>"+mensaje+"</body></html>");
			writer.close();
		} catch (Exception ex) { 
			try
			{
				res.sendError(500, "Error generando la pagina"); 
			} catch (Exception ex2) {}
		}
	}	
}