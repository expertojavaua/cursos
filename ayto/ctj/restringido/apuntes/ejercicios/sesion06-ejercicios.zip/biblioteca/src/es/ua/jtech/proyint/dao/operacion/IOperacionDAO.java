package es.ua.jtech.proyint.dao.operacion;

import java.util.Date;

import es.ua.jtech.proyint.dao.DAOException;
import es.ua.jtech.proyint.to.LibroTO;
import es.ua.jtech.proyint.to.UsuarioTO;

/**
 * Interface para el DAO Operacion
 * @author Miguel
 */
public interface IOperacionDAO {

	/**
	 * Realiza la reserva de un libro por un usuario
	 * @param usuario Usuario que realiza la reserva
	 * @param libro Libro a reservar
	 * @param finicio Fecha de inicio de la reserva 
	 * @param ffin Fecha de finalizaci�n de la reserva
	 * @return Devuelve si ha sido posible realizar la reservas
	 * @throws DAOException
	 */
	public boolean realizaReserva(UsuarioTO usuario, LibroTO libro,
			Date finicio, Date ffin) throws DAOException;

}