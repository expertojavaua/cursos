package es.ua.jtech.proyint.dao;

public class DAOException extends Exception {

	private static final long serialVersionUID = 6158132279964132104L;

	public DAOException() {
		super();
	}

	public DAOException(String message) {
		super(message);
	}

	public DAOException(String message, Throwable cause) {
		super(message, cause);
	}
}
