-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.27-community-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;



--
-- Dumping data for table `libro`
--

/*!40000 ALTER TABLE `libro` DISABLE KEYS */;
INSERT INTO `libro` (`isbn`,`titulo`,`autor`,`numPaginas`) VALUES 
  ('0131401572','Data Access Patterns','Clifton Nock.',512);
INSERT INTO `libro` (`isbn`,`titulo`,`autor`,`numPaginas`) VALUES 
  ('0321180860','Understanding SOA with Web Services','Eric Newcomer and Greg Lomow',NULL);
INSERT INTO `libro` (`isbn`,`titulo`,`autor`,`numPaginas`) VALUES 
  ('0471768944','Service-Oriented Architecture (SOA): ','Eric A. Marks and Michael Bell',NULL);
INSERT INTO `libro` (`isbn`,`titulo`,`autor`,`numPaginas`) VALUES 
  ('0764558315','EXPERT ONE-ON-ONE J2EE DEVELOPMENT WITHOUT EJB','Johnson, Rod',576);
INSERT INTO `libro` (`isbn`,`titulo`,`autor`,`numPaginas`) VALUES 
  ('097451408X','Practices of an Agile Developer','Venkat Subramaniam and Andy Hunt',208);
INSERT INTO `libro` (`isbn`,`titulo`,`autor`,`numPaginas`) VALUES 
  ('0977616649','Agile Retrospectives','Esther Derby and Diana Larsen',200);
/*!40000 ALTER TABLE `libro` ENABLE KEYS */;



--
-- Dumping data for table `usuario`
--

/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` (`login`,`password`,`nombre`,`apellido1`,`apellido2`,`tipoUsuario`,`estadoUsuario`) VALUES 
  ('antonio','martinez','Antonio','Martinez','González','socio','prestamo');
INSERT INTO `usuario` (`login`,`password`,`nombre`,`apellido1`,`apellido2`,`tipoUsuario`,`estadoUsuario`) VALUES 
  ('isabel','fernandez','Isabel','Fernández','Gómez','socio','reserva');
INSERT INTO `usuario` (`login`,`password`,`nombre`,`apellido1`,`apellido2`,`tipoUsuario`,`estadoUsuario`) VALUES 
  ('juan','antonio','Juan','Antonio','Pérez','socio','activo');
INSERT INTO `usuario` (`login`,`password`,`nombre`,`apellido1`,`apellido2`,`tipoUsuario`,`estadoUsuario`) VALUES 
  ('miguel','cazorla','Miguel','Cazorla','Quevedo','administrador','activo');
INSERT INTO `usuario` (`login`,`password`,`nombre`,`apellido1`,`apellido2`,`tipoUsuario`,`estadoUsuario`) VALUES 
  ('otto','colomina','Otto','Colomina','Pardo','profesor','activo');
INSERT INTO `usuario` (`login`,`password`,`nombre`,`apellido1`,`apellido2`,`tipoUsuario`,`estadoUsuario`) VALUES 
  ('patricia','dominguez','Patricia','Domínguez','Martínez','socio','prestamo');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;


--
-- Dumping data for table `operacion`
--

/*!40000 ALTER TABLE `operacion` DISABLE KEYS */;
INSERT INTO `operacion` (`idoperacion`,`login`,`isbn`,`tipoOperacion`,`finicio`,`ffin`) VALUES 
  (1,'patricia','0131401572','prestamo','2006-11-23','2006-11-27');
INSERT INTO `operacion` (`idoperacion`,`login`,`isbn`,`tipoOperacion`,`finicio`,`ffin`) VALUES 
  (2,'isabel','0131401572','reserva','2006-11-25','2006-11-28');
INSERT INTO `operacion` (`idoperacion`,`login`,`isbn`,`tipoOperacion`,`finicio`,`ffin`) VALUES 
  (3,'antonio','0764558315','prestamo','2006-11-10','2006-11-30');
INSERT INTO `operacion` (`idoperacion`,`login`,`isbn`,`tipoOperacion`,`finicio`,`ffin`) VALUES 
  (4,'juan','0471768944','multa','2006-11-01','2006-12-01');
/*!40000 ALTER TABLE `operacion` ENABLE KEYS */;



/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
