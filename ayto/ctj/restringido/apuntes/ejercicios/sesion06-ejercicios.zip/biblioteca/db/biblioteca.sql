-- ----------------------------------------------------------------------
-- MySQL GRT Application
-- SQL Script
-- ----------------------------------------------------------------------

SET FOREIGN_KEY_CHECKS = 0;

CREATE DATABASE IF NOT EXISTS `biblioteca`
  CHARACTER SET latin1;
-- -------------------------------------
-- Tables

DROP TABLE IF EXISTS `biblioteca`.`libro`;
CREATE TABLE `biblioteca`.`libro` (
  `isbn` VARCHAR(32) NOT NULL DEFAULT '',
  `titulo` VARCHAR(64) NULL,
  `autor` VARCHAR(64) NULL,
  `numPaginas` INT(11) NULL,
  PRIMARY KEY (`isbn`)
)
ENGINE = InnoDB
ROW_FORMAT = Compact
CHARACTER SET latin1 COLLATE latin1_spanish_ci;

DROP TABLE IF EXISTS `biblioteca`.`operacion`;
CREATE TABLE `biblioteca`.`operacion` (
  `idoperacion` INT(11) NOT NULL AUTO_INCREMENT,
  `login` VARCHAR(32) NOT NULL,
  `isbn` VARCHAR(32) NOT NULL,
  `tipoOperacion` ENUM('reserva','prestamo','multa') NULL,
  `finicio` DATE NULL,
  `ffin` DATE NULL,
  PRIMARY KEY (`idoperacion`),
  INDEX `login` (`login`),
  INDEX `isbn` (`isbn`),
  CONSTRAINT `fk_operacion_usuario` FOREIGN KEY `fk_operacion_usuario` (`login`)
    REFERENCES `biblioteca`.`usuario` (`login`)
    ON DELETE CASCADE
    ON UPDATE CASCADE,
  CONSTRAINT `fk_operacion_libro` FOREIGN KEY `fk_operacion_libro` (`isbn`)
    REFERENCES `biblioteca`.`libro` (`isbn`)
    ON DELETE CASCADE
    ON UPDATE CASCADE
)
ENGINE = InnoDB
ROW_FORMAT = Compact
CHARACTER SET latin1 COLLATE latin1_spanish_ci;

DROP TABLE IF EXISTS `biblioteca`.`usuario`;
CREATE TABLE `biblioteca`.`usuario` (
  `login` VARCHAR(32) NOT NULL DEFAULT '',
  `password` VARCHAR(32) NULL,
  `nombre` VARCHAR(64) NULL,
  `apellido1` VARCHAR(64) NULL,
  `apellido2` VARCHAR(64) NULL,
  `tipoUsuario` ENUM('socio','profesor','bibliotecario','administrador') NULL,
  `estadoUsuario` ENUM('baja','activo','reserva','prestamo','moroso') NULL,
  PRIMARY KEY (`login`)
)
ENGINE = InnoDB
ROW_FORMAT = Compact
CHARACTER SET latin1 COLLATE latin1_spanish_ci;


SET FOREIGN_KEY_CHECKS = 1;

-- ----------------------------------------------------------------------
-- EOF

