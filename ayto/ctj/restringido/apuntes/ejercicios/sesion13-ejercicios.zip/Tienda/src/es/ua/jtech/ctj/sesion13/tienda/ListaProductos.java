package es.ua.jtech.ctj.sesion13.tienda;

import java.io.*;
import java.util.*;
import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;
import javax.microedition.io.*;

public class ListaProductos extends List implements CommandListener {

	private final static String URL_LISTA = "http://www.jtech.ua.es/ejemplos-j2me/servlet/ListaProductos";

	MIDlet owner;

	Vector productos;

	public ListaProductos(MIDlet owner) throws IOException {
		super("Productos", List.IMPLICIT );
		
		this.owner = owner;
		
		// Crea lista
		productos = leeProductos();
		for(int i=0;i<productos.size();i++) {
			Producto prod = (Producto)productos.elementAt(i);
			this.append(prod.titulo, null);
		}

		this.setCommandListener(this);
	}	
	
	private Vector leeProductos() throws IOException {
		Vector lista = new Vector();
		
		// TODO: Establecer una conexion con el servidor y leer la lista de productos de el

		return lista;
	}
	
	public void commandAction(Command cmd, Displayable disp) {
		
		if(cmd == List.SELECT_COMMAND) {

			// Seleccion de un elemento de la lista
			int indice = this.getSelectedIndex();
			DatosProducto dp = new DatosProducto(owner, this, (Producto)productos.elementAt(indice));
			
			Display d = Display.getDisplay(owner);
			d.setCurrent(dp);
		}		
	}
}
