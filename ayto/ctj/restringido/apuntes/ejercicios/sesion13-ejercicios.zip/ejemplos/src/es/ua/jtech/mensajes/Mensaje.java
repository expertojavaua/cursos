/*
 * Created on 13-sep-2003
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package es.ua.jtech.mensajes;

import java.io.*;

/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class Mensaje {
	long ts;
	String asunto;
	String texto;
	
	public Mensaje() {
	}
	
	public String getAsunto() {
		return asunto;
	}
	public void setAsunto(String asunto) {
		this.asunto = asunto;
	}
	public String getTexto() {
		return texto;
	}
	public void setTexto(String texto) {
		this.texto = texto;
	}
	public long getTs() {
		return ts;
	}
	public void setTs(long ts) {
		this.ts = ts;
	}

	public void serialize(DataOutputStream dos) throws IOException {
		dos.writeUTF(asunto);
		dos.writeUTF(texto);
	}
	
	public static Mensaje deserialize(DataInputStream dis) throws IOException {
		Mensaje msg = new Mensaje();
		
		msg.asunto = dis.readUTF();
		msg.texto = dis.readUTF();
		
		return msg;
	}

}
