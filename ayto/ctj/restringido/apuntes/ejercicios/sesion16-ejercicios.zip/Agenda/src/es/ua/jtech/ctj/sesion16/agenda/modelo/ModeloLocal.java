package es.ua.jtech.ctj.sesion16.agenda.modelo;

import java.io.IOException;
import java.util.Date;

import javax.microedition.rms.RecordStoreException;

public class ModeloLocal {

	AdaptadorRMS rms;
	
	GestorAlarmas alarmas;

	public ModeloLocal(GestorAlarmas alarmas) throws RecordStoreException {
		rms = new AdaptadorRMS();
		
		this.alarmas = alarmas;
	}

	/*
	 * Agrega una cita indicando si esta pendiente de ser enviada al servidor
	 */
	public void addCita(Cita cita, boolean pendiente) throws IOException,
			RecordStoreException {
		int id = rms.addCita(cita);
		IndiceCita indice = new IndiceCita();
		indice.setId(id);
		indice.setFecha(cita.getFecha());
		indice.setAlarma(cita.isAlarma());
		indice.setPendiente(pendiente);
		rms.addIndice(indice);

		// Programa una alarma para la cita
		alarmas.programaAlarma(cita);
	}

	/*
	 * Obtiene todas las citas
	 */
	public Cita[] listaCitas() throws RecordStoreException, IOException {
		return rms.listaCitas();
	}

	/*
	 * Obtiene las citas correspondientes a los indices indicados
	 */
	public Cita[] listaCitas(IndiceCita[] indices) throws RecordStoreException,
			IOException {
		Cita[] citas = new Cita[indices.length];
		for (int i = 0; i < indices.length; i++) {
			citas[i] = rms.getCita(indices[i].getId());
		}

		return citas;
	}

	/*
	 * Busca las citas con alarmas pendientes
	 */
	public IndiceCita[] listaAlarmasPendientes() throws RecordStoreException,
			IOException {
		IndiceCita[] indices = rms.buscaCitas(new Date(), true);

		return indices;
	}

	/*
	 * Busca las citas pendientes de ser enviadas al servidor
	 */
	public IndiceCita[] listaCitasPendientes() throws RecordStoreException,
			IOException {
		IndiceCita[] indices = rms.listaCitasPendientes();

		return indices;
	}

	/*
	 * Marca las citas indicada como enviadas al servidor
	 */
	public void marcaEnviados(IndiceCita[] indices) throws IOException,
			RecordStoreException {
		for (int i = 0; i < indices.length; i++) {
			indices[i].setPendiente(false);
			rms.updateIndice(indices[i]);
		}
	}

	/*
	 * Obtiene la configuracion local
	 */
	public InfoLocal getInfoLocal() throws RecordStoreException, IOException {

		try {
			InfoLocal info = rms.getInfoLocal();
			return info;
		} catch (Exception e) {
		}

		InfoLocal info = new InfoLocal();
		rms.setInfoLocal(info);

		return info;
	}

	/*
	 * Modifica la configuracion local
	 */
	public void setInfoLocal(InfoLocal info) throws RecordStoreException,
			IOException {
		rms.setInfoLocal(info);
	}

	/*
	 * Libera recursos del modelo
	 */
	public void destroy() throws RecordStoreException {
		rms.cerrar();
	}
}