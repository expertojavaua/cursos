package es.ua.jtech.ctj.sesion16.mensajes.vista;

import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;
import javax.microedition.lcdui.TextField;

import es.ua.jtech.ctj.sesion16.mensajes.modelo.Mensaje;
import es.ua.jtech.ctj.sesion16.mensajes.modelo.Recursos;

public class EditaMensajeUI extends Form implements CommandListener {

	public final static int MAX_LENGHT = 255;

	ControladorUI controlador;

	Mensaje mensaje;
	
	TextField iAsunto;
	TextField iTexto;

	Command cmdAceptar;
	Command cmdCancelar;
	int eventoAceptar = ControladorUI.EVENTO_AGREGA_MENSAJE;
	int eventoCancelar = ControladorUI.EVENTO_MUESTRA_MENU;

	boolean crearNueva;

	public EditaMensajeUI(ControladorUI controlador) {
		super(controlador.getString(Recursos.STR_DATOS_TITULO));

		this.controlador = controlador;

		iAsunto = new TextField(controlador
				.getString(Recursos.STR_DATOS_ITEM_ASUNTO), "", MAX_LENGHT,
				TextField.ANY);
		iTexto = new TextField(controlador
				.getString(Recursos.STR_DATOS_ITEM_TEXTO), "", MAX_LENGHT,
				TextField.ANY);

		this.append(iAsunto);
		this.append(iTexto);

		cmdAceptar = new Command(controlador
				.getString(Recursos.STR_CMD_ACEPTAR), Command.OK, 1);
		cmdCancelar = new Command(controlador
				.getString(Recursos.STR_CMD_CANCELAR), Command.CANCEL, 1);
		this.addCommand(cmdAceptar);
		this.addCommand(cmdCancelar);

		this.setCommandListener(this);
	}

	private void setMensaje(Mensaje mensaje) {
		if (mensaje == null) {
			this.mensaje = new Mensaje();			
			iAsunto.setString(null);
			iTexto.setString(null);
		} else {
			this.mensaje = mensaje;
			iAsunto.setString(mensaje.getAsunto());
			iTexto.setString(mensaje.getTexto());
		}
	}

	private Mensaje getMensaje() {
		if(mensaje==null) {
			mensaje = new Mensaje();
		}

		mensaje.setAsunto(iAsunto.getString());
		mensaje.setTexto(iTexto.getString());

		return mensaje;
	}

	public void reset(Mensaje mensaje, int eventoAceptar, int eventoCancelar) {
		this.setMensaje(mensaje);
		this.eventoAceptar = eventoAceptar;
		this.eventoCancelar = eventoCancelar;
	}

	public void commandAction(Command cmd, Displayable disp) {
		if (cmd == cmdAceptar) {
			controlador.procesaEvento(eventoAceptar, this.getMensaje());
		} else if (cmd == cmdCancelar) {
			controlador.procesaEvento(eventoCancelar, null);
		}
	}

}