package es.ua.jtech.ctj.sesion16.mensajes.vista;

import javax.microedition.lcdui.ChoiceGroup;
import javax.microedition.lcdui.Command;
import javax.microedition.lcdui.CommandListener;
import javax.microedition.lcdui.Displayable;
import javax.microedition.lcdui.Form;

import es.ua.jtech.ctj.sesion16.mensajes.modelo.InfoLocal;
import es.ua.jtech.ctj.sesion16.mensajes.modelo.Recursos;

public class EditaConfigUI extends Form implements CommandListener {

	ControladorUI controlador;

	ChoiceGroup iModo;
	int itemModoOnline;
	int itemModoOffline;

	Command cmdAceptar;
	Command cmdCancelar;
	int eventoAceptar = ControladorUI.EVENTO_APLICA_CONFIG;
	int eventoCancelar = ControladorUI.EVENTO_MUESTRA_MENU;

	InfoLocal info;
	
	public EditaConfigUI(ControladorUI controlador) {
		super(controlador.getString(Recursos.STR_CONFIG_TITULO));

		this.controlador = controlador;

		iModo = new ChoiceGroup(controlador
				.getString(Recursos.STR_CONFIG_ITEM_MODO),
				ChoiceGroup.EXCLUSIVE);
		itemModoOnline = iModo.append(controlador
				.getString(Recursos.STR_CONFIG_ITEM_MODO_ONLINE), null);
		itemModoOffline = iModo.append(controlador
				.getString(Recursos.STR_CONFIG_ITEM_MODO_OFFLINE), null);
		
		this.append(iModo);

		cmdAceptar = new Command(controlador
				.getString(Recursos.STR_CMD_ACEPTAR), Command.OK, 1);
		cmdCancelar = new Command(controlador
				.getString(Recursos.STR_CMD_CANCELAR), Command.CANCEL, 1);
		this.addCommand(cmdAceptar);
		this.addCommand(cmdCancelar);

		this.setCommandListener(this);
	}

	private void setInfoLocal(InfoLocal info) {
		this.info = info;
		
		if (info.isOnline()) {
			iModo.setSelectedIndex(itemModoOnline, true);
		} else {
			iModo.setSelectedIndex(itemModoOffline, true);
		}
	}

	private InfoLocal getInfoLocal() {
		if(info==null) {
			info = new InfoLocal();
		}
		
		info.setOnline(iModo.getSelectedIndex() == itemModoOnline);

		return info;
	}

	public void reset(InfoLocal info, int eventoAceptar, int eventoCancelar) {
		this.setInfoLocal(info);
		this.eventoAceptar = eventoAceptar;
		this.eventoCancelar = eventoCancelar;
	}

	public void commandAction(Command cmd, Displayable disp) {
		if (cmd == cmdAceptar) {
			controlador.procesaEvento(eventoAceptar, this.getInfoLocal());
		} else if (cmd == cmdCancelar) {
			controlador.procesaEvento(eventoCancelar, null);
		}
	}

}