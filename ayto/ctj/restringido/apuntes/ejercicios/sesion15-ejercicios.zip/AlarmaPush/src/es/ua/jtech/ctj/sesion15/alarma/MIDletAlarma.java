package es.ua.jtech.ctj.sesion15.alarma;

import javax.microedition.midlet.MIDlet;
import javax.microedition.midlet.MIDletStateChangeException;
import javax.microedition.lcdui.*;

public class MIDletAlarma extends MIDlet {

	protected void startApp() throws MIDletStateChangeException {
		Display d = Display.getDisplay(this);
		FormularioAlarma f = new FormularioAlarma(this);
		d.setCurrent(f);
	}

	protected void pauseApp() {
	}

	protected void destroyApp(boolean arg0) throws MIDletStateChangeException {
	}

}
