package beans;

public class CronoBean
{
	private long creacion = 0;
	private int segundos = 0;
	
	public CronoBean()
	{
		creacion = System.currentTimeMillis();
	}
	
	public int getSegundos()
	{
		return (int)((System.currentTimeMillis() - creacion) / 1000);
	}
	
	public void setSegundos(int s)
	{
		segundos = s;
	}
}