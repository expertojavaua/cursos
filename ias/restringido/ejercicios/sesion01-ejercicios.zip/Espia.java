import java.io.*;
import java.net.*;

public class Espia {
	
	private static void instrucciones() {
		System.out.println("Uso: java Espia <puerto>");
	}
	
	public static void main(String[] args) {
		if (args.length < 1) {
			instrucciones();
			return;
		}

		int puerto;
		try {
			puerto = Integer.parseInt(args[0]);
		} catch (NumberFormatException e) {
			instrucciones();
			return;
		}
		
		try {
			ServerSocket ss = new ServerSocket(puerto);
			while (true) {
				Socket socket = ss.accept();
				new HiloServidor(socket).start();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

class HiloServidor extends Thread {

	Socket socket;

	public HiloServidor(Socket socket) {
		this.socket = socket;
	}

	public void run() {
		int c;
		String s;
		try {
			BufferedReader r =
				new BufferedReader(new InputStreamReader(System.in));
			InputStream in = socket.getInputStream();

			while ( (c = in.read()) != -1) {
				if (c != '\n') {
					if (c != '\r')
						System.out.print((char)c);
				} else {
					System.out.print(" [+]");
					s = r.readLine();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}