package es.ua.j2ee.context;

import javax.servlet.*;

public class ListenerAtributos implements ServletContextAttributeListener {

	public void attributeAdded(ServletContextAttributeEvent scab) {
		ServletContext sc = scab.getServletContext();

		sc.log("Atributo [" + scab.getName() + "] agregado");
	}

	public void attributeRemoved(ServletContextAttributeEvent scab) {
		ServletContext sc = scab.getServletContext();

		sc.log("Atributo [" + scab.getName() + "] eliminado");
	}

	public void attributeReplaced(ServletContextAttributeEvent scab) {
		ServletContext sc = scab.getServletContext();

		sc.log("Atributo [" + scab.getName() + "] remplazado");
	}

}
