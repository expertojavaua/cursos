import java.util.List;

import javax.xml.namespace.QName;
import javax.xml.rpc.Stub;
import javax.xml.rpc.handler.HandlerInfo;
import javax.xml.rpc.handler.HandlerRegistry;

import amazon.AmazonSearchPort;
import amazon.AmazonSearchService_Impl;
import amazon.Details;
import amazon.DirectorRequest;
import amazon.ProductInfo;

/*
 * Created on 19/04/2004
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */

/**
 * @author Miguel Angel
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class Cliente {
	public static void main(String[] args) {
		try {
			if(args.length!=1) {
				System.out.println("Uso: ant run -Ddirector=<nombre_director>");
				System.exit(-1);
			}

			AmazonSearchPort amazon = creaProxy();

			DirectorRequest dr = new DirectorRequest();
			dr.setDirector(args[0]);
			dr.setDevtag("D3JV7SSUMSD7I5");
			dr.setType("lite");
			dr.setMode("dvd");
			dr.setPage("1");
			ProductInfo pi = amazon.directorSearchRequest(dr);

			Details [] det = pi.getDetails();
			System.out.println("Lista de DVDs");
			System.out.println("=============");
			for(int i=0;i<det.length;i++) {
				System.out.println(det[i].getProductName() + "\t" + det[i].getOurPrice());
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}    

	private static AmazonSearchPort creaProxy() {
		AmazonSearchService_Impl as = new AmazonSearchService_Impl();

		if(System.getProperty("soap.debug","false").equals("true")) {
			HandlerRegistry hr = as.getHandlerRegistry();
			List chain = hr.getHandlerChain(new QName("http://soap.amazon.com", "AmazonSearchPort"));
			HandlerInfo hi = new HandlerInfo(HandlerEspia.class,null,null);
			chain.add(hi);
		}

		Stub stub = (Stub)(as.getAmazonSearchPort());
		return (AmazonSearchPort)stub;
	}
}
