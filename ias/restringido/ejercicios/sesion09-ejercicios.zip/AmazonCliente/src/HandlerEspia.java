
import java.io.*;
import javax.xml.soap.*;
import javax.xml.rpc.handler.*;
import javax.xml.rpc.handler.soap.*;
import javax.xml.namespace.QName;

public class HandlerEspia extends GenericHandler
{
	public HandlerEspia() { }

	public QName [] getHeaders() {
		return null;
	}

	public boolean handleRequest(MessageContext context) {
		System.out.println("PETICION:");

		try {
			SOAPMessageContext smc = (SOAPMessageContext)context;
			SOAPMessage msg = smc.getMessage();

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			msg.writeTo(baos);
			System.out.println(baos.toString());
		}
		catch(Exception ex) {
		}

		return true;
	}

	public boolean handleResponse(MessageContext context) {
		System.out.println("RESPUESTA:");

		try {
			SOAPMessageContext smc = (SOAPMessageContext)context;
			SOAPMessage msg = smc.getMessage();

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			msg.writeTo(baos);
			System.out.println(baos.toString());
		}
		catch(Exception ex) {
		}

		return true;
	}

}