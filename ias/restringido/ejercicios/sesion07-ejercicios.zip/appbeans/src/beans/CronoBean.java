package beans;

public class CronoBean
{
}