import es.ua.j2ee.sw.exchange.*;
   
public class Cliente {
  public static void main(String[] args) {

    if(args.length < 2) {
      System.out.println(
        "Uso: ant run -Dorigen=<pais_origen> -Ddestino=<pais_destino>");
      System.exit(-1);
    }
   
    try {
      CurrencyExchangePortType serv = creaProxy();

      float divisa = serv.getRate(args[0], args[1]);
      System.out.println("Cambio de " + args[0] + " a " + 
                          args[1] + " = " + divisa);
   
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
   
  private static CurrencyExchangePortType creaProxy() {
    return (CurrencyExchangePortType)(new 
       CurrencyExchangeService_Impl().getCurrencyExchangePort());
  }
}