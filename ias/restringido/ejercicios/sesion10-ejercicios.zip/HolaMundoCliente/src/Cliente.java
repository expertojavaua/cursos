import es.ua.j2ee.sw.hola.*;

public class Cliente {

	public static void main(String[] args) {
		if (args.length != 1) {
			System.err.println("Uso: ant run -Dnombre=<nombre>");
			System.exit(-1);
		}

		try {
			HolaMundoIF hola = creaProxy();
			System.out.println(hola.saluda(args[0]));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static HolaMundoIF creaProxy() {
		return (HolaMundoIF) (new HolaMundo_Impl().getHolaMundoIFPort());
	}
}