import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class ServletProtegido extends HttpServlet
{
	public ServletProtegido()
	{
	}
	
	public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		res.setContentType("text/plain");
		PrintWriter out = res.getWriter();
		out.println ("Hola, esto es un servlet. Si has llegado deber�as haberte autentificado bien");
	}

	public void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		doGet(req, res);
	}
}